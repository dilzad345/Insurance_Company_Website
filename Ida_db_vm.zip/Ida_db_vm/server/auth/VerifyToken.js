const jwt = require("jsonwebtoken");
const secret =require("../config/token.config");
const verifyToken = async (token) => {
    // console.log(token);
    if (!token) {
      return false;
    } else {
      return jwt.verify(token, secret.secretkey, (err, decoded) => {
        if (err) {
          return false;
        } else {
          return true;
        }
      });
    }
  };

module.exports = verifyToken;