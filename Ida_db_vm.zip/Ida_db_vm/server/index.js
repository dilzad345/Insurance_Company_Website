const express = require("express");
const app = express();
const mysql = require("mysql");
const bodyParser = require("body-parser");
const cors = require("cors");
// const bcrypt = require("bcrypt");
// const saltRounds = 10;
// const jwt = require("jsonwebtoken");
// const verifyToken = require("./auth/VerifyToken");
// const path = require('path');

const userRouter = require("./routes/userRouter");
const quotationRouter = require("./routes/quotationRouter");
const automationRoute = require("./routes/automationRoute");
const quotationHomeRoute=require("./routes/quotationHomeRoute");
const quotationLandlordsRoute = require("./routes/quotationLandlordsRoute");
//const { jwtSecret } = require('config');

// const PORT = 80;
// const PORT = 3001;
const PORT = 3001;
const db = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "root",
  port: 3306,
  database: "ida_db_vm",
});

app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
// front end attchment

// app.use(express.static(path.join(__dirname, 'build')));


//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

app.use("/user", userRouter); //http://localhost:3001/user/........ (broker)
app.use("/quotation", quotationRouter); //http://localhost:3001/quotation/........ (quotation)
app.use("/automation",automationRoute);
app.use("/quotationHome",quotationHomeRoute );//
app.use("/quotationLandlords",quotationLandlordsRoute);


app.listen(PORT, () => {
  console.log("listing on port id: ", PORT );
});
