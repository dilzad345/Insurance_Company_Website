const express = require("express");
const app = express();
const mysql = require("mysql");
const bodyParser = require("body-parser");
const cors = require("cors");
const bcrypt = require("bcrypt");
const saltRounds = 10;
const jwt = require("jsonwebtoken");
const catchAsync = require("../utils/catchAsync");
const { response } = require("express");
const verifyToken = require("../auth/VerifyToken");
const db = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "root",
  port: 3306,
  database: "ida_db_vm",
});

/* const verifyToken = async (token) => {
  //console.log(token);
  if (!token) {
    return false;
  } else {
    return jwt.verify(token, "jwtSecret_IDA", (err, decoded) => {
      if (err) {
        return false;
      } else {
        return true;
      }
    });
  }
}; */

let empty_str = ""; //created for checking values if having empty string

// login method with hashed password
exports.getQuotations = async (req, response, next) => {
  const token = req.headers.token;
  if (await verifyToken(token)) {
    // const user_email = req.query.userEmail;
    const query_getQuotations =
      "select * from quotation_details, client" +
      " where quotation_details.client_id_fk = client.client_id" +
      " and (quotation_details.quotation_status = 'Pending' or quotation_details.quotation_status = 'Verified' or quotation_details.quotation_status = 'submitted') ORDER BY quotation_details.client_id_fk DESC";
    // "select * from quotation_details, client" +
    // " where quotation_details.client_id_fk = client.client_id and client.user_email_fk = ?" +
    // " and (quotation_details.quotation_status = 'Pending' or quotation_details.quotation_status = 'Verified')";

    const pending_quotation =
      "SELECT COUNT(quotation_status) AS pendingCount FROM quotation_details, client" +
      " where quotation_details.quotation_status='Pending'" +
      " AND quotation_details.client_id_fk = client.client_id";

    // const pending_quotation = "SELECT COUNT(quotation_status) AS pendingCount FROM quotation_details, client" +
    // " where quotation_details.quotation_status='Pending'" +
    // " AND quotation_details.client_id_fk = client.client_id and client.user_email_fk = ?";

    const verified_quotation =
      "SELECT COUNT(quotation_status) AS verifiedCount FROM quotation_details, client" +
      " where quotation_details.quotation_status='Verified'" +
      " AND quotation_details.client_id_fk = client.client_id";

    const submitted_quotation =
      "SELECT COUNT(quotation_status) AS submittedCount FROM quotation_details, client" +
      " where quotation_details.quotation_status='Submitted'" +
      " AND quotation_details.client_id_fk = client.client_id";


    // const verified_quotation = "SELECT COUNT(quotation_status) AS verifiedCount FROM quotation_details, client" +
    // " where quotation_details.quotation_status='Verified'" +
    // " AND quotation_details.client_id_fk = client.client_id and client.user_email_fk = ?";

    // execute query on database and send the response
    //await db.query(query_getQuotations,[user_email], async(err, result) => {
    await db.query(query_getQuotations, [], async (err, result) => {
      if (err) {
        console.log(err.message);
      } else {
        // console.log(result);
        await db.query(
          verified_quotation,
          [],
          async (err, verifiedCountResult) => {
            if (err) {
              console.log(err.message);
            } else {
              //console.log(result);

              // console.log(verifiedCountResult);
              await db.query(pending_quotation, [], async (err, pendingCountResult) => {
                if (err) {
                  console.log(err.message);
                } else {
                  //console.log(result);
                  //console.log(pendingCountResult[0]);
                  await db.query(submitted_quotation, [], async (errSubmit, submitResult) => {
                    if (errSubmit) {
                      console.log("Error 4: ", errSubmit);
                    }
                    else {
                      const quotationDetail = {
                        verifiedQuotation: verifiedCountResult,
                        pendingQuotation: pendingCountResult,
                        submittedQuotation: submitResult,
                        getQuotation: result,
                      }
                      response.send(quotationDetail);
                    }
                  })
                  // const quotationDetail = {
                  //   verifiedQuotation: verifiedCountResult,
                  //   pendingQuotation: pendingCountResult,

                  //   getQuotation: result,
                  // };
                  // response.send(quotationDetail);
                  //console.log(quotationDetail[0]);
                }
              }
              );
              // response.send(dataQuotation);
            }
          }
        );
        //response.send(query_getQuotations);
      }
    });
  } else {
    response.send({ message: "You are not authenticated" });
  }
};

// get the quotation detail
exports.getQuotationDetail = catchAsync(async (req, response, next) => {
  if (await verifyToken(req.headers.token)) {
    const query_getQuotationDetail =
      "SELECT * FROM quotation_details WHERE quotation_id = ?";
    const query_getClientDetail = "SELECT * FROM client WHERE client_id = ?";
    const query_getAddressDetail = "SELECT * FROM address WHERE address_id = ?";
    const query_getContactDetail =
      "SELECT * FROM contact_details WHERE contact_id = ?";
    const query_getImportantQuestionDetail =
      "SELECT * FROM important_questions_motor WHERE important_question_motor_id = ?";
    const query_getPolicyCoreDetail =
      "SELECT * FROM policy_core_motor WHERE policy_core_motor_id = ?";
    const query_getVehicleDetail =
      "SELECT * FROM vehicle_information WHERE vehicle_info_id = ?";
    const query_getVehicleAddressDetail =
      "SELECT * FROM address WHERE address_id = ?";
    const query_getModificationDetails =
      "SELECT * FROM ns_accessories_modifications WHERE vehicle_id_fk = ?";
    const query_getQuotationDriverDetails =
      "SELECT * FROM quotation_driver_info WHERE quotation_id_fk = ?";
    const query_getDriverDetails =
      "SELECT * FROM driver_info WHERE driver_info_id =?";
    const query_getClaimDetails =
      "SELECT * FROM claim_details WHERE driver_info_id_fk = ?";
    await db.query(
      query_getQuotationDetail,
      [req.query.quotationId],
      async (errorQuote, resultQuote) => {
        if (errorQuote) {
          response.status(500).json({
            status: "failed",
          });
        } else {
          console.log(resultQuote);
          await db.query(
            query_getClientDetail,
            [resultQuote[0].client_id_fk],
            async (errorClient, resultClient) => {
              if (errorClient) {
                console.log(errorClient);
                response.status(500).json({
                  status: "failed",
                });
              } else {
                // console.log(resultClient[0]);
                const addressId = resultClient[0].address_id_fk;
                const contactId = resultClient[0].contact_id_fk;

                await db.query(
                  query_getAddressDetail,
                  [addressId],
                  async (errorAddress, resultAddress) => {
                    if (errorAddress) {
                      //console.log(errorAddress);
                    } else {
                      await db.query(
                        query_getContactDetail,
                        [contactId],
                        async (errorContact, resultContact) => {
                          if (errorContact) {
                            console.log(errorContact);
                          } else {
                            //console.log(resultContact);
                            const dataClient = {
                              client: resultClient[0],
                              address: resultAddress[0],
                              contact: resultContact[0],
                            };

                            await db.query(
                              query_getImportantQuestionDetail,
                              [resultQuote[0].important_question_id_fk],
                              async (errorImp, resultImp) => {
                                if (errorImp) {
                                  console.log(errorImp);
                                } else {
                                  const dataImportantQuestion = resultImp[0];

                                  await db.query(
                                    query_getPolicyCoreDetail,
                                    [resultQuote[0].policy_core_id_fk],
                                    async (errorPolicy, resultPolicy) => {
                                      if (errorPolicy) {
                                        console.log(errorPolicy);
                                      } else {
                                        const dataPolicyCore = resultPolicy[0];
                                        await db.query(
                                          query_getVehicleDetail,
                                          [resultQuote[0].vehicle_info_id_fk],
                                          async (
                                            errorVehicle,
                                            resultVehicle
                                          ) => {
                                            if (errorVehicle) {
                                              console.log(errorVehicle);
                                            } else {
                                              await db.query(
                                                query_getVehicleAddressDetail,
                                                [
                                                  resultVehicle[0]
                                                    .insured_addrees_id_fk,
                                                ],
                                                async (
                                                  errorVehicleAddress,
                                                  resultVehicleAdress
                                                ) => {
                                                  const dataVehicle = {
                                                    address:
                                                      resultVehicleAdress[0],
                                                    vehicle: resultVehicle[0],
                                                  };

                                                  await db.query(
                                                    query_getModificationDetails,
                                                    [
                                                      resultVehicle[0]
                                                        .vehicle_info_id,
                                                    ],
                                                    async (
                                                      errorModi,
                                                      resultModi
                                                    ) => {
                                                      if (errorModi) {
                                                        console.log(errorModi);
                                                      } else {
                                                        const dataModifications =
                                                          resultModi;
                                                        await db.query(
                                                          query_getQuotationDriverDetails,
                                                          [
                                                            resultQuote[0]
                                                              .quotation_id,
                                                          ],
                                                          async (
                                                            errorQuoteDriver,
                                                            resultQuoteDriver
                                                          ) => {
                                                            if (
                                                              errorQuoteDriver
                                                            ) {
                                                              console.log(
                                                                errorQuoteDriver
                                                              );
                                                            } else {
                                                              // console.log(
                                                              //   resultQuote[0]
                                                              //     .quotation_id
                                                              // );
                                                              let dataDrivers =
                                                                [];
                                                              let dataClaim =
                                                                [];
                                                              resultQuoteDriver.map(
                                                                async (
                                                                  driver,
                                                                  indexDriver
                                                                ) => {
                                                                  await db.query(
                                                                    query_getDriverDetails,
                                                                    [
                                                                      driver.driver_info_id_fk,
                                                                    ],
                                                                    async (
                                                                      errorDriver,
                                                                      resultDriver
                                                                    ) => {
                                                                      if (
                                                                        errorDriver
                                                                      ) {
                                                                      } else {
                                                                        //console.log(resultDriver[0])
                                                                        dataDrivers =
                                                                          [
                                                                            ...dataDrivers,
                                                                            ...resultDriver,
                                                                          ];

                                                                        await db.query(
                                                                          query_getClaimDetails,
                                                                          [
                                                                            driver.driver_info_id_fk,
                                                                          ],
                                                                          async (
                                                                            errorClaim,
                                                                            resultClaim
                                                                          ) => {
                                                                            if (
                                                                              errorClaim
                                                                            ) {
                                                                              console.log(
                                                                                errorClaim
                                                                              );
                                                                            } else {
                                                                              let claimWithDriver =
                                                                              {
                                                                                dataClaims:
                                                                                  resultClaim,
                                                                                driver:
                                                                                  resultDriver,
                                                                              };

                                                                              // dataClaim =
                                                                              //   [
                                                                              //     ...dataClaim,
                                                                              //     claimWithDriver,
                                                                              //   ];
                                                                              dataClaim.push(
                                                                                claimWithDriver
                                                                              );

                                                                              if (
                                                                                indexDriver +
                                                                                1 ===
                                                                                resultQuoteDriver.length
                                                                              ) {
                                                                                response
                                                                                  .status(
                                                                                    201
                                                                                  )
                                                                                  .json(
                                                                                    {
                                                                                      status:
                                                                                        "success",
                                                                                      data: {
                                                                                        dataClient:
                                                                                          dataClient,
                                                                                        dataImportantQuestion:
                                                                                          dataImportantQuestion,
                                                                                        dataPolicyCore:
                                                                                          dataPolicyCore,
                                                                                        dataVehicle:
                                                                                          dataVehicle,
                                                                                        dataModifications:
                                                                                          dataModifications,
                                                                                        dataDrivers:
                                                                                          dataDrivers,
                                                                                        dataClaim:
                                                                                          dataClaim,
                                                                                      },
                                                                                    }
                                                                                  );
                                                                              }
                                                                            }
                                                                          }
                                                                        );
                                                                      }
                                                                    }
                                                                  );
                                                                }
                                                              );
                                                            }
                                                          }
                                                        );
                                                      }
                                                    }
                                                  );
                                                }
                                              );
                                            }
                                          }
                                        );
                                      }
                                    }
                                  );
                                }
                              }
                            );
                          }
                        }
                      );
                    }
                  }
                );
              }
            }
          );
        }
      }
    );
  } else {
    response.send({ message: "You are not authenticated" });
  }
}); // end of get quotation detail method

// get client detail using client id
exports.getClientDetail = catchAsync(async (req, response, next) => {
  const query_getClientDetail = "SELECT * FROM client WHERE client_id = ?";
  const query_getAddressDetail = "SELECT * FROM address WHERE address_id = ?";
  const query_getContactDetail =
    "SELECT * FROM contact_details WHERE contact_id = ?";
  const query_getImportantQuestionDetail =
    "SELECT * FROM important_questions_motor WHERE important_questions_motor_id = ?";
  const query_getPolicyCoreDetail =
    "SELECT * FROM policy_core_motor WHERE policy_core_motor_id = ?";
  const query_getVehicleDetail =
    "SELECT * FROM vehicle_information WHERE vehicle_info_id = ?";
  const query_getVehicleAddressDetail =
    "SELECT * FROM address WHERE address_id = ?";
  const query_getModificationDetails =
    "SELECT * FROM ns_accessories_modifications WHERE vehicle_id_fk = ?";
  const query_getQuotationDriverDetails =
    "SELECT * FROM quotation_driver_info WHERE quotation_id_fk = ?";
  const query_getDriverDetails =
    "SELECT * FROM driver_info WHERE driver_info_id =?";
  const query_getClaimDetails =
    "SELECT * FROM claim_details WHERE driver_info_id_fk = ?";
  await db.query(
    query_getClientDetail,
    [req.query.clientId],
    async (errorClient, resultClient) => {
      if (errorClient) {
        console.log(errorClient);
        response.status(500).json({
          status: "failed",
        });
      } else {
        console.log(resultClient[0]);
        const addressId = resultClient[0].address_id_fk;
        const contactId = resultClient[0].contact_id_fk;

        await db.query(
          query_getAddressDetail,
          [addressId],
          async (errorAddress, resultAddress) => {
            if (errorAddress) {
              //console.log(errorAddress);
            } else {
              await db.query(
                query_getContactDetail,
                [contactId],
                async (errorContact, resultContact) => {
                  if (errorContact) {
                    console.log(errorContact);
                  } else {
                    //console.log(resultContact);
                    const dataClient = {
                      clientDetail: {
                        client: resultClient[0],
                        address: resultAddress[0],
                        contact: resultContact[0],
                      },
                    };

                    db.query(query_getImportantQuestionDetail, []);

                    // response.status(201).json({
                    //   status: "success",
                    //   data: data,
                    // });
                  }
                }
              );
            }
          }
        );
      }
    }
  );
}); // end of get client detail method

// tab1_client post method to insert client details. /addClient
exports.addClientDetails = async (req, response, next) => {
  const data = req.body.data_tab1_client;
  const query_addAddress =
    "INSERT INTO address(unit_number, street_number, street_name, street_type, suburb, state, postcode) VALUES (?,?,?,?,?,?,?)";
  const query_addContactDetails =
    "INSERT INTO contact_details(phone, email, branch, sales_team, service_team) VALUES (?,?,?,?,?)";
  const query_addClient =
    "INSERT INTO client(client_type, client_title, client_first_name, client_last_name, company_name," +
    " trading_as, reference_code, contact_id_fk, address_id_fk ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
  const query_addQuotation =
    "INSERT INTO quotation_details(quotation_type, quotation_status, client_id_fk) VALUES (?,?,?)";

  let addressIdFk;
  let contactIdFk;

  // add address
  db.query(
    query_addAddress,
    [
      data.unitNumber,
      data.streetNumber,
      data.streetName.trim(),
      data.streetType,
      data.suburb.trim(),
      data.state,
      data.postCode,
    ],
    (errorAddress, resultAddress) => {
      if (errorAddress) {
        console.log(errorAddress);
        response.status(500).json({
          status: "failed",
        });
      } else {
        addressIdFk = resultAddress.insertId;
        // add contact details
        db.query(
          query_addContactDetails,
          [
            data.phone,
            data.email,
            data.branch,
            data.salesTeam,
            data.serviceTeam,
          ],
          (errorContact, resultContact) => {
            if (errorContact) {
              console.log(errorContact);
              response.status(500).json({
                status: "failed",
              });
            } else {
              contactIdFk = resultContact.insertId;
              // add client's details
              db.query(
                query_addClient,
                [
                  data.clientType,
                  data.title,
                  data.firstName.trim(),
                  data.lastName.trim(),
                  data.companyName.trim(),
                  data.tradingAs.trim(),
                  data.officeTechReferenceCode,
                  contactIdFk,
                  addressIdFk,
                ],
                (errorClient, resultClient) => {
                  if (errorClient) {
                    console.log(errorClient);
                    response.status(500).json({
                      status: "failed",
                    });
                  } else {
                    const clientIdFk = resultClient.insertId;
                    db.query(
                      query_addQuotation,
                      ["Motor", "Pending", clientIdFk],
                      (errorQuotation, resultQuotation) => {
                        if (errorQuotation) {
                          console.log(errorQuotation);
                          response.status(500).json({
                            status: "failed",
                          });
                        } else {
                          response.status(201).json({
                            status: "success",
                            data: {
                              id: resultQuotation.insertId,
                            },
                          });
                        }
                      }
                    );
                  }
                }
              );
            }
          }
        );
      }
    }
  );
}; // end of add client method

// tab2_importantQuestions post method to insert important question data.
exports.addImportantQuestions = async (req, response, next) => {
  const data = req.body.data_tab2_importantQuestions;
  const quotationId_db = req.body.quotationId_db;

  const query_addImportantQuestions =
    "INSERT INTO important_questions_motor(insurance_policy_dc_last_12_month, insurance_policy_dc_5_years," +
    " claim_declined, reason_for_decline, any_criminal_conviction, existing_damage_vehicle, would_you_answer_yes, " +
    "bankrupt_or_insolvent_last_5_years, reason_bankrupt_or_insolvent_last_5_years, criminal_offence_past_5_years, " +
    "reason_criminal_offence_past_5_years ) VALUES (?,?,?,?,?, ?,?,?,?,?, ?)";

  const query_updateQuotation =
    "UPDATE quotation_details SET important_question_id_fk = ? WHERE quotation_id = ? ";

  // add important quetsions details
  db.query(
    query_addImportantQuestions,
    [
      data.insurancePolicyCancelledLast_12_months,
      data.insurancePolicyCancelledLast_5_years,
      data.hadClaimDeclained,
      data.reasonClaimDecalined,
      data.maliciousDamage,
      data.existingDamage,
      data.wouldAnswerYes,
      data.declaredBankrupt,
      data.reasonBankrupt,
      data.criminalOffence,
      data.reasonCriminalOffence,
    ],
    (errorImp, resultImp) => {
      if (errorImp) {
        console.log(errorImp);
        response.status(500).json({
          status: "failed",
        });
      } else {
        const impportantQuestion_id = resultImp.insertId;

        db.query(
          query_updateQuotation,
          [impportantQuestion_id, quotationId_db],
          (errorQuote, resultQuote) => {
            if (errorQuote) {
              console.log(errorQuote);
              response.status(500).json({
                status: "failed",
              });
            } else {
              response.status(201).json({
                status: "success",
                data: {
                  id: resultQuote,
                },
              });
            }
          }
        );
      }
    }
  );
};

// post method to insert policy core data
exports.addPolicyCore = async (req, response, next) => {
  const data = req.body.data_tab3_policyCore;
  const quotationId_db = req.body.quotationId_db;
  console.log(data);
  const query_addPolicyCore =
    "INSERT INTO policy_core_motor(holding_broker, holding_underwriter, stamp_duty_exempt, " +
    " no_claim_bonus, payment_frequency, preferred_day_for_installments, broker_fee_installments, product_type_allianz, " +
    " cover_type, sum_insured, agreed_value_amount, policy_from_date, policy_to_date, roadside_assistance, hire_care_inclusion_SVU_allianz, " +
    " windscreen_excess_waiver_SVU_allianz, who_repairs_the_vehicle_IAL_only, no_claim_bonus_protection_allianz, " +
    " restricted_driver_discount_allianz, named_driver_option_allianz, tools_of_trade_option_allianz, restricted_drivers_vero, " +
    " interested_parties, occupation_of_policyholder_zurich, excess_option_1, excess_option_2, excess_option_3, broker_fee, commercial_purposes_caravan_operations) " +
    " VALUES (?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,? ,?,?,?,?)"; // 29 cols without pk

  const query_updateQuotation =
    "UPDATE quotation_details SET policy_core_id_fk = ? WHERE quotation_id = ? ";

  let fromDateTemp = data.policyFromDate;
  let toDateTemp = data.policyToDate;

  fromDateTemp = fromDateTemp.substring(0, 10);
  toDateTemp = toDateTemp.substring(0, 10);
  // substring(0, 10)
  console.log("from dat temp: " + fromDateTemp);

  // add policy core details to the db
  db.query(
    query_addPolicyCore,
    [
      data.holdingBroker,
      data.holdingUnderwriter,
      data.stampDuty,
      data.noClaimBonus,
      data.paymentFrequency,
      data.preferredInstallments,
      data.broker_fee_installments,
      data.productType,
      data.coverType,
      data.sumInsured,
      data.agreedValueAmount,
      fromDateTemp,
      toDateTemp,
      data.roadsideAssistance,
      data.hireCareInclusion,
      data.windscreenExcessWaiver,
      data.repairsVehicle,
      data.claimBonusProtection,
      data.restrictedDriversDiscount,
      data.namedDriver,
      data.toolsTrade,
      data.restrictedDrivers,
      data.interestedParties,
      data.occupationPolicyholder,
      data.excessOption1,
      data.excessOption2,
      data.excessOption3,
      data.brokerFee,
      data.commercialPurposesCaravan,
    ],
    (errorPolicy, resultPolicy) => {
      console.log(resultPolicy);
      if (errorPolicy) {
        console.log(errorPolicy);
        response.status(500).json({
          status: "failed",
        });
      } else {
        db.query(
          query_updateQuotation,
          [resultPolicy.insertId, quotationId_db],
          (errorQuote, resultQuote) => {
            if (errorQuote) {
              console.log(errorQuote);
              response.status(500).json({
                status: "failed",
              });
            } else {
              response.status(201).json({
                status: "success",
                data: {
                  id: resultPolicy.insertId,
                },
              });
            }
          }
        );
      }
    }
  );
};

// post method to insert vehicle information
exports.addVehicleInfomation = async (req, response, next) => {
  let purchaseDate;
  // console.log(req.body);
  const data = req.body.data_tab4_vehicle;
  // console.log(data);
  const quotationId_db = req.body.quotationId_db;
  // console.log(data.purchaseDate);
  const query_addAddress =
    "INSERT INTO address(unit_number, street_number, street_name, street_type, suburb, state, postcode) VALUES (?,?,?,?,?,?,?)";
  const query_addVehicleInfo =
    "INSERT INTO vehicle_information(insured_addrees_id_fk, registration_of_vehicle," +
    "state_issued , vehicle_color, vehicle_year, vehicle_make, vehicle_model, security_device_fitted," +
    "vehicle_usage, avg_num_of_km_per_year, vehicle_parked_at_night, policyHolder_previously_insured, " +
    "vehicle_unregistered, driver_education_racing_sporting_events_courier_delivery, hire_car_removalist_vehicle_fleet_or_pool_vehicle_airside, " +
    "vehicle_has_specialised_paint, vehicle_has_turbo_supercharger, vehicle_has_nitro_hydrogen_fuel, vehicle_has_a_Roll_bar_rollcage_racing_harnesses, " +
    "vehicle_financed, vehicle_have_hail_damage, purchase_date, Purchase_Price, vehicle_type," +
    "vehicle_owned_years,where_is_parked) VALUES(?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,?,?)";
  const query_updateQuotation =
    "UPDATE quotation_details SET vehicle_info_id_fk = ? WHERE quotation_id = ? ";

  db.query(
    query_addAddress,
    [
      data.unitNumber,
      data.streetNumber,
      data.streetName.trim(),
      data.streetType,
      data.suburb.trim(),
      data.state,
      data.postCode,
    ],
    (errorAddress, resultAddress) => {
      if (errorAddress) {
        // console.log(errorAddress);
        response.status(500).json({
          status: "failed",
        });
      } else {
        if (data.purchaseDate === null) {
          purchaseDate = null;
        } else {
          purchaseDate = data.purchaseDate.substring(0, 10)
        }

        if (data.purchasePrice === empty_str) {
          data.purchasePrice = null;
        }
        if(data.vehicleMake === null){
            data.vehicleMake = null;
        }
        else{
          data.vehicleMake = data.vehicleMake.trim();
        }
        if(data.vehicleModel === null){
          data.vehicleModel = null;
      }
      else{
        data.vehicleModel = data.vehicleModel.trim();
      }
        db.query(
          query_addVehicleInfo,
          [
            resultAddress.insertId,
            data.registrationVehicle.trim(),
            data.stateIssued,
            data.vehicleColour,
            data.vehicleYear,
            data.vehicleMake,
            data.vehicleModel,
            data.securityDeviceFitted,
            data.vehicleUsage,
            data.numberKMsYear,
            data.vehicleParkedNight,
            data.previouslyInsured,
            data.vehicleUnregistered,
            data.usedDriver,
            data.usedHireCar,
            data.specialisedPaint,
            data.superCharger,
            data.hydrogenFuel,
            data.racingHarnesses,
            data.vehicleFinanced,
            data.hailDamage,
            purchaseDate,
            data.purchasePrice,
            data.vehicleType,
            data.similarPowerOfVehicle,
            data.vehicleParkedDay,
          ],
          (errorVehicle, resultVehicle) => {
            if (errorVehicle) {
              console.log(errorVehicle);
              response.status(500).json({
                status: "failed",
              });
            } else {
              db.query(
                query_updateQuotation,
                [resultVehicle.insertId, quotationId_db],
                (errorQuote, resultQuote) => {
                  if (errorQuote) {
                    console.log(errorQuote);
                    response.status(500).json({
                      status: "failed",
                    });
                  } else {
                    response.status(201).json({
                      status: "success",
                      data: {
                        id: resultVehicle.insertId,
                      },
                    });
                  }
                }
              );
            }
          }
        );
      }
    }
  );
}; // end add vehicle nformations

// post method to insert array of modifications
exports.addModification = async (req, response, next) => {
  const data = req.body.data_tab5_modifications;
  const vehicleId_db = req.body.vehicleId_db;
  let values = [];
  let count = 0;
  const query_addModifications =
    "INSERT INTO ns_accessories_modifications(vehicle_id_fk, type, category, description, value) VALUES ?";


  if (data.length > 0) {
    data.forEach((element) => {
      console.log("vehicle id: " + vehicleId_db);
      let arrayElem = [];
      arrayElem.push(vehicleId_db);
      arrayElem.push(element.type);
      arrayElem.push(element.category);
      arrayElem.push(element.description.trim());
      arrayElem.push(element.value);
      values.push(arrayElem);

      count++;
      if (count === data.length) {
        db.query(
          query_addModifications,
          [values],
          (errorModify, resultModify) => {
            if (errorModify) {
              console.log(errorModify);
              response.status(500).json({
                status: "failed",
              });
            } else {
              response.status(201).json({
                status: "success",
                data: {
                  id: resultModify,
                },
              });
            }
          }
        );
      }
    });
  } else {
    response.status(201).json({
      status: "No Modifications here",
    });
  }
}; // end of add modofication array to the db

// post method to insert driver array to the datatabase
exports.addDrivers = async (req, response, next) => {
  const driverArray = req.body.data_tab6_drivers;
  const claimArray = req.body.data_tab7_claims;
  const quotationId_db = req.body.quotationId_db;
  // console.log("q id: " + quotationId_db);
  let values = [];
  let countDriver = 0;
  let countClaim = 0;

  // console.log(driverArray);
  const query_addDrivers =
    "INSERT INTO driver_info(driver_type, driver_first_name, driver_surname, driver_gender, driver_dob, year_australian_drivers_license_obtained, state_issued, " +
    " employment_status_of_the_driver, demerit_points_in_last_3_years, fines_penalties_imposed_drugalcohol_offences, penalties_years_since_first_occurrence, " +
    " reason_for_conviction_fines_or_penalties, num_of_license_suspensions_cancellations_3y, suspensions_years_since_first_occurrence, reason_for_1st_suspension_or_cancellation, " +
    " reason_for_2nd_suspension_or_cancellation, reason_for_3rd_suspension_or_cancellation, number_of_claims_in_the_last_3_years, claims_years_since_firstOccurrence, reason_for_claims_last_3years, " +
    " had_any_accident_or_claim_involving_a_vehicle, accident_years_since_firstOccurrence, owns_this_vehicle, owns_another_Vehicle" +
    " ) VALUES (?,?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,?, ?,?,?)"; // 23 cols
  const query_addQuotationDriverDetails =
    "INSERT INTO quotation_driver_info(quotation_id_fk, driver_info_id_fk) VALUES(?,?)";
  const query_addClaims =
    "INSERT INTO claim_details(driver_info_id_fk, claim_type, claim_date, claims_years_since_firstOccurrence," +
    "reason_for_claims_last_3years, claim_description, claim_outcome, claim_amount) VALUES (?,?,?,?,?,?,?,?)";

  driverArray.forEach((element, index) => {
    //count++;
    let arrayElem = [];
    arrayElem.push(element.driverType);
    arrayElem.push(element.firstName.trim());
    arrayElem.push(element.surName.trim());
    arrayElem.push(element.gender);
    arrayElem.push(element.dateBirth.substring(0, 10));
    arrayElem.push(element.driversLicenseObtained.substring(0, 4));
    arrayElem.push(element.stateIssued);
    arrayElem.push(element.statusDriver);
    arrayElem.push(element.demeritPoints3);
    arrayElem.push(element.alcoholOffences);
    arrayElem.push(element.firstOccurrence1);
    arrayElem.push(element.reasonFines);
    arrayElem.push(element.licenseSuspensions);
    arrayElem.push(element.firstOccurrence2);
    arrayElem.push(element.suspension1st);
    arrayElem.push(element.suspension2nd);
    arrayElem.push(element.suspension3rd);
    arrayElem.push(element.numberClaims3);
    arrayElem.push(element.firstOccurrence3);
    arrayElem.push(element.reasonClaims3);
    arrayElem.push(element.accidentClaim);
    arrayElem.push(element.firstOccurrence4);
    arrayElem.push(element.ownVehicle);
    arrayElem.push(element.ownsAnotherVehicle);

    values.push(arrayElem);

    db.query(query_addDrivers, arrayElem, (errorDriver, resultDriver) => {
      if (errorDriver) {
        console.log(errorDriver);
        response.status(500).json({
          status: "failed",
        });
        //return false;
      } else {
        console.log("driver id: " + resultDriver.insertId);
        db.query(
          query_addQuotationDriverDetails,
          [quotationId_db, resultDriver.insertId],
          (errorQuotation, resultQuotation) => {
            if (errorQuotation) {
              console.log(errorQuotation);
              response.status(500).json({
                status: "failed",
              });
              //return false;
            } else {
              console.log("quote updated, claim lenght: " + claimArray.length);
              countDriver++;
              if (claimArray.length > 0) {
                claimArray.forEach((elementClaim, indexClaim) => {
                  console.log("dateclaim:", elementClaim.dateClaim.substring(0, 10));
                  if (elementClaim.driverIndex === index) {
                    db.query(
                      query_addClaims,
                      [
                        resultDriver.insertId,
                        elementClaim.typeClaim,
                        elementClaim.dateClaim.substring(0, 10),
                        elementClaim.firstOccurrence,
                        elementClaim.reasonClaims,
                        elementClaim.description.trim(),
                        elementClaim.claimOutcome,
                        elementClaim.amount,
                      ],
                      (errorClaim, resultClaim) => {
                        countClaim++;
                        if (errorClaim) {
                          console.log(errorClaim);
                          response.status(500).json({
                            status: "failed",
                          });
                          //return false;
                        } else {
                          console.log("claim: " + resultClaim.insertId);
                        }
                      }
                    ); // end of claim insert
                  }
                }); // end of for each
                // end of if
              } else {
                // response.status(201).json({
                //   status: "no claim data here",
                // });
              }
            }
          }
        ); // end of insert quotation driver details
      } // end of if
    }); // end of db.query
  }); // end of forEach
  response.status(201).json({
    status: "no claim data here",
  });
}; // end of add driver and claims

// method: to update quotation details
//updateHomeQuotations
exports.updateQuotation = async (req, response, next) => {
  const data_tab1 = req.body.data_tab1;
  console.log(data_tab1);
  const data_tab2 = req.body.data_tab2;
  const data_tab3 = req.body.data_tab3;
  const data_tab4 = req.body.data_tab4;
  const data_tab5 = req.body.data_tab5;
  const data_tab6 = req.body.data_tab6;
  const data_tab7 = req.body.data_tab7;
  const quotationId = req.body.quotationId;

  // make queries to perform on database actions
  const query_updateClient =
    "UPDATE client SET client_type = ? , client_title = ? , client_first_name = ? , " +
    "client_last_name = ? , company_name = ? , trading_as = ? , reference_code = ?, client_code = ?  WHERE client_id = ?";
  const query_updateAddress =
    "UPDATE address SET unit_number = ? , street_number = ? , street_name = ? ," +
    "street_type = ? , suburb = ? , state = ?, postcode = ?  WHERE address_id = ?";
  const query_updateContact =
    "UPDATE contact_details SET phone = ? , email = ? , branch = ?, " +
    "sales_team = ? , service_team = ?  WHERE contact_id = ?";
  const query_updateImportantQuestion =
    "UPDATE important_questions_motor SET insurance_policy_dc_last_12_month = ?, " +
    "insurance_policy_dc_5_years = ? , claim_declined = ?, reason_for_decline = ? , any_criminal_conviction = ?, " +
    " existing_damage_vehicle = ?, would_you_answer_yes = ? , bankrupt_or_insolvent_last_5_years = ? , " +
    " reason_bankrupt_or_insolvent_last_5_years = ? , criminal_offence_past_5_years = ? ," +
    "reason_criminal_offence_past_5_years = ?  WHERE important_question_motor_id = ?";

  const query_updatePolicyCore =
    "UPDATE POLICY_CORE_MOTOR SET holding_broker = ? , holding_underwriter = ?," +
    " stamp_duty_exempt = ?, no_claim_bonus = ? , payment_frequency = ? , preferred_day_for_installments = ?, " +
    " broker_fee_installments = ? , product_type_allianz = ? , cover_type = ? , sum_insured = ?," +
    " agreed_value_amount = ? , policy_from_date = ? , policy_to_date = ?, roadside_assistance = ?," +
    " hire_care_inclusion_SVU_allianz = ? , windscreen_excess_waiver_SVU_allianz = ? , who_repairs_the_vehicle_IAL_only = ?, " +
    " no_claim_bonus_protection_allianz = ? , restricted_driver_discount_allianz = ? , named_driver_option_allianz = ?," +
    " tools_of_trade_option_allianz = ? , restricted_drivers_vero = ? , interested_parties = ?," +
    " occupation_of_policyholder_zurich = ?, commercial_purposes_caravan_operations = ? , excess_option_1 = ?, " +
    " excess_option_2 = ?, excess_option_3 = ? , broker_fee = ?  WHERE policy_core_motor_id = ?";

  const query_updateVehicle =
    "UPDATE VEHICLE_INFORMATION SET registration_of_vehicle = ?, " +
    "vehicle_color = ?, vehicle_year = ?, vehicle_make = ?, vehicle_model = ?, security_device_fitted = ?, " +
    "vehicle_usage = ?, avg_num_of_km_per_year = ?, vehicle_parked_at_night = ?, policyHolder_previously_insured = ?, " +
    "vehicle_unregistered = ?, driver_education_racing_sporting_events_courier_delivery = ?," +
    "hire_car_removalist_vehicle_fleet_or_pool_vehicle_airside = ?, vehicle_has_specialised_paint = ?," +
    "vehicle_has_turbo_supercharger = ?, vehicle_has_nitro_hydrogen_fuel = ?," +
    "vehicle_has_a_Roll_bar_rollcage_racing_harnesses = ?, vehicle_financed= ?, vehicle_have_hail_damage = ?," +
    "purchase_date = ?, Purchase_Price = ?, vehicle_type = ?, vehicle_owned_years = ?, where_is_parked = ? " +
    "WHERE vehicle_info_id = ?"; // 23 params

  const query_updateModification =
    "UPDATE NS_ACCESSORIES_MODIFICATIONS SET type = ? , category = ?," +
    "description = ? , value = ?  WHERE nsam_id = ?";

  const query_createModification =
    "INSERT INTO NS_ACCESSORIES_MODIFICATIONS(vehicle_id_fk, type, category, " +
    "description, value) values(?,?,?,?,?)";

  const query_deleteModification =
    "DELETE FROM NS_ACCESSORIES_MODIFICATIONS WHERE nsam_id = ?";

  const query_updateDriver =
    "UPDATE Driver_Info SET driver_type = ?, driver_first_name = ?, driver_surname = ?, driver_gender = ?," +
    " driver_dob = ?, year_australian_drivers_license_obtained = ?, employment_status_of_the_driver = ?, " +
    " demerit_points_in_last_3_years = ?, fines_penalties_imposed_drugalcohol_offences = ?, penalties_years_since_first_occurrence = ?, reason_for_conviction_fines_or_penalties = ?," +
    " num_of_license_suspensions_cancellations_3y = ?, suspensions_years_since_first_occurrence = ?," +
    " reason_for_1st_suspension_or_cancellation = ?, reason_for_2nd_suspension_or_cancellation = ?," +
    " reason_for_3rd_suspension_or_cancellation = ?, number_of_claims_in_the_last_3_years = ?," +
    "had_any_accident_or_claim_involving_a_vehicle = ?," +
    " accident_years_since_firstOccurrence= ?, owns_this_vehicle = ?, owns_another_Vehicle = ? WHERE driver_info_id = ?"; // 24 params

  const query_deleteDriver = "DELETE FROM Driver_Info WHERE driver_info_id = ?";

  /* const query_deleteQuotationDriver =
    "DELETE FROM quotation_driver_info WHERE driver_info_id_fk = ?"; */

  const query_createDriver =
    "INSERT INTO driver_info(driver_type, driver_first_name, driver_surname, driver_gender, driver_dob, year_australian_drivers_license_obtained, " +
    " employment_status_of_the_driver, demerit_points_in_last_3_years, fines_penalties_imposed_drugalcohol_offences, penalties_years_since_first_occurrence, " +
    " reason_for_conviction_fines_or_penalties, num_of_license_suspensions_cancellations_3y, suspensions_years_since_first_occurrence, reason_for_1st_suspension_or_cancellation, " +
    " reason_for_2nd_suspension_or_cancellation, reason_for_3rd_suspension_or_cancellation, number_of_claims_in_the_last_3_years, claims_years_since_firstOccurrence," +
    " reason_for_claims_last_3years, had_any_accident_or_claim_involving_a_vehicle, accident_years_since_firstOccurrence, owns_this_vehicle, owns_another_Vehicle)" +
    " VALUES (?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,?, ?,?,?,?,?, ?,?,?)"; // 23 cols

  /*  const query_createQuotationDriver =
     "INSERT INTO quotation_driver_info(quotation_id_fk, driver_info_id_fk) VALUES(?,?)"; */

  const query_updateClaim =
    "UPDATE CLAIM_DETAILS SET claim_type = ?, claim_date = ?,claims_years_since_firstOccurrence = ?," +
    "reason_for_claims_last_3years = ?, claim_description = ?," +
    " claim_outcome = ? , claim_amount = ? WHERE claim_id = ?";

  const query_updateQuotationStatus =
    "UPDATE quotation_details SET quotation_status = 'Verified' WHERE quotation_id = ?";

  let editedCompanyName = "";
  let editedTradingAs = "";

  if (data_tab1.clientType === "Individual") {
    editedCompanyName = "";
    editedTradingAs = "";
  } else {
    editedCompanyName = data_tab1.companyName;
    editedTradingAs = data_tab1.tradingAs;
  }

  console.log("clientId", data_tab1.clientId);
  await db.query(
    query_updateClient,
    [
      data_tab1.clientType,
      data_tab1.title,
      data_tab1.firstName,
      data_tab1.lastName,
      editedCompanyName,
      editedTradingAs,
      data_tab1.officeTechReferenceCode,
      data_tab1.ClientIdFromUipath,
      data_tab1.clientId,
    ],
    async (errorClient, resultClient) => {
      if (errorClient) {
        console.log(errorClient);
        response.status(500).json({
          status: "failed",
        });
        return;
      } else {
        //console.log(resultClient);
        await db.query(
          query_updateAddress,
          [
            data_tab1.unitNumber,
            data_tab1.streetNumber,
            data_tab1.streetName,
            data_tab1.streetType,
            data_tab1.suburb,
            data_tab1.state,
            data_tab1.postCode,
            data_tab1.addressId,
          ],
          async (errorAddress, resultAddress) => {
            if (errorAddress) {
              console.log(errorAddress);
              response.status(500).json({
                status: "failed",
              });
            } else {
              await db.query(
                query_updateContact,
                [
                  data_tab1.phone,
                  data_tab1.email,
                  data_tab1.branch,
                  data_tab1.salesTeam,
                  data_tab1.serviceTeam,
                  data_tab1.contactId,
                ],
                async (errorContact, resultContact) => {
                  if (errorContact) {
                    console.log(errorContact);
                    response.status(500).json({
                      status: "failed",
                    });
                  } else {
                    await db.query(
                      query_updateImportantQuestion,
                      [
                        data_tab2.insurancePolicyCancelledLast_12_months,
                        data_tab2.insurancePolicyCancelledLast_5_years,
                        data_tab2.hadClaimDeclained,
                        data_tab2.reasonClaimDecalined,
                        data_tab2.maliciousDamage,
                        data_tab2.existingDamage,
                        data_tab2.wouldAnswerYes,
                        data_tab2.declaredBankrupt,
                        data_tab2.reasonBankrupt,
                        data_tab2.criminalOffence,
                        data_tab2.reasonCriminalOffence,
                        data_tab2.importantQuestionId,
                      ],
                      async (errorImp, resultImp) => {
                        if (errorImp) {
                          console.log(errorImp);
                          response.status(500).json({
                            status: "failed",
                          });
                        } else {
                          let policyFromDateTemp = data_tab3.policyFromDate;
                          let policyToDateTemp = data_tab3.policyToDate;
                          policyFromDateTemp = policyFromDateTemp.substring(0, 10);
                          policyToDateTemp = policyToDateTemp.substring(0, 10);
                          console.log("policycodefrom date:", policyFromDateTemp);
                          await db.query(
                            query_updatePolicyCore,
                            [
                              data_tab3.holdingBroker,
                              data_tab3.holdingUnderwriter,
                              data_tab3.stampDuty,
                              data_tab3.noClaimBonus,
                              data_tab3.paymentFrequency,
                              data_tab3.preferredInstallments,
                              data_tab3.broker_fee_installment,
                              data_tab3.productType,
                              data_tab3.coverType,
                              data_tab3.sumInsured,
                              data_tab3.agreedValueAmount,
                              policyFromDateTemp,
                              policyToDateTemp,
                              data_tab3.roadsideAssistance,
                              data_tab3.hireCareInclusion,
                              data_tab3.windscreenExcessWaiver,
                              data_tab3.repairsVehicle,
                              data_tab3.claimBonusProtection,
                              data_tab3.restrictedDriversDiscount,
                              data_tab3.namedDriver,
                              data_tab3.toolsTrade,
                              data_tab3.restrictedDrivers,
                              data_tab3.interestedParties,
                              data_tab3.occupationPolicyholder,
                              data_tab3.commercialPurposesCaravan,
                              data_tab3.excessOption1,
                              data_tab3.excessOption2,
                              data_tab3.excessOption3,
                              data_tab3.brokerFee,
                              data_tab3.policyCoreId,
                            ],
                            async (errorPolicyCore, resultPolicyCore) => {
                              if (errorPolicyCore) {
                                console.log(errorPolicyCore);
                                response.status(500).json({
                                  status: "failed",
                                });
                              } else {
                                await db.query(
                                  query_updateAddress,
                                  [
                                    data_tab4.unitNumber,
                                    data_tab4.streetNumber,
                                    data_tab4.streetName,
                                    data_tab4.streetType,
                                    data_tab4.suburb,
                                    data_tab4.state,
                                    data_tab4.postCode,
                                    data_tab4.addressId,
                                  ],
                                  async (
                                    errorAddressVehi,
                                    resultAddressVehi
                                  ) => {
                                    if (errorAddressVehi) {
                                      console.log(errorAddressVehi);
                                      response.status(500).json({
                                        status: "failed",
                                      });
                                    } else {
                                      let purchaseDateTemp =
                                        data_tab4.purchaseDate;

                                      if (purchaseDateTemp === null) {
                                        purchaseDateTemp = null;
                                      } else {
                                        // if(purchaseDateTemp !== null){
                                        purchaseDateTemp =
                                          purchaseDateTemp.substring(0, 10);
                                      }
                                      await db.query(
                                        query_updateVehicle,
                                        [
                                          data_tab4.registrationVehicle,
                                          data_tab4.vehicleColour,
                                          data_tab4.vehicleYear,
                                          data_tab4.vehicleMake,
                                          data_tab4.vehicleModel,

                                          data_tab4.securityDeviceFitted,
                                          data_tab4.vehicleUsage,
                                          data_tab4.numberKMsYear,
                                          data_tab4.vehicleParkedNight,
                                          data_tab4.previouslyInsured,

                                          data_tab4.vehicleUnregistered,
                                          data_tab4.usedDriver,
                                          data_tab4.usedHireCar,
                                          data_tab4.specialisedPaint,
                                          data_tab4.superCharger,

                                          data_tab4.hydrogenFuel,
                                          data_tab4.racingHarnesses,
                                          data_tab4.vehicleFinanced,
                                          data_tab4.hailDamage,
                                          purchaseDateTemp,

                                          data_tab4.purchasePrice,
                                          data_tab4.vehicleType,
                                          data_tab4.similarPowerOfVehicle,
                                          data_tab4.vehicleParkedDay,
                                          data_tab4.vehicleId,
                                        ],
                                        async (errorVehicle, resultVehicle) => {
                                          if (errorVehicle) {
                                            console.log(errorVehicle);
                                            response.status(500).json({ status: "failed", });
                                          }
                                          else {
                                            for (let i = 0; i < data_tab5.length; i++) {
                                              let curData;
                                              let curQuery;
                                              if (data_tab5[i].edit === "OLD") {
                                                curData = [
                                                  data_tab5[i].type,
                                                  data_tab5[i].category,
                                                  data_tab5[i].description,
                                                  data_tab5[i].value,
                                                  data_tab5[i].modiId,
                                                ];
                                                curQuery = query_updateModification;
                                              }
                                              else if (data_tab5[i].edit === "NEW") {
                                                curQuery = query_createModification;
                                                curData = [
                                                  data_tab4.vehicleId,
                                                  data_tab5[i].type,
                                                  data_tab5[i].category,
                                                  data_tab5[i].description,
                                                  data_tab5[i].value,
                                                ];
                                              }
                                              else if (data_tab5[i].edit === "DELETED") {
                                                curQuery = query_deleteModification;
                                                curData = [data_tab5[i].modiId];
                                              }

                                              await db.query(
                                                curQuery,
                                                curData,
                                                async (
                                                  errorModi,
                                                  resultModi
                                                ) => {
                                                  if (errorModi) {
                                                    console.log(errorModi);
                                                    response.status(500).json({
                                                      status: "failed",
                                                    });
                                                    return;
                                                  } else {
                                                  }
                                                }
                                              );
                                            }
                                            //
                                            for (let j = 0; j < data_tab6.length; j++) {
                                              console.log(data_tab6.length);
                                              let curQuery;
                                              let curData;
                                              if (data_tab6[j].edit === "OLD") {
                                                curQuery = query_updateDriver;
                                                curData = [
                                                  data_tab6[j].driverType,
                                                  data_tab6[j].firstName,
                                                  data_tab6[j].surName,
                                                  data_tab6[j].gender,
                                                  data_tab6[j].dateBirth.substring(0, 10),
                                                  data_tab6[j].driversLicenseObtained,
                                                  data_tab6[j].statusDriver,
                                                  data_tab6[j].demeritPoints3,
                                                  data_tab6[j].alcoholOffences,
                                                  data_tab6[j].firstOccurrence1,
                                                  data_tab6[j].reasonFines,
                                                  data_tab6[j].licenseSuspensions,
                                                  data_tab6[j].firstOccurrence2,
                                                  data_tab6[j].suspension1st,
                                                  data_tab6[j].suspension2nd,
                                                  data_tab6[j].suspension3rd,
                                                  data_tab6[j].numberClaims3,
                                                  // data_tab6[j].firstOccurrence3,
                                                  // data_tab6[j].reasonClaims3,
                                                  data_tab6[j].accidentClaim,
                                                  data_tab6[j].firstOccurrence4,
                                                  data_tab6[j].ownVehicle,
                                                  data_tab6[j].ownsAnotherVehicle,
                                                  data_tab6[j].driverId,
                                                ];
                                              } 
                                              else if (data_tab6[j].edit === "NEW") {
                                                curQuery = query_createDriver;
                                                curData = [
                                                  data_tab6[j].driverType,
                                                  data_tab6[j].firstName,
                                                  data_tab6[j].surName,
                                                  data_tab6[j].gender,
                                                  data_tab6[j].dateBirt.substring(0, 10),
                                                  data_tab6[j].driversLicenseObtained,
                                                  data_tab6[j].statusDriver,
                                                  data_tab6[j].demeritPoints3,
                                                  data_tab6[j].alcoholOffences,
                                                  data_tab6[j].firstOccurrence1,
                                                  data_tab6[j].reasonFines,
                                                  data_tab6[j].licenseSuspensions,
                                                  data_tab6[j].firstOccurrence2,
                                                  data_tab6[j].suspension1st,
                                                  data_tab6[j].suspension2nd,
                                                  data_tab6[j].suspension3rd,
                                                  data_tab6[j].numberClaims3,
                                                  // data_tab6[j].firstOccurrence3,
                                                  // data_tab6[j].reasonClaims3,
                                                  data_tab6[j].accidentClaim,
                                                  data_tab6[j].firstOccurrence4,
                                                  data_tab6[j].ownVehicle,
                                                  data_tab6[j].ownsAnotherVehicle,
                                                ];
                                              } else if (data_tab6[j].edit === "DELETED") {
                                                curQuery = query_deleteDriver;
                                                curData = [
                                                  data_tab6[j].driverId,
                                                ];
                                              }

                                              if (data_tab6[j].edit === "OLD") {
                                                await db.query(
                                                  curQuery,
                                                  curData,
                                                  async (
                                                    errorDriver,
                                                    resultDriver
                                                  ) => {
                                                    if (errorDriver) {
                                                      console.log(errorDriver);
                                                      response
                                                        .status(500)
                                                        .json({
                                                          status: "failed",
                                                        });
                                                      return;
                                                    } else {
                                                      console.log(resultDriver);
                                                      console.log(
                                                        data_tab7.length
                                                      );
                                                      if (
                                                        data_tab7.length === 0
                                                      ) {
                                                        await db.query(
                                                          query_updateQuotationStatus,
                                                          [quotationId],
                                                          async (
                                                            errorQuoteUpdate,
                                                            resultQuoteUpdate
                                                          ) => {
                                                            if (
                                                              errorQuoteUpdate
                                                            ) {
                                                              console.log(
                                                                errorQuoteUpdate
                                                              );
                                                              response
                                                                .status(500)
                                                                .json({
                                                                  status:
                                                                    "failed",
                                                                });
                                                            } else {
                                                              console.log(
                                                                "claims 0"
                                                              );
                                                              console.log(
                                                                resultQuoteUpdate
                                                              );
                                                            }
                                                          }
                                                        );
                                                      }
                                                      for (let k = 0; k < data_tab7.length; k++) {
                                                        let tempCliamDate = data_tab7[k].dateClaim;
                                                        tempCliamDate = tempCliamDate.substring(0, 10);
                                                        console.log("date claim:", tempCliamDate);
                                                        await db.query(
                                                          query_updateClaim,
                                                          [
                                                            data_tab7[k].typeClaim,
                                                            tempCliamDate,
                                                            data_tab7[k].firstOccurrence,
                                                            data_tab7[k].reasonClaims,
                                                            data_tab7[k].description,
                                                            data_tab7[k].claimOutcome,
                                                            data_tab7[k].amount,
                                                            data_tab7[k].claimId,
                                                          ],
                                                          async (errorClaim, resultClaim) => {
                                                            if (errorClaim) {
                                                              console.log(
                                                                errorClaim
                                                              );
                                                              response
                                                                .status(500)
                                                                .json({
                                                                  status:
                                                                    "failed",
                                                                });
                                                            } else {
                                                              console.log(resultClaim);
                                                              await db.query(
                                                                query_updateQuotationStatus,
                                                                [quotationId],
                                                                async (
                                                                  errorQuoteUpdate,
                                                                  resultQuoteUpdate
                                                                ) => {
                                                                  if (
                                                                    errorQuoteUpdate
                                                                  ) {
                                                                    console.log(
                                                                      errorQuoteUpdate
                                                                    );
                                                                    response
                                                                      .status(500).json({
                                                                        status:
                                                                          "failed",
                                                                      });
                                                                  } else {
                                                                    //console.log(resultQuoteUpdate);
                                                                  }
                                                                }
                                                              );
                                                            }
                                                          }
                                                        );
                                                      }
                                                    }
                                                  }
                                                );
                                              } else if (
                                                data_tab6[j].edit === "NEW"
                                              ) {
                                                // pending
                                              } else if (
                                                data_tab6[j].edit === "DELETED"
                                              ) {
                                                // pending
                                              }
                                            }
                                            //response
                                            console.log("Success");
                                            response.status(201).json({
                                              status: "success",
                                            });
                                          }
                                        }
                                      );
                                    }
                                  }
                                );
                              }
                            }
                          );
                        }
                      }
                    );
                  }
                }
              );
            }
          }
        );
      }
    }
  ); // end of client update
}; // end of update quotation method

// post method to insert array of modifications
exports.sampleURL = async (req, response, next) => {
  console.log("inside sample URL");
  /*
  const data = req.body.data_tab5_modifications;
  const vehicleId_db = req.body.vehicleId_db;
  let values = [];
  let count = 0;
  const query_addModifications =
    "INSERT INTO ns_accessories_modifications(vehicle_id_fk, type, category, description, value) VALUES ?";

  if (data.length > 0) {
    data.forEach((element) => {
      console.log("vehicle id: " + vehicleId_db);
      let arrayElem = [];
      arrayElem.push(vehicleId_db);
      arrayElem.push(element.type);
      arrayElem.push(element.category);
      arrayElem.push(element.description);
      arrayElem.push(element.value);
      values.push(arrayElem);

      count++;
      if (count === data.length) {
        db.query(
          query_addModifications,
          [values],
          (errorModify, resultModify) => {
            if (errorModify) {
              console.log(errorModify);
              response.status(500).json({
                status: "failed",
              });
            } else {
              response.status(201).json({
                status: "success",
                data: {
                  id: resultModify,
                },
              });
            }
          }
        );
      }
    });
  } else {
    response.status(201).json({
      status: "No Modifications here",
    });
  }
  */

  response.status(201).json({
    status: "success",
    data: "sample get",
  });
}; // end of add modofication array to the db
