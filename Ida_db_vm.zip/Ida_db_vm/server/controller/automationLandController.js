const jwt = require("jsonwebtoken");
const axios = require("axios");
const express = require("express");
const mysql = require("mysql");

// db details
const db = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "root",
  port: 3306,
  database: "ida_db_vm",
});

// method to verify token
const verifyToken = async (token) => {
  // console.log(token);
  if (!token) {
    return false;
  } else {
    return jwt.verify(token, "jwtSecret_IDA", (err, decoded) => {
      if (err) {
        return false;
      } else {
        return true;
      }
    });
  }
};

// sumbit quotaion to UiPath orchestrator
exports.submitLandQuotation = async (req, res, next) => {
  const quotation_id = req.query.quotationId;
  console.log("hi")
  if (await verifyToken(req.body.headers.token)) {
    const query_getQuotationDetail =
      "SELECT quotation_type FROM quotation_details WHERE quotation_id = ?";
    const query_getClientDetail =
      "SELECT client_id FROM client_landlords WHERE question_details_id = ?";
    const query_getImportantQuestionDetail =
      "SELECT important_questions_id FROM important_questions_landlords WHERE question_details_id = ?";
    const query_getPolicyCoreDetail =
      "SELECT policy_core_id FROM policycore_landlords WHERE question_details_id = ?";
    const query_updateQuotationStatus =
      "UPDATE quotation_details SET quotation_status = 'Submitted' WHERE quotation_id = ?";

    // get quotation type from quotation table
    await db.query(
      query_getQuotationDetail,
      [quotation_id],
      async (errorQuote, resultQuote) => {
        if (errorQuote) {
          console.log(errorQuote);
        } else {
          const quotation_type = resultQuote[0].quotation_type;

          // get client id from client table
          await db.query(
            query_getClientDetail,
            [quotation_id],
            async (errorClinet, resultClient) => {
              if (errorClinet) {
                console.log(errorClinet);
              } else {
                const client_id = resultClient[0].client_id;

                // get important question id from important question table
                await db.query(
                  query_getImportantQuestionDetail,
                  [quotation_id],
                  async (errorImp, resultImp) => {
                    if (errorImp) {
                      console.log(errorImp);
                    } else {
                      const important_questions_id =
                        resultImp[0].important_questions_id;

                      // get policy core details from policy core table
                      await db.query(
                        query_getPolicyCoreDetail,
                        [quotation_id],
                        async (errorPolicy, resultPolicy) => {
                          if (errorPolicy) {
                            console.log(errorPolicy);
                          } else {
                            const policyCore_id =
                              resultPolicy[0].policy_core_id;

                            // trigger sendUiPathData method
                            const data = {
                              Id: quotation_id,
                              InsType: quotation_type,
                              ImpQuesId: important_questions_id,
                              ClientId: client_id,
                              PolicyCId: policyCore_id,
                              VehicleInfoId: "",
                            };

                            // send data using sendDataUiPath emthod
                            await sendDataUIPath(data);
                            await db.query(
                              query_updateQuotationStatus,
                              [quotation_id],
                              async (errorUpdateQuote, resultUpdateQuote) => {
                                if (errorUpdateQuote) {
                                  console.log(errorUpdateQuote);
                                } else {
                                  console.log("Submitted to UI path");
                                  console.log(resultUpdateQuote);

                                  res.send(true);
                                }
                              }
                            );
                          }
                        }
                      );
                    }
                  }
                );
              }
            }
          );
        }
      }
    );
  } else {
    response.send({ message: "You are not authenticated" });
  }
};

// method to send UIPath queue data
const sendDataUIPath = async (data) => {
  console.log(data);
  await axios
    .post(
      `https://account.uipath.com/oauth/token`,
      {
        grant_type: "refresh_token",
        client_id: "8DEv1AMNXczW3y4U15LL3jYf62jK93n5",
        refresh_token: "2eE9eRwrnHGImkc6y5D-TGsmoyZr7DTB12jUS9Ikru3tS",
      },
      {
        headers: {
          "Content-Type": "application/json",
          "X-UIPATH-TenantName": "Default",
        },
      }
    )
    .then(async (res) => {
      //console.log(res);
      console.log(`Data sent successfully to uiPath`);
      var currentDate = new Date();
      await axios
        .post(
          `https://cloud.uipath.com/anjngyxrpczi/Default/orchestrator_/odata/Queues/UiPathODataSvc.AddQueueItem`,

          {
            itemData: {
              Name: "Approved_IDA",
              Priority: "High",
              SpecificContent: {
                Id: data.Id,
                InsType: data.InsType,
                ImpQuesId: data.ImpQuesId,
                ClientId: data.ClientId,
                PolicyCId: data.PolicyCId,
                VehicleInfoId: data.VehicleInfoId,
              },
              Reference: "" + data.Id + " => " + currentDate.toString(),
            },
          },
          {
            headers: {
              Authorization: "Bearer " + res.data.access_token,
              "Content-Type": "application/json",
              "X-UIPATH-TenantName": "Default",
              Accept: "application/json",
              "X-UIPATH-OrganizationUnitId": "2592424",
            },
          }
        )
        .then((res) => {
          console.log(res.data.SpecificContent);
          console.log("Success");
        })
        .catch((err) => {
          console.log(err);
        });
    })
    .catch((err) => {
      console.log(err);
    });
};
