const axios = require("axios");
const express = require("express");
const app = express();
const mysql = require("mysql");
const bodyParser = require("body-parser");
const cors = require("cors");
const bcrypt = require("bcrypt");
const saltRounds = 10;
const jwt = require("jsonwebtoken");
const catchAsync = require("../utils/catchAsync");
const { response } = require("express");
const { getQuotationDetail } = require("./quotationController");
let tokenError = false;

const db = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "root",
  port: 3306,
  database: "ida_db_vm",
});

const verifyToken = async (token) => {
  // console.log(token);
  if (!token) {
    return false;
  } else {
    return jwt.verify(token, "jwtSecret_IDA", (err, decoded) => {
      if (err) {
        return false;
      } else {
        return true;
      }
    });
  }
};

// const tokenErrorMessage = (tokenError) => {
//   return(
//   <div>
//     {tokenError === true && (
//     confirmAlert({
//       title: 'Invalid User',
//       message: 'Re-login to system.',
//       buttons:
//       [
//         {
//           label: 'Login',
//           onClick: () => {
//             signout(() => {
//               history.push("/signin");
//             });

//           }
//         },
//         // {
//         //   label: 'No',
//         //   onClick: () => null
//         // }
//       ]
//     })
//   )}</div>
//   );
// }

// login method with hashed password
exports.submitQuotationData = async (req, response, next) => {
  console.log(
    "testaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  );

  // console,log(req.headers);
  console.log("q id: " + [req.query.quotationId]);
  // console.log(req.body.headers.token);

  if (await verifyToken(req.body.headers.token)) {
    const query_getQuotationDetail =
      "SELECT * FROM quotation_details WHERE quotation_id = ?";
    const query_getClientDetail = "SELECT * FROM client WHERE client_id = ?";
    const query_getAddressDetail = "SELECT * FROM address WHERE address_id = ?";
    const query_getContactDetail =
      "SELECT * FROM contact_details WHERE contact_id = ?";
    const query_getImportantQuestionDetail =
      "SELECT * FROM important_questions_motor WHERE important_question_motor_id = ?";
    const query_getPolicyCoreDetail =
      "SELECT * FROM policy_core_motor WHERE policy_core_motor_id = ?";
    const query_getVehicleDetail =
      "SELECT * FROM vehicle_information WHERE vehicle_info_id = ?";
    const query_getVehicleAddressDetail =
      "SELECT * FROM address WHERE address_id = ?";
    const query_getModificationDetails =
      "SELECT * FROM ns_accessories_modifications WHERE vehicle_id_fk = ?";
    const query_getQuotationDriverDetails =
      "SELECT * FROM quotation_driver_info WHERE quotation_id_fk = ?";
    const query_getDriverDetails =
      "SELECT * FROM driver_info WHERE driver_info_id =?";
    const query_getClaimDetails =
      "SELECT * FROM claim_details WHERE driver_info_id_fk = ?";
    const query_updateQuotationStatus =
      "UPDATE quotation_details SET quotation_status = 'Submitted' WHERE quotation_id = ?";
    await db.query(
      query_getQuotationDetail,
      [req.query.quotationId],
      async (errorQuote, resultQuote) => {
        if (errorQuote) {
          console.log(errorQuote);
        } else {
          // console.log(resultQuote);
          await db.query(
            query_getClientDetail,
            [resultQuote[0].client_id_fk],
            async (errorClient, resultClient) => {
              if (errorClient) {
                console.log(errorClient);
              } else {
                // console.log(resultClient[0]);
                const addressId = resultClient[0].address_id_fk;
                const contactId = resultClient[0].contact_id_fk;

                await db.query(
                  query_getAddressDetail,
                  [addressId],
                  async (errorAddress, resultAddress) => {
                    if (errorAddress) {
                      //console.log(errorAddress);
                    } else {
                      await db.query(
                        query_getContactDetail,
                        [contactId],
                        async (errorContact, resultContact) => {
                          if (errorContact) {
                            console.log(errorContact);
                          } else {
                            //console.log(resultContact);
                            // const dataClient = {
                            //   client: resultClient[0],
                            //   address: resultAddress[0],
                            //   contact: resultContact[0],
                            // };

                            await db.query(
                              query_getImportantQuestionDetail,
                              [resultQuote[0].important_question_id_fk],
                              async (errorImp, resultImp) => {
                                if (errorImp) {
                                  console.log(errorImp);
                                } else {
                                  const dataImportantQuestion = resultImp[0];

                                  await db.query(
                                    query_getPolicyCoreDetail,
                                    [resultQuote[0].policy_core_id_fk],
                                    async (errorPolicy, resultPolicy) => {
                                      if (errorPolicy) {
                                        console.log(errorPolicy);
                                      } else {
                                        const dataPolicyCore = resultPolicy[0];
                                        await db.query(
                                          query_getVehicleDetail,
                                          [resultQuote[0].vehicle_info_id_fk],
                                          async (
                                            errorVehicle,
                                            resultVehicle
                                          ) => {
                                            if (errorVehicle) {
                                              console.log(errorVehicle);
                                            } else {
                                              await db.query(
                                                query_getVehicleAddressDetail,
                                                [
                                                  resultVehicle[0]
                                                    .insured_addrees_id_fk,
                                                ],
                                                async (
                                                  errorVehicleAddress,
                                                  resultVehicleAdress
                                                ) => {
                                                  const dataVehicle = {
                                                    address:
                                                      resultVehicleAdress[0],
                                                    vehicle: resultVehicle[0],
                                                  };

                                                  await db.query(
                                                    query_getModificationDetails,
                                                    [
                                                      resultVehicle[0]
                                                        .vehicle_info_id,
                                                    ],
                                                    async (
                                                      errorModi,
                                                      resultModi
                                                    ) => {
                                                      if (errorModi) {
                                                        console.log(errorModi);
                                                      } else {
                                                        const dataModifications =
                                                          resultModi;
                                                        await db.query(
                                                          query_getQuotationDriverDetails,
                                                          [
                                                            resultQuote[0]
                                                              .quotation_id,
                                                          ],
                                                          async (
                                                            errorQuoteDriver,
                                                            resultQuoteDriver
                                                          ) => {
                                                            if (
                                                              errorQuoteDriver
                                                            ) {
                                                              console.log(
                                                                errorQuoteDriver
                                                              );
                                                            } else {
                                                              // console.log(
                                                              //   resultQuote[0]
                                                              //     .quotation_id
                                                              // );
                                                              let dataDrivers =
                                                                [];
                                                              let dataClaim =
                                                                [];
                                                              resultQuoteDriver.map(
                                                                async (
                                                                  driver,
                                                                  indexDriver
                                                                ) => {
                                                                  await db.query(
                                                                    query_getDriverDetails,
                                                                    [
                                                                      driver.driver_info_id_fk,
                                                                    ],
                                                                    async (
                                                                      errorDriver,
                                                                      resultDriver
                                                                    ) => {
                                                                      if (
                                                                        errorDriver
                                                                      ) {
                                                                      } else {
                                                                        //console.log(resultDriver[0])
                                                                        dataDrivers =
                                                                          [
                                                                            ...dataDrivers,
                                                                            ...resultDriver,
                                                                          ];

                                                                        await db.query(
                                                                          query_getClaimDetails,
                                                                          [
                                                                            driver.driver_info_id_fk,
                                                                          ],
                                                                          async (
                                                                            errorClaim,
                                                                            resultClaim
                                                                          ) => {
                                                                            if (
                                                                              errorClaim
                                                                            ) {
                                                                              console.log(
                                                                                errorClaim
                                                                              );
                                                                            } else {
                                                                              let claimWithDriver =
                                                                              {
                                                                                dataClaims:resultClaim,
                                                                                driver:resultDriver,
                                                                              };

                                                                              // dataClaim =
                                                                              //   [
                                                                              //     ...dataClaim,
                                                                              //     claimWithDriver,
                                                                              //   ];
                                                                              dataClaim.push(
                                                                                claimWithDriver
                                                                              );

                                                                              if (
                                                                                indexDriver +
                                                                                1 ===
                                                                                resultQuoteDriver.length
                                                                              ) {
                                                                                data =
                                                                                {
                                                                                  // dataClient:
                                                                                  //   dataClient,
                                                                                  // dataImportantQuestion:
                                                                                  //   dataImportantQuestion,
                                                                                  // dataPolicyCore:
                                                                                  //   dataPolicyCore,
                                                                                  // dataVehicle:
                                                                                  //   dataVehicle,
                                                                                  // dataModifications:
                                                                                  //   dataModifications,
                                                                                  // dataDrivers:
                                                                                  //   dataDrivers,
                                                                                  // dataClaim:
                                                                                  //   dataClaim,

                                                                                  Id: resultQuote[0].quotation_id,

                                                                                  InsType: resultQuote[0].quotation_type,

                                                                                  ImpQuesId: resultQuote[0].important_question_id_fk,

                                                                                  ClientId: resultQuote[0].client_id_fk,

                                                                                  PolicyCId: resultQuote[0].policy_core_id_fk,

                                                                                  VehicleInfoId: resultQuote[0].vehicle_info_id_fk,
                                                                                };

                                                                                //   console.log(data);
                                                                                await sendDataUIPath(data);
                                                                                await db.query(
                                                                                  query_updateQuotationStatus,
                                                                                  [req.query.quotationId],
                                                                                  async (err, submitted_quotation) => {
                                                                                    if (err) {
                                                                                      console.log(err.message);
                                                                                    } else {
                                                                                      console.log("Submitted to UI path");
                                                                                      console.log(submitted_quotation);
                                                                                      response.send(true);
                                                                                    }
                                                                                  }
                                                                                );
                                                                              }
                                                                            }
                                                                          }
                                                                        );
                                                                      }
                                                                    }
                                                                  );
                                                                }
                                                              );
                                                            }
                                                          }
                                                        );
                                                      }
                                                    }
                                                  );
                                                }
                                              );
                                            }
                                          }
                                        );
                                      }
                                    }
                                  );
                                }
                              }
                            );
                          }
                        }
                      );
                    }
                  }
                );
              }
            }
          );
        }
      }
    );


  } else {
    response.send({ message: "You are not authenticated" });
  }
};

const sendDataUIPath = async (data) => {
  console.log(data);
  await axios
    .post(
      `https://account.uipath.com/oauth/token`,
      {
        grant_type: "refresh_token",
        client_id: "8DEv1AMNXczW3y4U15LL3jYf62jK93n5",
        refresh_token: "2eE9eRwrnHGImkc6y5D-TGsmoyZr7DTB12jUS9Ikru3tS",
      },
      {
        headers: {
          "Content-Type": "application/json",
          "X-UIPATH-TenantName": "Default",
        },
      }
    )
    .then(async (res) => {
      //console.log(res);
      console.log(`Hello world`);
      var currentDate = new Date();
      await axios
        .post(
          `https://cloud.uipath.com/anjngyxrpczi/Default/orchestrator_/odata/Queues/UiPathODataSvc.AddQueueItem`,

          {
            itemData: {
              Name: "Approved_IDA",
              Priority: "High",
              SpecificContent: {
                Id: data.Id,
                InsType: data.InsType,
                ImpQuesId: data.ImpQuesId,
                ClientId: data.ClientId,
                PolicyCId: data.PolicyCId,
                VehicleInfoId: data.VehicleInfoId,
              },
              Reference: "" + data.Id + " => " + currentDate.toString(),
            },
          },
          {
            headers: {
              Authorization: "Bearer " + res.data.access_token,
              "Content-Type": "application/json",
              "X-UIPATH-TenantName": "Default",
              Accept: "application/json",
              "X-UIPATH-OrganizationUnitId": "2592424",
            },
          }
        )
        .then((res) => {
          console.log(res.data.SpecificContent);
          console.log("Success");
        })
        .catch((err) => {
          console.log(err);
        });
    })
    .catch((err) => {
      console.log(err);
    });
};
