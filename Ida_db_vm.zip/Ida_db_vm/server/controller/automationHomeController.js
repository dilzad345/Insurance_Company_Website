const jwt = require("jsonwebtoken");
const axios = require("axios");
const express = require("express");
const mysql = require("mysql");
const db = require("../models/db");
const verifyToken = require("../auth/VerifyToken");

exports.submissionHomeQuotation = async (req, res, next) => {
  const quotation_id = req.query.quotationId;

  if (await verifyToken(req.body.headers.token)) {
    const query_getQuotationHome =
      "SELECT quotation_type FROM quotation_details WHERE quotation_id = ?";
    const query_getClientDetail =
      "SELECT client_id FROM client_home WHERE quotaion_id_fk = ?";
    const query_getIQHome =
      "SELECT important_questions_id FROM important_questions_home WHERE quotation_id_fk = ?";
    const query_getPolicycoreHome =
      "SELECT policy_core_id FROM policy_core_home WHERE quotation_id_fk = ?";
    const query_updateQuotationStatus =
      "UPDATE quotation_details SET quotation_status = 'Submitted' WHERE quotation_id = ?";

    // get quotation details from quotation table
    await db.query(
      query_getQuotationHome,
      [quotation_id],
      async (errorQuote, resultQuote) => {
        if (errorQuote) {
          console.log(errorQuote);
        } else {
          const quotation_type = resultQuote[0].quotation_type;

          // get client details from client table
          await db.query(
            query_getClientDetail,
            [quotation_id],
            async (errorClient, resultClient) => {
              if (errorClient) {
                console.log(errorClient);
              } else {
                const client_id = resultClient[0].client_id;

                // get important question id from important question table
                await db.query(
                  query_getIQHome,
                  [quotation_id],
                  async (errorIQ, resultIQ) => {
                    if (errorIQ) {
                      console.log(errorIQ);
                    } else {
                      const importantQuestion_id =
                        resultIQ[0].important_questions_id;

                      // get policy core details from policy core table
                      await db.query(
                        query_getPolicycoreHome,
                        [quotation_id],
                        async (errorPolicy, resultPolicy) => {
                          if (errorPolicy) {
                            console.log(errorPolicy);
                          } else {
                            const policyCore_id =
                              resultPolicy[0].policy_core_id;

                            const data = {
                              Id: quotation_id,
                              InsType: quotation_type,
                              ImpQuesId: importantQuestion_id,
                              ClientId: client_id,
                              PolicyCId: policyCore_id,
                              VehicleInfoId: "",
                            };

                            // send data using sendDataUiPath emthod
                            await sendDataUIPath(data);
                            await db.query(query_updateQuotationStatus, 
                                [quotation_id], 
                                async (errorUpdateQuote, resultUpdateQuote) => {
                                    if(errorUpdateQuote){
                                        console.log(errorUpdateQuote);
                                    } else {
                                        console.log('submitted to UiPath');
                                        console.log(resultUpdateQuote);

                                        res.send(true);
                                    }
                                })
                          }
                        }
                      );
                    }
                  }
                );
              }
            }
          );
        }
      }
    );
  } else {
    response.send({ message: "You are not authenticated" });
  }
};

// method to send UIPath queue data
const sendDataUIPath = async (data) => {
    console.log(data);
    await axios
      .post(
        `https://account.uipath.com/oauth/token`,
        {
          grant_type: "refresh_token",
          client_id: "8DEv1AMNXczW3y4U15LL3jYf62jK93n5",
          refresh_token: "2eE9eRwrnHGImkc6y5D-TGsmoyZr7DTB12jUS9Ikru3tS",
        },
        {
          headers: {
            "Content-Type": "application/json",
            "X-UIPATH-TenantName": "Default",
          },
        }
      )
      .then(async (res) => {
        //console.log(res);
        console.log(`Data sent successfully to uiPath`);
        var currentDate = new Date();
        await axios
          .post(
            `https://cloud.uipath.com/anjngyxrpczi/Default/orchestrator_/odata/Queues/UiPathODataSvc.AddQueueItem`,
  
            {
              itemData: {
                Name: "Approved_IDA",
                Priority: "High",
                SpecificContent: {
                  Id: data.Id,
                  InsType: data.InsType,
                  ImpQuesId: data.ImpQuesId,
                  ClientId: data.ClientId,
                  PolicyCId: data.PolicyCId,
                  VehicleInfoId: data.VehicleInfoId,
                },
                Reference: "" + data.Id + " => " + currentDate.toString(),
              },
            },
            {
              headers: {
                Authorization: "Bearer " + res.data.access_token,
                "Content-Type": "application/json",
                "X-UIPATH-TenantName": "Default",
                Accept: "application/json",
                "X-UIPATH-OrganizationUnitId": "2592424",
              },
            }
          )
          .then((res) => {
            console.log(res.data.SpecificContent);
            console.log("Success");
          })
          .catch((err) => {
            console.log(err);
          });
      })
      .catch((err) => {
        console.log(err);
      });
  };
  
