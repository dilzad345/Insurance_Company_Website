const express = require("express");
const app = express();
const mysql = require("mysql");
const bodyParser = require("body-parser");
const cors = require("cors");
const bcrypt = require("bcrypt");
const saltRounds = 10;
const jwt = require("jsonwebtoken");
const catchAsync = require("../utils/catchAsync");

const db = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "root",
  port: 3306,
  database: "ida_db_vm",
});

// login method with hashed password
exports.signin = (req, res, next) => {
  // console.log(req);
  // const userEmail = req.body.userEmail;
  const userEmail = req.body.usermail;
  // const userPassword = req.body.userPassword;
  const userPassword = req.body.password;
  const query_getUser = "SELECT * FROM user WHERE user_email = ?";

  db.query(query_getUser, userEmail, (err, result) => {
    //console.log('result count: ' + result.length)
    if (err) {
      console.log(err);
    } else if (result.length > 0) {
      //console.log('db password: ' + result[0].password + ' fr password: ' + userPassword + ' uemail: ' + result[0].user_email);
      bcrypt.compare(userPassword, result[0].password, (error, rslt) => {
        if (rslt) {
          // res.send(result);
          // console.log(result[0]);
          const db_name =
            result[0].user_first_name + " " + result[0].user_last_name;
          const db_email = result[0].user_email;
          const db_jobTitle = result[0].job_title;
          const token = jwt.sign({ db_email }, "jwtSecret_IDA" , {expiresIn : "1d"});

          res.json({
            auth: true,
            token: token,
            user: { name: db_name, email: db_email, job_title: db_jobTitle },
          });
        } else {
          res.send({
            auth: false,
            message: "wrong user email and password compination",
          });
        }
      });
    } else {
      res.send({ auth: false, message: "user does not exist" });
    }
  });
}; // end of sign in

// post method of add user to the db
exports.addUser = (req, res, next) => {
  console.log(req.body);
  const data = req.body;

  bcrypt.hash(data.password, saltRounds, (err, hashedPassword) => {
    const query_userInsert =
      "INSERT INTO user(user_email, password) VALUES (?, ?); ";

    db.query(
      query_userInsert,
      [data.userEmail, hashedPassword],
      (err, result) => {
        if (err) {
          console.log(err);
        } else {
          res.send(result); // rwturn to the front end
        }
      }
    );
  });
}; // end of add user method

//add user through Dashboard
exports.adminAddUser = (req, res, next) => {
  console.log(req.body);
  const data = req.body;

  bcrypt.hash(data.password, saltRounds, (err, hashedPassword) => {
    const query_userInsert =
      "INSERT INTO user(user_email, user_first_name, user_last_name, password, job_title) VALUES (?, ?, ?, ?, ?); ";

    db.query(
      query_userInsert,
      [
        data.userEmail,
        data.firstName,
        data.lastName,
        hashedPassword,
        data.userRole,
      ],
      (err, result) => {
        if (err) {
          console.log(err);
        } else {
          res.send(result); // rwturn to the front end
        }
      }
    );
  });
}; // end of add user method

const verifyJWT = (req, res, next) => {
  const token = req.headers["access-token"];

  if (!token) {
    res.send({ auth: false, message: "token is missing.." });
  } else {
    jwt.verify(token, "jwtSecret_IDA", (err, decoded) => {
      if (err) {
        res.json({ auth: false, message: "you failed to authenticae.." });
      } else {
        req.userId = decoded.id;
        next();
      }
    });
  }
};

// GET method to verify authenticated user
app.get("/isAuthenticated", verifyJWT, (req, res) => {
  res.send({ auth: true, message: "you are authenticated" });
});

exports.isAuthenticated = (req, res, next) => {
  const token = req.headers["access-token"];

  if (!token) {
    res.send({ auth: false, message: "token is missing.." });
  } else {
    jwt.verify(token, "jwtSecret_IDA", (err, decoded) => {
      if (err) {
        console.log(err);
        res.json({ auth: false, message: "you failed to authenticae.." });
      } else {
        req.userId = decoded.id;
        res.send({ auth: true, message: "you are authenticated" });
      }
    });
  }
};

// // sign out
// app.get('/signout', (req, res) => {
//     res.send({auth: false});
// })

exports.signOut = (req, res, next) => {
  res.send({ auth: false });
};
