// const jwt = require("jsonwebtoken");
const db = require("../models/db");
const catchAsync = require("../utils/catchAsync");
const verifyToken = require("../auth/VerifyToken");
// const verifyToken = async (token) => {
//   //console.log(token);
//   if (!token) {
//     return false;
//   } else {
//     return jwt.verify(token, "jwtSecret_IDA", (err, decoded) => {
//       if (err) {
//         return false;
//       } else {
//         return true;
//       }
//     });
//   }
// };

//getting Home quotation details with quotation id.
exports.getQuotationHomeDetails = async (req, response, next) => {
  //const id=req.headers.id;
  const query_getHomeQuotation =
    "select * from quotation_details where quotation_details.quotation_type='Home' and quotation_id =?";

  const query_getHomeClient =
    "select * from client_home where quotaion_id_fk=?";

  const query_getHomeImportantQuestion =
    "select * from important_questions_home where quotation_id_fk=?";

  const query_getHomeClaims =
    "select * from claims where quotation_id_fk=?";

  const query_getHomeContents =
    "select * from contents where quotation_id_fk=?";

  const query_getHomePolicy =
    "select * from policy_core_home where quotation_id_fk=?";

  const query_getHomeBuildings =
    "select * from building_details where quotation_id_fk=?";


  let HomeQuotationId = req.query.quotationHomeId;
  try {   //For error handling try-catch with async/await has been used.
    await db.query(query_getHomeQuotation, HomeQuotationId, async (err, result) => {
      try {
        if (result.length == 0) {
          response.send({ message: 'Invalid Request' });
        }
        else {
          await db.query(query_getHomeClient, HomeQuotationId, async (err, resultForHomeClient) => {
            try {
              await db.query(query_getHomeImportantQuestion, HomeQuotationId, async (err, resultForIQ) => {
                try {
                  await db.query(query_getHomeClaims, HomeQuotationId, async (err, resultForClaim) => {
                    try {
                      await db.query(query_getHomeContents, HomeQuotationId, async (err, resultForContents) => {
                        try {
                          await db.query(query_getHomePolicy, HomeQuotationId, async (err, resultForPolicy) => {
                            try {
                              await db.query(query_getHomeBuildings, HomeQuotationId, async (err, resultForBuildings) => {
                                try {
                                  const quotationDetail = {
                                    HomeBuildings: resultForBuildings[0],
                                    HomePolicy: resultForPolicy[0],
                                    HomeContents: resultForContents[0],
                                    HomeClaim: resultForClaim[0],
                                    HomeIQ: resultForIQ[0],
                                    HomeClient: resultForHomeClient[0],  //here many client has same quotation that's why did not put [0] sign.
                                    getHomeQuotation: result[0],
                                  }
                                  response.send(quotationDetail);
                                }
                                catch (err) {
                                  response.send({ error: err, message: err.message });
                                }
                              });
                            }
                            catch (err) {
                              response.send({ error: err, message: err.message });
                            }
                          });
                        }
                        catch (err) {
                          response.send({ error: err, message: err.message });
                        }
                      });
                    }
                    catch (err) {
                      response.send({ error: err, message: err.message });
                    }
                  });
                }
                catch (err) {
                  response.send({ error: err, message: err.message });
                }
              });
            }
            catch (err) {
              response.send({ error: err, message: err.message });
            }
          });
        }
      }
      catch (err) {
        response.send({ error: err, message: err.message });
      }
    });
  }

  catch (err) {
    response.send({ error: err, message: err.message });
  }
}

//update Home quotation Details for specific quotation.
exports.updateHomeQuotations = async (req, res, next) => {
  //query for updating clients for home quotation
  const query_UpdateHomeClient =
    "UPDATE client_home SET client_type=?,client_title=?,client_firstName=?," +
    "client_lastName=?,company_name=?,trading_as=?,reference_code=?,unit_number_postal=?," +
    "street_number_postal=?,street_name_postal=?,street_type_postal=?,suburb_postal=?,state_postal=?,postcode_postal=?," +
    "phone=?,email=?,branch=?,sales_team=?,service_team=?,unit_number_insured=?," +
    "street_number_insured=?,street_name_insured=?,street_type_insured=?,suburb_insured=?,state_insured=?," +
    "postcode_insured=?,holding_insurer=?,stamp_dutyExemption=?,user_email_fk=? WHERE quotaion_id_fk=?;"; //28 params

  //query for updating Important questions for home quotation
  const query_UpdateHomeIQ =
    "UPDATE important_questions_home SET any_policy_declined_last5years=?," +
    "claim_decline=?,criminal_conviction_last5years=?,under_construction_renovation=?," +
    "bankruptcy=?,has_flooded_last10_years=? WHERE quotation_id_fk=?;";

  //query for updating policy for home quotation
  const query_UpdateHomePolicy =
    "UPDATE policy_core_home SET cover_type=?,basis_settlement=?," +
    "building_contents=?, building_sum_insured=?,contents_insuredAmount=?," +
    "policy_fromDate=?,policy_toDate=?,dob_oldestInsured=?,industry_policyholder=?," +
    "policyholder_retired=?,business_conducted_from_home=?,ifYes_business_name=?,ifYes_business_type=?," +
    "ifYes_annual_revenue=?,ifYes_occupy_more_than_20_area=?,under_construction=?," +
    "poor_condition_maintained=?,unoccupied_90_days=?,hostel_brekfast_bed_guesthouse=?," +
    "community_public_housing=?,hold_insurance=?,interested_parties=?," +
    "jetty_attached_property=?,excess_option1=?,excess_option2=?,excess_option3=?," +
    "broker_fee=?,payment_frequncy=?,preferred_day_Installment=?,broker_free_Installment=?" +
    "WHERE quotation_id_fk=?;";

  //query for updating building details for home quotation
  const query_UpdateBuildings =
    "UPDATE building_details SET property_heritage_list=?,if_heriageList_moreDetails=?," +
    "home_occupancy=?,building_type=?,if_free_standing_whats_built=?," +
    "if_apartment_appartment_type=?,if_semi_detached_type=?,if_semi_detached_strata_manage=?," +
    "if_other_dwelling_describe_home=?,exceed_20k_mkm_2hect_5acres=?,if_exceed_insured_generate_income=?," +
    "if_exceed_farm_building_machinery=?,if_exceed_moreThan_6_liveStock=?," +
    "if_exceed_used_agisment_peoples_animals=?,if_exceed_horses_nonPersonal_use=?," +
    "if_exceed_aircrapt_landing_strip=?,construction_period=?,year_built=?,construction_walls=?," +
    "roof_construction=?,construction_quality=?,storeys_number=?,unit_buildingLevel=?," +
    "house_250m_waterCourse=?,water_supply=?,window_security=?,door_security=?," +
    "burglar_alarm=?,smoke_detector=?,construction_12_months=?,swimming_pool=?," +
    "Building_located_ground_level=?,mitigation_measures_property=?,occupency_certification=?" +
    "WHERE quotation_id_fk=?;";

  //query for updating contents for home quotation
  const query_UpdateHomeContents =
    "UPDATE contents SET type=?,category=?,description=?,value=? WHERE quotation_id_fk=?;";

  //query for updating claims details for home quotation
  const query_UpdateHomeClaims =
    "UPDATE claims SET claim_amount=?, claim_last_5_years=?,date_claim=?," +
    "claim_description=?  WHERE quotation_id_fk=?;";

  //query for updating quotation status for home
  const query_UpdateHomeQuotationStatus =
    "UPDATE quotation_details SET quotation_status='Verified' WHERE quotation_id=?";

  //select total quotation ids fromquotation table
  const query_QuotationId = "SELECT quotation_id FROM quotation_details WHERE quotation_id=?;";


  const homeClientTable = req.body;
  const homeIQ = req.body;
  const homePolicy = req.body;
  const homeBuildingTable = req.body;
  const homeContentstable = req.body;
  const homeClaimsTable = req.body;
  const homeQuotationId = req.params.id;

  try {
    await db.query(query_QuotationId, homeQuotationId, async (err, result) => {
      if (err) {
        return res.send({ error: err });
      }
      if (result.length === 0) {
        return res.send({ message: `Requested quotation is not valid.` });
      }
      else {
        await db.query(query_UpdateHomeClient,
          [homeClientTable.client_type,
          homeClientTable.client_title,
          homeClientTable.client_firstName,
          homeClientTable.client_lastName,
          homeClientTable.company_name,
          homeClientTable.trading_as, homeClientTable.reference_code,
          homeClientTable.unit_number_postal, homeClientTable.street_number_postal, homeClientTable.street_name_postal,
          homeClientTable.street_type_postal,
          homeClientTable.suburb_postal, homeClientTable.state_postal, homeClientTable.postcode_postal,
          homeClientTable.phone, homeClientTable.email, homeClientTable.branch, homeClientTable.sales_team,
          homeClientTable.service_team, homeClientTable.unit_number_insured,
          homeClientTable.street_number_insured, homeClientTable.street_name_insured, homeClientTable.street_type_insured,
          homeClientTable.suburb_insured, homeClientTable.state_insured,
          homeClientTable.postcode_insured, homeClientTable.holding_insurer, homeClientTable.stamp_dutyExemption,
          homeClientTable.user_email_fk, homeQuotationId
          ], async (err, resultHomeClient) => {

            if (err) {
              return res.send({ message: err });
            }
            else {

              try {
                //console.log(resultHomeClient);
                await db.query(query_UpdateHomeIQ,
                  [homeIQ.any_policy_declined_last5years,
                  homeIQ.claim_decline, homeIQ.criminal_conviction_last5years,
                  homeIQ.under_construction_renovation, homeIQ.bankruptcy,
                  homeIQ.has_flooded_last10_years, homeQuotationId], async (err, resultHomeIQ) => {
                    if (err) {
                      return res.send({ message: err });
                    }
                    else {
                      try {
                        await db.query(query_UpdateHomePolicy,
                          [homePolicy.cover_type,
                          homePolicy.basis_settlement,
                          homePolicy.building_contents,
                          homePolicy.building_sum_insured,
                          homePolicy.contents_insuredAmount,
                          homePolicy.policy_fromDate,
                          homePolicy.policy_toDate,
                          homePolicy.dob_oldestInsured,
                          homePolicy.industry_policyholder,
                          homePolicy.policyholder_retired,
                          homePolicy.business_conducted_from_home,
                          homePolicy.ifYes_business_name,
                          homePolicy.ifYes_business_type,
                          homePolicy.ifYes_annual_revenue,
                          homePolicy.ifYes_occupy_more_than_20_area,
                          homePolicy.under_construction,
                          homePolicy.poor_condition_maintained,
                          homePolicy.unoccupied_90_days,
                          homePolicy.hostel_brekfast_bed_guesthouse,
                          homePolicy.community_public_housing,
                          homePolicy.hold_insurance,
                          homePolicy.interested_parties,
                          homePolicy.jetty_attached_property,
                          homePolicy.excess_option1,
                          homePolicy.excess_option2,
                          homePolicy.excess_option3,
                          homePolicy.broker_fee,
                          homePolicy.payment_frequncy,
                          homePolicy.preferred_day_Installment,
                          homePolicy.broker_free_Installment, homeQuotationId], async (err, resultHomePolicy) => {
                            if (err) {
                              return res.send({ error: err });
                            }
                            else {
                              try {
                                await db.query(query_UpdateBuildings, [
                                  homeBuildingTable.property_heritage_list,
                                  homeBuildingTable.if_heriageList_moreDetails,
                                  homeBuildingTable.home_occupancy,
                                  homeBuildingTable.building_type,
                                  homeBuildingTable.if_free_standing_whats_built,
                                  homeBuildingTable.if_apartment_appartment_type,
                                  homeBuildingTable.if_semi_detached_type,
                                  homeBuildingTable.if_semi_detached_strata_manage,
                                  homeBuildingTable.if_other_dwelling_describe_home,
                                  homeBuildingTable.exceed_20k_mkm_2hect_5acres,
                                  homeBuildingTable.if_exceed_insured_generate_income,
                                  homeBuildingTable.if_exceed_farm_building_machinery,
                                  homeBuildingTable.if_exceed_moreThan_6_liveStock,
                                  homeBuildingTable.if_exceed_used_agisment_peoples_animals,
                                  homeBuildingTable.if_exceed_horses_nonPersonal_use,
                                  homeBuildingTable.if_exceed_aircrapt_landing_strip,
                                  homeBuildingTable.construction_period,
                                  homeBuildingTable.year_built,
                                  homeBuildingTable.construction_walls,
                                  homeBuildingTable.roof_construction,
                                  homeBuildingTable.construction_quality,
                                  homeBuildingTable.storeys_number,
                                  homeBuildingTable.unit_buildingLevel,
                                  homeBuildingTable.house_250m_waterCourse,
                                  homeBuildingTable.water_supply,
                                  homeBuildingTable.window_security,
                                  homeBuildingTable.door_security,
                                  homeBuildingTable.burglar_alarm,
                                  homeBuildingTable.smoke_detector,
                                  homeBuildingTable.construction_12_months,
                                  homeBuildingTable.swimming_pool,
                                  homeBuildingTable.Building_located_ground_level,
                                  homeBuildingTable.mitigation_measures_property,
                                  homeBuildingTable.occupency_certification, homeQuotationId
                                ], async (err, resultBuilding) => {
                                  if (err) {
                                    return res.send({ error: err });
                                  }
                                  else {

                                    try {
                                      await db.query(query_UpdateHomeContents, [
                                        homeContentstable.type,
                                        homeContentstable.category,
                                        homeContentstable.description,
                                        homeContentstable.value, homeQuotationId
                                      ], async (err, resultHomeContents) => {
                                        if (err) {
                                          return res.send({ error: err });
                                        }
                                        else {
                                          try {
                                            await db.query(query_UpdateHomeClaims, [
                                              homeClaimsTable.claim_amount,
                                              homeClaimsTable.claim_last_5_years,
                                              homeClaimsTable.date_claim,
                                              homeClaimsTable.claim_description, homeQuotationId
                                            ], async (err, resultHomeClaims) => {
                                              if (err) {
                                                return res.send({ error: err });
                                              }
                                              else {
                                                try {
                                                  await db.query(query_UpdateHomeQuotationStatus, [homeQuotationId],
                                                    async (err, resultHomeQuotationupdate) => {
                                                      if (err) {
                                                        return res.send({ error: err });
                                                      }
                                                      else {
                                                        return res.send({ message: "Quotation is verified" });
                                                      }
                                                    })
                                                }
                                                catch (err) {
                                                  return res.send({ error: err, message: err.message });
                                                }
                                              }
                                            })
                                          }
                                          catch (err) {
                                            return res.send({ error: err, message: err.message });
                                          }
                                        }
                                      })
                                    }
                                    catch {
                                      return res.send({ error: err, message: err.message });
                                    }
                                  }
                                })
                              }
                              catch (err) {
                                return res.send({ error: err, message: err.message });
                              }
                            }
                          })

                      }
                      catch (err) {
                        return res.send({ error: err, message: err.message });
                      }
                    }
                  });
              }
              catch (err) {
                return res.send({ error: err, message: err.message });
              }
            }
          })
      }
    });

  }
  catch (err) {
    return res.send({ error: err, message: err.message });
    //return res.status(201).json({error :`${err.message}`})
  }
}


//insert information into Home Quotation
exports.insertHomeQuotations = async (req, res, next) => {
  const query_insertQuotationHome =
    "INSERT INTO quotation_details (quotation_type,quotation_status) VALUES('Home','Pending')";

  const query_insertClientDetails =
    "INSERT INTO client_home (quotaion_id_fk,client_type,client_title,client_firstName," +
    "client_lastName,company_name,trading_as,reference_code,unit_number_postal,street_number_postal," +
    "street_name_postal,street_type_postal,suburb_postal,state_postal,postcode_postal,phone,email,branch," +
    "sales_team,service_team,unit_number_insured,street_number_insured,street_name_insured," +
    "street_type_insured,suburb_insured,state_insured,postcode_insured,holding_insurer," +
    "stamp_dutyExemption,user_email_fk) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,null)";

  const query_importantquestionsforHome =
    "INSERT INTO important_questions_home (quotation_id_fk,any_policy_declined_last5years," +
    "claim_decline,criminal_conviction_last5years,under_construction_renovation,bankruptcy," +
    "has_flooded_last10_years) VALUES (?,?,?,?,?,?,?)";

  const query_insertBuildingDetails =
    "INSERT INTO building_details (quotation_id_fk,property_heritage_list," +
    "if_heriageList_moreDetails,home_occupancy,building_type,if_free_standing_whats_built," +
    "if_apartment_appartment_type,if_semi_detached_type,if_semi_detached_strata_manage," +
    "if_other_dwelling_describe_home,exceed_20k_mkm_2hect_5acres,if_exceed_insured_generate_income," +
    "if_exceed_farm_building_machinery,if_exceed_moreThan_6_liveStock,if_exceed_used_agisment_peoples_animals," +
    "if_exceed_horses_nonPersonal_use,if_exceed_aircrapt_landing_strip,construction_period, year_built," +
    "construction_walls,roof_construction,construction_quality,storeys_number,unit_buildingLevel," +
    "house_250m_waterCourse,water_supply,window_security,door_security,burglar_alarm,smoke_detector," +
    "construction_12_months,swimming_pool,Building_located_ground_level,mitigation_measures_property," +
    "occupency_certification) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?," +
    "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

  const query_insertPolicyCoreHomeDetails =
    "INSERT INTO policy_core_home(quotation_id_fk,cover_type,basis_settlement,building_contents," +
    "building_sum_insured,contents_insuredAmount,policy_fromDate,policy_toDate,dob_oldestInsured," +
    "industry_policyholder,policyholder_retired,business_conducted_from_home,ifYes_business_name," +
    "ifYes_business_type,ifYes_annual_revenue,ifYes_occupy_more_than_20_area,under_construction," +
    "poor_condition_maintained,unoccupied_90_days,hostel_brekfast_bed_guesthouse,community_public_housing," +
    "hold_insurance,interested_parties,jetty_attached_property,excess_option1,excess_option2,excess_option3," +
    "broker_fee,payment_frequncy,preferred_day_Installment,broker_free_Installment) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?," +
    "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

  const query_inserthomeContents =
    "INSERT INTO contents(quotation_id_fk,type,category,description,value) VALUES(?,?,?,?,?)";

  const query_inserthomeClaims =
    "INSERT INTO claims(quotation_id_fk,claim_last_5_years,date_claim,claim_description,claim_amount) VALUES(?,?,?,?,?)";

  const homeClientTable = req.body;
  const homeIqtable = req.body;
  const policycorehomeTable = req.body;
  const homeBuildingTable = req.body;
  const homecontentsTable = req.body;
  const homeClaimsTable = req.body;
  try {
    await db.query(query_insertQuotationHome, async (err, homequotationDetails) => {
      if (err) {
        return res.send({ message: err });
      }
      else {
        //return res.send({ id:homequotationresult.insertId });
        let homeQuotationId = homequotationDetails.insertId;
        try {
          await db.query(query_insertClientDetails,
            [homeQuotationId,
              homeClientTable.client_type,
              homeClientTable.client_title,
              homeClientTable.client_firstName,
              homeClientTable.client_lastName,
              homeClientTable.company_name,
              homeClientTable.trading_as,
              homeClientTable.reference_code,
              homeClientTable.unit_number_postal,
              homeClientTable.street_number_postal,
              homeClientTable.street_name_postal,
              homeClientTable.street_type_postal,
              homeClientTable.suburb_postal,
              homeClientTable.state_postal,
              homeClientTable.postcode_postal,
              homeClientTable.phone,
              homeClientTable.email,
              homeClientTable.branch,
              homeClientTable.sales_team,
              homeClientTable.service_team,
              homeClientTable.unit_number_insured,
              homeClientTable.street_number_insured,
              homeClientTable.street_name_insured,
              homeClientTable.street_type_insured,
              homeClientTable.suburb_insured,
              homeClientTable.state_insured,
              homeClientTable.postcode_insured,
              homeClientTable.holding_insurer,
              homeClientTable.stamp_dutyExemption,
            ],
            async (err, homeclientdetails) => {
              if (err) {
                return res.send({ message: err });
              }
              else {

                try {
                  await db.query(query_importantquestionsforHome,
                    [
                      homeQuotationId,
                      homeIqtable.any_policy_declined_last5years,
                      homeIqtable.claim_decline,
                      homeIqtable.criminal_conviction_last5years,
                      homeIqtable.under_construction_renovation,
                      homeIqtable.bankruptcy,
                      homeIqtable.has_flooded_last10_years
                    ],
                    async (err, importantquestionsdetails) => {
                      if (err) {
                        return res.send({ message: err });
                      }
                      else {

                        try {
                          await db.query(query_insertPolicyCoreHomeDetails,
                            [
                              homeQuotationId,
                              policycorehomeTable.cover_type,
                              policycorehomeTable.basis_settlement,
                              policycorehomeTable.building_contents,
                              policycorehomeTable.building_sum_insured,
                              policycorehomeTable.contents_insuredAmount,
                              policycorehomeTable.policy_fromDate,
                              policycorehomeTable.policy_toDate,
                              policycorehomeTable.dob_oldestInsured,
                              policycorehomeTable.industry_policyholder,
                              policycorehomeTable.policyholder_retired,
                              policycorehomeTable.business_conducted_from_home,
                              policycorehomeTable.ifYes_business_name,
                              policycorehomeTable.ifYes_business_type,
                              policycorehomeTable.ifYes_annual_revenue,
                              policycorehomeTable.ifYes_occupy_more_than_20_area,
                              policycorehomeTable.under_construction,
                              policycorehomeTable.poor_condition_maintained,
                              policycorehomeTable.unoccupied_90_days,
                              policycorehomeTable.hostel_brekfast_bed_guesthouse,
                              policycorehomeTable.community_public_housing,
                              policycorehomeTable.hold_insurance,
                              policycorehomeTable.interested_parties,
                              policycorehomeTable.jetty_attached_property,
                              policycorehomeTable.excess_option1,
                              policycorehomeTable.excess_option2,
                              policycorehomeTable.excess_option3,
                              policycorehomeTable.broker_fee,
                              policycorehomeTable.payment_frequncy,
                              policycorehomeTable.preferred_day_Installment,
                              policycorehomeTable.broker_free_Installment
                            ],
                            async (err, policycorehomeDetails) => {
                              if (err) {
                                return res.send({ message: err });
                              }
                              else {
                                try {
                                  await db.query(query_insertBuildingDetails,
                                    [
                                      homeQuotationId,
                                      homeBuildingTable.property_heritage_list,
                                      homeBuildingTable.if_heriageList_moreDetails,
                                      homeBuildingTable.home_occupancy,
                                      homeBuildingTable.building_type,
                                      homeBuildingTable.if_free_standing_whats_built,
                                      homeBuildingTable.if_apartment_appartment_type,
                                      homeBuildingTable.if_semi_detached_type,
                                      homeBuildingTable.if_semi_detached_strata_manage,
                                      homeBuildingTable.if_other_dwelling_describe_home,
                                      homeBuildingTable.exceed_20k_mkm_2hect_5acres,
                                      homeBuildingTable.if_exceed_insured_generate_income,
                                      homeBuildingTable.if_exceed_farm_building_machinery,
                                      homeBuildingTable.if_exceed_moreThan_6_liveStock,
                                      homeBuildingTable.if_exceed_used_agisment_peoples_animals,
                                      homeBuildingTable.if_exceed_horses_nonPersonal_use,
                                      homeBuildingTable.if_exceed_aircrapt_landing_strip,
                                      homeBuildingTable.construction_period,
                                      homeBuildingTable.year_built,
                                      homeBuildingTable.construction_walls,
                                      homeBuildingTable.roof_construction,
                                      homeBuildingTable.construction_quality,
                                      homeBuildingTable.storeys_number,
                                      homeBuildingTable.unit_buildingLevel,
                                      homeBuildingTable.house_250m_waterCourse,
                                      homeBuildingTable.water_supply,
                                      homeBuildingTable.window_security,
                                      homeBuildingTable.door_security,
                                      homeBuildingTable.burglar_alarm,
                                      homeBuildingTable.smoke_detector,
                                      homeBuildingTable.construction_12_months,
                                      homeBuildingTable.swimming_pool,
                                      homeBuildingTable.Building_located_ground_level,
                                      homeBuildingTable.mitigation_measures_property,
                                      homeBuildingTable.occupency_certification

                                    ]
                                    , async (err, homeBuildingDetails) => {
                                      if (err) {
                                        return res.send({ message: err });
                                      }
                                      else {
                                        //return res.send({ message: `Succesfully Inserted building details` })
                                        try {
                                          await db.query(query_inserthomeContents,
                                            [
                                              homeQuotationId,
                                              homecontentsTable.type,
                                              homecontentsTable.category,
                                              homecontentsTable.description,
                                              homecontentsTable.value
                                            ],
                                            async (err, homecontentsDetails) => {
                                              if (err) {
                                                return res.send({ message: err });
                                              }
                                              else {
                                                //
                                                try {
                                                  await db.query(query_inserthomeClaims,
                                                    [
                                                      homeQuotationId,
                                                      homeClaimsTable.claim_last_5_years,
                                                      homeClaimsTable.date_claim,
                                                      homeClaimsTable.claim_description,
                                                      homeClaimsTable.claim_amount
                                                    ],
                                                    async (err, homeClaimsDetails) => {
                                                      if (err) {
                                                        return res.send({ message: err });
                                                      }
                                                      else {
                                                        return res.send({ message: `Your Quotation for home is inserted successfully` });
                                                      }
                                                    })
                                                }
                                                catch (err) {
                                                  return res.send({ message: err });
                                                }
                                              }
                                            })
                                        }
                                        catch (err) {
                                          return res.send({ error: err, message: err.message });
                                        }
                                      }
                                    })
                                }
                                catch (err) {
                                  return res.send({ error: err, message: err.message });
                                }
                              }
                            })
                        }
                        catch (err) {
                          return res.send({ error: err, message: err.message });
                        }
                      }
                    });
                }
                catch (err) {
                  return res.send({ error: err, message: err.message });
                }
              }
            })
        }
        catch (err) {
          return res.send({ error: err, message: err.message });
        }
      }
    })
  }
  catch (err) {
    return res.send({ error: err, message: err.message });
  }
};





//1.To get quotation by category for home
exports.getQuotationsHome = async (req, response, next) => {
  const token = req.headers.token;
  // console.log("access: ", verifyToken(token));
  if (await verifyToken(token)) {
    const user_email = req.query.userEmail;
    const query_getQuotations =
      "select * from quotation_details, client_home" +
      " where quotation_details.quotation_id = client_home.quotaion_id_fk" +
      " and (quotation_details.quotation_status = 'Pending' or " +
      "quotation_details.quotation_status = 'Verified' or quotation_details.quotation_status = 'submitted')" +
      "ORDER BY quotation_details.quotation_id DESC";

    const pending_quotation =
      "SELECT COUNT(quotation_status) AS pendingCount FROM quotation_details, client_home" +
      " where quotation_details.quotation_status='Pending'" +
      " AND quotation_details.quotation_id = client_home.quotaion_id_fk";


    const verified_quotation =
      "SELECT COUNT(quotation_status) AS verifiedCount FROM quotation_details, client_home" +
      " where quotation_details.quotation_status='Verified'" +
      " AND quotation_details.quotation_id = client_home.quotaion_id_fk";

    const submitted_quotation =
      "SELECT COUNT(quotation_status) AS submittedCount FROM quotation_details, client_home" +
      " where quotation_details.quotation_status='Submitted'" +
      " AND quotation_details.quotation_id = client_home.quotaion_id_fk";

    // execute query on database and send the response
    //await db.query(query_getQuotations,[user_email], async(err, result) => {
    await db.query(query_getQuotations, [], async (err, result) => {
      if (err) {
        console.log("Error 1: ", err.message);
      } else {
        // console.log(result);
        await db.query(
          verified_quotation, [], async (err, verifiedCountResult) => {
            if (err) {
              console.log("Error2: ", err.message);
            } else {
              //console.log(result);

              // console.log(verifiedCountResult);
              await db.query(pending_quotation, [], async (err, pendingCountResult) => {
                if (err) {
                  console.log("Error 3:", err.message);
                } else {
                  //console.log(result);
                  //console.log(pendingCountResult[0]);
                  /* const quotationDetail = {
                    verifiedQuotation: verifiedCountResult,
                    pendingQuotation: pendingCountResult,
                    getQuotation: result,
                  };
                  response.send(quotationDetail); */
                  await db.query(submitted_quotation, [], async (errSubmit, submitCount) => {
                    if (errSubmit) {
                      console.log("Error 4: ", errSubmit);
                    }
                    else {
                      const quotationDetail = {
                        verifiedQuotation: verifiedCountResult,
                        pendingQuotation: pendingCountResult,
                        submittedQuotation: submitCount,
                        getQuotation: result,
                      }
                      response.send(quotationDetail);
                    }
                  })
                  //console.log(quotationDetail[0]);
                }
              }
              );
              // response.send(dataQuotation);
            }
          }
        );
        //response.send(query_getQuotations);
      }
    });
  } else {
    response.send({ message: "You are not authenticated" });
  }
};

//2.To get quotation details by quotation id
exports.getQuotationDetail = async (req, response, next) => {

  const quotationId = req.query.quotationId;
  const token = req.headers.token;
  // console.log("access2: ", verifyToken(token));
  if (await verifyToken(token)) {
    const query_getQuotationDetail = "SELECT * FROM quotation_details WHERE quotation_id = ?";

    const query_getClientDetail = "SELECT * FROM client_home WHERE quotaion_id_fk = ?";

    const query_getImportantQuestionDetail = "SELECT * FROM important_questions_home WHERE quotation_id_fk = ?";

    const query_getPolicyCoreDetail = "SELECT * FROM policy_core_home WHERE quotation_id_fk = ?";

    const query_getHomeBuildings = "select * from building_details where quotation_id_fk=?";

    const query_getHomeContents = "select * from contents where quotation_id_fk=?";

    const query_getClaimDetails = "SELECT * FROM claims WHERE quotation_id_fk = ?";


    await db.query(query_getQuotationDetail, [quotationId], async (errorQuote, resultQuote) => {
      if (errorQuote) {
        response.status(500).json({
          status: "failed",
        });
      } else {
        console.log("quotation: ", resultQuote[0]);
        await db.query(query_getClientDetail, [quotationId], async (errorQuote, resultHomeClient) => {
          if (errorQuote) {
            response.status(500).json({
              status: "failed",
            });
          } else {
            console.log("client home: ", resultHomeClient[0]);
            await db.query(query_getImportantQuestionDetail, [quotationId], async (errorQuote, resultForIQ) => {
              if (errorQuote) {
                response.status(500).json({
                  status: "failed",
                });
              }
              else {
                //console.log("IQ home: ", resultForIQ[0]);
                await db.query(query_getPolicyCoreDetail, [quotationId], async (errorQuote, resultForPolicy) => {
                  if (errorQuote) {
                    response.status(500).json({
                      status: "failed",
                    });
                  }
                  else {
                    //console.log("Policy Core Home: ", resultForPolicy[0]);
                    await db.query(query_getHomeBuildings, [quotationId], async (errorQuote, resultForBuildings) => {
                      if (errorQuote) {
                        response.status(500).json({
                          status: "failed",
                        });
                      }
                      else {
                        //  console.log("Building Home: ", resultForBuildings[0]);
                        await db.query(query_getHomeContents, [quotationId], async (errorQuote, resultForContents) => {
                          if (errorQuote) {
                            response.status(500).json({
                              status: "failed",
                            });
                          }
                          else {
                            // console.log("contents: ", resultForContents);
                            await db.query(query_getClaimDetails, [quotationId], async (errorQuote, resultForClaim) => {
                              if (errorQuote) {
                                response.status(500).json({
                                  status: "failed",
                                });
                              }
                              else {
                                //  console.log("claims: ", resultForClaim);
                                response.status(201).json(
                                  {
                                    status: "success",
                                    data: {
                                      dataClientHome: resultHomeClient[0],
                                      dataImportantQuestionHome: resultForIQ[0],
                                      dataPolicyCoreHome: resultForPolicy[0],
                                      dataBuildingHome: resultForBuildings[0],
                                      dataContentsHome: resultForContents,
                                      dataClaimsHome: resultForClaim,
                                    },
                                  }
                                );

                              }

                            })
                          }
                        })
                      }
                    })
                  }
                })
              }
            })
          }
        })
      }
    }
    );
  } else {
    response.send({ message: "You are not authenticated" });
  }
}; // end of get quotation detail method


//3.Update details
exports.updateHomeQuotations = async (req, response, next) => {
  const data_tab1 = req.body.data_tab1;
  const data_tab2 = req.body.data_tab2;
  const data_tab3 = req.body.data_tab3;
  const data_tab4 = req.body.data_tab4;
  const data_tab5 = req.body.data_tab5;
  const data_tab6 = req.body.data_tab6;
  const quotationId = req.body.quotationId;

  // make queries to perform on database actions
  const query_updateClient =
    "UPDATE client_home SET client_code_home = ?,client_type = ?, client_title = ?, client_firstName = ?, client_lastName = ?, company_name = ?," +
    "trading_as = ?, reference_code = ?, unit_number_postal = ? ,street_number_postal = ? ,street_name_postal = ?," +
    "street_type_postal = ? ,suburb_postal =? ,state_postal =? ,postcode_postal = ?, phone = ? ,email = ? ,branch = ? ," +
    "sales_team = ? ,service_team =? WHERE quotaion_id_fk = ?"

  const query_updateIQ =
    "UPDATE important_questions_home SET any_policy_declined_last5years = ?," +
    "claim_decline = ? ,criminal_conviction_last5years = ?,under_construction_renovation = ?," +
    "bankruptcy = ?, has_flooded_last10_years = ?  WHERE quotation_id_fk = ?";


  const query_updatePolicyCoreHome =
    "UPDATE policy_core_home SET cover_type = ?,basis_settlement = ? ,building_contents = ?,building_sum_insured = ?, " +
    "contents_insuredAmount =? ,policy_fromDate  =?,policy_toDate =?,dob_oldestInsured =?,industry_policyholder =? ," +
    "policyholder_retired = ?, business_conducted_from_home = ? ,ifYes_business_name = ?," +
    "ifYes_business_type =?,ifYes_annual_revenue =? ,ifYes_occupy_more_than_20_area = ?,under_construction =?," +
    "poor_condition_maintained =?,unoccupied_90_days =?,hostel_brekfast_bed_guesthouse =?,community_public_housing = ?," +
    "hold_insurance =?,interested_parties =?,jetty_attached_property =?,excess_option1 =?,excess_option2 =?,excess_option3 =?," +
    "broker_fee =?,payment_frequncy =?, preferred_day_Installment =?, broker_free_Installment =?, unspecified_valuables = ? WHERE quotation_id_fk = ?";

  const query_updateBuilding =
    "UPDATE  building_details SET property_heritage_list =? ,if_heriageList_moreDetails =?,home_occupancy =?," +
    " building_type=?, if_free_standing_whats_built=?, if_apartment_appartment_type=?,if_semi_detached_type =?," +
    " if_semi_detached_strata_manage =?, if_other_dwelling_describe_home=?,exceed_20k_mkm_2hect_5acres =?," +
    "if_exceed_insured_generate_income =?, if_exceed_farm_building_machinery =?,if_exceed_moreThan_6_liveStock =?," +
    "if_exceed_used_agisment_peoples_animals =?,if_exceed_horses_nonPersonal_use =?," +
    "if_exceed_aircrapt_landing_strip =?, construction_period =?, year_built =?, construction_walls =?, roof_construction =?," +
    "construction_quality =?, storeys_number =?, unit_buildingLevel =?, house_250m_waterCourse =?, water_supply =?, window_security =?," +
    "door_security =?, burglar_alarm =?, smoke_detector =?, construction_12_months =?, swimming_pool =?, Building_located_ground_level =?," +
    "mitigation_measures_property =?, occupency_certification =?,  house_reroofed = ? ,house_replumbed = ?, house_rewired = ? WHERE quotation_id_fk = ?";

  const query_updateContents =
    "UPDATE contents SET type = ? ,category = ? ,description = ? ,value = ? WHERE contents_id = ?";

  const query_createContents =
    "INSERT INTO contents (quotation_id_fk ,type ,category ,description ,value)" +
    "VALUES (?,?,?,?,?)";

  const query_deleteContents =
    "DELETE FROM contents WHERE contents_id = ?";

  const query_updateClaims =
    "UPDATE claims SET claim_type = ?, date_claim = ?, claim_description = ?, claim_amount = ? WHERE claim_id= ?"

  const query_createClaims =
    "INSERT INTO claims (quotation_id_fk ,claim_type ,date_claim ,claim_description ,claim_amount)" +
    "VALUES (?,?,?,?,?)";

  const query_deleteClaims =
    "DELETE FROM claims WHERE claim_id = ?";


  const query_updateQuotationStatus =
    "UPDATE quotation_details SET quotation_status = 'Verified' WHERE quotation_id = ?";

  let fromDateTemp = data_tab3.policyFromDate;
  let toDateTemp = data_tab3.policyToDate;

  fromDateTemp = fromDateTemp.substring(0, 10);
  toDateTemp = toDateTemp.substring(0, 10);
  // console.log("From date: ", fromDateTemp);
  try {
    await db.query(query_updateClient, [
      data_tab1.ClientIdForHomeFromUipath,
      data_tab1.clientType,
      data_tab1.title,
      data_tab1.firstName,
      data_tab1.lastName,
      data_tab1.companyName,
      data_tab1.tradingAs,
      data_tab1.officeTechReferenceCode,
      data_tab1.unitNumber,
      data_tab1.streetNumber,
      data_tab1.streetName,
      data_tab1.streetType,
      data_tab1.suburb,
      data_tab1.state,
      data_tab1.postCode,
      data_tab1.phone,
      data_tab1.email,
      data_tab1.branch,
      data_tab1.salesTeam,
      data_tab1.serviceTeam,
      quotationId
    ], async (errorClient, resultClient) => {
      if (errorClient) {
        console.log("Error 2: ", errorClient);
        response.status(500).json({ status: "failed", });
      }
      else {
        // console.log("Successfully updated client data");
        // response.status(201).json({ status: "Successfully updated client data" });
        await db.query(query_updateIQ, [
          data_tab2.insPolcyCancellLast5Years,
          data_tab2.hadClaimDeclained,
          data_tab2.maliciousDamage,
          data_tab2.homeUnderConstruction,
          data_tab2.Bankruptcy,
          data_tab2.buildingFlooded,
          quotationId

        ], async (errorIQ, resultIQ) => {
          if (errorIQ) {
            console.log("Error 3: ", errorIQ);
            response.status(500).json({ status: "failed", });
          }
          else {
            //console.log("Successfully Updated Important Questions");
            //response.status(201).json({ status: "Successfully updated Important questions data" });
            //console.log("Successfully Important Questions")
            await db.query(query_updatePolicyCoreHome, [
              data_tab3.coverType,
              data_tab3.basisOfSettlement,
              data_tab3.buildingOrContents,
              data_tab3.buildingSumInsured,
              data_tab3.contentsSumInsuredAmount,
              fromDateTemp,
              toDateTemp,
              // data_tab3.policyFromDate,
              // data_tab3.policyToDate,
              data_tab3.dobOldestInsured.substring(0, 10),
              // data_tab3.dobOldestInsured,
              data_tab3.industryPolicyHolder,
              data_tab3.policyHolderRetired,
              data_tab3.conductedFromHome,
              data_tab3.fromHomeBusinessName,
              data_tab3.fromHomeWhatBusiness,
              data_tab3.fromHomeAnnualRevenue,
              data_tab3.fromHomeBusnsOccupyFloorArea,
              data_tab3.underConstruction,
              data_tab3.poorlyMaintained,
              data_tab3.unoccupiedDays,
              data_tab3.guestHouse,
              data_tab3.publicHousing,
              data_tab3.currentlyInsurance,
              data_tab3.interestedParties,
              data_tab3.jettyAttachedProperty,
              data_tab3.svuExcessOption1,
              data_tab3.svuExcessOption2,
              data_tab3.svuExcessOption3,
              data_tab3.brokerFee,
              data_tab3.paymentFrequency,
              data_tab3.preferredinstallments,
              data_tab3.brokerFeeinstallments,
              data_tab3.unspecifiedValues,
              quotationId
            ], async (errorPolicyCoreHome, resultPolicyCoreHome) => {
              if (errorPolicyCoreHome) {
                console.log("Error 4:", errorPolicyCoreHome);
                response.status(500).json({ status: "failed", });
              }
              else {
                // console.log("Successfully updated policy core home data");
                // response.status(201).json({ status: "Successfully updated policy core home data" })
                await db.query(query_updateBuilding, [
                  data_tab4.prptyHeritageList,
                  data_tab4.provideDetails,
                  data_tab4.whatOccupancyHome,
                  data_tab4.buildingType,
                  data_tab4.whatBuiltHome,
                  data_tab4.whatTypeApartment,
                  data_tab4.whatTypeSemiDetached,
                  data_tab4.managemenBodyCorporate,
                  data_tab4.dwellingDescribesHome,
                  data_tab4.smhAcres20000,
                  data_tab4.insuredGenerateIncome,
                  data_tab4.machineryImplmtVehicles,
                  data_tab4.more6Livestock,
                  data_tab4.propertyUsedAnimals,
                  data_tab4.nonPersonalUse,
                  data_tab4.aircraftLandingStrip,
                  data_tab4.constructionPeriod,
                  data_tab4.originalYearBuilt,
                  data_tab4.constructionWalls,
                  data_tab4.roofConstruction,
                  data_tab4.consQualityofHome,
                  data_tab4.numberOfPropertyHave,
                  data_tab4.unitBuildingLevel,
                  data_tab4.effectByWtaer,
                  data_tab4.mainsWaterSupply,
                  data_tab4.windowSecurity,
                  data_tab4.doorSecurity,
                  data_tab4.burglarAlarm,
                  data_tab4.smokeDetectors,
                  data_tab4.builtConstNextMnth,
                  data_tab4.swimmingPool,
                  data_tab4.locatedbelowgRoundLevel,
                  data_tab4.privateFlood,
                  data_tab4.occupancyCertificate,
                  data_tab4.housebeenReroofed,
                  data_tab4.housebeenReplumbed,
                  data_tab4.housebeenRewired,
                  quotationId
                ], async (errorBuilding, resultBuilding) => {
                  if (errorBuilding) {
                    console.log("ErrorBuilding: ", errorBuilding);
                    response.status(500).json({ status: "failed", });
                  }
                  else {
                    // console.log(data_tab5[0].contentID);
                    // console.log(data_tab5[0]);

                    //for contents page
                    for (let i = 0; i < data_tab5.length; i++) {
                      let curData;
                      let curQuery;
                      if (data_tab5[i].edit === "OLD") {
                        curData = [
                          data_tab5[i].type,
                          data_tab5[i].category,
                          data_tab5[i].description,
                          data_tab5[i].value,
                          data_tab5[i].contentID,
                        ];
                        curQuery = query_updateContents;
                        //response.status(201).json({ status: "Successfully updated contents data" })
                      }
                      else if (data_tab5[i].edit === "NEW") {
                        curQuery = query_createContents;
                        curData = [
                          quotationId,
                          data_tab5[i].type,
                          data_tab5[i].category,
                          data_tab5[i].description,
                          data_tab5[i].value,
                        ];
                      }
                      else if (data_tab5[i].edit === "DELETED") {
                        curQuery = query_deleteContents;
                        curData = [data_tab5[i].contentID];
                      }

                      await db.query(curQuery, curData, async (errorContents, resultContents) => {
                        if (errorContents) {
                          console.log(errorContents);
                          response.status(500).json({ status: "failed", });
                          return;
                        }
                        else {
                          console.log("Successfully updated contents data");
                        }
                      }
                      );
                    }

                    //for claim page
                    // console.log("data edit from tab6: ", data_tab6[0].edit);
                    for (let i = 0; i < data_tab6.length; i++) {
                      let curData;
                      let curQuery;

                      if (data_tab6[i].edit === "OLD") {
                        curData = [
                          data_tab6[i].typeClaim,
                          data_tab6[i].dateClaim.substring(0, 10),
                          data_tab6[i].description,
                          data_tab6[i].amount,
                          data_tab6[i].claimId,
                        ];
                        curQuery = query_updateClaims;
                      }
                      else if (data_tab6[i].edit === "NEW") {
                        curQuery = query_createClaims;
                        curData = [
                          quotationId,
                          data_tab6[i].typeClaim,
                          data_tab6[i].dateClaim.substring(0, 10),
                          data_tab6[i].description,
                          data_tab6[i].amount,
                        ];
                      }
                      else if (data_tab6[i].edit === "DELETED") {
                        curQuery = query_deleteClaims;
                        curData = [data_tab6[i].claimId];
                      }

                      await db.query(curQuery, curData, async (errorClaims, resultClaims) => {
                        if (errorClaims) {
                          console.log("Error Claim: ", errorClaims);
                          response.status(500).json({ status: "failed", });
                          return;
                        }
                        else {
                          console.log("Successfully updated claims data");
                        }
                      }
                      );
                    }


                    //response.status(201).json({ status: "Successfully updated Claim home data" })
                    await db.query(query_updateQuotationStatus, [quotationId],
                      async (errorQuotation, resultQuotation) => {
                        if (errorQuotation) {
                          console.log("Error Quotation: ", errorQuotation);
                          response.status(500).json({ status: "failed", });
                        }
                        else {
                          response.status(201).json({ status: "Successfully updated Quotation data" });
                        }
                      })
                  }
                })
              }
            })
          }
        })

      }
    });
  }
  catch (err) {
    console.log("Error 1: ", err);
    res.send(err);
  } 
}; // end of client update

// tab1_client post method to insert client details. /addClient
exports.addHomeClientDetails = async (req, res, next) => {
  const data = req.body.data_tab1_home_client;

  const data2 = req.body.data_tab4_buildinghome;
  //console.log(data2);
  const query_insertHomeClient =
    "INSERT INTO client_home(client_type, client_title, client_firstName, client_lastName, company_name," +
    "trading_as, reference_code, unit_number_postal ,street_number_postal ,street_name_postal," +
    "street_type_postal ,suburb_postal ,state_postal ,postcode_postal,phone ,email ,branch ,sales_team ,service_team," +
    "quotaion_id_fk)" +
    " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
  const query_addQuotation =
    "INSERT INTO quotation_details(quotation_type, quotation_status) VALUES (?,?)";

  try {
    await db.query(query_addQuotation, ["Home", "Pending"], async (err, homequotationDetails) => {
      if (err) {
        console.log("Erro1 : " + err);
        //return res.send({ message: err });
      }
      else {
        let quotation_id_home = homequotationDetails.insertId;
        try {
          await db.query(query_insertHomeClient,
            [
              data.clientType,
              data.title,
              data.firstName,
              data.lastName,
              data.companyName,
              data.tradingAs,
              data.officeTechReferenceCode,
              data.unitNumber,
              data.streetNumber,
              data.streetName,
              data.streetType,
              data.suburb,
              data.state,
              data.postCode,
              data.phone,
              data.email,
              data.branch,
              data.salesTeam,
              data.serviceTeam,
              quotation_id_home,

            ], async (err, homeClientDetails) => {
              if (err) {
                console.log("Erro2: " + err);
              }
              else {
                res.status(201).json({
                  status: "success",
                  data: {
                    id: homequotationDetails.insertId,
                  },
                });
              }
              //console.log(homeClientDetails);
            });
        }
        catch (err) {
          console.log("Errorline1785 :" + err);
          //return res.send({ error: err, message: err.message });
        }
      }
    });
  }
  catch (err) {
    console.log("Error :" + err);
    //return res.send({ error: err, message: err.message });
  }
}; // end of add client method


// tab2_importantQuestionsforHome post method to insert important question data.
exports.addImportantQuestionsforHome = async (req, res, next) => {
  const data = req.body.data_tab2_importantQuestions_home;
  const quotationId_db = req.body.quotationId_db;
  console.log("Quotation Id: " + quotationId_db);

  const query_addImportantQuestions =
    "INSERT INTO important_questions_home(quotation_id_fk ,any_policy_declined_last5years," +
    "claim_decline ,criminal_conviction_last5years ,under_construction_renovation, bankruptcy ," +
    "has_flooded_last10_years) VALUES (?,?,?,?, ?,?,?)";

  const query_updateQuotation =
    "UPDATE quotation_details SET important_question_id_fk = ? WHERE quotation_id = ? ";

  try {
    await db.query(query_addImportantQuestions,
      [
        quotationId_db,
        data.insPolcyCancellLast5Years,
        data.hadClaimDeclained,
        data.maliciousDamage,
        data.homeUnderConstruction,
        data.Bankruptcy,
        data.buildingFlooded

      ], async (err, importantQuestionsHome) => {
        if (err) {
          console.log("Erro2: " + err);
        }
        else {
          res.status(201).json({
            status: "success",
            data: {
              id: quotationId_db,
            },
          });
        }
      });
  }
  catch (err) {
    console.log("Error3 :" + err);

  }
};

// post method to insert policy core data for home
exports.addPolicyCoreHome = async (req, response, next) => {
  const data = req.body.data_tab3_policyCorehome;
  const quotationId_db = req.body.quotationId_db;
  // console.log(data);
  const query_addPolicyCorehome =
    "INSERT INTO policy_core_home(quotation_id_fk,cover_type,basis_settlement ,building_contents," +
    "building_sum_insured ,contents_insuredAmount ,policy_fromDate ,policy_toDate ,dob_oldestInsured," +
    "industry_policyholder ,policyholder_retired, business_conducted_from_home ,ifYes_business_name," +
    "ifYes_business_type ,ifYes_annual_revenue ,ifYes_occupy_more_than_20_area , under_construction," +
    "poor_condition_maintained,unoccupied_90_days,hostel_brekfast_bed_guesthouse, community_public_housing," +
    "hold_insurance,interested_parties,jetty_attached_property,excess_option1, excess_option2,excess_option3,broker_fee," +
    "payment_frequncy, preferred_day_Installment, broker_free_Installment , unspecified_valuables)" +
    "VALUES(?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? , ?)";

  const query_updateQuotation =
    "UPDATE quotation_details SET policy_core_id_fk = ? WHERE quotation_id = ? ";

  let fromDateTemp = data.policyFromDate;
  let toDateTemp = data.policyToDate;

  fromDateTemp = fromDateTemp.substring(0, 10);
  toDateTemp = toDateTemp.substring(0, 10);

  // console.log("from dat temp: " + data.policyFromDate);

  // add policy core details to the db
  db.query(
    query_addPolicyCorehome,
    [
      quotationId_db,
      data.coverType,
      data.basisOfSettlement,
      data.buildingOrContents,
      data.buildingSumInsured,
      data.contentsSumInsuredAmount,
      // data.policyFromDate,
      // data.policyToDate,
      fromDateTemp,
      toDateTemp,
      data.dobOldestInsured.substring(0, 10),
      // data.dobOldestInsured,
      data.industryPolicyHolder,
      data.policyHolderRetired,
      data.conductedFromHome,
      data.fromHomeBusinessName,
      data.fromHomeWhatBusiness,
      data.fromHomeAnnualRevenue,
      data.fromHomeBusnsOccupyFloorArea,
      data.underConstruction,
      data.poorlyMaintained,
      data.unoccupiedDays,
      data.guestHouse,
      data.publicHousing,
      data.currentlyInsurance,
      data.interestedParties,
      data.jettyAttachedProperty,
      data.svuExcessOption1,
      data.svuExcessOption2,
      data.svuExcessOption3,
      data.brokerFee,
      data.paymentFrequency,
      data.preferredinstallments,
      data.brokerFeeinstallments,
      data.unspecifiedValues,
    ],
    (errorPolicy, resultPolicy) => {
      //console.log(resultPolicy);
      if (errorPolicy) {
        console.log(errorPolicy);
        response.status(500).json({
          status: "failed",
        });
      } else {
        response.status(201).json({
          status: "success",
          data: {
            id: quotationId_db,
          },
        });
      }
    }
  );
};


exports.addBuildingDetailsHome = async (req, response, next) => {
  const data = req.body.data_tab4_buildinghome;
  // console.log("Tab4 Data :", data);
  const quotationId_db = req.body.quotationId_db;

  const query_addbuildingDetailshome =
    "INSERT INTO building_details (quotation_id_fk,property_heritage_list,if_heriageList_moreDetails," +
    "home_occupancy, building_type, if_free_standing_whats_built, if_apartment_appartment_type," +
    "if_semi_detached_type, if_semi_detached_strata_manage, if_other_dwelling_describe_home," +
    "exceed_20k_mkm_2hect_5acres,if_exceed_insured_generate_income, if_exceed_farm_building_machinery," +
    "if_exceed_moreThan_6_liveStock, if_exceed_used_agisment_peoples_animals,if_exceed_horses_nonPersonal_use," +
    "if_exceed_aircrapt_landing_strip, construction_period, year_built, construction_walls, roof_construction," +
    "construction_quality, storeys_number, unit_buildingLevel, house_250m_waterCourse, water_supply, window_security," +
    "door_security, burglar_alarm, smoke_detector, construction_12_months, swimming_pool, Building_located_ground_level," +
    "mitigation_measures_property, occupency_certification , is_insuredAddressSame_postalAddress ,house_reroofed , house_replumbed, house_rewired) VALUES(?, ?, ?, ?, ?, ?, ?," +
    "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?," +
    "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? , ? , ? , ?, ?)";

  const query_updateHomeClient =
    "UPDATE client_home SET street_number_insured = ?, street_name_insured = ?, street_type_insured = ?," +
    "suburb_insured = ? ,state_insured = ?, postcode_insured = ? WHERE quotaion_id_fk= ?";
  try {
    await db.query(query_addbuildingDetailshome,
      [
        quotationId_db,
        data.prptyHeritageList,
        data.provideDetails,
        data.whatOccupancyHome,
        data.buildingType,
        data.whatBuiltHome,
        data.whatTypeApartment,
        data.whatTypeSemiDetached,
        data.managemenBodyCorporate,
        data.dwellingDescribesHome,
        data.smhAcres20000,
        data.insuredGenerateIncome,
        data.machineryImplmtVehicles,
        data.more6Livestock,
        data.propertyUsedAnimals,
        data.nonPersonalUse,
        data.aircraftLandingStrip,
        data.constructionPeriod,
        data.originalYearBuilt,
        data.constructionWalls,
        data.roofConstruction,
        data.consQualityofHome,
        data.numberOfPropertyHave,
        data.unitBuildingLevel,
        data.effectByWtaer,
        data.mainsWaterSupply,
        data.windowSecurity,
        data.doorSecurity,
        data.burglarAlarm,
        data.smokeDetectors,
        data.builtConstNextMnth,
        data.swimmingPool,
        data.locatedbelowgRoundLevel,
        data.privateFlood,
        data.occupancyCertificate,
        data.insuredAddress,
        data.housebeenReroofed,
        data.housebeenReplumbed,
        data.housebeenRewired

      ], async (err, buildingDetailshome) => {
        if (err) {
          console.log("Erro2: " + err);
        }
        else {
          // response.status(201).json({
          //   status: "success",
          //   data: {
          //     id: quotationId_db,
          //   },
          // });
          await db.query(query_updateHomeClient, [
            data.streetNumber_insured,
            data.street_name_insured,
            data.street_type_insured,
            data.suburb_insured,
            data.state_insured,
            data.postcode_insured,
            quotationId_db
          ],
            async (err, updateHomeClient) => {
              if (err) {
                console.log("Error line 1998: " + err);
              }
              else {
                response.status(201).json({
                  status: "success",
                  data: {
                    id: quotationId_db,
                  },
                });
              }
            })
        }
      });
  }
  catch (err) {
    console.log("Erro3: " + err);
  }

}

//Method for insert contents of home
exports.addContentsHome = async (req, response, next) => {
  const data = req.body.data_tab5_contentshome;
  const quotationId_db = req.body.quotationId_db;
  // const data2 = req.body.data_tab3_policyCorehome;
  // console.log(data2);
  let values = [];
  let count = 0;

  const query_addContentshome =
    "INSERT INTO contents (quotation_id_fk ,type ,category ,description ,value)" +
    "VALUES ?";

  
    if (data.length > 0) {
    data.forEach((element) => {
      // console.log("vehicle id: " + vehicleId_db);
      let arrayElem = [];
      arrayElem.push(quotationId_db);
      arrayElem.push(element.type);
      arrayElem.push(element.category);
      arrayElem.push(element.description);
      arrayElem.push(element.value);
      values.push(arrayElem);

      count++;
      if (count === data.length) {
        db.query(query_addContentshome, [values], (errorContent, resultForContent) => {
          if (errorContent) {
            console.log(errorContent);
            response.status(500).json({
              status: "failed",
            });
          } else {
            response.status(201).json({
              status: "success",
              data: {
                id: quotationId_db,
              },
            });
          }
        }
        );
      }
    });
  }

  else {
    response.status(201).json({
      status: "No Contents here",
    });
    
  }
 
}

exports.addClaimsHome = async (req, response, next) => {
  const data = req.body.data_tab6_claimshome;
  const quotationId_db = req.body.quotationId_db;
  // const dataLength = data.length;
  let values = [];
  let count = 0;
  const query_addClaimshome =
    "INSERT INTO claims (quotation_id_fk, claim_type, date_claim, claim_description, claim_amount, insurer)" +
    "VALUES ?";

  if (data.length > 0) {
    data.forEach((element) => {
      // console.log("vehicle id: " + vehicleId_db);
      let arrayElem = [];
      arrayElem.push(quotationId_db);
      arrayElem.push(element.typeClaim);
      arrayElem.push(element.dateClaim.substring(0, 10));
      // arrayElem.push(element.dateClaim);
      arrayElem.push(element.description);
      arrayElem.push(element.amount);
      arrayElem.push(element.insurer);
      values.push(arrayElem);

      count++;
      if (count === data.length) {
        db.query(query_addClaimshome, [values], (errorClaim, resultForClaims) => {
          if (errorClaim) {
            console.log(errorClaim);
            response.status(500).json({
              status: "failed",
            });
          } else {
            response.status(201).json({
              status: "success",
              data: {
                id: quotationId_db,
              },
            });
          }
        }
        );
      }
    });
  } else {
    response.status(201).json({
      status: "No Claims here",
    });
  }
}