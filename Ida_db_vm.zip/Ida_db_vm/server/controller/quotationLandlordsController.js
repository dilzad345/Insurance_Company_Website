const db = require("../models/db");
const verifyToken = require("../auth/VerifyToken");
// const pdf = require('html-pdf');
// const pdfTemplate = require('../documents/pdfTemplate');
// const path = require('path');
// const nodemailer = require('nodemailer');
// const path = require('path')
// const hbs = require('nodemailer-express-handlebars')

// let transporter = nodemailer.createTransport({
//     host: 'smtp.gmail.com',
//     port: 465,
//     secure: true,
//     auth: {
//         user: 'ensuretek@gmail.com',
//         pass: 'ensure457@123'
//     },
//     requireTLS: false,
//     tls: {
//         rejectUnauthorized: false
//     },
//     debug: true
// });


// point to the template folder
// const handlebarOptions = {
//     viewEngine: {
//         partialsDir: path.resolve('./views/'),
//         defaultLayout: false,
//     },
//     viewPath: path.resolve('./views/'),
// };


//1.Method for inserting quotation Details
exports.addQuotation = async (req, res, next) => {
    const dataTab1 = req.body.ClientLand;
    const dataTab2 = req.body.IqLand;
    const dataTab3 = req.body.PolicycoreLand;
    const dataTab4 = req.body.Buildingland;
    const dataTab5 = req.body.ContentsLand;
    const dataTab6 = req.body.ClaimsLand;
    // console.log(dataTab3);
    //query for inserting quotation type
    const query_addLandQuotation =
        "INSERT INTO quotation_details(quotation_type, quotation_status) VALUES (?,?)";

    //query for inserting client details
    const query_insertLandClient =
        "INSERT INTO client_landlords(client_id , client_type , client_title , client_firstName ," +
        "client_lastName , company_name , trading_as , reference_code , unit_number_postal ," +
        "street_number_postal , street_name_postal ,street_type_postal , suburb_postal , state_postal ," +
        "postcode_postal , phone , email , branch , sales_team , service_team , unit_number_insured ," +
        "street_number_insured , street_name_insured , street_type_insured , suburb_insured  ,state_insured ," +
        "postcode_insured, insuredAddress, question_details_id) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?)";

    //query for inserting IQ
    const queryAddIQ =
        "INSERT INTO important_questions_landlords(question_details_id, any_policy_decline_last5years, howmany_policy_decline_last5years," +
        "howmany_policy_decline_last3years , reason_forThe_decline , clime_decline,  reason_clime_decline, any_criminal_conviction ," +
        "property_everBe_unoccupied , checking_onThe_property , why_property_unoccupied , under_construction_renovation," +
        "renovation_over$100k, value_of_renovation , start_date_renovation , estimated_completion_date ," +
        "what_work_undertaken , building_not_secure , contract_works_policy , external_roof_walls , rain_intoThe_building ," +
        "poorly_maintained , property_heritage , details_heritage_list , bed_breakfast ,boarding_house ," +
        "used_hostel , community_public_housing , home_office_surgery , social_housing_service ,property_redevelopment," +
        "property_trust , flooded_last_10years , property_used_farming , business_activity_conducted )" +
        "VALUES(?,?,?,?,?,?,?,?,?, ?,?,?,?,?,?,?,?, ?,?,?,?,?,?,?,?, ?,?,?,?,?,?,?,?,?,?)";

    let startDate = dataTab2.start_date_renovations.substring(0, 10);
    let estimateDate = dataTab2.Estimated_completion_date.substring(0, 10);

    //query for inserting Policycore
    const queryAddPolicycore =
        "INSERT INTO policycore_landlords(question_details_id, occupancy_home , property_managed , building_content , building_sum_insured ," +
        "content_ins_amount ,policy_from_date  , policy_to_date , dob_oldest_insured  , currently_hold_insurence  , current_insurer ," +
        "interested_parties , holding_broker , holding_underwriter , stamp_duty_exempt , no_claim_bonus ," +
        "payment_frequency , preffered_day_installment , broker_fee_installment , cover_theft_tenant ," +
        "cover_loss  ,sum_ins_amount_loss  , annual_rent_amount  , weekly_rent_amount  , cover_rent_default ," +
        "tenant_rent_14days , landlord_insurance_policy  , svu_excess_option1  ,svu_excess_option2  ,svu_excess_option3," +
        "broker_fee , cover_type_accidential , policyholder_retired , cover_Accidental_damage , residential_lease_agreement) VALUES(?,?,?,?,?,?,?,?,?,?, ?,?,?,?,?,?,?,?,?,?,?, ?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    let fromTemDate = dataTab3.policy_from_date.substring(0, 10);
    let toTempDate = dataTab3.policy_to_date.substring(0, 10);

    // //query for inserting Building
    const queryAddBuilding =
        "INSERT INTO building_landlords (question_details_id , building_type , free_standing_what_build ," +
        "apartment_what_type  , semi_deteched_what_type , semi_deteched_body_corprate , dewelling_what_describe ," +
        "multiple_unit_insured_all  , multiple_unit_number , multiple_unit_insured_building  , multiple_unit_total_units ," +
        "construction_period  , original_year_build  , construction_wall  , roof_construction  ," +
        "numbers_of_bathrooms  , numbers_of_bedrooms  , construction_quality  , storeys ," +
        "unit_building_level , building_size  , effected_by_flood  , main_water_supply ," +
        "window_security  , door_security  , burglar_alarm  ,smoke_detector ," +
        "building_construction12months  , outdoor_spa  , located_below_ground  , flood_mitigration ," +
        "occupancy_certificate  , register_body_corprote  , strata_title  , person_living_the_building)" +
        "VALUES(?,?,?,?,?,?,?, ?,?,?,?,?,?,?, ?,?,?,?,?,?,?, ?,?,?,?,?,?,?, ?,?,?,?,?,?,?)";

    //query for inserting Contents
    const queryAddContents =
        "INSERT INTO contents_landlords(quotation_id_fk, type, category, description, value)" +
        "VALUES ?";

    // query for inserting Claims
    const queryAddClaims =
        "INSERT INTO claim_landlords(question_details_id, claim_type, claim_date, description, amount)" +
        "VALUES ?";

    //promise for quotation type
    queryPromise1 = () => {
        return new Promise((resolve, reject) => {
            db.query(query_addLandQuotation, ["Landlord", "Pending"], (err, results) => {
                if (err) {
                    return reject(err);
                }
                return resolve(results);
            })
        })
    }

    //promise for client information
    queryPromise2 = (quotationId) => {
        return new Promise((resolve, reject) => {
            db.query(query_insertLandClient, [
                dataTab1.client_id,
                dataTab1.client_type,
                dataTab1.client_title,
                dataTab1.client_firstName,
                dataTab1.client_lastName,
                dataTab1.company_name,
                dataTab1.trading_as,
                dataTab1.reference_code,
                dataTab1.unit_number_postal,
                dataTab1.street_number_postal,
                dataTab1.street_name_postal,
                dataTab1.street_type_postal,
                dataTab1.suburb_postal,
                dataTab1.state_postal,
                dataTab1.postcode_postal,
                dataTab1.phone,
                dataTab1.email,
                dataTab1.branch,
                dataTab1.sales_team,
                dataTab1.service_team,
                dataTab1.unit_number_insured,
                dataTab1.street_number_insured,
                dataTab1.street_name_insured,
                dataTab1.street_type_insured,
                dataTab1.suburb_insured,
                dataTab1.state_insured,
                dataTab1.postcode_insured,
                dataTab1.insuredAddress,
                quotationId
            ], (err, results) => {
                if (err) {
                    return reject(err);
                }
                return resolve(results);
            })
        })

    }

    //promise for IQ
    queryPromise3 = (quotationId) => {
        return new Promise((resolve, reject) => {
            db.query(queryAddIQ, [
                quotationId,
                dataTab2.any_policy_decline_last5years,
                dataTab2.howmany_policy_decline_last5years,
                dataTab2.howmany_policy_decline_last3years,
                dataTab2.reason_forThe_decline,
                dataTab2.clime_decline,
                dataTab2.reason_clime_decline,
                dataTab2.any_criminal_conviction,
                dataTab2.property_everBe_unoccupied,
                dataTab2.checking_onThe_property,
                dataTab2.why_property_unoccupied,
                dataTab2.under_construction_renovation,
                dataTab2.renovation_over$100000,
                dataTab2.value_of_renovation,
                startDate,
                estimateDate,
                dataTab2.what_work_undertaken,
                dataTab2.building_not_secure,
                dataTab2.contract_works_policy,
                dataTab2.external_roof_walls,
                dataTab2.rain_intoThe_building,
                dataTab2.poorly_maintained,
                dataTab2.property_heritage,
                dataTab2.details_heritage_list,
                dataTab2.bed_breakfast,
                dataTab2.boarding_house,
                dataTab2.used_hostel,
                dataTab2.community_public_housing,
                dataTab2.home_office_surgery,
                dataTab2.social_housing_service,
                dataTab2.property_redevelopment,
                dataTab2.property_trust,
                dataTab2.flooded_last_10years,
                dataTab2.property_used_farming,
                dataTab2.business_activity_conducted,

            ], (err, results) => {
                if (err) {
                    return reject(err);
                }
                return resolve(results);
            })
        })
    }

    //promise for Policycore
    queryPromise4 = (quotationId) => {
        return new Promise((resolve, reject) => {
            db.query(queryAddPolicycore, [
                quotationId,
                dataTab3.occupancy_home,
                dataTab3.property_managed,
                dataTab3.building_content,
                dataTab3.building_sum_insured,
                dataTab3.content_ins_amount,
                fromTemDate,
                toTempDate,
                dataTab3.dob_oldest_insured.substring(0, 10),
                dataTab3.currently_hold_insurence,
                dataTab3.current_insurer,
                dataTab3.interested_parties,
                dataTab3.holding_broker,
                dataTab3.holding_underwriter,
                dataTab3.stamp_duty_exempt,
                dataTab3.no_claim_bonus,
                dataTab3.payment_frequency,
                dataTab3.preffered_day_installment,
                dataTab3.broker_fee_installment,
                dataTab3.cover_Theft_tenant,
                dataTab3.cover_loss,
                dataTab3.sum_ins_amount_loss,
                dataTab3.annual_rent_amount,
                dataTab3.weekly_rent_amount,
                dataTab3.cover_rent_default,
                dataTab3.tenant_rent_14Days,
                dataTab3.landlord_insurance_policy,
                dataTab3.svu_excess_option1,
                dataTab3.svu_excess_option2,
                dataTab3.svu_excess_option3,
                dataTab3.broker_fee,
                dataTab3.cover_type_accidential,
                dataTab3.policyholder_retired,
                dataTab3.cover_Accidental_damage,
                dataTab3.residential_lease_agreement,
            ], (err, results) => {
                if (err) {
                    return reject(err);
                }
                return resolve(results);
            })
        })
    }

    //promise for building
    queryPromise5 = (quotationId) => {
        return new Promise((resolve, reject) => {
            db.query(queryAddBuilding, [
                quotationId,
                dataTab4.building_type,
                dataTab4.free_standing_what_built,
                dataTab4.apartment_what_type,
                dataTab4.semi_deteched_what_type,
                dataTab4.semi_deteched_body_corprate,
                dataTab4.dewelling_what_describe,
                dataTab4.multiple_unit_insured_all,
                dataTab4.multiple_unit_number,
                dataTab4.multiple_unit_insured_building,
                dataTab4.multiple_unit_total_units,
                dataTab4.construction_period,
                dataTab4.original_year_build,
                dataTab4.construction_wall,
                dataTab4.roof_construction,
                dataTab4.numbers_of_bathrooms,
                dataTab4.numbers_of_bedrooms,
                dataTab4.construction_quality,
                dataTab4.storeys,
                dataTab4.unit_building_level,
                dataTab4.building_size,
                dataTab4.effected_by_flood,
                dataTab4.main_water_supply,
                dataTab4.window_security,
                dataTab4.door_security,
                dataTab4.burglar_alarm,
                dataTab4.smoke_detector,
                dataTab4.building_construction12months,
                dataTab4.outdoor_spa,
                dataTab4.located_below_ground,
                dataTab4.flood_mitigration,
                dataTab4.occupancy_certificate,
                dataTab4.register_body_corprote,
                dataTab4.strata_title,
                dataTab4.person_living_the_building,
            ], (err, results) => {
                if (err) {
                    return reject(err);
                }
                return resolve(results);
            })
        })
    }

    //promise for contents
    queryPromise6 = (quotationId) => {
        let values = [];
        let count = 0;
        if (dataTab5.length > 0) {
            return new Promise((resolve, reject) => {
                dataTab5.forEach(element => {
                    let arrayElem = [];
                    arrayElem.push(quotationId);
                    arrayElem.push(element.type);
                    arrayElem.push(element.category);
                    arrayElem.push(element.description);
                    arrayElem.push(element.value);
                    values.push(arrayElem);

                    count++;

                    if (count === dataTab5.length) {
                        db.query(queryAddContents, [values], (err, results) => {
                            if (err) {
                                return reject(err);
                            }
                            return resolve(results)
                        })
                    }
                });
            })
        }

    }

    queryPromise7 = (quotationId) => {
        let values = [];
        let count = 0;
        if (dataTab6.length > 0) {
            return new Promise((resolve, reject) => {
                dataTab6.forEach((element) => {
                    let arrayElem = [];
                    arrayElem.push(quotationId);
                    arrayElem.push(element.typeClaim);
                    arrayElem.push(element.dateClaim.substring(0, 10));
                    arrayElem.push(element.description);
                    arrayElem.push(element.amount);
                    values.push(arrayElem);

                    count++;
                    if (count === dataTab6.length) {
                        db.query(queryAddClaims, [values], (err, results) => {
                            if (err) {
                                return reject(err)
                            }
                            return resolve(results);
                        });
                    }
                });
            })
        }

    }

    //promise for downloading pdf
    // Promise8 = (props) => {
    //     // console.log(props);
    //     return new Promise((resolve, reject) => {
    //         pdf.create(pdfTemplate(props)).toFile('files/result.pdf', (err) => {
    //             if (err) {
    //                 return reject(err);
    //             }

    //             return resolve();
    //         });
    //     })
    // }

    try {
        //queries are executed in a sequential flow
        const result1 = await queryPromise1();
        const result2 = await queryPromise2(result1.insertId);
        const result3 = await queryPromise3(result1.insertId);
        const result4 = await queryPromise4(result1.insertId);
        const result5 = await queryPromise5(result1.insertId);
        const result6 = await queryPromise6(result1.insertId);
        const result7 = await queryPromise7(result1.insertId);
        // const result8 = await Promise8(req.body);
        // const result = [result1,result2,result3,result4,result5,result6,result7]
        res.status(200).json({
            Message: "Successully Inserted",
            // Result: result
        })
        return result1 + result2 + result3 + result4 + result5 + result6 + result7 ;
    } catch (err) {
        console.log(err);
    }

}

//2.Method for getting quotation by category for Land
exports.getQuotationsLand = async (req, res, next) => {
    // console.log(req);
    const token = req.headers.token;
    // console.log("access: ", verifyToken(token));
    if (await verifyToken(token)) {
        const user_email = req.query.userEmail;
        const query_getQuotations =
            "select * from quotation_details, client_landlords" +
            " where quotation_details.quotation_id = client_landlords.question_details_id" +
            " and (quotation_details.quotation_status = 'Pending' or " +
            "quotation_details.quotation_status = 'Verified' or quotation_details.quotation_status = 'submitted')" +
            "ORDER BY quotation_details.quotation_id DESC";

        const pending_quotation =
            "SELECT COUNT(quotation_status) AS pendingCount FROM quotation_details, client_landlords" +
            " where quotation_details.quotation_status='Pending'" +
            " AND quotation_details.quotation_id = client_landlords.question_details_id";


        const verified_quotation =
            "SELECT COUNT(quotation_status) AS verifiedCount FROM quotation_details, client_landlords" +
            " where quotation_details.quotation_status='Verified'" +
            " AND quotation_details.quotation_id = client_landlords.question_details_id";

        const submitted_quotation =
            "SELECT COUNT(quotation_status) AS submittedCount FROM quotation_details, client_landlords" +
            " where quotation_details.quotation_status='Submitted'" +
            " AND quotation_details.quotation_id = client_landlords.question_details_id";

        // execute query on database and send the response
        //await db.query(query_getQuotations,[user_email], async(err, result) => {
        db.query(query_getQuotations, [], async (err, result) => {
            if (err) {
                console.log("Error 1: ", err.message);
            } else {
                // console.log(result);
                db.query(
                    verified_quotation, [], async (err, verifiedCountResult) => {
                        if (err) {
                            console.log("Error2: ", err.message);
                        } else {
                            //console.log(result);
                            // console.log(verifiedCountResult);
                            db.query(pending_quotation, [], async (err, pendingCountResult) => {
                                if (err) {
                                    console.log("Error 3:", err.message);
                                } else {
                                    //console.log(result);
                                    //console.log(pendingCountResult[0]);
                                    /* const quotationDetail = {
                                      verifiedQuotation: verifiedCountResult,
                                      pendingQuotation: pendingCountResult,
                                      getQuotation: result,
                                    };
                                    response.send(quotationDetail); */
                                    db.query(submitted_quotation, [], async (errSubmit, submitCount) => {
                                        if (errSubmit) {
                                            console.log("Error 4: ", errSubmit);
                                        } else {
                                            const quotationDetail = {
                                                verifiedQuotation: verifiedCountResult,
                                                pendingQuotation: pendingCountResult,
                                                submittedQuotation: submitCount,
                                                getQuotation: result,
                                            }
                                            res.send(quotationDetail);
                                        }
                                    })
                                    //console.log(quotationDetail[0]);
                                }
                            });
                            // response.send(dataQuotation);
                        }
                    });
                //response.send(query_getQuotations);
            }
        });
    } else {
        res.send({
            message: "You are not authenticated"
        });
    }
}; //end method

//3.Methof for getting quotation details by quotation Id
exports.getQuotationsDetails = async (req, res, next) => {
    const quotationId = req.query.quotationId;
    const token = req.headers.token;
    console.log("access2: ", verifyToken(token));

    if (await verifyToken(token)) {
        const queryGetQuotationDetail = "SELECT * FROM quotation_details WHERE quotation_id = ?";
        const queryGetClientDetails =
            "SELECT * FROM client_landlords WHERE question_details_id = ?";

        const queryGetIQ =
            "SELECT * FROM important_questions_landlords WHERE question_details_id = ?";

        const queryGetPolicyCore =
            "SELECT * FROM policycore_landlords WHERE question_details_id = ?";

        const queryGetBuilding =
            "SELECT * FROM building_landlords WHERE question_details_id = ?";

        const queryGetContents =
            "SELECT * FROM contents_landlords WHERE quotation_id_fk = ?";

        const queryGetClaims =
            "SELECT * FROM claim_landlords WHERE question_details_id = ?";
        db.query(queryGetQuotationDetail, [quotationId], async (err, quotationResult) => {
            if (err) {
                console.log("ErrorLine477:" + err);
            } else {
                db.query(queryGetClientDetails, [quotationId], async (errClient, clientDetails) => {
                    if (errClient) {
                        console.log("ErrorLine482:", errClient);
                    } else {
                        db.query(queryGetIQ, [quotationId], async (errIq, IqDetails) => {
                            if (errIq) {
                                console.log("ErrLine496:", errIq);
                            } else {
                                db.query(queryGetPolicyCore, [quotationId], async (errPolicycore, policycoreDetails) => {
                                    if (errPolicycore) {
                                        console.log("ErrLine494:", errPolicycore);
                                    } else {

                                        db.query(queryGetBuilding, [quotationId], async (errBuilding, buildingDetails) => {
                                            if (errBuilding) {
                                                console.log("ErrLine502:", errBuilding);
                                            } else {
                                                db.query(queryGetContents, [quotationId], async (errContents, contentsDetails) => {
                                                    if (errContents) {
                                                        console.log("ErrLine509:", errContents);
                                                    } else {
                                                        db.query(queryGetClaims, [quotationId], async (errClaims, claimsDetails) => {
                                                            if (errClaims) {
                                                                console.log("ErrLine516:", errClaims);
                                                            } else {
                                                                res.status(200).json({
                                                                    status: "Success",
                                                                    data: {
                                                                        ClientDetailsForLand: clientDetails[0],
                                                                        IqDetailsForLand: IqDetails[0],
                                                                        PolicycoreDetailsForLand: policycoreDetails[0],
                                                                        BuildingDetailsForLand: buildingDetails[0],
                                                                        ContentsDetailsForLand: contentsDetails,
                                                                        ClaimsDetailsForLand: claimsDetails

                                                                    }
                                                                })
                                                            }
                                                        })
                                                    }
                                                })
                                            }
                                        })
                                    }

                                })
                            }
                        })
                    }
                })
            }
        })
    }
} //end method

//4. Method for updating quotation details by a quotaion Id and this funtion will update all the information by sequential
exports.updateLandQuotations = async (req, res, next) => {
    const dataTab1 = req.body.data_tab1;
    const dataTab2 = req.body.data_tab2;
    const dataTab3 = req.body.data_tab3;
    const dataTab4 = req.body.data_tab4;
    const dataTab5 = req.body.data_tab5;
    const dataTab6 = req.body.data_tab6;
    const quotationId = req.body.quotationId;

    //query for updating client details
    const queryUpdateClient =
        "UPDATE client_landlords SET client_code_landlord = ? ,client_type = ? , client_title = ? , client_firstName = ? , " +
        "client_lastName = ?  , company_name = ?  , trading_as =? , reference_code =?  , unit_number_postal = ? ," +
        "street_number_postal = ? , street_name_postal = ?  , street_type_postal = ?  , suburb_postal = ?  , state_postal = ? , " +
        "postcode_postal = ? , phone = ? , email = ? , branch = ? , sales_team = ? ," +
        "service_team = ? , unit_number_insured = ? , street_number_insured = ?  , street_name_insured = ? , street_type_insured = ?," +
        "suburb_insured = ? , state_insured = ? , postcode_insured = ? , insuredAddress = ? WHERE question_details_id = ?";

    const startDate = dataTab2.start_date_renovations.substring(0, 10);
    const estimatedDate = dataTab2.Estimated_completion_date.substring(0, 10);

    //query for updating Important Questions
    const queryUpdateIq =
        "UPDATE important_questions_landlords SET any_policy_decline_last5years = ?, howmany_policy_decline_last5years = ?," +
        "howmany_policy_decline_last3years = ? , reason_forThe_decline = ? , clime_decline = ?,  reason_clime_decline = ?, any_criminal_conviction = ?," +
        "property_everBe_unoccupied = ?, checking_onThe_property = ? , why_property_unoccupied = ?, under_construction_renovation = ?," +
        "renovation_over$100k = ? , value_of_renovation = ? , start_date_renovation = ? , estimated_completion_date = ? ," +
        "what_work_undertaken = ?, building_not_secure = ?, contract_works_policy = ?, external_roof_walls = ?, rain_intoThe_building = ? ," +
        "poorly_maintained = ? , property_heritage = ? , details_heritage_list = ? , bed_breakfast = ? ,boarding_house = ? ," +
        "used_hostel = ? , community_public_housing = ? , home_office_surgery = ?, social_housing_service = ?  ,property_redevelopment = ?," +
        "property_trust = ? , flooded_last_10years = ? , property_used_farming = ? , business_activity_conducted = ?  WHERE question_details_id = ?";

    let fromTemDate = dataTab3.policy_from_date.substring(0, 10);
    let toTempDate = dataTab3.policy_to_date.substring(0, 10);
    //query for updating Policy Core
    const queryUpdatePolicycore =
        "UPDATE policycore_landlords SET occupancy_home = ? , property_managed = ? , building_content = ?, building_sum_insured  = ? ," +
        "content_ins_amount = ? ,policy_from_date = ?  , policy_to_date  = ? , dob_oldest_insured = ? , currently_hold_insurence = ?, current_insurer = ? ," +
        "interested_parties = ? , holding_broker = ? , holding_underwriter = ? , stamp_duty_exempt = ? , no_claim_bonus = ? ," +
        "payment_frequency = ? , preffered_day_installment = ? , broker_fee_installment = ? , cover_theft_tenant = ? ," +
        "cover_loss = ? ,sum_ins_amount_loss = ? , annual_rent_amount = ? , weekly_rent_amount = ? , cover_rent_default = ? ," +
        "tenant_rent_14days = ? , landlord_insurance_policy = ? , svu_excess_option1 = ? , svu_excess_option2 = ? , svu_excess_option3 = ?," +
        "broker_fee = ? , cover_type_accidential = ? , policyholder_retired = ? , cover_Accidental_damage = ? , residential_lease_agreement = ? WHERE question_details_id = ?";

    //query for updating Policy Core
    const queryUpdateBuilding =
        "UPDATE building_landlords SET  building_type = ? , free_standing_what_build = ? ," +
        "apartment_what_type = ? , semi_deteched_what_type = ? , semi_deteched_body_corprate = ? , dewelling_what_describe = ? ," +
        "multiple_unit_insured_all = ? , multiple_unit_number = ? , multiple_unit_insured_building = ? , multiple_unit_total_units = ? ," +
        "construction_period = ? , original_year_build = ? , construction_wall = ? , roof_construction = ?  ," +
        "numbers_of_bathrooms = ?  , numbers_of_bedrooms = ?  , construction_quality = ?  , storeys = ? ," +
        "unit_building_level = ? , building_size = ? , effected_by_flood = ? , main_water_supply = ? ," +
        "window_security = ? , door_security = ? , burglar_alarm = ? , smoke_detector = ? ," +
        "building_construction12months = ?  , outdoor_spa = ? , located_below_ground = ? , flood_mitigration = ? ," +
        "occupancy_certificate = ?, register_body_corprote = ? , strata_title = ? , person_living_the_building = ? WHERE question_details_id = ?";

    // query for updating Contents
    const queryUpdateContents =
        "UPDATE contents_landlords SET type = ? , category = ? , description = ? , value = ? " +
        "WHERE content_id = ?";

    //query for create new contents 
    const queryCreateContents =
        "INSERT INTO contents_landlords (quotation_id_fk ,type ,category ,description ,value) " +
        "VALUES (?,?,?,?,?)";

    // query for updating Claims
    const queryUpdateClaims =
        "UPDATE claim_landlords SET claim_type = ? , claim_date = ? , description = ?, amount = ? WHERE claim_id = ? ";

    //query for create new claims
    const queryCreateClaims =
        "INSERT INTO claim_landlords (question_details_id , claim_type , claim_date , description , amount)" +
        "VALUES (? , ? , ? , ? , ?)";

    const queryUpdateQuotationStatus =
        "UPDATE quotation_details SET quotation_status = 'Verified' WHERE quotation_id = ?";

    // execute queries in parallel 
    queryPromise1 = () => {
        return new Promise((resolve, reject) => {
            db.query(queryUpdateClient, [
                dataTab1.uiPathIdForLand,
                dataTab1.client_type,
                dataTab1.client_title,
                dataTab1.client_firstName,
                dataTab1.client_lastName,
                dataTab1.company_name,
                dataTab1.trading_as,
                dataTab1.reference_code,
                dataTab1.unit_number_postal,
                dataTab1.street_number_postal,
                dataTab1.street_name_postal,
                dataTab1.street_type_postal,
                dataTab1.suburb_postal,
                dataTab1.state_postal,
                dataTab1.postcode_postal,
                dataTab1.phone,
                dataTab1.email,
                dataTab1.branch,
                dataTab1.sales_team,
                dataTab1.service_team,
                dataTab1.unit_number_insured,
                dataTab1.street_number_insured,
                dataTab1.street_name_insured,
                dataTab1.street_type_insured,
                dataTab1.suburb_insured,
                dataTab1.state_insured,
                dataTab1.postcode_insured,
                dataTab1.insuredAddress,
                quotationId
            ], (error, results) => {
                if (error) {
                    return reject(error);
                }
                return resolve(results);
            });
        });
    };

    queryPromise2 = () => {
        return new Promise((resolve, reject) => {
            db.query(queryUpdateIq, [
                dataTab2.any_policy_decline_last5years,
                dataTab2.howmany_policy_decline_last5years,
                dataTab2.howmany_policy_decline_last3years,
                dataTab2.reason_forThe_decline,
                dataTab2.clime_decline,
                dataTab2.reason_clime_decline,
                dataTab2.any_criminal_conviction,
                dataTab2.property_everBe_unoccupied,
                dataTab2.checking_onThe_property,
                dataTab2.why_property_unoccupied,
                dataTab2.under_construction_renovation,
                dataTab2.renovation_over$100000,
                dataTab2.value_of_renovation,
                startDate,
                estimatedDate,
                dataTab2.what_work_undertaken,
                dataTab2.building_not_secure,
                dataTab2.contract_works_policy,
                dataTab2.external_roof_walls,
                dataTab2.rain_intoThe_building,
                dataTab2.poorly_maintained,
                dataTab2.property_heritage,
                dataTab2.details_heritage_list,
                dataTab2.bed_breakfast,
                dataTab2.boarding_house,
                dataTab2.used_hostel,
                dataTab2.community_public_housing,
                dataTab2.home_office_surgery,
                dataTab2.social_housing_service,
                dataTab2.property_redevelopment,
                dataTab2.property_trust,
                dataTab2.flooded_last_10years,
                dataTab2.property_used_farming,
                dataTab2.business_activity_conducted,
                quotationId
            ], (error, results) => {
                if (error) {
                    return reject(error);
                }
                return resolve(results);
            })
        })
    };

    queryPromise3 = () => {
        return new Promise((resolve, reject) => {
            db.query(queryUpdatePolicycore, [
                dataTab3.occupancy_home,
                dataTab3.property_managed,
                dataTab3.building_content,
                dataTab3.building_sum_insured,
                dataTab3.content_ins_amount,
                fromTemDate,
                toTempDate,
                dataTab3.dob_oldest_insured.substring(0, 10),
                dataTab3.currently_hold_insurence,
                dataTab3.current_insurer,
                dataTab3.interested_parties,
                dataTab3.holding_broker,
                dataTab3.holding_underwriter,
                dataTab3.stamp_duty_exempt,
                dataTab3.no_claim_bonus,
                dataTab3.payment_frequency,
                dataTab3.preffered_day_installment,
                dataTab3.broker_fee_installment,
                dataTab3.cover_Theft_tenant,
                dataTab3.cover_loss,
                dataTab3.sum_ins_amount_loss,
                dataTab3.annual_rent_amount,
                dataTab3.weekly_rent_amount,
                dataTab3.cover_rent_default,
                dataTab3.tenant_rent_14Days,
                dataTab3.landlord_insurance_policy,
                dataTab3.svu_excess_option1,
                dataTab3.svu_excess_option2,
                dataTab3.svu_excess_option3,
                dataTab3.broker_fee,
                dataTab3.cover_type_accidential,
                dataTab3.policyholder_retired,
                dataTab3.cover_Accidental_damage,
                dataTab3.residential_lease_agreement,

                quotationId
            ], (error, results) => {
                if (error) {
                    console.log("ErroLine714:", error);
                    return reject(error);
                }
                return resolve(results);
            })
        })
    }

    queryPromise4 = () => {
        return new Promise((resolve, reject) => {
            db.query(queryUpdateBuilding, [
                dataTab4.building_type,
                dataTab4.free_standing_what_built,
                dataTab4.apartment_what_type,
                dataTab4.semi_deteched_what_type,
                dataTab4.semi_deteched_body_corprate,
                dataTab4.dewelling_what_describe,
                dataTab4.multiple_unit_insured_all,
                dataTab4.multiple_unit_number,
                dataTab4.multiple_unit_insured_building,
                dataTab4.multiple_unit_total_units,
                dataTab4.construction_period,
                dataTab4.original_year_build,
                dataTab4.construction_wall,
                dataTab4.roof_construction,
                dataTab4.numbers_of_bathrooms,
                dataTab4.numbers_of_bedrooms,
                dataTab4.construction_quality,
                dataTab4.storeys,
                dataTab4.unit_building_level,
                dataTab4.building_size,
                dataTab4.effected_by_flood,
                dataTab4.main_water_supply,
                dataTab4.window_security,
                dataTab4.door_security,
                dataTab4.burglar_alarm,
                dataTab4.smoke_detector,
                dataTab4.building_construction12months,
                dataTab4.outdoor_spa,
                dataTab4.located_below_ground,
                dataTab4.flood_mitigration,
                dataTab4.occupancy_certificate,
                dataTab4.register_body_corprote,
                dataTab4.strata_title,
                dataTab4.person_living_the_building,
                quotationId
            ], (error, results) => {
                if (error) {
                    console.log("ErroLine714:", error);
                    return reject(error);
                }
                return resolve(results);
            })
        })
    }

    let tempArray;
    let tempQuery;

    queryPromise5 = () => {
        if (dataTab5.length > 0) {
            dataTab5.forEach((item, index) => {
                if (item.edit === "OLD") {
                    tempQuery = queryUpdateContents;
                    tempArray = [
                        item.type,
                        item.category,
                        item.description,
                        item.value,
                        item.contentID
                    ];
                } else if (item.edit === "NEW") {
                    tempQuery = queryCreateContents;
                    tempArray = [
                        quotationId,
                        item.type,
                        item.category,
                        item.description,
                        item.value,
                    ];
                }
                return new Promise((resolve, reject) => {
                    db.query(tempQuery, tempArray, (error, results) => {
                        if (error) {
                            console.log("ErrorLine870:", error);
                            return reject(error);
                        }
                        return resolve(results)
                    })
                })
            })
        }
    }

    queryPromise6 = () => {
        if (dataTab6.length > 0) {
            dataTab6.forEach((item, index) => {
                if (item.edit === "OLD") {
                    tempQuery = queryUpdateClaims;
                    tempArray = [
                        item.typeClaim,
                        item.dateClaim.substring(0, 10),
                        item.description,
                        item.amount,
                        item.claimId
                    ];
                } else if (item.edit === "NEW") {
                    tempQuery = queryCreateClaims;
                    tempArray = [
                        quotationId,
                        item.typeClaim,
                        item.dateClaim.substring(0, 10),
                        item.description,
                        item.amount,
                    ];
                }
                return new Promise((resolve, reject) => {
                    db.query(tempQuery, tempArray, (error, results) => {
                        if (error) {
                            console.log("ErrLine864:", error);
                            return reject(error);
                        }
                        return resolve(results);
                    })
                })
            })
        }
    }

    queryPromise7 = () => {
        return new Promise((resolve, reject) => {
            db.query(queryUpdateQuotationStatus, [quotationId], (err, results) => {
                if (err) {
                    return reject(err);
                }
                return resolve(results);
            })
        })
    }


    const promise1 = queryPromise1();
    const promise2 = queryPromise2();
    const promise3 = queryPromise3();
    const promise4 = queryPromise4();
    const promise5 = queryPromise5();
    const promise6 = queryPromise6();
    const promise7 = queryPromise7();
    try {
        const promises = [promise1, promise2, promise3, promise4, promise5, promise6, promise7];
        const result = await Promise.all(promises);
        res.status(200).json({
            Message: "Successfully Updated",
            Result: result
        });
        // return result;
        // return result1 + result2 + result3 + result4; // you can do something with the results
    } catch (error) {
        console.log("ErrLine886:", error)
    }
}

//5. get method for reading pdf.
// exports.createPDF = async (req, res, next) => {
    
//     let indexPath = path.join(__dirname, "../files/result.pdf");
//     res.sendFile(indexPath);
   
// }