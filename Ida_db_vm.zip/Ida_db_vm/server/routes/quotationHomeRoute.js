const express = require("express");
const quotationHomeController = require('../controller/quotationHomeController');

const router = express.Router();


// Create a new Tutorial
//router.post("/getHomeMessage", quotationHomeController.create);

// Retrieve all Tutorials
//router.get("/getHomeMessage", quotationHomeController.findAll);//http://localhost:3001/quotationHome/getHomeMessage

// Retrieve all published Tutorials
//router.get("/getHomeMessage/published", quotationHomeController.findAllPublished);

//retrieve all details where quotation type is motor
router.get("/getQuotationHome",quotationHomeController.getQuotationHomeDetails);//http://localhost:3001/quotationHome/getQuotationHome

// Retrieve a single Tutorial with id
//router.get("/getHomeMessage/:id", quotationHomeController.findOne);


//update quotation details for home with specific id
//http://localhost:3001/quotationHome/updateQuotationHome


//insert quotation details for home
router.post("/insertQuotationHome",quotationHomeController.insertHomeQuotations);//http://localhost:3001/quotationHome/insertQuotationHome




router.post("/addHomeClient", quotationHomeController.addHomeClientDetails);//http://localhost:3001/quotationHome/addHomeClient
router.post("/addImportantQuestionsforHome",quotationHomeController.addImportantQuestionsforHome);
router.post("/addPolicyHome",quotationHomeController.addPolicyCoreHome);
router.post("/addBuildingDetailsHome",quotationHomeController.addBuildingDetailsHome);
router.post("/addContentsHome",quotationHomeController.addContentsHome);
router.post("/addClaimsHome",quotationHomeController.addClaimsHome);
router.get("/getQuotationsHome",quotationHomeController.getQuotationsHome);
router.get("/quotationDetailsforID", quotationHomeController.getQuotationDetail);
router.post("/updateQuotationHome",quotationHomeController.updateHomeQuotations);//http://localhost:3001/quotationHome/updateQuotationHome
module.exports = router;

