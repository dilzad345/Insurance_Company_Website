const express = require("express");

const userController = require("../controller/userController");

const router = express.Router();

router.post("/signin", userController.signin); // http://localhost3001/user/signin
router.post("/addUser", userController.addUser);
router.get("/isAuthenticated", userController.isAuthenticated);
router.post("/signout", userController.signOut);
router.post("/admin/addUser", userController.adminAddUser);

module.exports = router;
