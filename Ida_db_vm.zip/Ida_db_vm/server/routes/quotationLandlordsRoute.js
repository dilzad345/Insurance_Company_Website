const express = require("express");
const quotationLandController = require("../controller/quotationLandlordsController");
const router = express.Router();

//1. A route method for inserting client details 
// router.post("/addLandClient",quotationLandController.addLandClient);

//2. A route method for inserting Important Questions
// router.post("/addImportantQuestions", quotationLandController.addImportantQuestions); 

//3. A route method for inserting Policy Core
// router.post("/addPolicyCore", quotationLandController.addPolicyCoreLand);

//4. A route method for inserting Building
// router.post("/addBuilding" , quotationLandController.addBuildingLand);

//5. A route method for inserting Contents
// router.post("/addContents" , quotationLandController.addContentsLand);

//6. A route method for inserting Claims
// router.post("/addClaims" , quotationLandController.addClaimsLand);

router.post("/addQuotationLandlords", quotationLandController.addQuotation);
//2. A route mathod for getting quotation details for land
router.get("/getQuotationsLand", quotationLandController.getQuotationsLand); // http://localhost:3001/quotationLandlords/getQuotationsLand

//3. A route method for getting quotation Details by Id
router.get("/getQuotationDetails", quotationLandController.getQuotationsDetails);

//4. A route method for updating quotation for a specific quotation Id
router.post("/updateQuotationLand",quotationLandController.updateLandQuotations);

//5. A route method for generate pdf for quotation
// router.get("/fetchPdf", quotationLandController.createPDF);
module.exports = router;