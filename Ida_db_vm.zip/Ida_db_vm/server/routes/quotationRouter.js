const express = require("express");

const quotationController = require("../controller/quotationController");

const router = express.Router();

router.get("/getQuotations", quotationController.getQuotations); // '/quotation'
router.post("/addClient", quotationController.addClientDetails);
router.post(
  "/addImportantQuestions",
  quotationController.addImportantQuestions
);
router.post("/addPolicyCore", quotationController.addPolicyCore);
router.post("/addVehicle", quotationController.addVehicleInfomation);
router.post("/addModification", quotationController.addModification);
router.post("/addDrivers", quotationController.addDrivers);
router.get("/quotation", quotationController.getQuotationDetail); //http://localhost:3001/quotation/quotation
router.get("/client", quotationController.getClientDetail);
router.post('/updateQuotation', quotationController.updateQuotation); 
router.get('/sampleURL', quotationController.sampleURL); //sample get

module.exports = router;
