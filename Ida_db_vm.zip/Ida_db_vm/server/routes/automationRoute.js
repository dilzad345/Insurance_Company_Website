const express = require("express");

const automationController = require("../controller/automationController");

//For Home
const automationHomeController = require("../controller/automationHomeController");
const automationLandController = require("../controller/automationLandController");

const router = express.Router();

router.post("/submit", automationController.submitQuotationData); // http://localhost3001/user/signin
router.post("/submitHome", automationHomeController.submissionHomeQuotation);
router.post("/submitLand", automationLandController.submitLandQuotation);
module.exports = router;