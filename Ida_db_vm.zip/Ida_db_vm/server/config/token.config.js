module.exports = {
    'secretkey': 'jwtSecret_IDA'
  };