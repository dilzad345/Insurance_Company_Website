import React, {useContext} from 'react'
import "./topBar.css"
import logo from "../../images/logo.png"
// import { signout } from '../../auth/index';
import { AuthContext } from '../../context/AuthContext';

// import { UserContext } from '../../App';
const Topbar= () => {
    const { user , dispatch } = useContext(AuthContext)
    
    const handleLogout = () =>{
        dispatch({ type:"LOGOUT" });
    }
    return (
        <div className="topbar">
            <div className="topbarwrapper">
                <div className="topLeft">
                    <img alt = "EnsureTek Logo" src={logo} className="logo"/>
                </div> 
                <div className='topRight'>
                    {user ? (<button onClick={handleLogout} className="logoutBtn">Signout</button>) : <></>}
                </div>
            </div>
        </div>
    )
};


export default Topbar;