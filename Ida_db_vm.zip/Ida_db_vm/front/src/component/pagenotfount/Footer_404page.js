import React from "react";
import { Navbar } from "react-bootstrap";
import "./footer-new.css";

export default function Footer() {
  const date = new Date();
  const year = date.getFullYear();
  return (
    // <footer className="footer">
    // <footer className="box">
    //   <div className="footerlable">All Rights Reserved by ENSURETEK {year}</div>
    // </footer>
    <div>
      <Navbar
        className="footer-align"
        style={{ backgroundColor: "#02516b" }}
        bg="#70aec2"
        variant="dark"
      >
        <Navbar.Brand>
          <div className="tabalign">
            <div className="footerlable">
              All Rights Reserved by ENSURETEK {year}
            </div>
          </div>
        </Navbar.Brand>
      </Navbar>
    </div>
  );
}
