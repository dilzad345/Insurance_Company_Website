import React from "react";

import "../../css/homeStyle.css";
import { Navbar } from "react-bootstrap";

import logo from "../../images/logo.png";

import logo1 from "../../images/pagenotfound.png";
import "./pagenotfound.css";
// import Footer from "../footer/Footer";
import FooterNew from "../pagenotfount/Footer_404page";

export default function PagenotFount() {
  return (
    <div>
      <div>
        <Navbar
          style={{ backgroundColor: "#02516b" }}
          bg="#70aec2"
          variant="dark"
        >
          <Navbar.Brand href="#client">
            <img
              alt="EnsureTek logo"
              src={logo}
              width="35%"
              height="30%"
              className="d-inline-block align-top"
            />
          </Navbar.Brand>
        </Navbar>

        <div className="notfoundlogo">
          <a href="">
            <img
              alt="Page Not Found Clicked Here.."
              src={logo1}
              width="40%"
              height="35%"
              className="logoColor"
            />
          </a>
        </div>
      </div>

      {/* <FooterNew /> */}
    </div>
  );
}
