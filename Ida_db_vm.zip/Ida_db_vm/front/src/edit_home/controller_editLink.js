import axios from "axios";
import { API } from "../config";
// import catchAsync from "../utils/catchAsync";

import {tab1ValidationHomeEdit} from '../validationHome/Tab1_Validation_Home';
// import {Tab2_Validation_Home} from '../validationHome/Tab2_Validation_Home';
import {Tab3_Validation_Home} from '../validationHome/Tab3_Validation_Home';
import {Tab4_Validation_Home} from '../validationHome/Tab4_Validation_Home';
import {Tab5_Validation_Home} from '../validationHome/Tab5_Validation_Home';
import {Tab6_Validation_Home} from '../validationHome/Tab6_Validation_Home';

export const validateAllForms = (
  Tab1_Client_Home_var,
  Tab3_Policycore_Home_Var,
  Tab4_Building_Home_Var,
  Tab5_Contents_Home_Var,
  Tab6_Claims_Home_Var
) => {
  //console.log("tab6 validate: " , Tab6_Claims_Home_Var);
  let isValid = true;
   isValid = isValid * tab1ValidationHomeEdit(Tab1_Client_Home_var);
  //isValid = isValid * Tab2_Validation_Home(Tab2_Importan_Question_Home_var);
  isValid = isValid * Tab3_Validation_Home(Tab3_Policycore_Home_Var);
  isValid = isValid * Tab4_Validation_Home(Tab4_Building_Home_Var);
  isValid = isValid * Tab5_Validation_Home(Tab5_Contents_Home_Var,Tab3_Policycore_Home_Var);
  isValid = isValid * Tab6_Validation_Home(Tab6_Claims_Home_Var);

  return isValid;
};

// method: get all form details of a quotation using quotation id;
export const getQuotationDetail = async (quotationId) => {
  try {
    const result = await axios
      .get(`${API}/quotationHome/quotationDetailsforID?quotationId=` + quotationId,
        {
          headers: JSON.parse(localStorage.getItem("user"))
        });
    console.log("result :",result);
    return result;
  } catch (error) {
    console.log(error);
  }
}; // end of get quotation details

// method: update quotation details;
export const updateAllForms = async (
  Tab1_Client_Home_var,
  Tab2_Importan_Question_Home_var,
  Tab3_Policycore_Home_Var,
  Tab4_Building_Home_Var,
  Tab5_Contents_Home_Var,
  Tab6_Claims_Home_Var,
  //tab7_claims,
  quotationId) => {

  const dataForHome = {
    data_tab1: Tab1_Client_Home_var,
    data_tab2: Tab2_Importan_Question_Home_var,
    data_tab3: Tab3_Policycore_Home_Var,
    data_tab4: Tab4_Building_Home_Var,
    data_tab5: Tab5_Contents_Home_Var,
    data_tab6: Tab6_Claims_Home_Var,
    // data_tab7: tab7_claims,
    quotationId: quotationId,
  }
 console.log(dataForHome);
  try {
    const result = await axios.post(`${API}/quotationHome/updateQuotationHome`,dataForHome);
    return result;
  } catch (err) {
    console.log(err);
    return false;
  }

} // end of update all forms

export const assignValue_tab1 = (dataClient, Tab1_Client_Home_var, setTab1) => {
  setTab1({
    ClientIdForHomeFromUipath:dataClient.client_code_home,
    clientType: dataClient.client_type,  //client_type is one of the client home table's column name
    title: dataClient.client_title,
    firstName: dataClient.client_firstName,
    lastName: dataClient.client_lastName,
    companyName: dataClient.company_name,
    tradingAs: dataClient.trading_as,
    officeTechReferenceCode: dataClient.reference_code,
    unitNumber: dataClient.unit_number_postal,
    streetNumber: dataClient.street_number_postal,
    streetName: dataClient.street_name_postal,
    streetType: dataClient.street_type_postal,
    suburb: dataClient.suburb_postal,
    state: dataClient.state_postal,
    postCode: dataClient.postcode_postal,
    phone: dataClient.phone,
    email: dataClient.email,
    branch: dataClient.branch,
    salesTeam: dataClient.sales_team,
    serviceTeam: dataClient.service_team,
  });
};

export const assignValue_tab2 = (dataImp, Tab2_importantQuestions_home, setTab2) => {
  setTab2({
    insPolcyCancellLast5Years: dataImp.any_policy_declined_last5years,
    hadClaimDeclained: dataImp.claim_decline,
    maliciousDamage: dataImp.criminal_conviction_last5years,
    homeUnderConstruction: dataImp.under_construction_renovation,
    Bankruptcy: dataImp.bankruptcy,
    buildingFlooded: dataImp.has_flooded_last10_years,
  });
};

export const assignValue_tab3 = (dataPolicyCore, Tab3_Policycore_Home_Var, setTab3) => {
  setTab3({
    coverType: dataPolicyCore.cover_type,
    basisOfSettlement: dataPolicyCore.basis_settlement,
    buildingOrContents: dataPolicyCore.building_contents,
    buildingSumInsured: dataPolicyCore.building_sum_insured,
    contentsSumInsuredAmount: dataPolicyCore.contents_insuredAmount,
    policyFromDate: new Date(dataPolicyCore.policy_fromDate),
    // policyFromDate: dataPolicyCore.policy_fromDate.substring(0, 10),
    policyToDate: new Date(dataPolicyCore.policy_toDate),
    dobOldestInsured: new Date(dataPolicyCore.dob_oldestInsured),  //dob:date of birth
    industryPolicyHolder: dataPolicyCore.industry_policyholder,
    policyHolderRetired: dataPolicyCore.policyholder_retired,
    conductedFromHome: dataPolicyCore.business_conducted_from_home,
    fromHomeBusinessName: dataPolicyCore.ifYes_business_name,
    fromHomeWhatBusiness: dataPolicyCore.ifYes_business_type,
    fromHomeAnnualRevenue: dataPolicyCore.ifYes_annual_revenue,
    fromHomeBusnsOccupyFloorArea: dataPolicyCore.ifYes_occupy_more_than_20_area,
    underConstruction: dataPolicyCore.under_construction,
    poorlyMaintained: dataPolicyCore.poor_condition_maintained,
    unoccupiedDays: dataPolicyCore.unoccupied_90_days,
    guestHouse: dataPolicyCore.hostel_brekfast_bed_guesthouse,
    publicHousing: dataPolicyCore.community_public_housing,
    currentlyInsurance: dataPolicyCore.hold_insurance,
    interestedParties: dataPolicyCore.interested_parties,
    jettyAttachedProperty: dataPolicyCore.jetty_attached_property,
    svuExcessOption1: dataPolicyCore.excess_option1,
    svuExcessOption2: dataPolicyCore.excess_option2,
    svuExcessOption3: dataPolicyCore. excess_option3,
    brokerFee: dataPolicyCore.broker_fee,
    paymentFrequency: dataPolicyCore.payment_frequncy,
    preferredinstallments: dataPolicyCore.preferred_day_Installment,
    brokerFeeinstallments: dataPolicyCore.broker_free_Installment,
    unspecifiedValues:dataPolicyCore.unspecified_valuables
  });
};

export const assignValue_tab4 = (dataBuilding, Tab4_Building_Home_Var, setTab4,dataClient) => {
  setTab4({
    insuredAddress :dataBuilding.is_insuredAddressSame_postalAddress,
    streetNumber_insured:dataClient.street_number_insured,
    street_type_insured:dataClient.street_type_insured,
    street_name_insured:dataClient.street_name_insured,
    suburb_insured:dataClient.suburb_insured,
    state_insured:dataClient.state_insured,
    postcode_insured:dataClient.postcode_insured,
    streetNumber:dataClient.street_number_postal,
    streetType:dataClient.street_type_postal,
    streetName:dataClient.street_name_postal,
    suburb:dataClient.suburb_postal,
    state:dataClient.state_postal,
    postCode:dataClient.postcode_postal,
    UnitNumber:dataClient.unit_number_postal,

    prptyHeritageList: dataBuilding.property_heritage_list,
    provideDetails: dataBuilding.if_heriageList_moreDetails,
    whatOccupancyHome: dataBuilding.home_occupancy,
    buildingType: dataBuilding.building_type,
    whatBuiltHome: dataBuilding.if_free_standing_whats_built,
    whatTypeApartment: dataBuilding.if_apartment_appartment_type,
    whatTypeSemiDetached: dataBuilding.if_semi_detached_type,
    managemenBodyCorporate: dataBuilding.if_semi_detached_strata_manage,
    dwellingDescribesHome: dataBuilding.if_other_dwelling_describe_home,
    smhAcres20000: dataBuilding.exceed_20k_mkm_2hect_5acres,
    insuredGenerateIncome: dataBuilding.if_exceed_insured_generate_income,
    machineryImplmtVehicles: dataBuilding.if_exceed_farm_building_machinery,
    more6Livestock: dataBuilding.if_exceed_moreThan_6_liveStock,
    propertyUsedAnimals: dataBuilding.if_exceed_used_agisment_peoples_animals,
    nonPersonalUse: dataBuilding.if_exceed_horses_nonPersonal_use,
    aircraftLandingStrip: dataBuilding.if_exceed_aircrapt_landing_strip,
    constructionPeriod: dataBuilding.construction_period,
    originalYearBuilt: dataBuilding.year_built,
    constructionWalls: dataBuilding.construction_walls,
    roofConstruction: dataBuilding.roof_construction,
    consQualityofHome: dataBuilding.construction_quality,
    numberOfPropertyHave: dataBuilding.storeys_number,
    unitBuildingLevel: dataBuilding.unit_buildingLevel,
    effectByWtaer: dataBuilding.house_250m_waterCourse,
    mainsWaterSupply: dataBuilding.water_supply,
    windowSecurity: dataBuilding.window_security,
    doorSecurity: dataBuilding.door_security,
    burglarAlarm: dataBuilding.burglar_alarm,
    smokeDetectors: dataBuilding.smoke_detector,
    builtConstNextMnth: dataBuilding.construction_12_months,
    swimmingPool: dataBuilding.swimming_pool,
    locatedbelowgRoundLevel: dataBuilding.Building_located_ground_level,
    privateFlood: dataBuilding.mitigation_measures_property,
    occupancyCertificate: dataBuilding.occupency_certification,
    housebeenReroofed: dataBuilding.house_reroofed,
    housebeenReplumbed: dataBuilding.house_replumbed,
    housebeenRewired : dataBuilding.house_rewired,
  });

  // console.log("building: ",Tab4_Building_Home_Var);
};


export const assignValue_tab5 = (dataContents, Tab5_Contents_Home_Var, setTab5, setTab5_validation) => {
  // console.log("datacontents from controller page:", Tab5_Contents_Home_Var);
  dataContents.map((content) => {
    setTab5((tab5_contents) => [
      ...tab5_contents,
      {
        contentID: content.contents_id,
        edit: 'OLD',
        type: content.type,
        category: content.category,
        description: content.description,
        value: content.value,
      },
    ]);
   
    setTab5_validation((tab5_validation) => [
      ...tab5_validation,
      {
        type: true,
        category: true,
        description: true,
        value: true,
      },
    ]);
    // console.log("Contents Tab: ",Tab5_Contents_Home_Var);
  });
};



export const assignValue_tab6 = (dataClaims, tab6_claims, setTab6, setTab6_validation) => {
  // console.log("claims fromcontroller page:",dataClaims);
  dataClaims.map((claimArray) => {
      setTab6((tab6_claims) => [
        ...tab6_claims,
        {
          edit: 'OLD',
          claimId: claimArray.claim_id,
          typeClaim: claimArray.claim_type,
          dateClaim: new Date(claimArray.date_claim),
          description: claimArray.claim_description,
          amount: claimArray.claim_amount,
          insurer:claimArray.insurer
        }
      ]);

      setTab6_validation((tab6_validation) => [
        ...tab6_validation,
        {
          typeClaim: null,
          dateClaim: null,
          description: null,
          claimOutcome: null,
          amount: null,
          insurer:null
        }
      ]);
    
  })
};
