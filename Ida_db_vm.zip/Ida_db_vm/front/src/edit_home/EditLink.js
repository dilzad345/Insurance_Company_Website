import React, { useEffect, useState } from "react";
import Tab1_Client_Home from "./Tab1_Client_Home";
import Tab2_IQ_Home from "./Tab2_Importan_Question_Home";
import Tab3_PolicyCore_Home from "./Tab3_Policycore_Home";
import Tab4_Building_Home from "./Tab4_Building_Home";
import Tab5_Contents_Home from "./Tab5_Contents_Home";
import Tab6_Claims_Home from "./Tab6_Claims_Home";
import { useStep } from "react-hooks-helper";
import {navigationEditBar} from "../core/navigationBar_Home";
// import { navigationBar } from "../core/navigationBar_Home";
import { useStateWithCallbackLazy } from "use-state-with-callback";
import { updateAllForms } from "./controller_editLink";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import history from "../auth/history";
import { signout } from "../auth";
import {
  validateAllForms,
  // assignValuesToEveryForm,
  getQuotationDetail,
  // getClientDetail,
  assignValue_tab3,
  assignValue_tab1,
  assignValue_tab2,
  assignValue_tab4,
  assignValue_tab5,
  assignValue_tab6,
  // assignValue_tab7,
} from "./controller_editLink";


// import { agreedValueAmount_validate } from "../validations/tab3_validate";
let tokenError = false;

//Error message for invalid token
const tokenErrorMessage = (tokenError) => {
  return (
    <div>
      {tokenError === true &&
        confirmAlert({
          title: "Invalid User",
          message: "Re-login to system.",
          buttons: [
            {
              label: "Login",
              onClick: () => {
                signout(() => {
                  history.push("/signin");
                });
              },
            },
            // {
            //   label: 'No',
            //   onClick: () => null
            // }
          ],
        })}
    </div>
  );
};

// navigation helper
const steps = [
  { id: "tab1_client_home" },
  { id: "tab2_importantQuestions_home" },
  { id: "tab3_policyCore_home" },
  { id: "tab4_buildingDetails_home" },
  { id: "tab5_contents_home" },
  { id: "tab6_claims_home" },
];

const EditLink = (props) => {
  // const [quotationEdit, set_quotationEdit] = useStateWithCallbackLazy({});
  const [quotationId, setQuotationId] = useStateWithCallbackLazy();

  const { step, navigation } = useStep({
    steps,
    initialStep: 0,
  }); // end of useStep

  // get all quotation details from the db and assign values to the related variables
  useEffect(() => {
    setQuotationId(props.id, () => {
      assignValuesToEveryForm(props.id);
      //set_quotationEdit(result_quotationEdit, () => {console.log(quotationEdit);});
    });
  });

  //
  const assignValuesToEveryForm = async (quotationId) => {
    if (quotationId) {
      await getQuotationDetail(quotationId)
        .then(async (resQuote) => {
          console.log("results: ", resQuote.data.data);

          if (resQuote.data.message) {
            console.log("Error in token");
            tokenError = true;
            tokenErrorMessage(tokenError);
          } else {
            const dataClient = resQuote.data.data.dataClientHome;
            //console.log("client Home: ",dataClient);dataImportantQuestionHome
            const dataImp = resQuote.data.data.dataImportantQuestionHome;
            const dataPolicyCore = resQuote.data.data.dataPolicyCoreHome; //datapolicycoreHome is coming from backend
            const dataBuilding = resQuote.data.data.dataBuildingHome;
            const dataContents = resQuote.data.data.dataContentsHome;

            const dataClaims = resQuote.data.data.dataClaimsHome;
            // console.log("claims Home: ", dataClaims);
            // Tab2_Importan_Question_Home_var
            assignValue_tab1(dataClient, Tab1_Client_Home_var, setTab1);
            assignValue_tab2(dataImp, Tab2_Importan_Question_Home_var, setTab2);
            assignValue_tab3(dataPolicyCore, Tab3_Policycore_Home_Var, setTab3);
            assignValue_tab4(dataBuilding, Tab4_Building_Home_Var, setTab4,dataClient);
            assignValue_tab5(dataContents, Tab5_Contents_Home_Var, setTab5, setTab5_validation);
            assignValue_tab6(dataClaims, Tab6_Claims_Home_Var, setTab6, setTab6_validation);
            // console.log("tab5 assigned value:",assignValue_tab5);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    }
  };

  // tab1 variable object defined
  const [Tab1_Client_Home_var, setTab1] = useStateWithCallbackLazy({
    ClientIdForHomeFromUipath:"",
    ClientId_Home: "",
    clientType: " ",
    title: "",
    firstName: "",
    lastName: "",
    companyName: "",
    tradingAs: "",
    officeTechReferenceCode: "",
    unitNumber: null,
    streetNumber: 0,
    streetName: "",
    streetType: " ",
    suburb: "",
    state: " ",
    postCode: 0,
    phone: "",
    email: "",
    branch: "",
    salesTeam: " ",
    serviceTeam: " ",
  });

  // tab1 validation
  const [Tab1_Validation_Home_Var, setTab1_validation] = useState({
    clientType: null,
    title: null,
    firstName: null,
    lastName: null,
    companyName: null,
    tradingAs: null,
    tab1_fullValidation: null,
  });

  // tab2 variable object defined
  const [Tab2_Importan_Question_Home_var, setTab2] = useStateWithCallbackLazy({
    insPolcyCancellLast5Years: "No",
    hadClaimDeclained: "No",
    maliciousDamage: "No",
    homeUnderConstruction: "No",
    Bankruptcy: "No",
    buildingFlooded: "No",
  });

  // tab2 validation
  const [tab2_validation, setTab2_validation] = useState({});

  // tab3 variable object defined
  const [Tab3_Policycore_Home_Var, setTab3] = useStateWithCallbackLazy({
    coverType: "Accidential Damage",
    basisOfSettlement: "Replacement",
    buildingOrContents: "Building only",
    buildingSumInsured: "Yes",  //has to be checked
    contentsSumInsuredAmount: "1000",
    coverType:"Accidental Damage",
    // policyFromDate: "2021-02-02",
    policyFromDate: "2021-02-02",
    policyToDate: "2022-02-02",
    dobOldestInsured: "yyyy-MM-dd",  //dob:date of birth
    industryPolicyHolder: "Banking and Finance",
    policyHolderRetired: "No",
    conductedFromHome: "No",
    fromHomeBusinessName: "ABC",
    fromHomeWhatBusiness: "Accounting",
    fromHomeAnnualRevenue: "Insurer Decides",
    fromHomeBusnsOccupyFloorArea: "No",
    underConstruction: "No",
    poorlyMaintained: "No",
    unoccupiedDays: "No",
    guestHouse: "No",
    publicHousing: "No",
    currentlyInsurance: "0-1 Years",
    interestedParties: "Adelaide Bank",
    jettyAttachedProperty: "No",
    svuExcessOption1: "500",
    svuExcessOption2: "600",
    svuExcessOption3: "700",
    brokerFee: "800", //has to be rechecked
    paymentFrequency: "Yearly",
    preferredinstallments: "600",
    brokerFeeinstallments: "700",
    unspecifiedValues: " ",

  });

  //tab3 validation
  const [Tab3_Validation_Home_Var, setTab3_validation] = useState({
    coverType: "",
    basisOfSettlement: "",
    buildingOrContents: "",
    buildingSumInsured: "",
    contentsSumInsuredAmount: "",
    policyFromDate: "",
    policyToDate: "",
    dobOldestInsured: "",  //dob:date of birth
    industryPolicyHolder: "",
    policyHolderRetired: "",
    conductedFromHome: "",
    fromHomeBusinessName: "",
    fromHomeWhatBusiness: "",
    fromHomeAnnualRevenue: "",
    currentlyInsurance: "",
    interestedParties: "",
    svuExcessOption1: "",
    svuExcessOption2: "",
    svuExcessOption3: "",
    brokerFee: "",
    paymentFrequency: "",
    preferredinstallments: "",
    brokerFeeinstallments: "",
  });

  //assign objects for tab3
  const [Tab4_Building_Home_Var, setTab4] = useStateWithCallbackLazy({
    prptyHeritageList: "No",
    provideDetails: "Australia",
    whatOccupancyHome: "Rent/Lease",
    buildingType: "Free Standing / House",
    whatBuiltHome: "Concrete slab",
    whatTypeApartment: "Ground floor",
    whatTypeSemiDetached: "Duplex/Triplex",
    managemenBodyCorporate: "No",
    dwellingDescribesHome: "Granny flat",
    smhAcres20000: "No",
    insuredGenerateIncome: "No",
    machineryImplmtVehicles: "No",
    more6Livestock: "No",
    propertyUsedAnimals: "No",
    nonPersonalUse: "No",
    aircraftLandingStrip: "No",
    constructionPeriod: "1960 to now (project home)",
    originalYearBuilt: "1",
    constructionWalls: "Concrete",
    roofConstruction: "Concrete Tile",
    consQualityofHome: "Standard",
    numberOfPropertyHave: "1",
    unitBuildingLevel: "1",
    effectByWtaer: "No",
    mainsWaterSupply: "No",
    windowSecurity: "Key Operated Locks",
    doorSecurity: "Key operated dead locks/bolts",
    burglarAlarm: "Back to base",
    smokeDetectors: "Back to base",
    builtConstNextMnth: "No",
    swimmingPool: "No",
    locatedbelowgRoundLevel: "No",
    privateFlood: "No",
    occupancyCertificate: "No",
    housebeenReroofed: "Yes",
    housebeenReplumbed: "Yes",
    housebeenRewired : "Yes",
  });

  //tab4 validation
  const [Tab4_Validation_Home_Var, setTab4_validation] = useState({
    originalYearBuilt: "",
  });

  const [Tab5_Contents_Home_Var, setTab5] = useStateWithCallbackLazy([]);

  const [Tab5_Validation_Home_Var, setTab5_validation] = useState([]);

  const [Tab6_Claims_Home_Var, setTab6] = useStateWithCallbackLazy([]);

  const [Tab6_Validation_Home_Var, setTab6_validation] = useState([
    {
      
    }
  ]);

  // submit all forms
  const updateAllForm = () => {
    return updateAllForms(
      Tab1_Client_Home_var,
      Tab2_Importan_Question_Home_var,
      Tab3_Policycore_Home_Var,
      Tab4_Building_Home_Var,
      Tab5_Contents_Home_Var,
      Tab6_Claims_Home_Var,
      //tab7_claims,
      quotationId
    )
      .then((res) => {
        console.log(res.status);
        if (res.status === 201) {
          console.log("No Error");
          return true;
        } else {
          console.log("Error");
          return false;
        }
      })
      .catch((err) => {
        console.log(err);
        return false;
      });
  }; // end of submit function

  // validate all forms
  const isAllFormsValid = () => {

    // console.log("validate a;ll forms: ", Tab6_Claims_Home_Var)
    const isValid = validateAllForms(
      Tab1_Client_Home_var,
      Tab3_Policycore_Home_Var,
      Tab4_Building_Home_Var,
      Tab5_Contents_Home_Var,
      Tab6_Claims_Home_Var,
      //tab7_claims
    );
    return isValid;
  };

  // props: tab1, creating props to provide to every tab components
  const props1 = {
    Tab1_Client_Home_var,
    setTab1,
    Tab1_Validation_Home_Var,
    setTab1_validation,
    navigation,
  };
  const props2 = {
    Tab2_Importan_Question_Home_var,
    setTab2,
    tab2_validation,
    setTab2_validation,
    navigation,
  };

  const props3 = {
    Tab3_Policycore_Home_Var,
    setTab3,
    Tab3_Validation_Home_Var,
    setTab3_validation,
    navigation,
  };

  let coverType = props3.Tab3_Policycore_Home_Var.coverType;

  const props4 = {
    Tab4_Building_Home_Var,
    setTab4,
    Tab4_Validation_Home_Var,
    setTab4_validation,
    navigation,
  };

  const props5 = {
    Tab5_Contents_Home_Var,
    setTab5,
    Tab5_Validation_Home_Var,
    setTab5_validation,
    coverType,
    Tab3_Policycore_Home_Var,
    setTab3,
    Tab3_Validation_Home_Var,
    setTab3_validation,
    navigation,
  };
//  console.log("props5: ",props5)
  const props6 = {
    Tab6_Claims_Home_Var,
    setTab6,
    Tab6_Validation_Home_Var,
    setTab6_validation,
    isAllFormsValid,
    updateAllForm,
    navigation,
  };
//console.log(props5);
  /* const props7 = {
    tab6_drivers,
    tab7_claims,
    setTab7,
    tab7_validation,
    setTab7_validation,
    isAllFormsValid,
    updateAllForm,
    navigation,
  }; */

  // return function to display all tabs
  const displayTabs = () => {
    // console.log(step.id);
    switch (step.id) {
      default:
        return <Tab1_Client_Home {...props1} />;
      case "tab1_client_home":
        return <Tab1_Client_Home {...props1} />;
      case "tab2_importantQuestions_home":
        return <Tab2_IQ_Home {...props2} />;
      case "tab3_policyCore_home":
        return <Tab3_PolicyCore_Home {...props3} />;
      case "tab4_buildingDetails_home":
        return <Tab4_Building_Home {...props4} />;
      case "tab5_contents_home":
        return <Tab5_Contents_Home {...props5} />;
      case "tab6_claims_home":
        return <Tab6_Claims_Home {...props6} />;

    }
  };





  // set props to navigation bar
  const propsNavBar = {
    step,
    navigation,
    Tab1_Client_Home_var,
    Tab2_Importan_Question_Home_var,
    Tab3_Policycore_Home_Var,
    Tab4_Building_Home_Var,
    Tab5_Contents_Home_Var,
    Tab6_Claims_Home_Var,
  };

  // render return
  return (
    // <div className="container-fluid">
    <div>
      {navigationEditBar(propsNavBar)}
      {/* {navigationBar(propsNavBar)} */}
      {displayTabs()}
      <ToastContainer
        style={{ marginLeft: "50px", marginBottom: "-25px", width: "30%" }}
      />
    </div>
  );
};

export default EditLink;
