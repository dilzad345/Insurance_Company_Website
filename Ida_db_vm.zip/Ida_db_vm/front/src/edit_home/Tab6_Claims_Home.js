import React, { useState } from "react";
import {
  TextField,
  Container,
  Button,
  InputLabel,
  MenuItem,
  Select,
  Grid,
} from "@material-ui/core";
// import { makeStyles } from "@material-ui/core/styles";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Autocomplete } from '@mui/material';
import { insurerValues } from '../constants/dropDownData';
 import DatePicker from "react-datepicker";
import { Redirect } from 'react-router-dom';
import {
  typeClaim_validate,
  dateClaim_validate,
  description_validate,
  amount_validate,
} from "../validationHome/Tab6_Validation_Home";


const notifyDeleteclaimfication = () =>
  toast.success("Claim Deleted!", {
    position: "bottom-center",
    autoClose: 5000,
    hideProgressBar: true,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
  });

const Tab6_Claims_Home = ({
  Tab6_Claims_Home_Var,
  setTab6,
  Tab6_Validation_Home_Var,
  setTab6_validation,
  isAllFormsValid,
  navigation,
  updateAllForm,

}) => {
  // const claimCount = Tab6_Claims_Home_Var.length;
  // const classes = useStyles();
  // const [loaded, setLoad] = useState(false);
  const [loadClientHome, setLoadClientHome] = useState(false);
  const claimCount = Tab6_Claims_Home.length;
  console.log("Tab6_Claims_Home:", claimCount);

  const notify = () =>
    toast.success("Verify Status: Success!", {
      position: "bottom-center",
      autoClose: 5000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });

  const notifyFailure = () =>
    toast.error("Verify Status: Failed!", {
      position: "bottom-center",
      autoClose: 2000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });

  const handleSubmit = () => {
    updateAllForm()
      .then((res) => {
        console.log(res);
        if (res === true) {
          notify();
          setTimeout(function () { setLoadClientHome(true); }, 3000);
          console.log("set load home page: " + res);
          // setLoadClientHome(true); // change to true to redirect to the client home page
        } else if (res === false) {
          notifyFailure();
          setTimeout(function () { setLoadClientHome(true); }, 3000);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const loadClientHomePage = () => {
    if (loadClientHome) {
      return <Redirect to='/user/dashboard_home' />
    }
  }

  // add a home claims claimfications
  const addMore = () => {
    setTab6((Tab6_Claims_Home_Var) => [
      ...Tab6_Claims_Home_Var,
      { edit: "NEW", typeClaim: " ", dateClaim: new Date(), description: "", amount: "" },
    ]);
    setTab6_validation((Tab6_Validation_Home_Var) => [
      ...Tab6_Validation_Home_Var,
      { typeClaim: " ", dateClaim: " ", description: "", amount: "" },
    ]);
  };

  // onClick method: delete claimfication when not needed
  const deleteclaim = (ind) => {
    console.log(ind);
    let temp = [...Tab6_Claims_Home_Var];
    // let tempValidate = [...Tab6_Validation_Home_Var];
    let tempObj = temp[ind];
    confirmAlert({
      title: "Confirm to delete",
      message: "Are you sure to do this?",
      buttons: [
        {
          label: "Yes",
          onClick: () => {
            // removing the element using splice
            if (tempObj.edit === "NEW") {
              console.log("new delete: " + ind);
              const temp1 = [...Tab6_Claims_Home_Var];
              const tempValidate1 = [...Tab6_Validation_Home_Var];
              temp1.splice(ind, 1); // removing the element using splice
              tempValidate1.splice(ind, 1);
              Tab6_Claims_Home_Var = temp1;
              Tab6_Validation_Home_Var = tempValidate1;
              setTab6(temp1); // updating the list
              setTab6_validation(tempValidate1);
            }
            else {
              tempObj = {
                // updating the temporary list
                ...tempObj,
                edit: "DELETED",
              };
              temp[ind] = tempObj; // replace the list with temporary list
              console.log("temp", temp[ind]);
              console.log("ind: " + ind + " edit: " + temp[ind].edit);
              setTab6(temp);
              // setTab6_validation(tempValidate);
            }
            notifyDeleteclaimfication();
          },
        },
        {
          label: "No",
          onClick: () => null,
        },
      ],
    });
  };

   // set insurer field when selecting
   const setInsurer = (ind, val) => {
    console.log(ind);
    console.log(val);
    let name = "insurer";
    let value;
    let tempArr = [...Tab6_Claims_Home_Var];
    let tempObj = tempArr[ind];

    if (val) {
      value = val.insurAus;
      tempObj = {
        ...tempObj,
        [name]: value,
      };
      tempArr[ind] = tempObj;
      //console.log(tempArr);

      setTab6(tempArr, () => {
        validationAfterChange(ind, name, value);
      });
    }

    else {
      value = " ";
      tempObj = {
        ...tempObj,
        [name]: value,
      };
      tempArr[ind] = tempObj;
      //console.log(tempArr);

      setTab6(tempArr, () => {
        validationAfterChange(ind, name, value);
      });
    }
  }

  // on change method; to change field values according to the changes
  const onChangeField = (ind) => (event) => {
    let name = event.target.name;
    let value = event.target.value;
    // make a copy of original list as temporary list
    let tempArr = [...Tab6_Claims_Home_Var];
    let tempObj = tempArr[ind];

    // updating the temporary list
    tempObj = {
      ...tempObj,
      [event.target.name]: event.target.value,
    };

    // replace the list with temporary listg
    tempArr[ind] = tempObj;
    //console.log(tempArr);

    setTab6(tempArr, () => {
      validationAfterChange(ind, name, value);
    });
  };

  //method for not to typing in date field
  const handleDateChangeRaw = (e) => {
    e.preventDefault();
  }
  const dateClaim = (date, index) => {
    console.log(date);
    // setTab7({
    //   ...tab7_claims,
    //   dateClaim: date,

    // });
    let name = "dateClaim"
    let value = date;
    console.log("value:" ,value);
    console.log("index:" ,index);
    // make a copy of original list as temporary list
    let tempArr = [...Tab6_Claims_Home_Var];
    let tempObj = tempArr[index];

    // updating the temporary list
    tempObj = {
      ...tempObj,
      [name]: value,
    };

    // replace the list with temporary list
    tempArr[index] = tempObj;
    console.log("temparr:" ,tempArr);
    setTab6(tempArr);
    //console.log(setTab6);
    dateClaim_validate(index, value, Tab6_Validation_Home_Var, setTab6_validation);
  };
  // call validation
  const validationAfterChange = (index, name, value) => {
    switch (name) {
      case "typeClaim": {
        typeClaim_validate(index, value, Tab6_Validation_Home_Var, setTab6_validation);
        break;
      }
      case "dateClaim": {
        dateClaim_validate(index, value, Tab6_Validation_Home_Var, setTab6_validation);
        break;
      }
      case "description": {
        description_validate(index, value, Tab6_Validation_Home_Var, setTab6_validation);
        break;
      }
      case "amount": {
        amount_validate(index, value, Tab6_Validation_Home_Var, setTab6_validation);
        break;
      }
      default: {
        return "Not match to condition";
      }
    }
  };
  const displayTab6 = () => {
    return (
      <Container maxWidth="md" style={{ marginBottom: "50px" }}>
        <div className="container p-3 my-3dark text-dark">
          <Grid item xs={12} justifyContent="center" container>
            <h3>Add button below to add claims in the last 5 years</h3>
          </Grid>
          {Tab6_Claims_Home_Var.map((claim, index) => {
            if (claim.edit !== "DELETED") {
              return (
                <div>
                  <Grid
                    key={index}
                    container
                    spacing={3}
                    direction="row"
                    justifyContent="center"
                    alignItems="center"
                    style={{ marginBottom: "20px", marginTop: "20px" }}
                  >
                    <Grid item xs={4}>
                      <InputLabel
                        htmlFor="typeClaim"
                        style={{ marginBottom: "5px" }}
                        required
                      >
                        Type of Claim
                      </InputLabel>
                    </Grid>

                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <Select
                        name="typeClaim"
                        variant="outlined"
                        autoComplete="off"
                        onChange={onChangeField(index)}
                        onClose={() =>
                          validationAfterChange(index, "typeClaim", claim.typeClaim)
                        }
                        value={claim.typeClaim}
                        style={{ height: "40px" }}
                        fullWidth
                      >
                        <MenuItem disabled value=" ">
                          Please Select
                        </MenuItem>
                        <MenuItem value="Earthquake, storm, cyclone or hail">Earthquake, storm, cyclone or hail</MenuItem>
                        <MenuItem value="Bushfire">Bushfire</MenuItem>
                        <MenuItem value="Flood - Current Address">Flood - Current Address</MenuItem>
                        <MenuItem value="Flood - Previous Address">Flood - Previous Address</MenuItem>
                        <MenuItem value="House fire (not bushfire)">House fire (not bushfire)</MenuItem>
                        <MenuItem value="Theft (without break in)">Theft (without break in)</MenuItem>
                        <MenuItem value="Burglary (with break in)">Burglary (with break in)</MenuItem>
                        <MenuItem value="Damage from water from pipes and drains">Damage from water from pipes and drains</MenuItem>
                        <MenuItem value="Damage cause by children, pets or other accidental damage">Damage cause by children, pets or other accidental damage</MenuItem>
                        <MenuItem value="Other claim type">Other claim type</MenuItem>
                      </Select>
                      {/*  {Tab6_Validation_Home_Var[index].typeClaim !== null &&
                    Tab6_Validation_Home_Var[index].typeClaim !== "true" && (
                      <div className="text-danger font-italic">
                        {Tab6_Validation_Home_Var[index].typeClaim}
                      </div>
                    )} */}
                    </Grid>

                    <Grid item xs={4}>
                      <InputLabel
                        htmlFor="dateClaim"
                        style={{ marginBottom: "5px" }}
                        required
                      >
                        Date of Claim
                      </InputLabel>
                    </Grid>

                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <div>
                        <DatePicker
                          selected={claim.dateClaim}
                          dateFormat="dd/MM/yyyy"
                          name="dateClaim"
                          className="date-picker-align"
                          variant="outlined"
                          autoComplete="off"
                          onChange={(date) => dateClaim(date, index)}
                          onChangeRaw={handleDateChangeRaw}
                          value={claim.dateClaim}
                          minDate={new Date(claim.dateClaim)}
                        />
                      </div>
                      {/* {Tab6_Validation_Home_Var[index].dateClaim !== null &&
                        Tab6_Validation_Home_Var[index].dateClaim !== "true" && (
                          <div className="text-danger font-italic">
                            {Tab6_Validation_Home_Var[index].dateClaim}
                          </div>
                        )} */}
                    </Grid>

                    <Grid item xs={4}>
                      <InputLabel
                        htmlFor="Description"
                        style={{ marginBottom: "5px" }}
                        required
                      >
                        Description
                      </InputLabel>
                    </Grid>

                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <TextField
                        name="description"
                        value={claim.description}
                        onChange={onChangeField(index)}
                        size="small"
                        variant="outlined"
                        autoComplete="off"
                        required
                        fullWidth
                      />
                      {/*  {Tab6_Validation_Home_Var[index].description !== null &&
                    Tab6_Validation_Home_Var[index].description !== "true" && (
                      <div className="text-danger font-italic">
                        {Tab6_Validation_Home_Var[index].description}
                      </div>
                    )} */}
                    </Grid>

                    <Grid item xs={4}>
                      <InputLabel
                        htmlFor="amount"
                        style={{ marginBottom: "5px" }}
                        required
                      >
                        Amount
                      </InputLabel>
                    </Grid>

                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <TextField
                        type="number"
                        name="amount"
                        value={claim.amount}
                        onChange={onChangeField(index)}
                        size="small"
                        variant="outlined"
                        autoComplete="off"
                        // style={{ marginBottom: "20px" }}
                        required
                        fullWidth
                      />
                      {Tab6_Validation_Home_Var[index].amount !== null &&
                        Tab6_Validation_Home_Var[index].amount !== "true" && (
                          <div className="text-danger font-italic">
                            {Tab6_Validation_Home_Var[index].amount}
                          </div>
                        )}
                    </Grid>
                    {/* insurer field */}
                  <Grid item xs={4}>
                    <InputLabel
                      htmlFor="insurer"
                      style={{ marginBottom: "5px" }}
                      required
                    >
                      Insurer
                    </InputLabel>
                  </Grid>

                  <Grid item xs={8} style={{ marginBottom: "20px" }}>
                    <Autocomplete
                      options={insurerValues}
                      sx={{ width: 1 }}
                      isOptionEqualToValue={(option, value) => option.id === value.id}
                      getOptionLabel={(option) =>
                        (option.insurAus ? option.insurAus : claim.insurer)}
                      defaultValue={"please Select"}
                      name="insurer"
                      onChange={(event, val) => setInsurer(index, val)}
                      renderInput={(params) =>
                        <TextField {...params}
                          variant="outlined"
                          value={claim.insurer}
                          label="Insurer"
                          required
                        />}
                    />
                    {Tab6_Validation_Home_Var[index].insurer !== null &&
                      Tab6_Validation_Home_Var[index].insurer !== "true" && (
                        <div className="text-danger font-italic">
                          {Tab6_Validation_Home_Var[index].insurer}
                        </div>
                      )}
                  </Grid>
                  </Grid>

                  <div>
                    <Button
                      style={{ float: "right", width: "10%", marginBottom: "30px" }}
                      onClick={() => deleteclaim(index)}
                      // className="bg-warning"
                      variant="contained"
                      color="secondary"
                    >
                      DELETE
                    </Button>

                    <br />
                    <hr
                      style={{
                        color: "red",
                        backgroundColor: "green",
                        height: 1,
                        marginTop: "50px",
                      }}
                    />
                  </div>
                </div>
              )
            };
          })}
          <Grid
            direction="row"
            container
            justifyContent="center"
            alignItems="center"
          >
            <Grid item xs={12} style={{ marginTop: "20px" }}>
              <div className="alert alert-info">
              Add button below to add claims in the last 5 years
              </div>
            </Grid>
            <Grid item xs={4}></Grid>
            <Grid
              item
              xs={4}
              container
              justifyContent="center"
              alignItems="center"
            >
              <Button
                fullWidth
                onClick={addMore}
                className="bg-success text-white"
              >
                ADD MORE
              </Button>
            </Grid>
            <Grid item xs={4}></Grid>
          </Grid>
        </div>

        <Grid>
          {isAllFormsValid() ? (
            <Button
              variant="contained"
              className="bg-warning"
              style={{
                marginTop: "1rem",
                float: "right",
                marginBottom: "50px",
              }}
              onClick={handleSubmit}
            >
              VERIFY
            </Button>
          ) : (
            <Button
              variant="contained"
              className="bg-alert"
              style={{
                marginTop: "1rem",
                float: "right",
                marginBottom: "50px",
              }}
              disabled
            >
              VERIFY
            </Button>
          )}
          <ToastContainer style={{ marginLeft: "50px", marginBottom: "-25px", width: "30%" }} />
        </Grid>

        <Grid>
          <Button
            variant="contained"
            color="secondary"
            style={{
              marginTop: "1rem",
              float: "left",
              width: "10%",
            }}
            onClick={() => navigation.next()}
          >
            EXIT
          </Button>
        </Grid>

        {/* <Button
        variant="contained"
        color="primary"
        type="Submit"
        style={{
          marginTop: "1rem",
          float: "right",
          marginBottom: "50px",
          width: "10%",
        }}
        onClick={() => navigation.next()}
      >
        NEXT
      </Button> */}

        <Button
          variant="contained"
          color="primary"
          // className="bg-warning"
          style={{
            marginTop: "1rem",
            float: "right",
            marginBottom: "50px",
            marginRight: "20px",
            width: "10%",
          }}
          onClick={() => navigation.previous()}
        >
          PREVIOUS
        </Button>
        <ToastContainer style={{ marginLeft: "50px", marginBottom: "-25px", width: "30%" }} />
      </Container>
    )
  };

  return (
    <div>
      {displayTab6()}
      {loadClientHomePage()}
    </div>
  );
};

export default Tab6_Claims_Home;
