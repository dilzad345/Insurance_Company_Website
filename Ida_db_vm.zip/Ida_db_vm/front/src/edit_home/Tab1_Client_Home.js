import React from 'react';
import "../css/homeStyle.css";
import {
  TextField,
  Container,
  Button,
  Select,
  InputLabel,
  MenuItem,
  Grid, Box
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import { Autocomplete } from '@mui/material';
import { streetTypes, stateAus } from "../constants/dropDownData";
import {
  validationForSpecialchar
} from "../constants/validChecker";
import { Redirect } from 'react-router-dom';
import {
  ClientIdForHomeFromUipath_validate,
  clientType_validate,
  title_validate,
  firstName_validate,
  lastName_validate,
  companyName_validate,
  tradingAs_validate,
  streetNumber_validate,
  streetName_validate,
  streetType_validate,
  suburb_validate,
  state_validate,
  postCode_validate,
  phone_validate,
  email_validate,
  branch_validate,
  salesTeam_validate,
  serviceTeam_validate,
} from "../validationHome/Tab1_Validation_Home";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    alignContent: "center",
    padding: theme.spacing(2),
    //textAlign: 'center',
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary,
  },

  // bg_color: {
  //   backgroundColor: "#f0f0f5",
  //   marginBottom: "5px",
  // },
}));

const returnClientHome = () => {
  return <Redirect to='/client_home_link' />
}



const Tab1_Client_Home = ({
  Tab1_Client_Home_var,
  setTab1,
  Tab1_Validation_Home_Var,
  setTab1_validation,
  navigation,
}) => {

  const classes = useStyles();
  console.log(Tab1_Validation_Home_Var)
  const onChangeField = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    setTab1(
      {
        ...Tab1_Client_Home_var,
        [name]: value,
      },
      () => {
        console.log("hhh")
        validationAfterChange(name, value);
      }
    );
  };

  //setStreet Type
  const setStreetType = (val) => {
    console.log("val", val);
    // console.log(i);
    // console.log(streetType[0]);
    //  let name = e.target.name;
    let name = "streetType";
    if (val) {

      let value = val.group;
      setTab1(
        {
          ...Tab1_Client_Home_var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    } else {
      let value = " ";
      setTab1(
        {
          ...Tab1_Client_Home_var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    }
  }

  //set state for Aus
  const setStateAus = (val, event) => {
    console.log(val);
    if (val) {
      let name = "state";
      let value = val.stAus;
      console.log(value)
      setTab1(
        {
          ...Tab1_Client_Home_var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    } else {
      let name = "state";
      let value = " ";
      setTab1(
        {
          ...Tab1_Client_Home_var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    }
  } //end of this method

  // call validation
  const validationAfterChange = (name, value) => {
    if (name === "clientType") {
      if (Tab1_Client_Home_var.clientType === "Company") {
        Tab1_Client_Home_var.title = " ";
        Tab1_Client_Home_var.firstName = "";
        Tab1_Client_Home_var.lastName = "";
      } else if (Tab1_Client_Home_var.clientType === "Individual") {
        Tab1_Client_Home_var.companyName = "";
        Tab1_Client_Home_var.tradingAs = "";
      }
    }
    // console.log("Name:"+name);
    console.log("Value:" + value);
    switch (name) {
      
      case "ClientIdForHomeFromUipath": {
        console.log(name);
        ClientIdForHomeFromUipath_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "clientType": {
        clientType_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "title": {
        title_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "firstName": {
        firstName_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "lastName": {
        lastName_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "companyName": {
        companyName_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "tradingAs": {
        tradingAs_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }

      case "streetNumber": {
        streetNumber_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "streetName": {
        streetName_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "streetType": {
        streetType_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "suburb": {
        suburb_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "state": {
        state_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "postCode": {
        postCode_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "phone": {
        phone_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "email": {
        email_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "branch": {
        branch_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "salesTeam": {
        salesTeam_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "serviceTeam": {
        serviceTeam_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      default: {
        console.log("Not match to condition");
      }
    }
  };

  return (
    <Container maxWidth="md" style={{ marginBottom: "30px" }}>
      <div>
        <Grid
          container
          spacing={3}
          direction="row"
          justifyContent="center"
          alignItems="center">
          <Grid
            item
            xs={12}
            textalign="center"
            justifyContent="center"
            container
          >
            <h3>GENERAL INFORMATION</h3>
          </Grid>


          {/* Client Code */}
          <Grid item xs={5} className={classes.bg_color}>
            <InputLabel
              htmlFor="Unit Number (not req for PO Box)"
              style={{ marginBottom: "5px" }} required>
              Client ID
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              error ={Tab1_Validation_Home_Var.ClientIdForHomeFromUipath !== "true" ? true : false}
              name="ClientIdForHomeFromUipath"
              value={Tab1_Client_Home_var.ClientIdForHomeFromUipath}
              onChange={onChangeField}
              size="small"
              type="number"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "2px", height: "40px", marginLeft: "5px", width: "500px" }}
              fullWidth />
            {Tab1_Validation_Home_Var.ClientIdForHomeFromUipath !== null &&
              Tab1_Validation_Home_Var.ClientIdForHomeFromUipath !== "true" && (
                <div className="text-danger font-italic">
                  {Tab1_Validation_Home_Var.ClientIdForHomeFromUipath}
                </div>
              )}
          </Grid>

          {/* CLIENT TYPE */}
          <Grid item xs={5}>
            <InputLabel
              required
              htmlFor="Client Type"
              style={{ marginBottom: "5px" }}
            >
              Client Type
            </InputLabel>
          </Grid>

          <Grid item xs={7}>
            <Select
              name="clientType"
              margin="none"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              value={Tab1_Client_Home_var.clientType}
              //value={"Company"}
              onClose={() =>
                validationAfterChange("clientType", Tab1_Client_Home_var.clientType)
              }
              style={{ marginBottom: "2px", height: "40px", marginLeft: "5px", width: "500px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Individual">Individual</MenuItem>
              <MenuItem value="Company">Company</MenuItem>

            </Select>

            {Tab1_Validation_Home_Var.clientType !== null &&
              Tab1_Validation_Home_Var.clientType !== "true" && (
                <div className="text-danger font-italic">
                  {Tab1_Validation_Home_Var.clientType}
                </div>
              )}
          </Grid>


          {Tab1_Client_Home_var.clientType === "Individual" && (
            <Grid item container xs={12} direction="row" spacing={2}>
              <Grid item xs={5}>
                <InputLabel
                  htmlFor="Client Title"
                  style={{ marginBottom: "5px" }}
                // required
                >
                  Client Title
                </InputLabel>
              </Grid>
              <Grid item xs={7}>
                <Select
                  margin="none"
                  name="title"
                  variant="outlined"
                  size="small"
                  autoComplete="off"
                  value={Tab1_Client_Home_var.title}
                  onChange={onChangeField}
                  // onClose={() =>
                  //   validationAfterChange("title")
                  // }
                  style={{ height: "40px", marginLeft: "7px", width: "500px" }}
                  fullWidth
                >
                  <MenuItem disabled value=" ">
                    Please Select
                  </MenuItem>
                  <MenuItem value="Mr">Mr</MenuItem>
                  <MenuItem value="Miss">Miss</MenuItem>
                  <MenuItem value="Mrs">Mrs</MenuItem>
                  <MenuItem value="Ms">Ms</MenuItem>
                  <MenuItem value="Dr">Dr</MenuItem>
                </Select>
                {Tab1_Validation_Home_Var.title !== null &&
                  Tab1_Validation_Home_Var.title !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab1_Validation_Home_Var.title}
                    </div>
                  )}
              </Grid>

              <Grid item xs={5}>
                {/* First Name */}
                <InputLabel
                  htmlFor="First Name"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  First Name
                </InputLabel>
              </Grid>
              <Grid item xs={7}>
                <TextField
                  name="firstName"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  onChange={onChangeField}
                  value={Tab1_Client_Home_var.firstName}
                  style={{ marginBottom: "5px", marginLeft: "7px", width: "500px" }}
                  fullWidth
                />
                {Tab1_Validation_Home_Var.firstName !== null &&
                  Tab1_Validation_Home_Var.firstName !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab1_Validation_Home_Var.firstName}
                    </div>
                  )}
              </Grid>

              <Grid item xs={5}>
                {/* Last Name */}
                <InputLabel
                  htmlFor="Last Name"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Last Name
                </InputLabel>
              </Grid>
              <Grid item xs={7}>
                <TextField
                  name="lastName"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  onChange={onChangeField}
                  // onClose={() =>
                  //   validationAfterChange("lastName")
                  // }
                  value={Tab1_Client_Home_var.lastName}
                  style={{ marginLeft: "7px", width: "500px" }}
                  fullWidth
                />
                {Tab1_Validation_Home_Var.lastName !== null &&
                  Tab1_Validation_Home_Var.lastName !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab1_Validation_Home_Var.lastName}
                    </div>
                  )}
              </Grid>
            </Grid>
          )}


          {Tab1_Client_Home_var.clientType === "Company" && (
            <Grid item container xs={12} direction="row" spacing={2}>

              <Grid item xs={5} >
                <InputLabel
                  htmlFor="Company Name"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Company Name
                </InputLabel>
              </Grid>

              <Grid item xs={7}>
                <TextField
                  name="companyName"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  // onClose={() =>
                  //   validationAfterChange("companyName")
                  // }
                  value={Tab1_Client_Home_var.companyName}
                  onChange={onChangeField}
                  style={{ marginBottom: "10px", marginLeft: "8px", width: "500px" }}
                  fullWidth
                />
                {Tab1_Validation_Home_Var.companyName !== null &&
                  Tab1_Validation_Home_Var.companyName !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab1_Validation_Home_Var.companyName}
                    </div>
                  )}
              </Grid>

              {/* Trading As */}
              <Grid item xs={5}>
                <InputLabel
                  htmlFor="Trading As"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Trading As
                </InputLabel>
              </Grid>
              <Grid item xs={7}>
                <TextField
                  name="tradingAs"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  onChange={onChangeField}
                  // onClose={() =>
                  //   validationAfterChange("tradingAs")
                  // }
                  value={Tab1_Client_Home_var.tradingAs}
                  style={{ marginLeft: "7px", width: "500px" }}
                  fullWidth
                />

                {Tab1_Validation_Home_Var.tradingAs !== null &&
                  Tab1_Validation_Home_Var.tradingAs !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab1_Validation_Home_Var.tradingAs}
                    </div>
                  )}
              </Grid>
            </Grid>
          )}


          {/* office tect reference code */}
          <Grid item xs={5}>
            <InputLabel
              htmlFor="OfficeTech Reference Code (IBA ONLY)"
              style={{ marginBottom: "5px" }}
            >
              OfficeTech Reference Code (IBA ONLY)
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              name="officeTechReferenceCode"
              size="small"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              value={Tab1_Client_Home_var.officeTechReferenceCode}
              style={{ marginLeft: "5px", width: "500px" }}
              fullWidth
            />
            {Tab1_Validation_Home_Var.officeTechReferenceCode !== null &&
              Tab1_Validation_Home_Var.officeTechReferenceCode !== "true" && (
                <div className="text-danger font-italic">
                  {Tab1_Validation_Home_Var.officeTechReferenceCode}
                </div>
              )}
          </Grid>

          {/* Unit Number */}
          {/* <Grid item xs={5}>
            <InputLabel
              htmlFor="Unit Number (not req for PO Box)"
              style={{ marginBottom: "5px" }}
            >
              Unit Number (not req for PO Box)
            </InputLabel>
          </Grid> */}
          {/* <Grid item xs={7}>
            <TextField
              // label="Unit Number (not req for PO Box)"
              name="unitNumber"
              size="small"
              type="number"
              // margin="normal"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              value={Tab1_Client_Home_var.unitNumber}
              style={{ marginLeft: "5px", width: "500px" }}
              fullWidth
            />
            {Tab1_Validation_Home_Var.unitNumber !== null &&
              Tab1_Validation_Home_Var.unitNumber !== "true" && (
                <div className="text-danger font-italic">
                  {Tab1_Validation_Home_Var.unitNumber}
                </div>
              )}
          </Grid> */}

          {/* box component */}
          <Box component="span"
            sx={{
              width: '100%',
              // height: 00,
              p: 4,
              // alignItems: '',
              borderRadius: 8,
              border: '1px solid grey',
              display: 'flex',
              flexWrap: 'wrap',
              // alignItems:'center',
              justifyContent: 'space-between',
              flexDirection: 'row',
            }} m={2} pt={3}

          >
            <Grid item xs={12} justifyContent='center' container>
              <Box sx={{
                border: '1px solid grey',
                borderRadius: 8,
                padding: '6px 8px 0px 7px',
                // alignItems:'center',
                // alignContent:'center',
                margin: '0px 0px 10px 2px',
                justifyContent: 'center'
              }}>
                <h5>POSTAL ADDRESS</h5>
              </Box>
            </Grid>
            
            {/* Unit Number */}
            <Grid item xs={4} style={{ padding: '8px' }}>
              <TextField
                label="Unit Number (not req for PO Box)"
                name="unitNumber"
                size="small"
                type="text"
                // margin="normal"
                variant="outlined"
                autoComplete="off"
                onChange={onChangeField}
                onKeyPress={(e) => validationForSpecialchar(e)}
                value={Tab1_Client_Home_var.unitNumber}
                style={{ width: "100%" }}
                InputLabelProps={{ style: { fontSize: 15 } }}
                fullWidth
              />
              {Tab1_Validation_Home_Var.unitNumber !== null &&
                Tab1_Validation_Home_Var.unitNumber !== "true" && (
                  <div className="text-danger font-italic">
                    {Tab1_Validation_Home_Var.unitNumber}
                  </div>
                )}
            </Grid>
            {/* Street Number */}
            <Grid item xs={4} style={{ padding: '8px' }}>
              <TextField
                // label="Street Number (not req for PO Box)"
                name="streetNumber"
                label="Street Number"
                size="small"
                type="text"
                variant="outlined"
                autoComplete="off"
                onChange={onChangeField}
                onKeyPress={(e) => validationForSpecialchar(e)}
                value={Tab1_Client_Home_var.streetNumber}
                style={{ width: '100%' }}
                required
                fullWidth
              />
              {Tab1_Validation_Home_Var.streetNumber !== null &&
                Tab1_Validation_Home_Var.streetNumber !== "true" && (
                  <div className="text-danger font-italic">
                    {Tab1_Validation_Home_Var.streetNumber}
                  </div>
                )}
            </Grid>
            

            

            {/* Street Name */}
            <Grid item xs={4} style={{ padding: '8px' }}>
              <TextField
                // label="Street Name (or PO Box)"
                name="streetName"
                size="small"
                // margin="normal"
                label="Street Name"
                variant="outlined"
                autoComplete="off"
                onChange={onChangeField}
                value={Tab1_Client_Home_var.streetName}
                style={{ width: '100%' }}
                required
                fullWidth
              />

              {Tab1_Validation_Home_Var.streetName !== null &&
                Tab1_Validation_Home_Var.streetName !== "true" && (
                  <div className="text-danger font-italic">
                    {Tab1_Validation_Home_Var.streetName}
                  </div>
                )}
            </Grid>
            {/* Street Type */}
            <Grid item xs={4} style={{ padding: '8px' }}>
              <Autocomplete
                options={streetTypes}
                sx={{ width: '100%' }}
                isOptionEqualToValue={(option, value) => option.id === value.id}
                getOptionLabel={(option) =>
                  (option.group ? option.group : Tab1_Client_Home_var.streetType)}
                defaultValue={"please Select"}

                name="streetType"
                onChange={(event, value) => setStreetType(value)}
                renderInput={(params) =>
                  <TextField {...params}
                    variant="outlined"
                    // fullwidth
                    value={Tab1_Client_Home_var.streetType}
                    label="Street Type"
                    required
                    inputProps={{
                      ...params.inputProps,
                      style: { padding: '1px 0' }
                    }}
                  />}

              />

              {Tab1_Validation_Home_Var.streetType !== null &&
                Tab1_Validation_Home_Var.streetType !== "true" && (
                  <div className="text-danger font-italic">
                    {Tab1_Validation_Home_Var.streetType}
                  </div>
                )}
            </Grid>

            {/* Suburb */}
            <Grid item xs={4} style={{ padding: '8px' }}>
              {/* <InputLabel
                required
                htmlFor="Suburb"
                style={{ marginBottom: "5px" }}
              >
                Suburb
              </InputLabel> */}
              <TextField
                // label="Suburb"
                name="suburb"
                size="small"
                style={{ width: '100%' }}
                label="Suburb"
                variant="outlined"
                onChange={onChangeField}
                autoComplete="off"
                value={Tab1_Client_Home_var.suburb}
                required
                fullWidth
              />
              {Tab1_Validation_Home_Var.suburb !== null &&
                Tab1_Validation_Home_Var.suburb !== "true" && (
                  <div className="text-danger font-italic">{ }
                    {Tab1_Validation_Home_Var.suburb}
                  </div>
                )}
            </Grid>
            {/* <Grid item xs={7}>
            </Grid> */}

            {/* State */}
            <Grid item xs={4} style={{ padding: '8px' }}>
              <Autocomplete
                options={stateAus}
                sx={{ width: '100%' }}
                isOptionEqualToValue={(option, value) => option.id === value.id}
                getOptionLabel={(option) => (option.stAus ? option.stAus : Tab1_Client_Home_var.state)}

                defaultValue={"Please Select"}
                name="state"
                onChange={(event, value) => setStateAus(value, event)}
                renderInput={(params) =>
                  <TextField {...params}
                    variant="outlined"
                    fullWidth
                    value={Tab1_Client_Home_var.state}
                    label="State"
                    required
                    inputProps={{
                      ...params.inputProps,
                      style: { padding: '1px 0' }
                    }}
                  />}

              />

              {Tab1_Validation_Home_Var.state !== null &&
                Tab1_Validation_Home_Var.state !== "true" && (
                  <div className="text-danger font-italic">{ }
                    {Tab1_Validation_Home_Var.state}
                  </div>
                )}
            </Grid>

            {/* Post Code */}
            <Grid item xs={4} style={{ padding: '8px' }}>
              {/* <InputLabel
                required
                htmlFor="Post Code"
                style={{ marginBottom: "5px" }}
              >
                Post Code
              </InputLabel> */}
              <TextField
                name="postCode"
                size="small"
                style={{ width: '100%' }}
                variant="outlined"
                type="number"
                label="PostCode"
                autoComplete="off"
                onChange={onChangeField}
                value={Tab1_Client_Home_var.postCode}
                required
                fullWidth
              />

              {Tab1_Validation_Home_Var.postCode !== null &&
                Tab1_Validation_Home_Var.postCode !== "true" && (
                  <div className="text-danger font-italic">{ }
                    {Tab1_Validation_Home_Var.postCode}
                  </div>
                )}
            </Grid>
          </Box>



          {/* Street Number */}
          {/* <Grid item xs={5}>
            <InputLabel
              htmlFor="Street Number (not req for PO Box)"
              style={{ marginBottom: "5px" }}
              required
            >
              Street Number (not req for PO Box)
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              // label="Street Number (not req for PO Box)"
              name="streetNumber"
              // margin="normal"
              size="small"
              type="number"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              value={Tab1_Client_Home_var.streetNumber}
              style={{ marginLeft: "5px" , width: "500px" }}
              fullWidth
            />

            {Tab1_Validation_Home_Var.streetNumber !== null &&
              Tab1_Validation_Home_Var.streetNumber !== "true" && (
                <div className="text-danger font-italic">
                  {Tab1_Validation_Home_Var.streetNumber}
                </div>
              )}

          </Grid> */}

          {/* Street Type */}
          {/* <Grid item xs={5}>
            <InputLabel
              htmlFor="Street Type (not req for PO Box)"
              style={{ marginBottom: "5px" }}
              required
            >
              Street Type (not req for PO Box)
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              value={Tab1_Client_Home_var.streetType}
              name="streetType"
              style={{ height: "40px" , marginLeft: "5px" , width: "500px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="street">Street</MenuItem>
              <MenuItem value="Road">Road</MenuItem>
              <MenuItem value="Avenue">Avenue</MenuItem>
              <MenuItem value="Close">Close</MenuItem>
              <MenuItem value="Court">Court</MenuItem>
              <MenuItem value="Circuit">Circuit</MenuItem>
              <MenuItem value="Teerace">Teerace</MenuItem>
              <MenuItem value="drive">Drive</MenuItem>
              <MenuItem value="Lane">Lane</MenuItem>
              <MenuItem value="Parade">Parade</MenuItem>
              <MenuItem value="Quay">Quay</MenuItem>
              <MenuItem value="Way">Way</MenuItem>
            </Select>

            {Tab1_Validation_Home_Var.streetType !== null &&
              Tab1_Validation_Home_Var.streetType !== "true" && (
                <div className="text-danger font-italic">
                  {Tab1_Validation_Home_Var.streetType}
                </div>
              )}

          </Grid> */}

          {/* Street Name */}
          {/* <Grid item xs={5}>
            <InputLabel
              required
              htmlFor="Street Name"
              style={{ marginBottom: "5px" }}
            >
              Street Name
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              // label="Street Name (or PO Box)"
              name="streetName"
              size="small"
              // margin="normal"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              value={Tab1_Client_Home_var.streetName}
              style={{ marginLeft: "5px" , width: "500px" }}
              fullWidth
            />

            {Tab1_Validation_Home_Var.streetName !== null &&
              Tab1_Validation_Home_Var.streetName !== "true" && (
                <div className="text-danger font-italic">
                  {Tab1_Validation_Home_Var.streetName}
                </div>
              )}

          </Grid> */}

          {/* Suburb */}
          {/* <Grid item xs={5}>
            <InputLabel
              required
              htmlFor="Suburb"
              style={{ marginBottom: "5px" }}
            >
              Suburb
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              // label="Suburb"
              name="suburb"
              size="small"
              style={{ marginLeft: "5px" , width: "500px" }}
              // margin="normal"
              variant="outlined"
              onChange={onChangeField}
              autoComplete="off"
              value={Tab1_Client_Home_var.suburb}
              fullWidth
            />
            {Tab1_Validation_Home_Var.suburb !== null &&
              Tab1_Validation_Home_Var.suburb !== "true" && (
                <div className="text-danger font-italic">{ }
                  {Tab1_Validation_Home_Var.suburb}
                </div>
              )}

          </Grid> */}

          {/* State */}
          {/* <Grid item xs={5}>
            <InputLabel
              required
              htmlFor="State"
              style={{ marginBottom: "5px" }}
            >
              State
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              value={Tab1_Client_Home_var.state}
              name="state"
              style={{ height: "40px" ,  marginLeft: "5px" , width: "500px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="QLD">QLD</MenuItem>
              <MenuItem value="NSW">NSW</MenuItem>
              <MenuItem value="VIC">VIC</MenuItem>
              <MenuItem value="SA">SA</MenuItem>
              <MenuItem value="WA">WA</MenuItem>
              <MenuItem value="MACT">MACT</MenuItem>
              <MenuItem value="TASS">TASS</MenuItem>
              <MenuItem value="NT">NT</MenuItem>
            </Select>
            {Tab1_Validation_Home_Var.state !== null &&
              Tab1_Validation_Home_Var.state !== "true" && (
                <div className="text-danger font-italic">{ }
                  {Tab1_Validation_Home_Var.state}
                </div>
              )}

          </Grid> */}

          {/* Post Code */}
          {/* <Grid item xs={5}>
            <InputLabel
              required
              htmlFor="Post Code"
              style={{ marginBottom: "5px" }}
            >
              Post Code
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              name="postCode"
              size="small"
              style={{ marginLeft: "5px" , width: "500px" }}
              variant="outlined"
              type="number"
              autoComplete="off"
              onChange={onChangeField}
              value={Tab1_Client_Home_var.postCode}
              fullWidth
            />

            {Tab1_Validation_Home_Var.postCode !== null &&
              Tab1_Validation_Home_Var.postCode !== "true" && (
                <div className="text-danger font-italic">{ }
                  {Tab1_Validation_Home_Var.postCode}
                </div>
              )}

          </Grid> */}

          {/* Phone */}
          <Grid item xs={5}>
            <InputLabel
              required
              htmlFor="Phone"
              style={{ marginBottom: "5px", width: "500px" }}
              maxLength="10"
            >
              Phone
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              name="phone"

              // inputProps={{ inputMode: 'numeric', pattern: '[0-9]*' }}

              size="small"
              style={{ marginLeft: "5px", width: "500px" }}
              variant="outlined"
              type="number"
              value={Tab1_Client_Home_var.phone}
              autoComplete="off"
              inputProps={{ maxLength: 12 }}
              fullWidth
              onChange={onChangeField}
            />
            {Tab1_Validation_Home_Var.phone !== null &&
              Tab1_Validation_Home_Var.phone !== "true" && (
                <div className="text-danger font-italic">{ }
                  {Tab1_Validation_Home_Var.phone}
                </div>
              )}
          </Grid>

          {/* E-mail */}
          <Grid item xs={5}>
            <InputLabel
              required
              htmlFor="E-mail"
              style={{ marginBottom: "5px" }}
            >
              E-mail
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              // label="E-mail"
              name="email"
              value={Tab1_Client_Home_var.email}
              size="small"
              style={{ marginLeft: "5px", width: "500px" }}
              // margin="normal"
              variant="outlined"
              autoComplete="off"
              fullWidth
              onChange={onChangeField}
            />
            {Tab1_Validation_Home_Var.email !== null &&
              Tab1_Validation_Home_Var.email !== "true" && (
                <div className="text-danger font-italic">{ }
                  {Tab1_Validation_Home_Var.email}
                </div>
              )}
          </Grid>

          {/* Branch */}
          <Grid item xs={5}>
            <InputLabel
              required
              htmlFor="Branch"
              style={{ marginBottom: "5px" }}
            >
              Branch
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <Select
             error ={Tab1_Validation_Home_Var.branch !== "true" ? true : false}
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="branch"
              value={Tab1_Client_Home_var.branch}
              style={{ height: "40px", marginLeft: "5px", width: "500px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Insurance Brokers Australia">
                Insurance Brokers Australia
              </MenuItem>
              <MenuItem value="Hayward Insurance Solutions Pty Ltd">
                Hayward Insurance Solutions Pty Ltd
              </MenuItem>
            </Select>

            {Tab1_Validation_Home_Var.branch !== null &&
              Tab1_Validation_Home_Var.branch !== "true" && (
                <div className="text-danger font-italic">{ }
                  {Tab1_Validation_Home_Var.branch}
                </div>
              )}

          </Grid>

          {/* Sales Team */}
          <Grid item xs={5}>
            <InputLabel
              required
              htmlFor="Sales Team"
              style={{ marginBottom: "5px" }}
            >
              Sales Team
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <Select
              error ={Tab1_Validation_Home_Var.salesTeam !== "true" ? true : false}
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="salesTeam"
              onChange={onChangeField}
              value={Tab1_Client_Home_var.salesTeam}
              style={{ height: "40px", marginLeft: "5px", width: "500px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Chris Dalton">Chris Dalton</MenuItem>
              <MenuItem value="Gary Hayward">Gary Hayward</MenuItem>
              <MenuItem value="Mark Hayward">Mark Hayward</MenuItem>
              <MenuItem value="GC(Billy)">GC(Billy)</MenuItem>
              <MenuItem value="GC Team">GC Team</MenuItem>
              <MenuItem value="Billy Noke">Billy Noke</MenuItem>
              <MenuItem value="Gerold-Grafton<">Gerold-Grafton</MenuItem>
              <MenuItem value="Gerold-Warwick">Gerold-Warwick</MenuItem>
            </Select>

            {Tab1_Validation_Home_Var.salesTeam !== null &&
              Tab1_Validation_Home_Var.salesTeam !== "true" && (
                <div className="text-danger font-italic">{ }
                  {Tab1_Validation_Home_Var.salesTeam}
                </div>
              )}

          </Grid>

          {/* Service Team */}
          <Grid item xs={5}>
            <InputLabel
              required
              htmlFor="Service Team"
              style={{ marginBottom: "5px" }}
            >
              Service Team
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <Select
             error ={Tab1_Validation_Home_Var.serviceTeam !== "true" ? true : false}
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="serviceTeam"
              onChange={onChangeField}
              value={Tab1_Client_Home_var.serviceTeam}
              style={{ height: "40px", marginLeft: "5px", width: "500px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Brisbane">Brisbane</MenuItem>
              <MenuItem value="Luanne">Luanne</MenuItem>
              <MenuItem value="Michella">Michella</MenuItem>
              <MenuItem value="Patricia">Patricia</MenuItem>
              <MenuItem value="Taryn">Taryn</MenuItem>
            </Select>

            {Tab1_Validation_Home_Var.serviceTeam !== null &&
              Tab1_Validation_Home_Var.serviceTeam !== "true" && (
                <div className="text-danger font-italic">{ }
                  {Tab1_Validation_Home_Var.serviceTeam}
                </div>
              )}

          </Grid>





          {/* navigation buttons */}
          <Grid item xs={6}>
            <Button
              variant="contained"
              color="secondary"
              style={{
                marginTop: "1rem",
                float: "left",
                width: "20%",
              }}
              onClick={() => {
                returnClientHome()
              }}
            >
              EXIT
            </Button>
          </Grid>

          <Grid item xs={6}>
            <Button
              variant="contained"
              color="primary"
              style={{
                marginTop: "1rem",
                float: "right",
              }}
              onClick={() => navigation.next()}
            >
              NEXT
            </Button>
          </Grid>
        </Grid>
      </div>
    </Container>


  );
}



//   };
export default Tab1_Client_Home;