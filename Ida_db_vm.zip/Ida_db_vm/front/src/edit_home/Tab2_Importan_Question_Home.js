import React from "react";
import {
  
  Container,
  Button,
  Select,
  InputLabel,
  MenuItem,
  Grid,
} from "@material-ui/core";
// import { makeStyles } from "@material-ui/core/styles";

// const useStyles = makeStyles((theme) => ({
//     root: {
//       flexGrow: 1,
//       alignContent: "center",
//       padding: theme.spacing(2),
//       //textAlign: 'center',
//     },
//     paper: {
//       padding: theme.spacing(2),
//       textAlign: "center",
//       color: theme.palette.text.secondary,
//     },
  
//     // bg_color: {
//     //   backgroundColor: "#f0f0f5",
//     //   marginBottom: "5px",
//     // },
//   }));

 

  const Tab2_Importan_Question_Home = ({
    Tab2_Importan_Question_Home_var,
    setTab2,
    navigation,
  }) => {

    // const classes = useStyles();

    const onChangeField = (e) => {
      let name = e.target.name;
      let value = e.target.value;
      setTab2(
        {
          ...Tab2_Importan_Question_Home_var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    };


    const validationAfterChange = (name, value) => {
      
    };


    return (
        <Container maxWidth="md" style={{ marginBottom: "30px" }}>
      <div >
        <Grid
          container
          spacing={3}
          direction="row"
          justifyContent="center"
          alignItems="center"
        >
          <Grid item={true} xs={12}  justifyContent="center" container style={{ marginTop: "25px" }}>
            <h3>IMPORTANT QUESTIONS</h3>
          </Grid>

          

          {/* Any insurance policy declined or cancelled by the insurer in the last 5 years */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Any insurance policy declined or cancelled by the insurer in the last 5 years"
              style={{ marginBottom: "5px" }}
              required
            >
              Any insurance policy declined or cancelled by the insurer in the
              last 5 years
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="insPolcyCancellLast5Years"
              margin="none"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              value={Tab2_Importan_Question_Home_var.insPolcyCancellLast5Years}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Last 12 months">Last 12 months</MenuItem>
              <MenuItem value="Last 24 months">Last 24 months</MenuItem>
              <MenuItem value="Last 5 years">Last 5 years</MenuItem>
            </Select>
          </Grid>

          {/* Had a claim declined */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Had a claim declined"
              style={{ marginBottom: "5px" }}
              required
            >
              Had a claim declined
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="hadClaimDeclained"
              margin="none"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              value={Tab2_Importan_Question_Home_var.hadClaimDeclained}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Last 1 year">Last 1 year</MenuItem>
              <MenuItem value="Last 2 years">Last 2 years</MenuItem>
              <MenuItem value="Last 3 years">Last 3 years</MenuItem>
              <MenuItem value="Last 4 years">Last 4 years</MenuItem>
              <MenuItem value="Last 5 years">Last 5 years</MenuItem>
            </Select>
          </Grid>

          
            
          

          {/* Had any criminal conviction relating to fraud, theft, dishonesty, arson, or malicious damage (excluding any convictions that are not legally required to be disclosed)? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Had any criminal conviction relating to fraud, theft, dishonesty, arson, or malicious damage (excluding any convictions that are not legally required to be disclosed)?"
              style={{ marginBottom: "5px" }}
              required
            >
              Had any criminal conviction relating to fraud, theft, dishonesty,
              arson, or malicious damage (excluding any convictions that are not
              legally required to be disclosed)?
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="maliciousDamage"
              margin="none"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              value={Tab2_Importan_Question_Home_var.maliciousDamage}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Last 1 year">Last 1 year</MenuItem>
              <MenuItem value="Last 2 years">Last 2 years</MenuItem>
              <MenuItem value="Last 3 years">Last 3 years</MenuItem>
              <MenuItem value="Last 4 years">Last 4 years</MenuItem>
              <MenuItem value="Last 5 years">Last 5 years</MenuItem>
            </Select>
          </Grid>

          {/* Is the home under construction / renovation? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Is the home under construction / renovation?"
              style={{ marginBottom: "5px" }}
              required
            >
              Is the home under construction / renovation?
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="homeUnderConstruction"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab2_Importan_Question_Home_var.homeUnderConstruction}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>
          {/* Has any person who will be covered by this insurance ever filed for Bankruptcy */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Has any person who will be covered by this insurance ever filed for Bankruptcy"
              style={{ marginBottom: "5px" }}
              required
            >
              Has any person who will be covered by this insurance ever filed for Bankruptcy
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="Bankruptcy"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              value={Tab2_Importan_Question_Home_var.Bankruptcy}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

{/* Has the land or building been flooded more than once in the last 10 years? */}
<Grid item xs={6}>
            <InputLabel
              htmlFor="Has the land or building been flooded more than once in the last 10 years?"
              style={{ marginBottom: "5px" }}
              required
            >
              Has the land or building been flooded more than once in the last 10 years?
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="buildingFlooded"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              value={Tab2_Importan_Question_Home_var.buildingFlooded}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>          
        </Grid>
          
        <Grid>
            <Button
              variant="contained"
              color="secondary"
              style={{
                marginTop: "1rem",
                float: "left",
                width: "10%",
              }}
            //   onClick={() => navigation.next()}
            >
              EXIT
            </Button>
          </Grid>
        
          <Grid>
            <Button
              variant="contained"
              color="primary"
              style={{
                marginTop: "1rem",
                float: "right",
                width: "10%"
              }}
              onClick={() => navigation.next()}
            >
              NEXT
            </Button>
          </Grid>
          <Grid>
            <Button
              variant="contained"
              color="primary"
              style={{ marginTop: "1rem",  marginBottom: "1rem",float: "right", marginRight: "20px", width: "10%"}}
              onClick={() => navigation.previous()}
            >
              PREVIOUS
            </Button>
          </Grid>

      </div>
    </Container>
    );
}

export default Tab2_Importan_Question_Home;