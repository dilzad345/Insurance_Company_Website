export const Tab4_Validation_Land = (Tab4_Building_Land_Var) => {
    let result = true;

    result =
      result * (Tab4_Building_Land_Var.building_type !== " " && Tab4_Building_Land_Var.building_type !== null);

      if (Tab4_Building_Land_Var.building_type === "Free Standing / House") {
        result = result * (Tab4_Building_Land_Var.free_standing_what_built !== " " && Tab4_Building_Land_Var.free_standing_what_built !== null);
    }

    if (Tab4_Building_Land_Var.building_type === ("Apartment / Unit (Ground Floor)" || "Apartment / Unit (Above Ground Floor)")) {
        result = result * (Tab4_Building_Land_Var.apartment_what_type !== " " && Tab4_Building_Land_Var.apartment_what_type !== null);
        result = result * (Tab4_Building_Land_Var.unit_building_level !== " " && Tab4_Building_Land_Var.unit_building_level !== null);
    }

    if (Tab4_Building_Land_Var.building_type === "Semi-Detached / Terrace") {
      result = result * (Tab4_Building_Land_Var.semi_deteched_what_type !== " " && Tab4_Building_Land_Var.semi_deteched_what_type !== null);
      result = result * (Tab4_Building_Land_Var.semi_deteched_body_corprate !== " " && Tab4_Building_Land_Var.semi_deteched_body_corprate !== null);
    }

    if (Tab4_Building_Land_Var.building_type === "Multiple units or residenses") {
        result = result * (Tab4_Building_Land_Var.multiple_unit_insured_all !== " " && Tab4_Building_Land_Var.multiple_unit_insured_all !== null);
        result = result * (Tab4_Building_Land_Var.multiple_unit_number !== " " && Tab4_Building_Land_Var.multiple_unit_number !== "");
        result = result * (Tab4_Building_Land_Var.multiple_unit_insured_building !== " " && Tab4_Building_Land_Var.multiple_unit_insured_building !== null);
        result = result * (Tab4_Building_Land_Var.multiple_unit_total_units !== " " && Tab4_Building_Land_Var.multiple_unit_total_units !== "");
    }

    result =
      result * (Tab4_Building_Land_Var.construction_period !== " " && Tab4_Building_Land_Var.construction_period !== null);

      result = 
      result * (Tab4_Building_Land_Var.original_year_build !== " " && Tab4_Building_Land_Var.original_year_build !== "" &&
      Tab4_Building_Land_Var.original_year_build.length === 4);

      result =
      result * (Tab4_Building_Land_Var.construction_wall !== " " && Tab4_Building_Land_Var.construction_wall !== null);

      result =
      result * (Tab4_Building_Land_Var.roof_construction !== " " && Tab4_Building_Land_Var.roof_construction !== null);

      result =
      result * (Tab4_Building_Land_Var.numbers_of_bathrooms !== " " && Tab4_Building_Land_Var.numbers_of_bathrooms !== null);

      result =
      result * (Tab4_Building_Land_Var.numbers_of_bedrooms !== " " && Tab4_Building_Land_Var.numbers_of_bedrooms !== null);

      result =
      result * (Tab4_Building_Land_Var.construction_quality !== " " && Tab4_Building_Land_Var.construction_quality !== null);

      result =
      result * (Tab4_Building_Land_Var.storeys !== " " && Tab4_Building_Land_Var.storeys !== null);

      result =
      result * (Tab4_Building_Land_Var.effected_by_flood !== " " && Tab4_Building_Land_Var.effected_by_flood !== null);
      
      result =
      result * (Tab4_Building_Land_Var.main_water_supply !== " " && Tab4_Building_Land_Var.main_water_supply !== null);

      result =
      result * (Tab4_Building_Land_Var.window_security !== " " && Tab4_Building_Land_Var.window_security !== null);

      result =
      result * (Tab4_Building_Land_Var.door_security !== " " && Tab4_Building_Land_Var.door_security !== null);

      result =
      result * (Tab4_Building_Land_Var.burglar_alarm !== " " && Tab4_Building_Land_Var.burglar_alarm !== null);

      result =
      result * (Tab4_Building_Land_Var.smoke_detector !== " " && Tab4_Building_Land_Var.smoke_detector !== null);

      result =
      result * (Tab4_Building_Land_Var.building_construction12months !== " " && Tab4_Building_Land_Var.building_construction12months !== null);

      result =
      result * (Tab4_Building_Land_Var.outdoor_spa !== " " && Tab4_Building_Land_Var.outdoor_spa !== null);

      result =
      result * (Tab4_Building_Land_Var.located_below_ground !== " " && Tab4_Building_Land_Var.located_below_ground !== null);

      result =
      result * (Tab4_Building_Land_Var.flood_mitigration !== " " && Tab4_Building_Land_Var.flood_mitigration !== null);

      result =
      result * (Tab4_Building_Land_Var.occupancy_certificate !== " " && Tab4_Building_Land_Var.occupancy_certificate !== null);

      result =
      result * (Tab4_Building_Land_Var.strata_title !== " " && Tab4_Building_Land_Var.strata_title !== null);

      result 
      = result * (Tab4_Building_Land_Var.person_living_the_building !== " " && Tab4_Building_Land_Var.person_living_the_building !== "");
    return result;
};


export const tab4ValidationLandEdit = (Tab4_Building_Land_Var) =>{
  let result = true;

  result =
      result * (Tab4_Building_Land_Var.building_type !== " " && Tab4_Building_Land_Var.building_type !== null);

      if (Tab4_Building_Land_Var.building_type === "Free Standing / House") {
        result = result * (Tab4_Building_Land_Var.free_standing_what_built !== " " && Tab4_Building_Land_Var.free_standing_what_built !== null);
    }

    if (Tab4_Building_Land_Var.building_type === ("Apartment / Unit (Ground Floor)" || "Apartment / Unit (Above Ground Floor)")) {
        result = result * (Tab4_Building_Land_Var.apartment_what_type !== " " && Tab4_Building_Land_Var.apartment_what_type !== null);
        result = result * (Tab4_Building_Land_Var.unit_building_level !== " " && Tab4_Building_Land_Var.unit_building_level !== null);
    }

    if (Tab4_Building_Land_Var.building_type === "Semi-Detached / Terrace") {
      result = result * (Tab4_Building_Land_Var.semi_deteched_what_type !== " " && Tab4_Building_Land_Var.semi_deteched_what_type !== null);
      result = result * (Tab4_Building_Land_Var.semi_deteched_body_corprate !== " " && Tab4_Building_Land_Var.semi_deteched_body_corprate !== null);
    }

    if (Tab4_Building_Land_Var.building_type === "Multiple units or residenses") {
        result = result * (Tab4_Building_Land_Var.multiple_unit_insured_all !== " " && Tab4_Building_Land_Var.multiple_unit_insured_all !== null);
        result = result * (Tab4_Building_Land_Var.multiple_unit_number !== " " && Tab4_Building_Land_Var.multiple_unit_number !== "");
        result = result * (Tab4_Building_Land_Var.multiple_unit_insured_building !== " " && Tab4_Building_Land_Var.multiple_unit_insured_building !== null);
        result = result * (Tab4_Building_Land_Var.multiple_unit_total_units !== " " && Tab4_Building_Land_Var.multiple_unit_total_units !== "");
    }

    result =
      result * (Tab4_Building_Land_Var.construction_period !== " " && Tab4_Building_Land_Var.construction_period !== null);

      result = 
      result * (Tab4_Building_Land_Var.original_year_build !== " " && Tab4_Building_Land_Var.original_year_build !== "" &&
      Tab4_Building_Land_Var.original_year_build.length === 4);

      result =
      result * (Tab4_Building_Land_Var.construction_wall !== " " && Tab4_Building_Land_Var.construction_wall !== null);

      result =
      result * (Tab4_Building_Land_Var.roof_construction !== " " && Tab4_Building_Land_Var.roof_construction !== null);

      result =
      result * (Tab4_Building_Land_Var.numbers_of_bathrooms !== " " && Tab4_Building_Land_Var.numbers_of_bathrooms !== null);

      result =
      result * (Tab4_Building_Land_Var.numbers_of_bedrooms !== " " && Tab4_Building_Land_Var.numbers_of_bedrooms !== null);

      result =
      result * (Tab4_Building_Land_Var.construction_quality !== " " && Tab4_Building_Land_Var.construction_quality !== null);

      result =
      result * (Tab4_Building_Land_Var.storeys !== " " && Tab4_Building_Land_Var.storeys !== null);

      result =
      result * (Tab4_Building_Land_Var.effected_by_flood !== " " && Tab4_Building_Land_Var.effected_by_flood !== null);
      
      result =
      result * (Tab4_Building_Land_Var.main_water_supply !== " " && Tab4_Building_Land_Var.main_water_supply !== null);

      result =
      result * (Tab4_Building_Land_Var.window_security !== " " && Tab4_Building_Land_Var.window_security !== null);

      result =
      result * (Tab4_Building_Land_Var.door_security !== " " && Tab4_Building_Land_Var.door_security !== null);

      result =
      result * (Tab4_Building_Land_Var.burglar_alarm !== " " && Tab4_Building_Land_Var.burglar_alarm !== null);

      result =
      result * (Tab4_Building_Land_Var.smoke_detector !== " " && Tab4_Building_Land_Var.smoke_detector !== null);

      result =
      result * (Tab4_Building_Land_Var.building_construction12months !== " " && Tab4_Building_Land_Var.building_construction12months !== null);

      result =
      result * (Tab4_Building_Land_Var.outdoor_spa !== " " && Tab4_Building_Land_Var.outdoor_spa !== null);

      result =
      result * (Tab4_Building_Land_Var.located_below_ground !== " " && Tab4_Building_Land_Var.located_below_ground !== null);

      result =
      result * (Tab4_Building_Land_Var.flood_mitigration !== " " && Tab4_Building_Land_Var.flood_mitigration !== null);

      result =
      result * (Tab4_Building_Land_Var.occupancy_certificate !== " " && Tab4_Building_Land_Var.occupancy_certificate !== null);

      result =
      result * (Tab4_Building_Land_Var.strata_title !== " " && Tab4_Building_Land_Var.strata_title !== null);

      result 
      = result * (Tab4_Building_Land_Var.person_living_the_building !== " " && Tab4_Building_Land_Var.person_living_the_building !== "");


  return result;
}


export const building_type_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        building_type: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        building_type: "true",
      });
    }
  };

  export const free_standing_what_built_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        free_standing_what_built: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        free_standing_what_built: "true",
      });
    }
  };

  export const apartment_what_type_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        apartment_what_type: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        apartment_what_type: "true",
      });
    }
  };

  export const unit_building_level_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        unit_building_level: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        unit_building_level: "true",
      });
    }
  };

  export const semi_deteched_what_type_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        semi_deteched_what_type: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        semi_deteched_what_type: "true",
      });
    }
  };

  export const semi_deteched_body_corprate_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        semi_deteched_body_corprate: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        semi_deteched_body_corprate: "true",
      });
    }
  };

  export const multiple_unit_insured_all_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        multiple_unit_insured_all: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        multiple_unit_insured_all: "true",
      });
    }
  };

  export const multiple_unit_number_installment_validate = (
    value,
    Tab_Validation_Land_Var,
    setTab_validation
  ) => {
    if (value === "") {
        setTab_validation({
        ...Tab_Validation_Land_Var,
        multiple_unit_number: "Must have value",
      });
    } else {
        setTab_validation({
        ...Tab_Validation_Land_Var,
        multiple_unit_number: "true",
      });
    }
  };

  export const multiple_unit_insured_building_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        multiple_unit_insured_building: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        multiple_unit_insured_building: "true",
      });
    }
  };

  export const multiple_unit_total_units_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        multiple_unit_total_units: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        multiple_unit_total_units: "true",
      });
    }
  };

  export const construction_period_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        construction_period: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        construction_period: "true",
      });
    }
  };

  export const original_year_build_validate = (
    value,
    Tab_Validation_Land_Var,
    setTab4_validation
  ) => {
    if (value === "") {
      setTab4_validation({
        ...Tab_Validation_Land_Var,
        original_year_build: "Must have value",
      });
    } else if (value.length > 4 || value.length < 4) {
      setTab4_validation({
        ...Tab_Validation_Land_Var,
        original_year_build: "Invalid Original Year Build.",
      });
    }
    
    else {
      setTab4_validation({
        ...Tab_Validation_Land_Var,
        original_year_build: "true",
      });
    }
  };

  export const construction_wall_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        construction_wall: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        construction_wall: "true",
      });
    }
  };

  export const roof_construction_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        roof_construction: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        roof_construction: "true",
      });
    }
  };

  export const numbers_of_bathrooms_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        numbers_of_bathrooms: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        numbers_of_bathrooms: "true",
      });
    }
  };

  export const numbers_of_bedrooms_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        numbers_of_bedrooms: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        numbers_of_bedrooms: "true",
      });
    }
  };

  export const construction_quality_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        construction_quality: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        construction_quality: "true",
      });
    }
  };

  export const storeys_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        storeys: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        storeys: "true",
      });
    }
  };

//   export const unit_building_level_validate = (
//     value,
//     Tab4_Validation_Land_Var,
//     setTab4_validation
//   ) => {
//     console.log("val:" + value);
//     if (value === null || value === " ") {
//         setTab4_validation({
//         ...Tab4_Validation_Land_Var,
//         unit_building_level: "Must select an option",
//       });
//     } else {
//         setTab4_validation({
//         ...Tab4_Validation_Land_Var,
//         unit_building_level: "true",
//       });
//     }
//   };

  
  export const building_size_validate = (
    value,
    Tab_Validation_Land_Var,
    setTab_validation
  ) => {
    if (value === "") {
        setTab_validation({
        ...Tab_Validation_Land_Var,
        building_size: "Must have value",
      });
    } else {
        setTab_validation({
        ...Tab_Validation_Land_Var,
        building_size: "true",
      });
    }
  };

  export const effected_by_flood_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        effected_by_flood: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        effected_by_flood: "true",
      });
    }
  };

  export const main_water_supply_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        main_water_supply: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        main_water_supply: "true",
      });
    }
  };

  export const window_security_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        window_security: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        window_security: "true",
      });
    }
  };

  export const door_security_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        door_security: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        door_security: "true",
      });
    }
  };

  export const burglar_alarm_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        burglar_alarm: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        burglar_alarm: "true",
      });
    }
  };

  export const smoke_detector_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        smoke_detector: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        smoke_detector: "true",
      });
    }
  };

  export const building_construction12months_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        building_construction12months: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        building_construction12months: "true",
      });
    }
  };

  export const outdoor_spa_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        outdoor_spa: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        outdoor_spa: "true",
      });
    }
  };

  export const located_below_ground_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        located_below_ground: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        located_below_ground: "true",
      });
    }
  };

  export const flood_mitigration_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        flood_mitigration: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        flood_mitigration: "true",
      });
    }
  };

  export const occupancy_certificate_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        occupancy_certificate: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        occupancy_certificate: "true",
      });
    }
  };

  export const register_body_corprote_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        register_body_corprote: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        register_body_corprote: "true",
      });
    }
  };

  export const strata_title_validate = (
    value,
    Tab4_Validation_Land_Var,
    setTab4_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        strata_title: "Must select an option",
      });
    } else {
        setTab4_validation({
        ...Tab4_Validation_Land_Var,
        strata_title: "true",
      });
    }
  };

  export const person_living_the_building_validate = (
    value,
    Tab_Validation_Land_Var,
    setTab_validation
  ) => {
    if (value === "") {
        setTab_validation({
        ...Tab_Validation_Land_Var,
        person_living_the_building: "Must have value",
      });
    } else {
        setTab_validation({
        ...Tab_Validation_Land_Var,
        person_living_the_building: "true",
      });
    }
  };