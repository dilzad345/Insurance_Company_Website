// import { useState } from "react";
import { digit_valid_check, char_valid_check, email_valid_check } from "../constants/validChecker";

export const Tab1_Validation_Land = (Tab1_Client_Land_var) => {
    let result = true;
  
    result =
      result *
      (Tab1_Client_Land_var.client_type !== " " && Tab1_Client_Land_var.client_type !== null);
    if (Tab1_Client_Land_var.client_type === "Individual") {
      result = result * (Tab1_Client_Land_var.client_firstName !== "");
      result = result * (Tab1_Client_Land_var.client_lastName !== "");
    } else if (Tab1_Client_Land_var.client_type === "Company") {
      result = result * (Tab1_Client_Land_var.company_name !== "");
    }

    const digitValid_check2 = () => {
      if (!digit_valid_check.digit_valid_checker.test((Tab1_Client_Land_var.phone))) {
        // console.log("Hello" + tab1_client.phone);
        return true;
      }
    }
  
    result =
      result *
      (Tab1_Client_Land_var.street_number_postal !== " " && Tab1_Client_Land_var.street_number_postal !== "");
  
    result =
      result * (Tab1_Client_Land_var.street_name_postal !== " " && Tab1_Client_Land_var.street_name_postal !== "");
  

      result =
    result *
    (Tab1_Client_Land_var.street_type_postal !== " " &&  Tab1_Client_Land_var.street_type_postal !== "Please Select");
  
    result = result * (Tab1_Client_Land_var.suburb_postal !== " " && Tab1_Client_Land_var.suburb_postal !== "");
  
    result = result * (Tab1_Client_Land_var.state_postal !== " " && Tab1_Client_Land_var.state_postal !== "Please Select");
  
    result =
      result * (Tab1_Client_Land_var.postcode_postal !== " " && Tab1_Client_Land_var.postcode_postal !== "");
  
    result =
      result *
      (Tab1_Client_Land_var.phone !== " " &&
      Tab1_Client_Land_var.phone !== "" &&
      Tab1_Client_Land_var.phone.length === 10 && !digitValid_check2());

      result = 
        result * (Tab1_Client_Land_var.insuredAddress !== " " && Tab1_Client_Land_var.insuredAddress !== null);

    if (Tab1_Client_Land_var.insuredAddress === "No") {
      result =
      result *
      (Tab1_Client_Land_var.street_number_insured !== " " && Tab1_Client_Land_var.street_number_insured !== "");

    result =
    result *
    (Tab1_Client_Land_var.street_name_insured !== " " && Tab1_Client_Land_var.street_name_insured !== "");

    result =
    result *
    (Tab1_Client_Land_var.street_type_insured !== "Please Select" && Tab1_Client_Land_var.street_type_insured !== " ");

    result =
    result *
    (Tab1_Client_Land_var.suburb_insured !== " " && Tab1_Client_Land_var.suburb_insured !== "");

    result =
    result *
    (Tab1_Client_Land_var.state_insured !== "Please Select" && Tab1_Client_Land_var.state_insured !== " ");

    result =
    result *
    (Tab1_Client_Land_var.postcode_insured !== " " && Tab1_Client_Land_var.postcode_insured !== "")

  }


  // if (Tab1_Client_Land_var.insuredAddress === "Yes") {
  //   Tab1_Client_Land_var.street_number_insured = "";
  //   Tab1_Client_Land_var.street_name_insured = "";
  //   Tab1_Client_Land_var.street_type_insured = "Please Select";
  //   Tab1_Client_Land_var.suburb_insured = "";
  //   Tab1_Client_Land_var.state_insured = "Please Select";
  //   Tab1_Client_Land_var.postcode_insured = "";

  // }


      const check_email = () => {
        // const email_valid_check = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,15}/g;
        if (!email_valid_check.email_valid_checker.test(Tab1_Client_Land_var.email)) {
          // console.log("Hello"+Tab1_Client_Home_var.email);
          return true;      
        }
      };
      result =
        result *
        (Tab1_Client_Land_var.email !== " " &&
        Tab1_Client_Land_var.email !== "" &&
          !check_email());
  
    return result;
    };


  
export const tab1ValidationLandEdit = (Tab1_Client_Land_var) =>{
  let result = true;
  // console.log(Tab1_Client_Land_var.uiPathIdForLand);
  const ClientIdFromUipathValid_check = () => {
    if (!digit_valid_check.digit_valid_checker.test((Tab1_Client_Land_var.uiPathIdForLand))) {
      // console.log("Hello " + tab1_client.ClientIdFromUipath);
      return true;
    }
  }
  result = result * (Tab1_Client_Land_var.uiPathIdForLand !== "" && 
  Tab1_Client_Land_var.uiPathIdForLand !==null &&  !ClientIdFromUipathValid_check() && Tab1_Client_Land_var.uiPathIdForLand.length ===4);
  
  result =
    result *
    (Tab1_Client_Land_var.client_type !== " " && Tab1_Client_Land_var.client_type !== null);
  if (Tab1_Client_Land_var.client_type === "Individual") {

    // result = result * (Tab1_Client_Land_var.client_title !== null && Tab1_Client_Land_var.client_title !== " ");
    result = result * (Tab1_Client_Land_var.client_firstName !== "");
    result = result * (Tab1_Client_Land_var.client_lastName !== "");
  } else if (Tab1_Client_Land_var.client_type === "Company") {
    result = result * (Tab1_Client_Land_var.company_name !== "");
    // result = result * (Tab1_Client_Land_var.trading_as !== "");
  }

  const digitValid_check2 = () => {
    if (!digit_valid_check.digit_valid_checker.test((Tab1_Client_Land_var.phone))) {
      // console.log("Hello" + tab1_client.phone);
      return true;
    }
  }

  // result =
  //     result *
  //     (Tab1_Client_Land_var.uiPathIdForLand !== " " && Tab1_Client_Land_var.uiPathIdForLand !== "" &&
  //     Tab1_Client_Land_var.uiPathIdForLand.length === 4);

      result =
      result *
      (Tab1_Client_Land_var.street_number_postal !== " " && Tab1_Client_Land_var.street_number_postal !== "");
  
    result =
      result * (Tab1_Client_Land_var.street_name_postal !== " " && Tab1_Client_Land_var.street_name_postal !== "");
  

      result =
    result *
    (Tab1_Client_Land_var.street_type_postal !== " " &&  Tab1_Client_Land_var.street_type_postal !== "Please Select");
  
    result = result * (Tab1_Client_Land_var.suburb_postal !== " " && Tab1_Client_Land_var.suburb_postal !== "");
  
    result = result * (Tab1_Client_Land_var.state_postal !== " " && Tab1_Client_Land_var.state_postal !== "Please Select");
  
    result =
      result * (Tab1_Client_Land_var.postcode_postal !== " " && Tab1_Client_Land_var.postcode_postal !== "");
  
    result =
      result *
      (Tab1_Client_Land_var.phone !== " " &&
      Tab1_Client_Land_var.phone !== "" &&
      Tab1_Client_Land_var.phone.length === 10 && !digitValid_check2());

      result = 
        result * (Tab1_Client_Land_var.insuredAddress !== " " && Tab1_Client_Land_var.insuredAddress !== null);

    if (Tab1_Client_Land_var.insuredAddress === "No") {

      result =
      result *
      (Tab1_Client_Land_var.street_number_insured !== " " && Tab1_Client_Land_var.street_number_insured !== "");

    result =
    result *
    (Tab1_Client_Land_var.street_name_insured !== " " && Tab1_Client_Land_var.street_name_insured !== "");

    result =
    result *
    (Tab1_Client_Land_var.street_type_insured !== "Please Select" && Tab1_Client_Land_var.street_type_insured !== " ");

    result =
    result *
    (Tab1_Client_Land_var.suburb_insured !== " " && Tab1_Client_Land_var.suburb_insured !== "");

    result =
    result *
    (Tab1_Client_Land_var.state_insured !== "Please Select" && Tab1_Client_Land_var.state_insured !== " ");

    result =
    result *
    (Tab1_Client_Land_var.postcode_insured !== " " && Tab1_Client_Land_var.postcode_insured !== "")

  }


  // if (Tab1_Client_Land_var.insuredAddress === "Yes") {
  //   Tab1_Client_Land_var.street_number_insured = "";
  //   Tab1_Client_Land_var.street_name_insured = "";
  //   Tab1_Client_Land_var.street_type_insured = "Please Select";
  //   Tab1_Client_Land_var.suburb_insured = "";
  //   Tab1_Client_Land_var.state_insured = "Please Select";
  //   Tab1_Client_Land_var.postcode_insured = "";

  // }
   

    

  result = result * (Tab1_Client_Land_var.branch !== " " && Tab1_Client_Land_var.branch !== "");

  result =
    result * (Tab1_Client_Land_var.sales_team !== " " && Tab1_Client_Land_var.sales_team !== null);

  result =
    result *
    (Tab1_Client_Land_var.service_team !== " " && Tab1_Client_Land_var.service_team !== null);

    const check_email = () => {
      // const email_valid_check = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,15}/g;
      if (!email_valid_check.email_valid_checker.test(Tab1_Client_Land_var.email)) {
        // console.log("Hello"+Tab1_Client_Home_var.email);
        return true;      
      }
    };
    result =
      result *
      (Tab1_Client_Land_var.email !== " " &&
      Tab1_Client_Land_var.email !== "" &&
        !check_email());

  return result;
}
  
export const uiPathIdForLand_validate = (value, Tab1_Validation_Land_Var, setTab1_validation) => {
  console.log("jjjjjjj")
  if (value === "" || value === null) {
    setTab1_validation({
      ...Tab1_Validation_Land_Var,
      uiPathIdForLand: "Client Id: Must have digits value",
    });
  }
  else if (value.length < 4 || value.length > 4) {
    setTab1_validation({
      ...Tab1_Validation_Land_Var,
      uiPathIdForLand: "Client Id: Must have 4 digits",
    });
  } else {
    setTab1_validation({
      ...Tab1_Validation_Land_Var,
      uiPathIdForLand: "true",
    });
  }
}

// export const client_ID_validate = (value, Tab1_Validation_Land_Var, setTab1_validation) => {
//   if (value === "") {
//     setTab1_validation({
//       ...Tab1_Validation_Land_Var,
//       client_id: "Client Id: Must have digits value",
//     });
//   }
//   else if (value.length < 4 || value.length > 4) {
//     setTab1_validation({
//       ...Tab1_Validation_Land_Var,
//       client_id: "Client Id: Must have 4 digits",
//     });
//   } else {
//     setTab1_validation({
//       ...Tab1_Validation_Land_Var,
//       client_id: "true",
//     });
//   }
// }
  
  
  export const clientType_validate = (
    value,
    Tab1_Validation_Land_Var,
    setTab1_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        client_type: "Client type: Must select an option",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        client_type: "true",
      });
    }
  };
  
  export const title_validate = (value, Tab1_Validation_Land_Var, setTab1_validation) => {
    if (value === null) {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        client_title: "Title: Must select an option",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        client_title: "true",
      });
    }
  };
  
  export const firstName_validate = (
    value,
    Tab1_Validation_Land_Var,
    setTab1_validation
  ) => {
    const regex = /^([A-Za-z])([A-Za-z\s])+$/;
    if (value === "") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        client_firstName: "First name: Must have value",
      });
    } else if (!regex.test(value)) {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        client_firstName: "First name: Invalid",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        client_firstName: "true",
      });
    }
  };
  
  export const lastName_validate = (
    value,
    Tab1_Validation_Land_Var,
    setTab1_validation
  ) => {
    const regex = /^([A-Za-z])([A-Za-z\s])+$/;
    console.log(value);
    if (value === "") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        client_lastName: "Last name: Must have value",
      });
    } else if (!regex.test(value)) {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        client_lastName: "Last name: Invalid",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        client_lastName: "true",
      });
    }
  };
  
  export const companyName_validate = (
    value,
    Tab1_Validation_Land_Var,
    setTab1_validation
  ) => {
    if (value === "") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        company_name: "Must have value",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        company_name: "true",
      });
    }
  };
  
  export const tradingAs_validate = (
    value,
    Tab1_Validation_Land_Var,
    setTab1_validation
  ) => {
    if (value === "") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        trading_as: " Must have value",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        trading_as: "true",
      });
    }
  };
  
  export const streetNumber_validate = (
    value,
    Tab1_Validation_Land_Var,
    setTab1_validation
  ) => {
    if (value === "") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        street_number_postal: "Must have value",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        street_number_postal: "true",
      });
    }
  };
  
  export const streetName_validate = (
    value,
    Tab1_Validation_Land_Var,
    setTab1_validation
  ) => {
    if (value === "") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        street_name_postal: "Must have value",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        street_name_postal: "true",
      });
    }
  };
  
  export const streetType_validate = (
    value,
    Tab1_Validation_Land_Var,
    setTab1_validation
  ) => {
    if (value === null || value === " ") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        street_type_postal: "Street Type: Must select an option",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        street_type_postal: "true",
      });
    }
  };
  
  export const suburb_validate = (value, Tab1_Validation_Land_Var, setTab1_validation) => {
    if (value === "") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        suburb_postal: "Must have value",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        suburb_postal: "true",
      });
    }
  };
  
  export const state_validate = (value, Tab1_Validation_Land_Var, setTab1_validation) => {
    if (value === null || value === " ") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        state_postal: "Title: Must select an option",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        state_postal: "true",
      });
    }
  };
  
  export const postCode_validate = (
    value,
    Tab1_Validation_Land_Var,
    setTab1_validation
  ) => {
    if (value === "") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        postcode_postal: "Must have value.",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        postcode_postal: "true",
      });
    }
  };
  
  export const phone_validate = (value, Tab1_Validation_Land_Var, setTab1_validation) => {
    if (value === "") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        phone: "Must have value.",
      });
    } else if (value.length > 10 || value.length < 10) {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        phone: "Invalid phone number.",
      });
    }
    
    else if (!digit_valid_check.digit_valid_checker.test(value)) {
      if (value.length === 10) {
        setTab1_validation({
          ...Tab1_Validation_Land_Var,
          phone: "Phone Number: Invalid Type.",
        });
      }
    }
    else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        phone: "true",
      });
    }
  };
  
  export const email_validate = (value, Tab1_Validation_Land_Var, setTab1_validation) => {


    if (value === "") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        email: "Email: Must have value",
      });
    } else if (!email_valid_check.email_valid_checker.test(value)) {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        email: "Email: Invalid Email",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        email: "true",
      });
    }
  };

  export const insuredAddress_validate = (
    value,
    Tab1_Validation_Land_Var,
    setTab1_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        insuredAddress: "Must select an option",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        insuredAddress: "true",
      });
    }
  };

  export const street_number_insured_validate = (
    value,
    Tab1_Validation_Land_Var,
    setTab1_validation
  ) => {
    if (value === "") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        street_number_insured: "Must have value",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        street_number_insured: "true",
      });
    }
  };

  export const street_name_insured_validate = (
    value,
    Tab1_Validation_Land_Var,
    setTab1_validation
  ) => {
    if (value === "") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        street_name_insured: "Must have value",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        street_name_insured: "true",
      });
    }
  };

  export const street_type_insured_validate = (
    value,
    Tab1_Validation_Land_Var,
    setTab1_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        street_type_insured: "Must select an option",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        street_type_insured: "true",
      });
    }
  };

  export const suburb_insured_validate = (
    value,
    Tab1_Validation_Land_Var,
    setTab1_validation
  ) => {
    if (value === "") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        suburb_insured: "Must have value",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        suburb_insured: "true",
      });
    }
  };

  export const state_insured_validate = (
    value,
    Tab1_Validation_Land_Var,
    setTab1_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        state_insured: "Must select an option",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        state_insured: "true",
      });
    }
  };

  export const postcode_insured_validate = (
    value,
    Tab1_Validation_Land_Var,
    setTab1_validation
  ) => {
    if (value === "") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        postcode_insured: "Must have value",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        postcode_insured: "true",
      });
    }
  };

  
  
  export const branch_validate = (value, Tab1_Validation_Land_Var, setTab1_validation) => {
    if (value === "" || value === " ") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        branch: "Must have value",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        branch: "true",
      });
    }
  };
  
  export const salesTeam_validate = (
    value,
    Tab1_Validation_Land_Var,
    setTab1_validation
  ) => {
    if (value === null || value === " ") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        sales_team: "Title: Must select an option",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        sales_team: "true",
      });
    }
  };
  
  export const serviceTeam_validate = (
    value,
    Tab1_Validation_Land_Var,
    setTab1_validation
  ) => {
    if (value === null || value === " ") {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        service_team: "Title: Must select an option",
      });
    } else {
      setTab1_validation({
        ...Tab1_Validation_Land_Var,
        service_team: "true",
      });
    }
    

    

      
  






  };
  