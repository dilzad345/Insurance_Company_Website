export const Tab2_Validation_Land = (Tab2_Importan_Question_Land_var) => {
    let result = true;
  
    
    if (Tab2_Importan_Question_Land_var.any_policy_decline_last5years !== "No") {
        result = result * (Tab2_Importan_Question_Land_var.howmany_policy_decline_last5years !== " " && Tab2_Importan_Question_Land_var.howmany_policy_decline_last5years !== null);
        result = result * (Tab2_Importan_Question_Land_var.howmany_policy_decline_last3years !== " " && Tab2_Importan_Question_Land_var.howmany_policy_decline_last3years !== null);
        result = result * (Tab2_Importan_Question_Land_var.reason_forThe_decline !== " " && Tab2_Importan_Question_Land_var.reason_forThe_decline !== null);
    } 

    if (Tab2_Importan_Question_Land_var.clime_decline !== "No") {
        result = result * (Tab2_Importan_Question_Land_var.reason_clime_decline !== " " && Tab2_Importan_Question_Land_var.reason_clime_decline !== "");
    } 

    if (Tab2_Importan_Question_Land_var.property_everBe_unoccupied !== "No") {
        result = result * (Tab2_Importan_Question_Land_var.checking_onThe_property !== " " && Tab2_Importan_Question_Land_var.checking_onThe_property !== null);
        result = result * (Tab2_Importan_Question_Land_var.why_property_unoccupied !== " " && Tab2_Importan_Question_Land_var.why_property_unoccupied !== "");
    } 

    if (Tab2_Importan_Question_Land_var.under_construction_renovation === "Yes") {
        result = result * (Tab2_Importan_Question_Land_var.renovation_over$100000 !== " " && Tab2_Importan_Question_Land_var.renovation_over$100000 !== null);
        result = result * (Tab2_Importan_Question_Land_var.value_of_renovation !== " " && Tab2_Importan_Question_Land_var.value_of_renovation !== "");
        result = result * (Tab2_Importan_Question_Land_var.start_date_renovations !== " " && Tab2_Importan_Question_Land_var.start_date_renovations !== "");
        result = result * (Tab2_Importan_Question_Land_var.Estimated_completion_date !== " " && Tab2_Importan_Question_Land_var.Estimated_completion_date !== "");
        result = result * (Tab2_Importan_Question_Land_var.what_work_undertaken !== " " && Tab2_Importan_Question_Land_var.what_work_undertaken !== "");
    } 

    if (Tab2_Importan_Question_Land_var.renovation_over$100000 === "Yes") {
        result = result * (Tab2_Importan_Question_Land_var.value_of_renovation !== " " && Tab2_Importan_Question_Land_var.value_of_renovation !== "");
        result = result * (Tab2_Importan_Question_Land_var.start_date_renovations !== " " && Tab2_Importan_Question_Land_var.start_date_renovations !== "");
        result = result * (Tab2_Importan_Question_Land_var.Estimated_completion_date !== " " && Tab2_Importan_Question_Land_var.Estimated_completion_date !== "");
        result = result * (Tab2_Importan_Question_Land_var.what_work_undertaken !== " " && Tab2_Importan_Question_Land_var.what_work_undertaken !== "");
    }

    if (Tab2_Importan_Question_Land_var.property_heritage === "Yes") {
        result = result * (Tab2_Importan_Question_Land_var.details_heritage_list !== " " && Tab2_Importan_Question_Land_var.details_heritage_list !== "");
    } 

    result = result * (Tab2_Importan_Question_Land_var.property_used_farming !== " " && Tab2_Importan_Question_Land_var.property_used_farming !== "");

    if (Tab2_Importan_Question_Land_var.property_used_farming === "Yes") {
      result = result * (Tab2_Importan_Question_Land_var.business_activity_conducted !== " " && Tab2_Importan_Question_Land_var.business_activity_conducted !== null);
  }
  
    return result;
  };



  export const tab2ValidationLandEdit = (Tab2_Importan_Question_Land_var) =>{
    let result = true;

    if (Tab2_Importan_Question_Land_var.any_policy_decline_last5years !== "No") {
      result = result * (Tab2_Importan_Question_Land_var.howmany_policy_decline_last5years !== " " && Tab2_Importan_Question_Land_var.howmany_policy_decline_last5years !== null);
      result = result * (Tab2_Importan_Question_Land_var.howmany_policy_decline_last3years !== " " && Tab2_Importan_Question_Land_var.howmany_policy_decline_last3years !== null);
      result = result * (Tab2_Importan_Question_Land_var.reason_forThe_decline !== " " && Tab2_Importan_Question_Land_var.reason_forThe_decline !== null);
  } 

  if (Tab2_Importan_Question_Land_var.clime_decline !== "No") {
      result = result * (Tab2_Importan_Question_Land_var.reason_clime_decline !== " " && Tab2_Importan_Question_Land_var.reason_clime_decline !== "");
  } 

  if (Tab2_Importan_Question_Land_var.property_everBe_unoccupied !== "No") {
      result = result * (Tab2_Importan_Question_Land_var.checking_onThe_property !== " " && Tab2_Importan_Question_Land_var.checking_onThe_property !== null);
      result = result * (Tab2_Importan_Question_Land_var.why_property_unoccupied !== " " && Tab2_Importan_Question_Land_var.why_property_unoccupied !== "");
  } 

  if (Tab2_Importan_Question_Land_var.under_construction_renovation === "Yes") {
      result = result * (Tab2_Importan_Question_Land_var.renovation_over$100000 !== " " && Tab2_Importan_Question_Land_var.renovation_over$100000 !== null);
      result = result * (Tab2_Importan_Question_Land_var.value_of_renovation !== " " && Tab2_Importan_Question_Land_var.value_of_renovation !== "");
      result = result * (Tab2_Importan_Question_Land_var.start_date_renovations !== " " && Tab2_Importan_Question_Land_var.start_date_renovations !== "");
      result = result * (Tab2_Importan_Question_Land_var.Estimated_completion_date !== " " && Tab2_Importan_Question_Land_var.Estimated_completion_date !== "");
      result = result * (Tab2_Importan_Question_Land_var.what_work_undertaken !== " " && Tab2_Importan_Question_Land_var.what_work_undertaken !== "");
  } 

  if (Tab2_Importan_Question_Land_var.renovation_over$100000 === "Yes") {
      result = result * (Tab2_Importan_Question_Land_var.value_of_renovation !== " " && Tab2_Importan_Question_Land_var.value_of_renovation !== "");
      result = result * (Tab2_Importan_Question_Land_var.start_date_renovations !== " " && Tab2_Importan_Question_Land_var.start_date_renovations !== "");
      result = result * (Tab2_Importan_Question_Land_var.Estimated_completion_date !== " " && Tab2_Importan_Question_Land_var.Estimated_completion_date !== "");
      result = result * (Tab2_Importan_Question_Land_var.what_work_undertaken !== " " && Tab2_Importan_Question_Land_var.what_work_undertaken !== "");
  }

  if (Tab2_Importan_Question_Land_var.property_heritage === "Yes") {
      result = result * (Tab2_Importan_Question_Land_var.details_heritage_list !== " " && Tab2_Importan_Question_Land_var.details_heritage_list !== "");
  } 

  result = result * (Tab2_Importan_Question_Land_var.property_used_farming !== " " && Tab2_Importan_Question_Land_var.property_used_farming !== "");

  if (Tab2_Importan_Question_Land_var.property_used_farming === "Yes") {
    result = result * (Tab2_Importan_Question_Land_var.business_activity_conducted !== " " && Tab2_Importan_Question_Land_var.business_activity_conducted !== null);
}

    return result;
  }
  
  
  export const howmany_policy_decline_last5years_validate = (
    value,
    Tab2_Validation_Land_Var,
    setTab2_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        howmany_policy_decline_last5years: "Must select an option",
      });
    } else {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        howmany_policy_decline_last5years: "true",
      });
    }
  };

  export const howmany_policy_decline_last3years_validate = (
    value,
    Tab2_Validation_Land_Var,
    setTab2_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        howmany_policy_decline_last3years: "Must select an option",
      });
    } else {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        howmany_policy_decline_last3years: "true",
      });
    }
  };

  export const reason_forThe_decline_validate = (
    value,
    Tab2_Validation_Land_Var,
    setTab2_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        reason_forThe_decline: "Must select an option",
      });
    } else {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        reason_forThe_decline: "true",
      });
    }
  };

  export const reason_clime_decline_validate = (
    value,
    Tab2_Validation_Land_Var,
    setTab2_validation
  ) => {
    if (value === "") {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        reason_clime_decline: "Must have value",
      });
    } else {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        reason_clime_decline: "true",
      });
    }
  };

  export const checking_onThe_property_validate = (
    value,
    Tab2_Validation_Land_Var,
    setTab2_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        checking_onThe_property: "Must select an option",
      });
    } else {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        checking_onThe_property: "true",
      });
    }
  };

  export const why_property_unoccupied_validate = (
    value,
    Tab2_Validation_Land_Var,
    setTab2_validation
  ) => {
    if (value === "") {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        why_property_unoccupied: "Must have value",
      });
    } else {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        why_property_unoccupied: "true",
      });
    }
  };

  export const renovation_over$100000_validate = (
    value,
    Tab2_Validation_Land_Var,
    setTab2_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        renovation_over$100000: "Must select an option",
      });
    } else {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        renovation_over$100000: "true",
      });
    }
  };

  //kk

  export const value_of_renovation_validate = (
    value,
    Tab2_Validation_Land_Var,
    setTab2_validation
  ) => {
    if (value === "") {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        value_of_renovation: "Must have value",
      });
    } else {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        value_of_renovation: "true",
      });
    }
  };

  export const start_date_renovations_validate = (
    value,
    Tab2_Validation_Land_Var,
    setTab2_validation
  ) => {
    if (value === "") {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        start_date_renovations: "Must have value",
      });
    } else {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        start_date_renovations: "true",
      });
    }
  };

  export const Estimated_completion_date_validate = (
    value,
    Tab2_Validation_Land_Var,
    setTab2_validation
  ) => {
    if (value === "") {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        Estimated_completion_date: "Must have value",
      });
    } else {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        Estimated_completion_date: "true",
      });
    }
  };

  export const what_work_undertaken_validate = (
    value,
    Tab2_Validation_Land_Var,
    setTab2_validation
  ) => {
    if (value === "") {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        what_work_undertaken: "Must have value",
      });
    } else {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        what_work_undertaken: "true",
      });
    }
  };

  export const details_heritage_list_validate = (
    value,
    Tab2_Validation_Land_Var,
    setTab2_validation
  ) => {
    if (value === "") {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        details_heritage_list: "Must have value",
      });
    } else {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        details_heritage_list: "true",
      });
    }
  };

  export const business_activity_conducted_validate = (
    value,
    Tab2_Validation_Land_Var,
    setTab2_validation
  ) => {
    console.log("val:" + value);
    if (value === null || value === " ") {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        business_activity_conducted: "Must select an option",
      });
    } else {
        setTab2_validation({
        ...Tab2_Validation_Land_Var,
        business_activity_conducted: "true",
      });
    }
  };

  

  
  
  
  
  
  