import { digit_valid_check, char_valid_check, email_valid_check } from "../constants/validChecker";

export const Tab3_Validation_Land = (Tab3_Policycore_Land_Var) => {
    let result = true;

    result =
      result * (Tab3_Policycore_Land_Var.cover_type_accidential !== " " && Tab3_Policycore_Land_Var.cover_type_accidential !== null);

    result =
      result * (Tab3_Policycore_Land_Var.occupancy_home !== " " && Tab3_Policycore_Land_Var.occupancy_home !== null);

      result =
      result * (Tab3_Policycore_Land_Var.property_managed !== " " && Tab3_Policycore_Land_Var.property_managed !== null);

      result =
      result * (Tab3_Policycore_Land_Var.building_content !== " " && Tab3_Policycore_Land_Var.building_content !== null);

      if (Tab3_Policycore_Land_Var.building_content === "Building only") {

        Tab3_Policycore_Land_Var.content_ins_amount = "";
        result =
        result * (Tab3_Policycore_Land_Var.building_sum_insured !== " " && Tab3_Policycore_Land_Var.building_sum_insured !== "");
  
      }
      if (Tab3_Policycore_Land_Var.building_content === "Contents only") {

        Tab3_Policycore_Land_Var.building_sum_insured = "";
        result =
        result * (Tab3_Policycore_Land_Var.content_ins_amount !== " " && Tab3_Policycore_Land_Var.content_ins_amount !== "");
  
      }
     
      if (Tab3_Policycore_Land_Var.building_content === "Building and Contents") {
        result =
        result * (Tab3_Policycore_Land_Var.building_sum_insured !== " " && Tab3_Policycore_Land_Var.building_sum_insured !== "");
  
        
        result =
        result * (Tab3_Policycore_Land_Var.content_ins_amount !== " " && Tab3_Policycore_Land_Var.content_ins_amount !== "");
  
      }
      
      result =
      result * (Tab3_Policycore_Land_Var.policy_from_date !== " " && Tab3_Policycore_Land_Var.policy_from_date !== null);

      result =
      result * (Tab3_Policycore_Land_Var.policy_to_date !== " " && Tab3_Policycore_Land_Var.policy_to_date !== null);

      result =
      result * (Tab3_Policycore_Land_Var.dob_oldest_insured !== " " && Tab3_Policycore_Land_Var.dob_oldest_insured !== null);

      result =
      result * (Tab3_Policycore_Land_Var.currently_hold_insurence !== " " && Tab3_Policycore_Land_Var.currently_hold_insurence !== null);

      result =
      result * (Tab3_Policycore_Land_Var.current_insurer !== " " && Tab3_Policycore_Land_Var.current_insurer !== null);

      result =
      result * (Tab3_Policycore_Land_Var.policyholder_retired !== " " && Tab3_Policycore_Land_Var.policyholder_retired !== null);

      result =
      result * (Tab3_Policycore_Land_Var.interested_parties !== " " && Tab3_Policycore_Land_Var.interested_parties !== null);

      // result =
      // result * (Tab3_Policycore_Land_Var.holding_broker !== " " && Tab3_Policycore_Land_Var.holding_broker !== null);

      // result =
      // result * (Tab3_Policycore_Land_Var.holding_underwriter !== " " && Tab3_Policycore_Land_Var.holding_underwriter !== null);

      result =
      result * (Tab3_Policycore_Land_Var.stamp_duty_exempt !== " " && Tab3_Policycore_Land_Var.stamp_duty_exempt !== null);

      result =
      result * (Tab3_Policycore_Land_Var.no_claim_bonus !== " " && Tab3_Policycore_Land_Var.no_claim_bonus !== null);

      result =
      result * (Tab3_Policycore_Land_Var.payment_frequency !== " " && Tab3_Policycore_Land_Var.payment_frequency !== null);


      const digitValid_check2 = () => {
        if (!digit_valid_check.digit_valid_checker.test((Tab3_Policycore_Land_Var.preffered_day_installment))) {
          // console.log("Hello" + tab1_client.phone);
          return true;
        }
      }
      
      if (Tab3_Policycore_Land_Var.payment_frequency === "Monthly") {
        result = result * (Tab3_Policycore_Land_Var.preffered_day_installment !== " " &&
        Tab3_Policycore_Land_Var.preffered_day_installment !== "" &&
        Tab3_Policycore_Land_Var.preffered_day_installment < 32 &&
        Tab3_Policycore_Land_Var.preffered_day_installment.length < 3 && !digitValid_check2());
        result = result * (Tab3_Policycore_Land_Var.broker_fee_installment !== " " && Tab3_Policycore_Land_Var.broker_fee_installment !== "");
    }

    result =
      result * (Tab3_Policycore_Land_Var.cover_Theft_tenant !== " " && Tab3_Policycore_Land_Var.cover_Theft_tenant !== null);

      result =
      result * (Tab3_Policycore_Land_Var.cover_loss !== " " && Tab3_Policycore_Land_Var.cover_loss !== null);

      if (Tab3_Policycore_Land_Var.cover_loss === "Yes") {
      result = result * (Tab3_Policycore_Land_Var.sum_ins_amount_loss !== " " && Tab3_Policycore_Land_Var.sum_ins_amount_loss !== "");
      }


      result = result * (Tab3_Policycore_Land_Var.annual_rent_amount !== " " && Tab3_Policycore_Land_Var.annual_rent_amount !== "");
     
      result = result * (Tab3_Policycore_Land_Var.weekly_rent_amount !== " " && Tab3_Policycore_Land_Var.weekly_rent_amount !== "");

      result =
      result * (Tab3_Policycore_Land_Var.cover_Accidental_damage !== " " && Tab3_Policycore_Land_Var.cover_Accidental_damage !== null);

      result =
      result * (Tab3_Policycore_Land_Var.cover_rent_default !== " " && Tab3_Policycore_Land_Var.cover_rent_default !== null);

      if (Tab3_Policycore_Land_Var.cover_rent_default === "Yes") {
        result = result * (Tab3_Policycore_Land_Var.tenant_rent_14Days !== " " && Tab3_Policycore_Land_Var.tenant_rent_14Days !== null);
        result = result * (Tab3_Policycore_Land_Var.residential_lease_agreement !== " " && Tab3_Policycore_Land_Var.residential_lease_agreement !== null);
        result = result * (Tab3_Policycore_Land_Var.landlord_insurance_policy !== " " && Tab3_Policycore_Land_Var.landlord_insurance_policy !== null);
        
    } 

    result =
    result * (Tab3_Policycore_Land_Var.svu_excess_option1 !== " " && Tab3_Policycore_Land_Var.svu_excess_option1 !== null);

  
    return result;
    };

    export const tab3ValidationLandEdit = (Tab3_Policycore_Land_Var) =>{
      let result = true;

      result =
      result * (Tab3_Policycore_Land_Var.cover_type_accidential !== " " && Tab3_Policycore_Land_Var.cover_type_accidential !== null);

    result =
      result * (Tab3_Policycore_Land_Var.occupancy_home !== " " && Tab3_Policycore_Land_Var.occupancy_home !== null);

      result =
      result * (Tab3_Policycore_Land_Var.property_managed !== " " && Tab3_Policycore_Land_Var.property_managed !== null);

      result =
      result * (Tab3_Policycore_Land_Var.building_content !== " " && Tab3_Policycore_Land_Var.building_content !== null);

      if (Tab3_Policycore_Land_Var.building_content === "Building only") {

        Tab3_Policycore_Land_Var.content_ins_amount = "";
        result =
        result * (Tab3_Policycore_Land_Var.building_sum_insured !== " " && Tab3_Policycore_Land_Var.building_sum_insured !== "");
  
      }
      if (Tab3_Policycore_Land_Var.building_content === "Contents only") {

        Tab3_Policycore_Land_Var.building_sum_insured = "";
        result =
        result * (Tab3_Policycore_Land_Var.content_ins_amount !== " " && Tab3_Policycore_Land_Var.content_ins_amount !== "");
  
      }
     
      if (Tab3_Policycore_Land_Var.building_content === "Building and Contents") {
        result =
        result * (Tab3_Policycore_Land_Var.building_sum_insured !== " " && Tab3_Policycore_Land_Var.building_sum_insured !== "");
  
        
        result =
        result * (Tab3_Policycore_Land_Var.content_ins_amount !== " " && Tab3_Policycore_Land_Var.content_ins_amount !== "");
  
      }
      result =
      result * (Tab3_Policycore_Land_Var.policy_from_date !== " " && Tab3_Policycore_Land_Var.policy_from_date !== null);

      result =
      result * (Tab3_Policycore_Land_Var.policy_to_date !== " " && Tab3_Policycore_Land_Var.policy_to_date !== null);

      result =
      result * (Tab3_Policycore_Land_Var.dob_oldest_insured !== " " && Tab3_Policycore_Land_Var.dob_oldest_insured !== null);

      result =
      result * (Tab3_Policycore_Land_Var.currently_hold_insurence !== " " && Tab3_Policycore_Land_Var.currently_hold_insurence !== null);

      result =
      result * (Tab3_Policycore_Land_Var.current_insurer !== " " && Tab3_Policycore_Land_Var.current_insurer !== null);

      result =
      result * (Tab3_Policycore_Land_Var.policyholder_retired !== " " && Tab3_Policycore_Land_Var.policyholder_retired !== null);

      result =
      result * (Tab3_Policycore_Land_Var.interested_parties !== " " && Tab3_Policycore_Land_Var.interested_parties !== null);

      result =
      result * (Tab3_Policycore_Land_Var.holding_broker !== " " && Tab3_Policycore_Land_Var.holding_broker !== null);

      result =
      result * (Tab3_Policycore_Land_Var.holding_underwriter !== " " && Tab3_Policycore_Land_Var.holding_underwriter !== null);

      result =
      result * (Tab3_Policycore_Land_Var.stamp_duty_exempt !== " " && Tab3_Policycore_Land_Var.stamp_duty_exempt !== null);

      result =
      result * (Tab3_Policycore_Land_Var.no_claim_bonus !== " " && Tab3_Policycore_Land_Var.no_claim_bonus !== null);

      result =
      result * (Tab3_Policycore_Land_Var.payment_frequency !== " " && Tab3_Policycore_Land_Var.payment_frequency !== null);


      const digitValid_check2 = () => {
        if (!digit_valid_check.digit_valid_checker.test((Tab3_Policycore_Land_Var.preffered_day_installment))) {
          // console.log("Hello" + tab1_client.phone);
          return true;
        }
      }
      
      if (Tab3_Policycore_Land_Var.payment_frequency === "Monthly") {
        result = result * (Tab3_Policycore_Land_Var.preffered_day_installment !== " " &&
        Tab3_Policycore_Land_Var.preffered_day_installment !== "" &&
        Tab3_Policycore_Land_Var.preffered_day_installment < 32 &&
        Tab3_Policycore_Land_Var.preffered_day_installment.length < 3 && !digitValid_check2());
        result = result * (Tab3_Policycore_Land_Var.broker_fee_installment !== " " && Tab3_Policycore_Land_Var.broker_fee_installment !== "");
    }

    result =
      result * (Tab3_Policycore_Land_Var.cover_Theft_tenant !== " " && Tab3_Policycore_Land_Var.cover_Theft_tenant !== null);

      result =
      result * (Tab3_Policycore_Land_Var.cover_loss !== " " && Tab3_Policycore_Land_Var.cover_loss !== null);

      if (Tab3_Policycore_Land_Var.cover_loss === "Yes") {
      result = result * (Tab3_Policycore_Land_Var.sum_ins_amount_loss !== " " && Tab3_Policycore_Land_Var.sum_ins_amount_loss !== "");
      }


      result = result * (Tab3_Policycore_Land_Var.annual_rent_amount !== " " && Tab3_Policycore_Land_Var.annual_rent_amount !== "");
     
      result = result * (Tab3_Policycore_Land_Var.weekly_rent_amount !== " " && Tab3_Policycore_Land_Var.weekly_rent_amount !== "");

      result =
      result * (Tab3_Policycore_Land_Var.cover_Accidental_damage !== " " && Tab3_Policycore_Land_Var.cover_Accidental_damage !== null);

      result =
      result * (Tab3_Policycore_Land_Var.cover_rent_default !== " " && Tab3_Policycore_Land_Var.cover_rent_default !== null);

      if (Tab3_Policycore_Land_Var.cover_rent_default === "Yes") {
        result = result * (Tab3_Policycore_Land_Var.tenant_rent_14Days !== " " && Tab3_Policycore_Land_Var.tenant_rent_14Days !== null);
        result = result * (Tab3_Policycore_Land_Var.residential_lease_agreement !== " " && Tab3_Policycore_Land_Var.residential_lease_agreement !== null);
        result = result * (Tab3_Policycore_Land_Var.landlord_insurance_policy !== " " && Tab3_Policycore_Land_Var.landlord_insurance_policy !== null);
        
    } 

    result =
    result * (Tab3_Policycore_Land_Var.svu_excess_option1 !== " " && Tab3_Policycore_Land_Var.svu_excess_option1 !== null);

    // result =
    // result * (Tab3_Policycore_Land_Var.svu_excess_option2 !== " " && Tab3_Policycore_Land_Var.svu_excess_option2 !== null);

    // result =
    // result * (Tab3_Policycore_Land_Var.svu_excess_option3 !== " " && Tab3_Policycore_Land_Var.svu_excess_option3 !== null);

    result =
    result * (Tab3_Policycore_Land_Var.broker_fee !== " " && Tab3_Policycore_Land_Var.broker_fee !== "");


      return result;
  }


    export const cover_type_accidential_validate = (
      value,
      Tab3_Validation_Land_Var,
      setTab3_validation
    ) => {
      console.log("val:" + value);
      if (value === null || value === " ") {
          setTab3_validation({
          ...Tab3_Validation_Land_Var,
          cover_type_accidential: "Must select an option",
        });
      } else {
          setTab3_validation({
          ...Tab3_Validation_Land_Var,
          cover_type_accidential: "true",
        });
      }
    };

    export const occupancy_home_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            occupancy_home: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            occupancy_home: "true",
          });
        }
      };

      export const property_managed_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            property_managed: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            property_managed: "true",
          });
        }
      };

      export const building_content_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            building_content: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            building_content: "true",
          });
        }
      };

      export const building_sum_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        if (value === "") {
          setTab3_validation({
            ...Tab3_Validation_Land_Var,
            building_sum_insured: "Must have value",
          });
        } else {
          setTab3_validation({
            ...Tab3_Validation_Land_Var,
            building_sum_insured: "true",
          });
        }
      };

      export const content_ins_amount_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        if (value === "") {
          setTab3_validation({
            ...Tab3_Validation_Land_Var,
            content_ins_amount: " Must have value",
          });
        } else {
          setTab3_validation({
            ...Tab3_Validation_Land_Var,
            content_ins_amount: "true",
          });
        }
      };

      export const policy_from_date_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            policy_from_date: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            policy_from_date: "true",
          });
        }
      };

      export const policy_to_date_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            policy_to_date: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            policy_to_date: "true",
          });
        }
      };

      export const dob_oldest_insurede_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            dob_oldest_insured: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            dob_oldest_insured: "true",
          });
        }
      };

      export const currently_hold_insurence_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            currently_hold_insurence: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            currently_hold_insurence: "true",
          });
        }
      };

      export const current_insurer_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            current_insurer: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            current_insurer: "true",
          });
        }
      };

      export const policyholder_retired_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            policyholder_retired: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            policyholder_retired: "true",
          });
        }
      };

      export const interested_parties_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            interested_parties: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            interested_parties: "true",
          });
        }
      };

      export const holding_broker_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            holding_broker: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            holding_broker: "true",
          });
        }
      };

      export const holding_underwriter_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            holding_underwriter: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            holding_underwriter: "true",
          });
        }
      };

      export const stamp_duty_exempt_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            stamp_duty_exempt: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            stamp_duty_exempt: "true",
          });
        }
      };

      export const no_claim_bonus_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            no_claim_bonus: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            no_claim_bonus: "true",
          });
        }
      };

      export const payment_frequency_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            payment_frequency: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            payment_frequency: "true",
          });
        }
      };

      export const preffered_day_installment_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        if (value === "") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            preffered_day_installment: "Must have value",
          });
        } else if (value.length > 2) {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            preffered_day_installment: "Invalid number.",
          });
        }
        else if (value > 31) {
          setTab3_validation({
          ...Tab3_Validation_Land_Var,
          preffered_day_installment: "Invalid number.",
        });
      }
        else if (!digit_valid_check.digit_valid_checker.test(value)) {
          if (value.length === 2) {
            setTab3_validation({
              ...Tab3_Validation_Land_Var,
              preffered_day_installment: "Preffered day Installment: Invalid Type.",
            });
          }
        }
        else {
          setTab3_validation({
            ...Tab3_Validation_Land_Var,
            preffered_day_installment: "true",
          });
        }
      }
    ;

      export const broker_fee_installment_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        if (value === "") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            broker_fee_installment: "Must have value",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            broker_fee_installment: "true",
          });
        }
      };

      export const cover_Theft_tenant_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            cover_Theft_tenant: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            cover_Theft_tenant: "true",
          });
        }
      };

      export const cover_loss_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            cover_loss: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            cover_loss: "true",
          });
        }
      };

      export const sum_ins_amount_loss_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        if (value === "") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            sum_ins_amount_loss: "Must have value",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            sum_ins_amount_loss: "true",
          });
        }
      };

      export const annual_rent_amount_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        if (value === "") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            annual_rent_amount: "Must have value",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            annual_rent_amount: "true",
          });
        }
      };

      export const weekly_rent_amount_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        if (value === "") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            weekly_rent_amount: "Must have value",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            weekly_rent_amount: "true",
          });
        }
      };

      export const cover_Accidental_damage_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            cover_Accidental_damage: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            cover_Accidental_damage: "true",
          });
        }
      };

      export const cover_rent_default_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            cover_rent_default: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            cover_rent_default: "true",
          });
        }
      };

      export const tenant_rent_14Days_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            tenant_rent_14Days: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            tenant_rent_14Days: "true",
          });
        }
      };

      export const residential_lease_agreement_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            residential_lease_agreement: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            residential_lease_agreement: "true",
          });
        }
      };

      export const landlord_insurance_policy_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            landlord_insurance_policy: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            landlord_insurance_policy: "true",
          });
        }
      };

      export const svu_excess_option1_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            svu_excess_option1: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            svu_excess_option1: "true",
          });
        }
      };

      export const svu_excess_option2_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            svu_excess_option2: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            svu_excess_option2: "true",
          });
        }
      };

      export const svu_excess_option3_validate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            svu_excess_option3: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            svu_excess_option3: "true",
          });
        }
      };


      export const brokerFeevalidate = (
        value,
        Tab3_Validation_Land_Var,
        setTab3_validation
      ) => {
        // console.log("val:" + value);
        if (value === null || value === " ") {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            broker_fee: "Must select an option",
          });
        } else {
            setTab3_validation({
            ...Tab3_Validation_Land_Var,
            broker_fee: "true",
          });
        }
      };