import React , {useContext , useEffect} from "react";
import { HashRouter, Switch, Route, Redirect } from "react-router-dom";

import Signin from "./user/Signin";
import Login from "./pages/login/login";
import PrivateRoute from "./auth/PrivateRoute";
import Dashboard from "./user/UserDashboard_Main";
import Dashboard_Motor from "./user/UserDashboard_Motor";
import Dashboard_Home from "./user/UserDashboard_Home";
import DashBoardforLand from "./user/UserDashBoard_Land";
import EditLink from "./edit/EditLink";
import EditLink_Home from "./edit_home/EditLink";
import EditLinkLand from "./editLand/editLink"
import ClientLink from "./client/ClientLink";
import ClientHome from "./client/ClientHome";
import LandingPage from "./pages/landingPage";
// import clientRegionalInsure from "./client/clientRegionalInsure";
import HomeClient from "./clientHome/ClientHomeLink";
import Landlord from "./clientLand/ClientLandLink"; 
import adminDashboard from "./admin/adminDashboard";
import adminAddUser from "./admin/adminAddUser";
import PagenotFount from "../src/component/pagenotfount/Pagenotfount";
import Topbar from './component/topBar/topBar'
import { AuthContext } from "./context/AuthContext";
import { Logout } from "./context/AuthAction";
const Routes = () => {
  const { user , dispatch  } = useContext(AuthContext)
  
  const EXPIRE_TIME = 60 * 60 * 1000 ; // after 1hour localstorage will be cleared
  if(user){
    useEffect(() => {
      setTimeout(() => {
         dispatch(Logout())
     }, EXPIRE_TIME); 
   });
  } 
  

  return (
    <div>
      <HashRouter>

        <Topbar/>
        <Switch>
          <Route
            exact
            path="/"
            render={() => {
              return <Redirect to="/client" />; 
            }}
          />

          {/* <Route path="/signin" exact component={Signin} /> */}

          <Route path="/login">{!user ? <Login/> : <Redirect to="/user/dashboard" />}</Route>
          <Route path="/user/dashboard">{user ? <Dashboard/> : <Redirect to ="/login"/>}</Route>
          <Route path="/motor_client_web_form" exact component={ClientLink} />
          <Route path="/home_client_web_form" exact component={HomeClient} />
          <Route path="/landlord_client_web_form" exact component={Landlord} />
          <PrivateRoute path="/user/dashboard" exact component={Dashboard} />
          
          {/* <PrivateRoute
            path="/user/dashboard_motor"
            exact
            component={Dashboard_Motor}
          /> */}
           <Route path="/user/dashboard_motor">{user ? <Dashboard_Motor/> : <Redirect to ="/login"/>}</Route>

          {/* <PrivateRoute
            path="/user/dashboard_home"
            exact
            component={Dashboard_Home}
          /> */}
          <Route path="/user/dashboard_home">{user ? <Dashboard_Home/> : <Redirect to ="/login"/>}</Route>
          
          {/* <PrivateRoute
            path="/user/dashboardLandlords"
            exact
            component={DashBoardforLand}
          />
        */}
        <Route path="/user/dashboardLandlords">{user ? <DashBoardforLand/> : <Redirect to ="/login"/>}</Route>
          
          {/* <PrivateRoute
            path="/admin/dashboard"
            exact
            component={adminDashboard}
          /> */}
          <Route path="/user/dashboard">{user ? <adminDashboard/> : <Redirect to ="/login"/>}</Route>
          
          {/* <PrivateRoute
            path="/admin/dashboard/add-user"
            exact
            component={adminAddUser}
          /> */}
          <Route path="/user/dashboard/add-user">{user ? <adminAddUser/> : <Redirect to ="/login"/>}</Route>
          
          {/* <PrivateRoute
            path="/user/motor_quotation_edit/:quotation_id"
            exact
            component={EditLink}
          /> */}
          
          
          {/* <PrivateRoute
            path="/user/home_quotation_edit/:quotation_id"
            exact
            component={EditLink_Home} EditLinkLand
          /> */}
           
           {/* <PrivateRoute
            path="/user/editLandPage/:quotation_id"
            exact
            component={EditLinkLand} 
          />  */}
          
          <Route path="/user/editHomeContentsPage/:quotationId" render = { (props) =>user ? <EditLink_Home id={props.match.params.quotationId}/> : <Redirect to ="/login"/>}/>
          <Route path="/user/editMotorPage/:quotationId" render={ (props) => user ? <EditLink id={props.match.params.quotationId} /> : <Redirect to="/login" />}/>
          <Route path = "/user/editLandPage/:quotationId" render = { (props) => user ? <EditLinkLand id={props.match.params.quotationId}/> : <Redirect to="/login"/>}/>

          {/* <Route path="/client" exact component={ClientHome} /> */}
          <Route path="/client" exact component={LandingPage} />
          <Route path="/*" component={PagenotFount} />
          {/* <Route path="/client" exact component={clientRegionalInsure} /> */}
          {/* <PrivateRoute path='/user/dashboard' exact component={Dashboard} /> */}
          {/* <PrivateRoute path='/profile/:userId' exact component={Profile} /> */}
        </Switch>
      </HashRouter>
    </div>
  );
};

export default Routes;
