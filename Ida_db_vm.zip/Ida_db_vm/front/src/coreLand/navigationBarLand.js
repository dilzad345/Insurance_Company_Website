import React from "react";
// import { Button, Grid } from "@material-ui/core";
// import { Navbar } from "react-bootstrap";
//import logo from "../../images/logo.png";
// import logo from "../images/logo.png";
import "./navBar.css"
import { Tab1_Validation_Land } from "../validationLand/Tab1_Validation_Land";
import { Tab2_Validation_Land } from "../validationLand/Tab2_Validation_Land";
import { Tab3_Validation_Land } from "../validationLand/Tab3_Validation_Land";
import { Tab4_Validation_Land } from "../validationLand/Tab4_Validation_Land";
import { Tab5_Validation_Land } from "../validationLand/Tab5_Validation_Land";
import { Tab6_Validation_Land } from "../validationLand/Tab6_Validation_Land";


const navigationBarLand = ({
  step,
    navigation,
    Tab1_Client_Land_var,
    Tab2_Importan_Question_Land_var,
    Tab3_Policycore_Land_Var,
    Tab4_Building_Land_Var,
    Tab5_Contents_Land_Var,
    Tab6_Claims_Land_Var,
}) => {
  const navButtonClick = (index) => {
    navigation.go(index);
  };

  return (
    <div className="btn-container">

     <button  
       onClick={() => {navButtonClick(0);}}
       style={{
        border: Tab1_Validation_Land(Tab1_Client_Land_var)
        ? "solid 3px #05fc81"
        : "solid 3px red",
        backgroundColor:
        step.id === "Tab1_Client_Land_var" ? "#1B1523" : "#2A3A64",
    }}
    className="btn"
     >
      Client
     </button>
     <button
     style={{
      border: Tab2_Validation_Land(Tab2_Importan_Question_Land_var)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "Tab2_Importan_Question_Land_var" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {navButtonClick(1);}}>Important Questions</button>
     <button
     style={{
      border: Tab3_Validation_Land(Tab3_Policycore_Land_Var)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "Tab3_Policycore_Land_Var" ? "#02516b" : "#2A3A64",
    }}
    onClick={() => {
      navButtonClick(2);
    }}
    className="btn"
     >Policy Core</button>
     <button
     style={{
      border: Tab4_Validation_Land(Tab4_Building_Land_Var)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "Tab4_Building_Land_Var" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {
      navButtonClick(3);
    }}>Building</button>

     <button
     style={{
      border: Tab5_Validation_Land(Tab5_Contents_Land_Var)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "Tab5_Contents_Land_Var" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {
      navButtonClick(4);
    }}>Contents</button>
     <button
     style={{
      border: Tab6_Validation_Land(Tab6_Claims_Land_Var)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "Tab6_Claims_Land_Var" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {
      navButtonClick(5);
    }}>
       Claims
     </button>
      {/* <Grid
        container
        spacing={2}
        direction="row"
        justifyContent="center"
        alignItems="center"
        style={{ marginBottom: "50px" }}
        className="my-2"> */}

        {/* <Grid item xs={1}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "White",
              border: Tab1_Validation_Land(Tab1_Client_Land_var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "Tab1_Client_Land_var" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(0);
            }}

          >
            Client
          </Button>
        </Grid> */}

        {/* <Grid item xs={2}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "White",
              border: Tab2_Validation_Land(Tab2_Importan_Question_Land_var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "Tab2_Importan_Question_Land_var" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(1);
            }}
          >
            Important Questions
          </Button>
        </Grid> */}

        {/* <Grid item xs={2}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "White",
              border: Tab3_Validation_Land(Tab3_Policycore_Land_Var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "Tab3_Policycore_Land_Var" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(2);
            }}
          >
            Policy Core
          </Button>
        </Grid> */}

        {/* <Grid item xs={1}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "White",
              border: Tab4_Validation_Land(Tab4_Building_Land_Var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "Tab4_Building_Land_Var" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(3);
            }}
          >
            Building
          </Button>
        </Grid> */}

        {/* <Grid item xs={1}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "White",
              border: Tab5_Validation_Land(Tab5_Contents_Land_Var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "Tab5_Contents_Land_Var" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(4);
            }}
          >
            Contents
          </Button>
        </Grid> */}

        {/* <Grid item xs={1}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "White",
              border: Tab6_Validation_Land(Tab6_Claims_Land_Var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "Tab6_Claims_Land_Var" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(5);
            }}>
            Claims
          </Button>
        </Grid> */}



      {/* </Grid> */}
    </div>
  );





};

export default navigationBarLand;