// import { createBrowserHistory } from "history";
import {createHashHistory} from "history";

// const history = createBrowserHistory({forceRefresh:true});
const history = createHashHistory({forceRefresh:true});

export default history;