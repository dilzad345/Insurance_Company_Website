import React, { useState, useEffect }  from "react";
import { Route, Redirect } from "react-router-dom";
import { validateRoute } from "./index";

const PrivateRoute = ({ component: Component, ...rest }) => {

  const [load, setLoad] = useState(true);

  useEffect(() =>{
    if(JSON.parse(localStorage.getItem("user")) === null){
      setLoad(false);
    } else if(JSON.parse(localStorage.getItem("user")).auth === false){
      setLoad(false);
    } else if(JSON.parse(localStorage.getItem("user")).auth){
      setLoad(true);
    }
    
    validateRoute((result) => {
    });
  })

  return (
    <Route
      {...rest}
      render={(props) => load ? ( <Component {...props} />
        ) : (
          <Redirect
            to={{
              pathname: "/login",

              state: { from: props.location },
            }}
          />
        )
      }
    />
  );
};

export default PrivateRoute;
