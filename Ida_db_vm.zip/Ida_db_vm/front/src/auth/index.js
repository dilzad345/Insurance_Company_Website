import {useContext}from "react";
import { API } from "../config";
import axios from "axios";
import history from "./history";
// import { UserContext } from "../App";
import { AuthContext } from "../context/AuthContext";

export const signup = (user) => {
  return fetch(`${API}/signup`, {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify(user),
  })
    .then((response) => {
      return response.json();
    })
    .catch((err) => {
      console.log(err);
    });
};

export const signin = async(user) => {
  // const {dispatch , isFetching} = useContext(AuthContext);
  console.log(user);
  try{
    const res= await axios.post(`${API}/user/signin` , user); // http://localhost3001/user/signin
    // dispatch({ type : "LOGIN_SUCCESS" , payload : res.data})
    return res;
  }
   catch(err){
    // dispatch({ type : "LOGIN_FAILURE"})
    console.log(err);
   }
  
};

export const authenticate = (data, next) => {
  if (typeof window !== "undefined") {
    localStorage.setItem("userJWT", JSON.stringify(data));
    next();
  }
};

export const signout = (next) => {
  // const {state, dispatch} = useContext(UserContext)
  // const {state, dispatch} = useContext(UserContext)
  if (typeof window !== "undefined") {
    
    next();
    return axios
      .get(`${API}/user/signout`)
      .then((response) => {
        console.log("signout", response);
        localStorage.removeItem("user");
        // dispatch({type:"USER", payload :false});
        history.push("/signin");
      })
      .catch((error) => {
        console.log(error);
      });
    // return fetch(`${API}/signout`, {
    //   method: 'GET',
    // })
    //   .then((response) => {
    //     console.log('signout', response);
    //   })
    //   .catch((err) => console.log(err));
  }
};

// validate user by calling server
const tokenValidation = async (token) => {
  return await axios
    .get(`${API}/user/isAuthenticated`, {
      headers: {
        "access-token": token,
      },
    })
    .then((res) => {
      
      //console.log(res.data);
      if (res.data.auth) {
        return true;
      } else {
        return false;
      }
    })
    .catch((error) => {
      console.log(error);
      return false;
    });
};

export const isAuthenticated = async () => {
  if (typeof window === "undefined") {
    return false;
  }
// console.log("jjjj")
  const user = JSON.parse(localStorage.getItem("user"));

  if (user) {
    let result = await tokenValidation(user.token);
    if (result) {
      return JSON.parse(localStorage.getItem("user"));
    } else {
      return false;
    }
  } else {
    return false;
  }
};

export const validateRoute = (next) => {
  if (typeof window === "undefined") {
    return false;
  }

  if(localStorage.getItem("user")){
     const user = JSON.parse(localStorage.getItem("user"));
     const isAuthenticated = user.auth; 
    //  console.log(user);
     next();
     return isAuthenticated;
  }
  else{
    next();
    return false;
  }
  //let ss = verify(next);
  // next(false)
};

