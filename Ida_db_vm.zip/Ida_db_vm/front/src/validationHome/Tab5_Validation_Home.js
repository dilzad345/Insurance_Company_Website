// navBar validation for client page
export const Tab5_Validation_Home = (Tab5_Contents_Home_Var, Tab3_Policycore_Home_Var) => {
  let result = true;
 
  if (Tab3_Policycore_Home_Var.coverType === "Defined Events") {
    result = result * (Tab3_Policycore_Home_Var.unspecifiedValues !== " ");
  }

  Tab5_Contents_Home_Var.forEach((element, index) => {
    console.log(element.type);
    result = result * (element.type !== " " && element.type !== null);
    result = result * (element.category !== " " && element.category !== null);
    result = result * (element.description !== " " && element.description !== "");
    result = result * (element.value !== " " && element.value !== "" && element.value > 0);

  });
  console.log(result);
  return result;
}; // end of client navBar validation

// navBar validation for edit page
export const tab5_validateEdit = (Tab5_Contents_Home_Var) => {

  let result = true;
  Tab5_Contents_Home_Var.forEach((element, index) => {
    if (element.edit !== "DELETED") {
      result = result * (element.type !== " " && element.type !== null);
      result = result * (element.category !== " " && element.category !== null);
      result = result * (element.description !== " " && element.description !== "");
      result = result * (element.value !== " " && element.value !== "");
    }
  });

  return result;
}; // end of edit navBar validation

export const type_validate = (
  index,
  value,
  tab5_validation,
  setTab5_validation
) => {
  console.log(value)
  if (value === null || value === " ") {
    let tempArr = [...tab5_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      type: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab5_validation(tempArr);
  } else {
    let tempArr = [...tab5_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      type: "true",
    };

    tempArr[index] = tempObj;

    setTab5_validation(tempArr);
  }
};

export const category_validate = (
  index,
  value,
  tab5_validation,
  setTab5_validation
) => {
  if (value === null || value === " ") {
    let tempArr = [...tab5_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      category: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab5_validation(tempArr);
  } else {
    let tempArr = [...tab5_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      category: "true",
    };

    tempArr[index] = tempObj;

    setTab5_validation(tempArr);
  }
};

export const description_validate = (
  index,
  value,
  tab5_validation,
  setTab5_validation
) => {
  if (value === "") {
    let tempArr = [...tab5_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      description: "Description : Must have a value",
    };

    tempArr[index] = tempObj;

    setTab5_validation(tempArr);
  } else {
    let tempArr = [...tab5_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      description: "true",
    };

    tempArr[index] = tempObj;

    setTab5_validation(tempArr);
  }
};

export const value_validate = (
  index,
  value,
  tab5_validation,
  setTab5_validation
) => {
  const amount_validate = /(?:\.\d{0,1})$/;
  let tempArr = [...tab5_validation];
  let tempObj = tempArr[index];
  if (value === "") {


    tempObj = {
      ...tempObj,
      value: "Value : Must have digits only",
    };

    tempArr[index] = tempObj;

    setTab5_validation(tempArr);
  } else if (value < 0) {
    tempObj = {
      ...tempObj,
      value: "Value : Value cannot be negative",
    };

    tempArr[index] = tempObj;

    setTab5_validation(tempArr);
  } else if (value === "0") {
    tempObj = {
      ...tempObj,
      value: "Value : Value cannot be zero.",
    };

    tempArr[index] = tempObj;

    setTab5_validation(tempArr);
  } else if (amount_validate.test(value)) {
    tempObj = {
      ...tempObj,
      value: "Value : Enter valid value(Eg. $800.00).",
    };

    tempArr[index] = tempObj;

    setTab5_validation(tempArr);
  } else {
    let tempArr = [...tab5_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      value: "true",
    };

    tempArr[index] = tempObj;

    setTab5_validation(tempArr);
  }
};
