export const Tab4_Validation_Home = (Tab4_Building_Home_Var) => {
  let result = true;


  result = result * (Tab4_Building_Home_Var.prptyHeritageList !== " ");
  result = result * (Tab4_Building_Home_Var.whatOccupancyHome !== " ");
  result = result * (Tab4_Building_Home_Var.buildingType !== " ");
  result = result * (Tab4_Building_Home_Var.insuredAddress !== " ");

  result = result * (Tab4_Building_Home_Var.smhAcres20000 !== " ");
  result = result * (Tab4_Building_Home_Var.insuredGenerateIncome !== " ");
  result = result * (Tab4_Building_Home_Var.machineryImplmtVehicles !== " ");
  result = result * (Tab4_Building_Home_Var.more6Livestock !== " ");
  result = result * (Tab4_Building_Home_Var.propertyUsedAnimals !== " ");
  result = result * (Tab4_Building_Home_Var.nonPersonalUse !== " ");
  result = result * (Tab4_Building_Home_Var.aircraftLandingStrip !== " ");
  result = result * (Tab4_Building_Home_Var.constructionPeriod !== " ");
  result = result * (Tab4_Building_Home_Var.constructionWalls !== " ");
  result = result * (Tab4_Building_Home_Var.roofConstruction !== " ");
  result = result * (Tab4_Building_Home_Var.consQualityofHome !== " ");
  result = result * (Tab4_Building_Home_Var.numberOfPropertyHave !== " ");
  // result = result *(Tab4_Building_Home_Var.unitBuildingLevel !==" ");
  result = result * (Tab4_Building_Home_Var.effectByWtaer !== " ");
  result = result * (Tab4_Building_Home_Var.mainsWaterSupply !== " ");
  result = result * (Tab4_Building_Home_Var.windowSecurity !== " ");
  result = result * (Tab4_Building_Home_Var.doorSecurity !== " ");
  result = result * (Tab4_Building_Home_Var.burglarAlarm !== " ");
  result = result * (Tab4_Building_Home_Var.builtConstNextMnth !== " ");
  result = result * (Tab4_Building_Home_Var.swimmingPool !== " ");
  result = result * (Tab4_Building_Home_Var.locatedbelowgRoundLevel !== " ");
  result = result * (Tab4_Building_Home_Var.privateFlood !== " ");

  if ((Tab4_Building_Home_Var.buildingType === "Free Standing / House")
    || (Tab4_Building_Home_Var.buildingType === "Townhouse")
    || (Tab4_Building_Home_Var.buildingType === "Display Home")) {

    Tab4_Building_Home_Var.whatTypeSemiDetached = " ";
    Tab4_Building_Home_Var.dwellingDescribesHome = " ";
    Tab4_Building_Home_Var.managemenBodyCorporate = " ";
    Tab4_Building_Home_Var.whatTypeApartment = " ";
    result = result * (Tab4_Building_Home_Var.whatBuiltHome !== " ");
  }

  if ((Tab4_Building_Home_Var.buildingType === "Apartment / Unit (Ground Floor)")
    || (Tab4_Building_Home_Var.buildingType === "Apartment / Unit (Above Ground Floor)")
    || (Tab4_Building_Home_Var.buildingType === "Semi-Detached / Terrace")) {

    result = result * (Tab4_Building_Home_Var.managemenBodyCorporate !== " ")
  }
  if (Tab4_Building_Home_Var.buildingType === "Other") {
    Tab4_Building_Home_Var.whatTypeSemiDetached = " ";
    // Tab4_Building_Home_Var.whatTypeApartment =" ";
    // Tab4_Building_Home_Var.managemenBodyCorporate =" ";
    Tab4_Building_Home_Var.whatBuiltHome = " ";
    result = result * (Tab4_Building_Home_Var.dwellingDescribesHome !== " ")
  }

  if (Tab4_Building_Home_Var.insuredAddress === "No") {
    result =
      result * (Tab4_Building_Home_Var.streetNumber_insured !== " " && Tab4_Building_Home_Var.streetNumber_insured !== "");
    result =
      result * (Tab4_Building_Home_Var.street_type_insured !== "Please Select" &&
        Tab4_Building_Home_Var.street_type_insured !== " ");
    result =
      result *
      (Tab4_Building_Home_Var.street_name_insured !== " " && Tab4_Building_Home_Var.street_name_insured !== null);

    result = result * (Tab4_Building_Home_Var.suburb_insured !== " " && Tab4_Building_Home_Var.suburb_insured !== "");

    result = result * (Tab4_Building_Home_Var.state_insured !== "Please Select"
      && Tab4_Building_Home_Var.state_insured !== " ");

    result =
      result * (Tab4_Building_Home_Var.postcode_insured !== " " && Tab4_Building_Home_Var.postcode_insured !== "");

  }

  if (Tab4_Building_Home_Var.prptyHeritageList === "Yes") {
    result =
      result *
      (Tab4_Building_Home_Var.provideDetails !== "" &&
        Tab4_Building_Home_Var.provideDetails !== " ");
  }

  if (Tab4_Building_Home_Var.insuredAddress === "Yes") {
    Tab4_Building_Home_Var.streetNumber_insured = "";
    Tab4_Building_Home_Var.street_name_insured = "";
    Tab4_Building_Home_Var.street_type_insured = "Please Select";
    Tab4_Building_Home_Var.suburb_insured = "";
    Tab4_Building_Home_Var.state_insured = "Please Select";
    Tab4_Building_Home_Var.postcode_insured = "";

  }

  const checkYearDiff = () => {
    // console.log("hi")
    let selectYearInt = parseInt(Tab4_Building_Home_Var.originalYearBuilt);
    let currentYear = new Date().toLocaleDateString();
    let currentYearStr = currentYear.substring(currentYear.length - 4);
    let currentYearInt = parseInt(currentYearStr);
    let yearDiff = currentYearInt - selectYearInt;
    // if (yearDiff < 4) {
    //   return true;
    // } else {

    //   return false;
    // }
    return yearDiff;
  } // end of method

  if (checkYearDiff() < 4) {
    //console.log("hi")
    result =
      result *
      (Tab4_Building_Home_Var.occupancyCertificate !== "" &&
        Tab4_Building_Home_Var.occupancyCertificate !== " ");

  }
  if (checkYearDiff() > 50) {
    //console.log("hi")
    result =
      result *
      (Tab4_Building_Home_Var.housebeenReroofed !== "" &&
        Tab4_Building_Home_Var.housebeenReroofed !== " ");

    result =
      result *
      (Tab4_Building_Home_Var.housebeenReplumbed !== "" &&
        Tab4_Building_Home_Var.housebeenReplumbed !== " ");

    result =
      result *
      (Tab4_Building_Home_Var.housebeenRewired !== "" &&
        Tab4_Building_Home_Var.housebeenRewired !== " ");

  }
  else {
    Tab4_Building_Home_Var.occupancyCertificate = " ";
    Tab4_Building_Home_Var.housebeenReroofed = " ";
    Tab4_Building_Home_Var.housebeenReplumbed = " ";
    Tab4_Building_Home_Var.housebeenRewired = " ";

  }
  return result;
};

export const streetNumber_validate = (
  value,
  Tab4_Validation_Home_Var,
  setTab4_validation
) => {
  if (value === "") {
    setTab4_validation({
      ...Tab4_Validation_Home_Var,
      streetNumber_insured: "Street Number : Must have value",
    });
  } else {
    setTab4_validation({
      ...Tab4_Validation_Home_Var,
      streetNumber_insured: "true",
    });
  }
};


export const streetName_validate = (
  value,
  Tab4_Validation_Home_Var,
  setTab4_validation
) => {
  if (value === "") {
    setTab4_validation({
      ...Tab4_Validation_Home_Var,
      street_name_insured: "Street Name: Must have value",
    });
  } else {
    setTab4_validation({
      ...Tab4_Validation_Home_Var,
      street_name_insured: "true",
    });
  }
};


export const suburb_validate = (value, Tab4_Validation_Home_Var, setTab4_validation) => {
  if (value === "") {
    setTab4_validation({
      ...Tab4_Validation_Home_Var,
      suburb_insured: "Suburb: Must have value",
    });
  } else {
    setTab4_validation({
      ...Tab4_Validation_Home_Var,
      suburb_insured: "true",
    });
  }
};
export const streetType_validate = (
  value,
  Tab4_Validation_Home_Var,
  setTab4_validation
) => {
  if (value === null || value === " ") {
    setTab4_validation({
      ...Tab4_Validation_Home_Var,
      street_type_insured: "Street Type: Must select an option",
    });
  } else {
    setTab4_validation({
      ...Tab4_Validation_Home_Var,
      street_type_insured: "true",
    });
  }
};

export const state_validate = (
  value,
  Tab4_Validation_Home_Var,
  setTab4_validation) => {
  if (value === null || value === " ") {
    setTab4_validation({
      ...Tab4_Validation_Home_Var,
      state_insured: "State: Must select an option",
    });
  } else {
    setTab4_validation({
      ...Tab4_Validation_Home_Var,
      state_insured: "true",
    });
  }
};

export const postCode_validate = (
  value,
  Tab4_Validation_Home_Var,
  setTab4_validation
) => {
  if (value === "") {
    setTab4_validation({
      ...Tab4_Validation_Home_Var,
      postcode_insured: "Postcode: Must have value.",
    });
  } else {
    setTab4_validation({
      ...Tab4_Validation_Home_Var,
      postcode_insured: "true",
    });
  }
};

export const provideDetails_validate = (
  value,
  Tab4_Validation_Home_Var,
  setTab4_validation
) => {
  if (value === "") {
    setTab4_validation({
      ...Tab4_Validation_Home_Var,
      provideDetails: "Must have value",
    });
  } else {
    setTab4_validation({
      ...Tab4_Validation_Home_Var,
      provideDetails: "true",
    });
  }
};


export const originalYearBuilt_validate = (
  value,
  Tab4_Validation_Home_Var,
  setTab4_validation
) => {
  // console.log("values from valid" +value);
  if (value === "") {
    setTab4_validation({
      ...Tab4_Validation_Home_Var,
      originalYearBuilt: "Year : Must have digits only",
    });
  } else {
    setTab4_validation({
      ...Tab4_Validation_Home_Var,
      originalYearBuilt: "true",
    });
  }
};