// import { useState } from "react";
import { digit_valid_check, email_valid_check } from "../constants/validChecker";
export const Tab1_Validation_Home = (Tab1_Client_Home_var) => {
  let result = true;

  result =
    result *
    (Tab1_Client_Home_var.clientType !== " " &&
      Tab1_Client_Home_var.clientType !== null);

  if (Tab1_Client_Home_var.clientType === "Individual") {

    // result =
    //   result * (Tab1_Client_Home_var.title !== null &&
    //     Tab1_Client_Home_var.title !== " ");

    //prevent from typing multiple white spaces
    if (!Tab1_Client_Home_var.firstName.replace(/\s/g, '').length) {
      Tab1_Client_Home_var.firstName = "";
      result = result *
        (Tab1_Client_Home_var.firstName !== "" &&
          Tab1_Client_Home_var.firstName !== null);
    }
    if (!Tab1_Client_Home_var.lastName.replace(/\s/g, '').length) {
      Tab1_Client_Home_var.lastName = "";
      result =
        result *
        (Tab1_Client_Home_var.lastName !== "" &&
          Tab1_Client_Home_var.lastName !== null);
    }
  }

  else if (Tab1_Client_Home_var.clientType === "Company") {
    if (!Tab1_Client_Home_var.companyName.replace(/\s/g, '').length) {
      Tab1_Client_Home_var.companyName = "";
      result = result *
        (Tab1_Client_Home_var.companyName !== "" &&
          Tab1_Client_Home_var.companyName !== null);
    }
    if (!Tab1_Client_Home_var.tradingAs.replace(/\s/g, '').length) {
      Tab1_Client_Home_var.tradingAs = "";
      result =
        result *
        (Tab1_Client_Home_var.tradingAs !== "" &&
          Tab1_Client_Home_var.tradingAs !== null);
    }
  }

  result =
    result *
    (Tab1_Client_Home_var.streetNumber !== " "
      && Tab1_Client_Home_var.streetNumber !== "" &&
      Tab1_Client_Home_var.streetNumber !== null);

  if (!Tab1_Client_Home_var.streetName.replace(/\s/g, '').length) {
    Tab1_Client_Home_var.streetName = "";
    result =
      result *
      (Tab1_Client_Home_var.streetName !== "" &&
        Tab1_Client_Home_var.streetName !== null &&
        Tab1_Client_Home_var.streetName !=="");
  }
  
  result =
    result *
    (Tab1_Client_Home_var.streetType !== " " && 
    Tab1_Client_Home_var.streetType !== "Please Select");

  result = result * (Tab1_Client_Home_var.suburb !== " " && Tab1_Client_Home_var.suburb !== "");

  result = result * 
  (Tab1_Client_Home_var.state !== " " && 
  Tab1_Client_Home_var.state !== null &&
  Tab1_Client_Home_var.state !=="Please Select");

  result =
    result * 
    (Tab1_Client_Home_var.postCode !== " " && 
    Tab1_Client_Home_var.postCode !== "" &&
    Tab1_Client_Home_var.postCode !==null);

  result =
    result *
    (Tab1_Client_Home_var.phone !== " " &&
      Tab1_Client_Home_var.phone !== "" &&
      Tab1_Client_Home_var.phone.length >=10 &&
      Tab1_Client_Home_var.phone !==null);

  const check_email = () => {
    // const email_valid_check = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,15}/g;
    if (!email_valid_check.email_valid_checker.test(Tab1_Client_Home_var.email)) {
      // console.log("Hello"+Tab1_Client_Home_var.email);
      return true;
    }
  };
  result =
    result *
    (Tab1_Client_Home_var.email !== " " &&
      Tab1_Client_Home_var.email !== "" &&
      !check_email());



  // result = result * (Tab1_Client_Home_var.branch !== " " && Tab1_Client_Home_var.branch !== "");

  // result =
  //   result * (Tab1_Client_Home_var.salesTeam !== " " && Tab1_Client_Home_var.salesTeam !== null);

  // result =
  //   result *
  //   (Tab1_Client_Home_var.serviceTeam !== " " && Tab1_Client_Home_var.serviceTeam !== null);

  return result;
};


export const tab1ValidationHomeEdit = (Tab1_Client_Home_var) => {
  let result = true;
  // console.log(Tab1_Client_Home_var);
  const ClientIdFromUipathValid_check = () => {
    if (!digit_valid_check.digit_valid_checker.test((Tab1_Client_Home_var.ClientIdForHomeFromUipath))) {
      // console.log("Hello " + Tab1_Client_Home_var.ClientIdForHomeFromUipath);
      return true;
    }
  }
  result =
    result *
    (Tab1_Client_Home_var.ClientIdForHomeFromUipath !== " " && Tab1_Client_Home_var.ClientIdForHomeFromUipath !== "" &&
      Tab1_Client_Home_var.ClientIdForHomeFromUipath !== null && !ClientIdFromUipathValid_check()
      && Tab1_Client_Home_var.ClientIdForHomeFromUipath.length === 4);

  result =
    result *
    (Tab1_Client_Home_var.clientType !== " " && Tab1_Client_Home_var.clientType !== null);
  
    if (Tab1_Client_Home_var.clientType === "Individual") {

    // result = result * (Tab1_Client_Home_var.title !== null && Tab1_Client_Home_var.title !== " ");
    result = result * (Tab1_Client_Home_var.firstName !== "");
    result = result * (Tab1_Client_Home_var.lastName !== "");
  } else if (Tab1_Client_Home_var.clientType === "Company") {
    result = result * (Tab1_Client_Home_var.companyName !== "");
    result = result * (Tab1_Client_Home_var.tradingAs !== "");
  }

  result =
    result *
    (Tab1_Client_Home_var.streetNumber !== " " && Tab1_Client_Home_var.streetNumber !== "");

  result =
    result * (Tab1_Client_Home_var.streetName !== " " && Tab1_Client_Home_var.streetName !== "");

  result =
    result *
    (Tab1_Client_Home_var.streetType !== " " && Tab1_Client_Home_var.streetType !== null);

  result = result * (Tab1_Client_Home_var.suburb !== " " && Tab1_Client_Home_var.suburb !== "");

  result = result * (Tab1_Client_Home_var.state !== " " && Tab1_Client_Home_var.state !== null);

  result =
    result * (Tab1_Client_Home_var.postCode !== " " && Tab1_Client_Home_var.postCode !== "");

  result =
    result *
    (Tab1_Client_Home_var.phone !== " " &&
      Tab1_Client_Home_var.phone !== "" &&
      Tab1_Client_Home_var.phone.length < 11);

  const check_email = () => {
    const email_valid_check = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,15}/g;

    if (!email_valid_check.test(Tab1_Client_Home_var.email)) {
      console.log("Hello" + Tab1_Client_Home_var.email);
      return true;
    }
  };
  result =
    result *
    (Tab1_Client_Home_var.email !== " " &&
      Tab1_Client_Home_var.email !== "" &&
      !check_email());



  result = result * (Tab1_Client_Home_var.branch !== " " && Tab1_Client_Home_var.branch !== "");

  result =
    result * (Tab1_Client_Home_var.salesTeam !== " " && Tab1_Client_Home_var.salesTeam !== null);

  result =
    result *
    (Tab1_Client_Home_var.serviceTeam !== " " && Tab1_Client_Home_var.serviceTeam !== null);

  return result;
};


export const ClientIdForHomeFromUipath_validate = (value, Tab1_Validation_Home_Var, setTab1_validation) => {
  if (value === "") {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      ClientIdForHomeFromUipath: "Client Id: Must have digits value",
    });
  }
  else if (value === null) {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      ClientIdForHomeFromUipath: "Client Id: Please Insert Value",
    });
  }
 
  else if (value.length < 4 || value.length > 4) {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      ClientIdForHomeFromUipath: "Client Id: Must have 4 digits",
    });
  } else {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      ClientIdForHomeFromUipath: "true",
    });
  }
}



export const clientType_validate = (value, Tab1_Validation_Home_Var, setTab1_validation) => {
  console.log("val:" + value);
  if (value === null || value === " ") {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      clientType: "Client Type: Must select an option",
    });
  } else {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      clientType: "true",
    });
  }
};

export const title_validate = (value, Tab1_Validation_Home_Var, setTab1_validation) => {
  if (value === null) {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      title: "Title: Must select an option",
    });
  } else {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      title: "true",
    });
  }
};

export const firstName_validate = (
  value,
  Tab1_Validation_Home_Var,
  setTab1_validation
) => {
  // const regex = /^([A-Za-z])([A-Za-z\s])+$/;
  if (value === "" || value === null) {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      firstName: "First Name: Must have value",
    });
  }
  // else if (!regex.test(value)) {
  //   setTab1_validation({
  //     ...Tab1_Validation_Home_Var,
  //     firstName: "First Name: Invalid",
  //   });

  else {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      firstName: "true",
    });
  }
};

export const lastName_validate = (
  value,
  Tab1_Validation_Home_Var,
  setTab1_validation
) => {
  // const regex = /^([A-Za-z])([A-Za-z\s])+$/;
  console.log(value);
  if (value === "" || value === null) {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      lastName: "Last Name: Must have value",
    });
  }
  // else if (!regex.test(value)) {
  //   setTab1_validation({
  //     ...Tab1_Validation_Home_Var,
  //     lastName: "Last Name: Invalid",
  //   });
  // } 
  else {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      lastName: "true",
    });
  }
};

export const companyName_validate = (
  value,
  Tab1_Validation_Home_Var,
  setTab1_validation
) => {
  if (value === "") {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      companyName: "Company Name : Must have value",
    });
  } else {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      companyName: "true",
    });
  }
};

export const tradingAs_validate = (
  value,
  Tab1_Validation_Home_Var,
  setTab1_validation
) => {
  if (value === "") {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      tradingAs: "Trading : Must have value",
    });
  } else {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      tradingAs: "true",
    });
  }
};

export const streetNumber_validate = (
  value,
  Tab1_Validation_Home_Var,
  setTab1_validation
) => {
  if (value === "") {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      streetNumber: "Street Number : Must have value",
    });
  } else {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      streetNumber: "true",
    });
  }
};

export const streetName_validate = (
  value,
  Tab1_Validation_Home_Var,
  setTab1_validation
) => {
  if (value === "") {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      streetName: "Street Name: Must have value",
    });
  } else {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      streetName: "true",
    });
  }
};

export const streetType_validate = (
  value,
  Tab1_Validation_Home_Var,
  setTab1_validation
) => {
  if (value === null || value === " ") {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      streetType: "Street Type: Must select an option",
    });
  } else {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      streetType: "true",
    });
  }
};

export const suburb_validate = (value, Tab1_Validation_Home_Var, setTab1_validation) => {
  if (value === "") {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      suburb: "Suburb: Must have value",
    });
  } else {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      suburb: "true",
    });
  }
};

export const state_validate = (value, Tab1_Validation_Home_Var, setTab1_validation) => {
  if (value === null || value === " ") {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      state: "State: Must select an option",
    });
  } else {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      state: "true",
    });
  }
};

export const postCode_validate = (
  value,
  Tab1_Validation_Home_Var,
  setTab1_validation
) => {
  if (value === "") {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      postCode: "Postcode: Must have value.",
    });
  } else {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      postCode: "true",
    });
  }
};

export const phone_validate = (value, Tab1_Validation_Home_Var, setTab1_validation) => {
  if (value === "") {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      phone: "Phone: Must have only digits.",
    });
  } else if (value.length < 10) {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      phone: "Phone:Must have 10 digits.",
    });
  } else {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      phone: "true",
    });
  }
};

export const email_validate = (value, Tab1_Validation_Home_Var, setTab1_validation) => {


  if (value === "") {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      email: "Email: Must have value",
    });
  } else if (!email_valid_check.email_valid_checker.test(value)) {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      email: "Email: Invalid Email",
    });
  } else {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      email: "true",
    });
  }
};

export const branch_validate = (value, Tab1_Validation_Home_Var, setTab1_validation) => {
  if (value === "" || value === " ") {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      branch: "Branch : Must have value",
    });
  } else {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      branch: "true",
    });
  }
};

export const salesTeam_validate = (
  value,
  Tab1_Validation_Home_Var,
  setTab1_validation
) => {
  if (value === null || value === " ") {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      salesTeam: "Title: Must select an option",
    });
  } else {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      salesTeam: "true",
    });
  }
};

export const serviceTeam_validate = (
  value,
  Tab1_Validation_Home_Var,
  setTab1_validation
) => {
  if (value === null || value === " ") {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      serviceTeam: "Title: Must select an option",
    });
  } else {
    setTab1_validation({
      ...Tab1_Validation_Home_Var,
      serviceTeam: "true",
    });
  }
};
