// navBar validation for client page
export const Tab6_Validation_Home = ( Tab6_Claims_Home_Var ) => {
  let result = true;
  // console.log("from tab6 validation page:",Tab6_Claims_Home_Var);
  Tab6_Claims_Home_Var.forEach((element, index) => {
    result = result * (element.typeClaim !== " " && element.typeClaim !== null);
    result = result * (element.dateClaim !== " " && element.dateClaim !== null);
    result = result * (element.description !== " " && element.description !== "");
    result = result * (element.amount !== " " && element.amount !== "" && element.amount > 0);
    result = result * (element.insurer !== " " && element.insurer !== null && element.insurer !== "");
  });
  // console.log(result)
  return result;
}; // end of client navBar validation

// navBar validation for edit page
export const tab6_validateEdit = (Tab6_Claims_Home_Var) => {

  let result = true;
  Tab6_Claims_Home_Var.forEach((element, index) => {
    if (element.edit !== "DELETED") {
      result = result * (element.typeClaim !== " " && element.typeClaim !== null);
      result = result * (element.dateClaim !== " " && element.dateClaim !== null);
      result = result * (element.description !== " " && element.description !== "");
      result = result * (element.amount !== " " && element.amount !== "");
    }
  });
  return result;
}; // end of edit navBar validation

export const typeClaim_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  // console.log("Type Claim:",value);
  if (value === null || value === " ") {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      typeClaim: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      typeClaim: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const dateClaim_validate = (
  index,value,
  tab6_validation,setTab6_validation
) => {
  console.log("Date Claim: ",value);
  if (value === null || value === " ") {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      dateClaim: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      dateClaim: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const description_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  if (value === "") {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      description: "Description : Must have a value",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      description: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

// export const amount_validate = (
//   index,
//   value,
//   tab6_validation,
//   setTab6_validation
// ) => {
//   const amount_validate = /(?:\.\d{0,1})$/;
//   let tempArr = [...tab6_validation];
//   let tempObj = tempArr[index];
//   if (value === "") {
    
    
//     tempObj = {
//       ...tempObj,
//       amount: "Value : Must have a value",
//     };

//     tempArr[index] = tempObj;

//     setTab6_validation(tempArr);
//   } else if (value < 0) {
//     tempObj = {
//       ...tempObj,
//       amount: "Value : Value cannot be negative",
//     };

//     tempArr[index] = tempObj;

//     setTab6_validation(tempArr);
//   } else if (value === "0") {
//     tempObj = {
//       ...tempObj,
//       amount: "Value : Value cannot be zero.",
//     };

//     tempArr[index] = tempObj;

//     setTab6_validation(tempArr);
//   }else if (amount_validate.test(value)) {
//     tempObj = {
//       ...tempObj,
//       amount: "Value : Enter valid value(Eg. $800.00).",
//     };

//     tempArr[index] = tempObj;

//     setTab6_validation(tempArr);
//   }else {
//     let tempArr = [...tab6_validation];
//     let tempObj = tempArr[index];

//     tempObj = {
//       ...tempObj,
//       value: "true",
//     };

//     tempArr[index] = tempObj;

//     setTab6_validation(tempArr);
//   }
// };


export const amount_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  if (value === "") {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      amount: "Amount : Must have digits only",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      amount: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};
export const insurer_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  if (value === " " || value === "") {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      insurer: "Insurer : Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      insurer: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};
