export const Tab3_Validation_Home = (Tab3_Policycore_Home_Var) => {
  let result = true;

  result = result * (Tab3_Policycore_Home_Var.coverType !== " ");
  if(Tab3_Policycore_Home_Var.coverType ==="Accidental Damage"){
    Tab3_Policycore_Home_Var.unspecifiedValues = " ";
  }
  result = result * (Tab3_Policycore_Home_Var.basisOfSettlement !== " ");
  result = result * (Tab3_Policycore_Home_Var.buildingOrContents !== " ");
  result = result * (Tab3_Policycore_Home_Var.industryPolicyHolder !== " ");
  result = result * (Tab3_Policycore_Home_Var.policyHolderRetired !== " ");
  result = result * (Tab3_Policycore_Home_Var.conductedFromHome !== " ");
  result = result * (Tab3_Policycore_Home_Var.fromHomeBusinessName !== " ");
  result = result * (Tab3_Policycore_Home_Var.fromHomeWhatBusiness !== " ");
  result = result * (Tab3_Policycore_Home_Var.fromHomeAnnualRevenue !== " " &&
    Tab3_Policycore_Home_Var.fromHomeAnnualRevenue !== null);

  result = result * (Tab3_Policycore_Home_Var.underConstruction !== " ");
  result = result * (Tab3_Policycore_Home_Var.poorlyMaintained !== " ");
  result = result * (Tab3_Policycore_Home_Var.unoccupiedDays !== " ");
  result = result * (Tab3_Policycore_Home_Var.guestHouse !== " ");
  result = result * (Tab3_Policycore_Home_Var.publicHousing !== " ");
  result = result * (Tab3_Policycore_Home_Var.currentlyInsurance !== " ");
  result = result * (Tab3_Policycore_Home_Var.interestedParties !== " ");
  result = result * (Tab3_Policycore_Home_Var.svuExcessOption1 !== " ");
  result = result * (Tab3_Policycore_Home_Var.paymentFrequency !== " ");

  if (Tab3_Policycore_Home_Var.buildingOrContents === "Yes") {
    result = result * (Tab3_Policycore_Home_Var.buildingSumInsured !== "");
    result = result * (Tab3_Policycore_Home_Var.buildingSumInsured !== "");
  }

  if (Tab3_Policycore_Home_Var.buildingOrContents === "Yes") {
    result = result * (Tab3_Policycore_Home_Var.contentsSumInsuredAmount !== "");
    result = result * (Tab3_Policycore_Home_Var.contentsSumInsuredAmount !== "");
  }

  if (Tab3_Policycore_Home_Var.conductedFromHome === "Yes") {
    result = result * (Tab3_Policycore_Home_Var.fromHomeBusinessName !== "");
    result = result * (Tab3_Policycore_Home_Var.fromHomeBusinessName !== "");
  }

  if (Tab3_Policycore_Home_Var.conductedFromHome === "Yes") {
    result = result * (Tab3_Policycore_Home_Var.fromHomeAnnualRevenue !== "");
    result = result * (Tab3_Policycore_Home_Var.fromHomeAnnualRevenue !== "");
  }

  if (Tab3_Policycore_Home_Var.paymentFrequency === "Monthly") {
    result = result * (Tab3_Policycore_Home_Var.preferredinstallments !== "Please Select");
    result = result * (Tab3_Policycore_Home_Var.brokerFeeinstallments !== "");
  }

  result =
    result *
    (Tab3_Policycore_Home_Var.buildingSumInsured !== "" &&
      Tab3_Policycore_Home_Var.buildingSumInsured !== " " &&
      Tab3_Policycore_Home_Var.buildingSumInsured !== null);

  result =
    result *
    (Tab3_Policycore_Home_Var.policyToDate !== "" && Tab3_Policycore_Home_Var.policyToDate !== " ");


  result =
    result *
    (Tab3_Policycore_Home_Var.policyFromDate !== "" && Tab3_Policycore_Home_Var.policyFromDate !== " ");

  // result =
  //   result *
  //   (Tab3_Policycore_Home_Var.unspecifiedValues !== "" && Tab3_Policycore_Home_Var.unspecifiedValues !== " ");


  result =
    result *
    (Tab3_Policycore_Home_Var.contentsSumInsuredAmount !== "" &&
      Tab3_Policycore_Home_Var.contentsSumInsuredAmount !== " ");

  // result =
  //   result *
  //   (Tab3_Policycore_Home_Var.brokerFee !== "" && Tab3_Policycore_Home_Var.brokerFee !== " ");

  return result;
};

export const tab3validationHomeedit = (Tab3_Policycore_Home_Var) => {
  let result = true;

  result = result * (Tab3_Policycore_Home_Var.brokerFee !== "" &&
    Tab3_Policycore_Home_Var.brokerFee !== null);

  result = result * (Tab3_Policycore_Home_Var.svuExcessOption2 !== " ");
  result = result * (Tab3_Policycore_Home_Var.svuExcessOption3 !== " ");

  return result;
}

export const buildingSumInsured_validate = (
  value,
  Tab3_Validation_Home_Var,
  setTab3_validation
) => {
  console.log("value" + value);
  if (value === "") {
    setTab3_validation({
      ...Tab3_Validation_Home_Var,
      buildingSumInsured: "Building Sum Insured: must have digits only",
    });
  } else {
    setTab3_validation({
      ...Tab3_Validation_Home_Var,
      buildingSumInsured: "true",
    });
  }
};

export const contentsSumInsuredAmount_validate = (
  value,
  Tab3_Validation_Home_Var,
  setTab3_validation
) => {
  console.log("value" + value);
  if (value === "") {
    setTab3_validation({
      ...Tab3_Validation_Home_Var,
      contentsSumInsuredAmount: "Contents Sum Insured: must have value",
    });
  } else {
    setTab3_validation({
      ...Tab3_Validation_Home_Var,
      contentsSumInsuredAmount: "true",
    });
  }
};

export const fromHomeBusinessName_validate = (
  value,
  Tab3_Validation_Home_Var,
  setTab3_validation
) => {
  console.log("value" + value);
  if (value === "") {
    setTab3_validation({
      ...Tab3_Validation_Home_Var,
      fromHomeBusinessName: "Business Name: must have value",
    });
  } else {
    setTab3_validation({
      ...Tab3_Validation_Home_Var,
      fromHomeBusinessName: "true",
    });
  }
};

export const preferredinstallments_validate = (
  value,
  Tab3_Validation_Home_Var,
  setTab3_validation
) => {
  // console.log("value" + value);
  if (value === "") {
    setTab3_validation({
      ...Tab3_Validation_Home_Var,
      preferredinstallments: "Installment : Must have value",
    });
  } 
  else if(value > 31){
    setTab3_validation({
      ...Tab3_Validation_Home_Var,
      preferredinstallments: "Invalid Number",
    });
  }
  else {
    setTab3_validation({
      ...Tab3_Validation_Home_Var,
      preferredinstallments: "true",
    });
  }
};

export const policyFromDate_validate = (
  value,
  Tab3_Validation_Home_Var,
  setTab3_validation
) => {
  console.log("value" + value);
  if (value === "") {
    setTab3_validation({
      ...Tab3_Validation_Home_Var,
      policyFromDate: "Broker Fee: must have value",
    });
  } else {
    setTab3_validation({
      ...Tab3_Validation_Home_Var,
      policyFromDate: "true",
    });
  }
};

export const policyToDate_validate = (
  value,
  Tab3_Validation_Home_Var,
  setTab3_validation
) => {
  console.log("value" + value);
  if (value === "") {
    setTab3_validation({
      ...Tab3_Validation_Home_Var,
      policyToDate: "Broker Fee: must have value",
    });
  } else {
    setTab3_validation({
      ...Tab3_Validation_Home_Var,
      policyToDate: "true",
    });
  }
};

export const dobOldestInsured_validate = (
  value,
  Tab3_Validation_Home_Var,
  setTab3_validation
) => {
  console.log("value" + value);
  if (value === "") {
    setTab3_validation({
      ...Tab3_Validation_Home_Var,
      dobOldestInsured: "Broker Fee: must have value",
    });
  } else {
    setTab3_validation({
      ...Tab3_Validation_Home_Var,
      dobOldestInsured: "true",
    });
  }
};

export const brokerFee_validate = (
  value,
  Tab3_Validation_Home_Var,
  setTab3_validation
) => {
  console.log("value" + value);
  if (value === "") {
    setTab3_validation({
      ...Tab3_Validation_Home_Var,
      brokerFee: "Broker Fee: must have digits only",
    });
  } else {
    setTab3_validation({
      ...Tab3_Validation_Home_Var,
      brokerFee: "true",
    });
  }
};

export const unspecifiedValues_validate = (
  value,
  Tab3_Validation_Home_Var,
  setTab3_validation
) => {
  console.log("value" + value);
  if (value === "") {
    setTab3_validation({
      ...Tab3_Validation_Home_Var,
      unspecifiedValues: "This Field must select an option",
    });
  } else {
    setTab3_validation({
      ...Tab3_Validation_Home_Var,
      unspecifiedValues: "true",
    });
  }
};

