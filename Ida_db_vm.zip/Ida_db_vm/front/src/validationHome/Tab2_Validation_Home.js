export const Tab2_Validation_Home = (Tab2_Importan_Question_Home_var) => {
    let result = true;

   

      return result;
};
