export const digit_valid_check = {
    digit_valid_checker : /^[0-9]*$/
}

export const char_valid_check = {

    char_valid_checker: /^([A-Za-z])([A-Za-z\s])+$/
}

