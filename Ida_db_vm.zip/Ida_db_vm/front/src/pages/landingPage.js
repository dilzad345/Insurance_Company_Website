import React from 'react'
import "./landingPage.css"

export default function landingPage() {
  return (
   
    // <div className="showcase-area">
    //       <div className="container">
    //         <div className="left">
    //           <div className="big-title">
    //             <h1>Insurance Quotation</h1>
               
    //           </div>
    //           <p className="text">
    //           Please choose the type of Insurance Quotation that you need from the options below
    //           </p>
    //           <div className="cta">
    //             <a href="#/home_client_web_form" className="btn">Home & Contents Insurance</a>
    //             <a href="#/motor_client_web_form" className="btn">Personal Motor Insurance</a>
    //             <a href="#/landlord_client_web_form" className="btn">Landlords Insurance</a>
    //           </div>
    //         </div>

    //         <div className="right">
    //           <img src={require("../images/insure.png")} alt="Insurance" className="insurance" />
    //         </div>
    //       </div>
    //     </div>
    <section className="hero" id="hero">
        <div className="container">

          <div className="hero-content">
            <h1 className="h1 hero-title">Insurance Quotation</h1>

            <p className="hero-text">
            Please choose the type of Insurance Quotation that you need from the options below
            </p>

            <div className="btnGroup">
                 <a href="#/home_client_web_form" className="btnContent">Home & Contents Insurance</a>
                 <a href="#/motor_client_web_form" className="btnContent">Personal Motor Insurance</a>
                 <a href="#/landlord_client_web_form" className="btnContent">Landlords Insurance</a>
              
            </div>

          </div>

          <figure className="hero-banner">
            <img src={require("../images/insure.png")} alt="Insurance"/>
          </figure>

        </div>
      </section>
  )
}
