import React, {
    useState , useContext
} from 'react';
import {
    omit
} from 'lodash';
import {
    AuthContext
} from "../../context/AuthContext";
import { LoginFailure ,LoginSuccess , LoginStart } from '../../context/AuthAction';
import axios from "axios";
import { API } from "../../config";

const useForm = () => {

    //Form values
    const [values, setValues] = useState({});
    //Errors
    const [errors, setErrors] = useState({});

    const { user, dispatch  } = useContext(AuthContext);


    const validate = (event, name, value) => {
        //A function to validate each input values
        switch (name) {

            case 'email':
                if (
                    !new RegExp(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/).test(value)
                ) {
                    setErrors({
                        ...errors,
                        email: 'Enter a valid email address'
                    })
                } else {

                    let newObj = omit(errors, "email");
                    setErrors(newObj);

                }
                break;

            case 'password':
                if ( !new RegExp(/^[0-9]+$/).test(value) ) {
                    setErrors({
                        ...errors,
                        password: 'Password should contains atleast 9 charaters '
                    })
                } else {

                    let newObj = omit(errors, "password");
                    setErrors(newObj);

                }
                break;

            default:
                break;
        }
    }

    //A method to handle form inputs
    const handleChange = (event) => {
        //To stop default events    
        event.persist();

        let name = event.target.name;
        let val = event.target.value;

        validate(event, name, val);
        //Let's set these values in state

        setValues({
            ...values,
            [name]: val,
        })

    }


    const handleSubmit = async (event) => {
        event.preventDefault();

        if (Object.keys(errors).length === 0 && Object.keys(values).length !== 0) {
            // callback();
            dispatch(LoginStart());

            try {
                const res = await axios.post(`${API}/user/signin`, {
                    usermail: values.email,
                    password: values.password,
                });
                const auth = res.data.auth;
                auth ? dispatch(LoginSuccess(res.data)) : setErrors({WrongCredentials : "Please Verify Your Credentials"});
                return auth;
            } 
            catch (err) {
                dispatch(LoginFailure());
            }


        } else {
            // alert("There is an Error!");
            setValues({})
            setErrors({emptyFieldError : "Please enter your credentials"})
        }
    }


    return {
        values,
        errors,
        handleChange,
        handleSubmit
    }
}

export default useForm