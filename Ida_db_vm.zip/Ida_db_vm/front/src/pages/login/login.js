import axios from "axios";
import { API } from "../../config";
import React ,{ useContext, useRef  } from "react";
import { AuthContext } from "../../context/AuthContext";
import useForm from "./useFormHook";
import "./login.css";
import { CircularProgress } from "@material-ui/core";
// import EmailSharp from "@material-ui/icons/EmailSharp";
// import { Mixins } from "@material-ui/core/styles/createMixins";
export default function Login() {
  

const { isFetching } = useContext(AuthContext);
const {handleChange, values,errors,handleSubmit} = useForm();

  return (
    
    <div className="container">
      <div className="containerWrapper">
      <div className="left">
              <img src={require("../../images/avatar.svg")} className="avatar"/>
              <h1 className="loginTitle">Login</h1>
              <form className="loginForm" onSubmit={handleSubmit}>
              
                <input
                id="myText"
                type="text"
                name="email"
                required
                className="loginInput"
                placeholder="Email"
                onChange={handleChange}></input>
         { errors.email && <span className="err">{errors.email}</span>}

         <input
          type="password"
          name="password" 
          required
          className="loginInput"
          placeholder="password"
          onChange={handleChange}
        />
          { errors.password && <span className="err">{errors.password} </span> }
         { errors.emptyFieldError && <span className="err">{errors.emptyFieldError} </span> }
         { errors.WrongCredentials && <span className="err">{errors.WrongCredentials} </span> }
         
         <span className="forgotpassword">Forgot password?</span>
         <button className="loginButton" type="submit" disabled={isFetching}>
           {isFetching ? (<CircularProgress size="20px" color="white"/>) : ("Log In")}
         
         </button>
       </form>
    </div>
           <div className="right">
             <img src={require("../../images/insure.png")} alt="insurance" className="insurance2" />
           </div>
      </div> 
           
    </div>
  );
}