import React, { useState } from "react";
import Tab1_Client from "./Tab1_Client";
import Tab2_ImportantQuestions from "./Tab2_ImportantQuestions";
import Tab3_PolicyCore from "./Tab3_PolicyCore";
import Tab4_vehicle from "./Tab4_Vehicle";
import Tab5_Modifications from "./Tab5_Modifications";
import Tab6_drivers from "./Tab6_Driver";
import Tab7_Claims from "./Tab7_Claims";
import { useStep } from "react-hooks-helper";
import { navigationBar } from "../core/navigationBar";
import { useStateWithCallbackLazy } from "use-state-with-callback";
import { addAllFormsValues, validateAllForms } from "./controller_clientLink";
// import { streetType } from "../constants/dropDownData"
// navigation helper
const steps = [
  { id: "tab1_client" },
  { id: "tab2_importantQuestions" },
  { id: "tab3_policyCore" },
  { id: "tab4_vehicle" },
  { id: "tab5_modifications" },
  { id: "tab6_drivers" },
  { id: "tab7_claims" },
];

const ClientLink = () => {
  //const [ formData, setForm ] = useForm(defaultData);
  const { step, navigation } = useStep({
    steps,
    initialStep: 0,
  }); 

  // tab1 variable object defined
  const [tab1_client, setTab1] = useStateWithCallbackLazy({

    clientType: " ",
    title: " ",
    firstName: "",
    lastName: "",
    companyName: "",
    tradingAs: "",
    officeTechReferenceCode: null,
    unitNumber: null,
    streetNumber: null,
    streetName: "",
    streetType: "Please Select",
    suburb: "",
    state: " ",
    postCode: null,
    phone: "",
    email: null,
    branch: " ",
    salesTeam: " ",
    serviceTeam: " ",

    //branch: "Insurance Brokers Australia",
    // salesTeam: "Chris Dalton",
    // serviceTeam: "Brisbane",

    //set default values
    // clientType: "Individual",
    // title: "Mr",
    // firstName: "John",
    // lastName: "Smith",
    // companyName: "KaayalTek",
    // tradingAs: "Software Solutions",
    // officeTechReferenceCode: "",
    // unitNumber: 111,
    // streetNumber: 18,
    // streetName: "Carver",
    // streetType: "CRESCENT",
    // suburb: "Baulkham Hills",
    // state: "NSW",
    // postCode: '2156',
    // phone: "0117788985",
    // email: "sample@mail.com",
    // branch: "Insurance Brokers Australia",
    // salesTeam: "Chris Dalton",
    // serviceTeam: "Brisbane",
  });

  // tab1 validation
  const [tab1_validation, setTab1_validation] = useState({
    clientType: null,
    title: null,
    firstName: null,
    lastName: null,
    companyName: null,
    tradingAs: null,
    tab1_fullValidation: null,
    streetNumber: "",
    streetName: "",
    streetType: " ",
    suburb: "",
    state: " ",
    postCode: "",
    phone: null,
    email: "",
    branch: "",
    salesTeam: "",
    serviceTeam: "",


  });

  // tab2 variable object defined
  const [tab2_importantQuestions, setTab2] = useStateWithCallbackLazy({
    insurancePolicyCancelledLast_12_months: "No",
    insurancePolicyCancelledLast_5_years: "No",
    hadClaimDeclained: "No",
    reasonClaimDecalined: "",
    maliciousDamage: "No",
    existingDamage: "No",
    wouldAnswerYes: "",
    declaredBankrupt: "No",
    reasonBankrupt: "aaa",
    criminalOffence: "No",
    reasonCriminalOffence: "bbb",
  });

  // tab2 validation
  const [tab2_validation, setTab2_validation] = useState({
    reasonBankrupt: "",
    reasonCriminalOffence: "",
  });

  // let myCurrentDate = new Date();
  // let myFutureDate = new Date(myCurrentDate);
  // let myPastDate = new Date(myCurrentDate);
  // myFutureDate.setDate(myFutureDate.getDate() + 1);
  // myPastDate.setDate(myPastDate.getDate() - 1);

  let myCurrentToDate = new Date();
  myCurrentToDate.setFullYear(myCurrentToDate.getFullYear() + 1);

  // tab3 variable object defined
  const [tab3_policyCore, setTab3] = useStateWithCallbackLazy({

    holdingBroker: " ",
    holdingUnderwriter: " ",
    stampDuty: " ",
    noClaimBonus: " ",
    paymentFrequency: " ",
    preferredInstallments: " ",
    broker_fee_installments: null,
    productType: " ",
    coverType: " ",
    sumInsured: " ",
    agreedValueAmount: null,
    policyFromDate: new Date(),
    policyToDate: myCurrentToDate,
    roadsideAssistance: " ",
    hireCareInclusion: " ",
    windscreenExcessWaiver: " ",
    repairsVehicle: null,
    claimBonusProtection: " ",
    restrictedDriversDiscount: " ",
    namedDriver: " ",
    toolsTrade: " ",
    restrictedDrivers: " ",
    interestedParties: "Please Select",
    occupationPolicyholder: " ",
    commercialPurposesCaravan: " ",
    excessOption1: " ",
    excessOption2: " ",
    excessOption3: " ",
    brokerFee: null,


    // set default values
    // holdingBroker: "No",
    // holdingUnderwriter: "AAMI",
    // stampDuty: "No",
    // noClaimBonus: "60% - Level 1",
    // paymentFrequency: "Yearly",
    // preferredInstallments: "12",
    // broker_fee_installments: "100",
    // productType: "Classic",
    // coverType: "Comprehensive",
    // sumInsured: "Market Value",
    // agreedValueAmount: "200",
    // policyFromDate: new Date(),
    // policyToDate: myCurrentToDate,
    // roadsideAssistance: "No",
    // hireCareInclusion: "No",
    // windscreenExcessWaiver: "No",
    // repairsVehicle: "Insurer Decides",
    // claimBonusProtection: "No",
    // restrictedDriversDiscount: "Insurer Decides",
    // namedDriver: "No",
    // toolsTrade: "Insurer Decides",
    // restrictedDrivers: "hii",
    // interestedParties: "AMP",
    // occupationPolicyholder: "Design",
    // commercialPurposesCaravan: "No",
    // excessOption1: "500",
    // excessOption2: "600",
    // excessOption3: "700",
    // brokerFee: "800",

  });

  const [tab3_validation, setTab3_validation] = useState({
    holdingBroker: " ",
    holdingUnderwriter: " ",
    stampDuty: " ",
    noClaimBonus: " ",
    paymentFrequency: " ",
    preferredInstallments: "",
    broker_fee_installments: "",
    productType: null,
    coverType: " ",
    sumInsured: " ",
    agreedValueAmount: "",
    policyFromDate: "",
    policyToDate: "",
    roadsideAssistance: " ",
    hireCareInclusion: " ",
    windscreenExcessWaiver: " ",
    repairsVehicle: " ",
    claimBonusProtection: " ",
    namedDriver: " ",
    restrictedDriversDiscount: null,
    toolsTrade: " ",
    restrictedDrivers: " ",
    interestedParties: null,
    // otherParty : " ",
    occupationPolicyholder: " ",
    commercialPurposesCaravan: " ",
    excessOption1: " ",
    excessOption2: " ",
    excessOption3: " ",
    brokerFee: "",
  });

  //set max date reduced by 1  for purchase date
  let myCurrentDate = new Date();
  myCurrentDate.setDate(myCurrentDate.getDate() - 1);
  //end of this method

  const [tab4_vehicle, setTab4] = useStateWithCallbackLazy({
    unitNumber: null,
    streetNumber: null,
    streetType: "Please Select",
    streetName: "",
    suburb: "",
    state: " ",
    postCode: null, // 7 variables
    vehicleParkedDay: " ",
    vehicleParkedNight: " ",
    registrationVehicle: "",
    stateIssued : " ",
    vehicleColour: " ",
    vehicleYear: "2010",
    vehicleMake: "",
    vehicleModel: null,
    vehicleType: null,
    securityDeviceFitted: " ", // 7 variables
    similarPowerOfVehicle: " ",
    vehicleUsage: " ",
    numberKMsYear: " ",
    previouslyInsured: " ",
    vehicleUnregistered: " ",
    usedDriver: " ",
    usedHireCar: " ",
    specialisedPaint: " ",
    superCharger: " ",
    hydrogenFuel: " ",
    racingHarnesses: " ",
    vehicleFinanced: " ",
    hailDamage: " ",
    purchaseDate: myCurrentDate, //if giving null as default value the date is getting off by one
    purchasePrice: null, // 15 variables


    //set values
    // unitNumber: "",
    // streetNumber: "18",
    // streetType: "CRESCENT",
    // streetName: "Carver",
    // suburb: "Baulkham Hills",
    // state: "NSW",
    // postCode: "2156", // 7 variables
    // vehicleParkedDay: "Carport",
    // vehicleParkedNight: "Carport",
    // registrationVehicle: "Car",
    // stateIssued : " ",
    // vehicleColour: " ",
    // vehicleYear: "1998",
    // vehicleMake: "Make",
    // vehicleModel: "Model",
    // vehicleType: "Type",
    // securityDeviceFitted: "None", // 7 variables
    // similarPowerOfVehicle: "5 YEARS",
    // vehicleUsage: "Private Use Only",
    // numberKMsYear: "0 - 5000",
    // previouslyInsured: "None",
    // vehicleUnregistered: "No",
    // usedDriver: "No",
    // usedHireCar: "Yes",
    // specialisedPaint: "No",
    // superCharger: "No",
    // hydrogenFuel: "No",
    // racingHarnesses: "No",
    // vehicleFinanced: "No Finance",
    // hailDamage: "No",
    // purchaseDate: myCurrentDate,
    // purchasePrice: null, // 15 variables
  });


  // console.log( new Date(tab4_vehicle.purchaseDate.replace(/-/g, '\/')));
  const [tab4_validation, setTab4_validation] = useState({
    streetNumber: " ",
    streetName: " ",
    streetType: " ",
    suburb: "",
    state: " ",
    postCode: " ",
    registrationVehicle: " ",
    stateIssued : " ",
    vehicleUsage: " ",
    numberKMsYear: " ",
    vehicleParkedNight: " ",
    previouslyInsured: " ",
    vehicleUnregistered: " ",
    usedDriver: " ",
    usedHireCar: " ",
    specialisedPaint: " ",
    superCharger: " ",
    hydrogenFuel: " ",
    racingHarnesses: " ",
    vehicleFinanced: " ",
    hailDamage: " ",
    purchasePrice: " "
  });

  const [tab5_modifications, setTab5] = useStateWithCallbackLazy([]);

  const [tab5_validation, setTab5_validation] = useState([]);

  //set default year reduced by 16 from current year for date of birth
  let tempDate= new Date();
  tempDate.setFullYear(tempDate.getFullYear()-16);
 //end of method , if we setFullYear the date is getting of by 1

  const [tab6_drivers, setTab6] = useStateWithCallbackLazy([
    {
      driverType: "Main",
      firstName: "",
      surName: "",
      gender: " ",
      dateBirth: tempDate, // 7 vars
      driversLicenseObtained: new Date(),
      stateIssued : " ",
      statusDriver: " ",
      demeritPoints3: " ",
      alcoholOffences: " ",
      firstOccurrence1: " ",
      reasonFines: " ", // 6 vars
      licenseSuspensions: " ",
      firstOccurrence2: " ",
      suspension1st: " ",
      suspension2nd: " ",
      suspension3rd: " ",
      numberClaims3: " ", // 6 vars
      accidentClaim: " ",
      firstOccurrence4: " ",
      ownVehicle: " ",
      ownsAnotherVehicle: " ", // 6 vars


      //set default values
      // driverType: "Main",
      // firstName: "John",
      // surName: "Smith",
      // gender: "Male",
      // dateBirth: tempDate, // 7 vars
      // driversLicenseObtained: new Date(),
      // statusDriver: "Employed",
      // demeritPoints3: "0",
      // alcoholOffences: "0",
      // firstOccurrence1: "0",
      // reasonFines: " ", // 6 vars
      // licenseSuspensions: "0",
      // firstOccurrence2: "0",
      // stateIssued: " ",
      // suspension2nd: " ",
      // suspension3rd: " ",
      //  numberClaims3: "0", // 6 vars
      // firstOccurrence3: "0",
      // reasonClaims3: " ",
      // accidentClaim: "0",
      // firstOccurrence4: "0",
      // ownVehicle: "Yes",
      // ownsAnotherVehicle: "Yes",
    },
  ]);

  const [tab6_validation, setTab6_validation] = useState([
    {
      firstName: "",
      surName: "",
      gender: "",
      dateBirth: "",
      driversLicenseObtained: "",
      statusDriver: "",
      demeritPoints3: "",
      alcoholOffences: "",
      firstOccurrence1: "",
      reasonFines: "",
      licenseSuspensions: "",
      firstOccurrence2: "",
      suspension1st: "",
      suspension2nd: "",
      suspension3rd: "",
      numberClaims3: "",
      firstOccurrence3: "",
      reasonClaims3: "",
      accidentClaim: "",
      firstOccurrence4: "",
      ownVehicle: "",
      ownsAnotherVehicle: "",
    },
  ]);

  const [tab7_claims, setTab7] = useStateWithCallbackLazy([
    // {firstOccurrence :" ",
    //   reasonClaims:" "}
  ]);

  const [tab7_validation, setTab7_validation] = useState([
    {
      typeClaim: "",
      dateClaim: "",
      firstOccurrence: "",
      reasonClaims: "",
      description: "",
      claimOutcome: "",
      amount: "",

    },
  ]);

  // submit all forms
  const submitAllForms = () => {
    return addAllFormsValues(

      tab1_client,
      tab2_importantQuestions,
      tab3_policyCore,
      tab4_vehicle,
      tab5_modifications,
      tab6_drivers,
      tab7_claims

    ).then((res) => {
      console.log(res);
      if (res.status === 201) {
        return true;
      } else {
        return false;
      }

    }).catch((error) => {
      console.log(error);
      return false;
    });
  }; // end of submit function

  // validate all forms
  const isAllFormsValid = () => {
    const isValid = validateAllForms(
      tab1_client,
      tab2_importantQuestions,
      tab3_policyCore,
      tab4_vehicle,
      tab5_modifications,
      tab6_drivers,
      tab7_claims
    );
    return isValid;
  };

  // props: tab1, creating props to provide to every tab components
  const props1 = {
    tab1_client,
    setTab1,
    tab1_validation,
    setTab1_validation,
    navigation,
  };
  const props2 = {
    tab2_importantQuestions,
    setTab2,
    tab2_validation,
    setTab2_validation,
    navigation,
  };

  const props3 = {
    tab3_policyCore,
    setTab3,
    tab3_validation,
    setTab3_validation,
    navigation,
  };

  const props4 = {
    tab4_vehicle,
    setTab4,
    tab4_validation,
    setTab4_validation,
    navigation,
  };

  const props5 = {
    tab5_modifications,
    setTab5,
    tab5_validation,
    setTab5_validation,
    navigation,
  };

  const props6 = {
    tab6_drivers,
    setTab6,
    tab6_validation,
    setTab6_validation,
    tab7_claims,
    setTab7,
    tab7_validation,
    setTab7_validation,
    navigation,
  };

  const props7 = {
    tab6_drivers,
    tab7_claims,
    setTab7,
    tab7_validation,
    setTab7_validation,
    isAllFormsValid,
    submitAllForms,
    navigation,
  };

  // return function to display all tabs
  const displayTabs = () => {
    switch (step.id) {
      default:
        return <Tab1_Client {...props1} />;
      case "tab1_client":
        return <Tab1_Client {...props1} />;
      case "tab2_importantQuestions":
        return <Tab2_ImportantQuestions {...props2} />;
      case "tab3_policyCore":
        return <Tab3_PolicyCore {...props3} />;
      case "tab4_vehicle":
        return <Tab4_vehicle {...props4} />;
      case "tab5_modifications":
        return <Tab5_Modifications {...props5} />;
      case "tab6_drivers":
        return <Tab6_drivers {...props6} />;
      case "tab7_claims":
        return <Tab7_Claims {...props7} />;
    }
  };

  // set props to navigation bar
  const propsNavBar = {
    step,
    navigation,
    tab1_client,
    tab2_importantQuestions,
    tab3_policyCore,
    tab4_vehicle,
    tab5_modifications,
    tab6_drivers,
    tab7_claims,
  };

  // render return
  return (
    <div>
      {navigationBar(propsNavBar)}
      {displayTabs()}
    </div>
  );
};

export default ClientLink;
