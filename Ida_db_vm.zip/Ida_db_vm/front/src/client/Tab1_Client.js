import React, { useState } from "react";
// import Footer from "../component/footer/Footer";
import "../css/homeStyle.css";
import {
  TextField,
  Container,
  Button,
  Select,
  InputLabel,
  MenuItem,
  Grid,
} from "@material-ui/core";
import { Autocomplete } from "@mui/material";
import { confirmAlert } from "react-confirm-alert";
import { makeStyles } from "@material-ui/core/styles";
import {
  inpNum,
  validationForSpecialchar,
  validationForAlpha,
  inpTextwithSpace,
  inpTextwithNumSpe,
} from "../constants/validChecker";
import { streetTypes } from "../constants/dropDownData";
// import {} from "../constants/dropDownData"
// import { includes } from 'lodash';
import {
  clientType_validate,
  // title_validate,
  firstName_validate,
  lastName_validate,
  companyName_validate,
  // tradingAs_validate,
  streetNumber_validate,
  streetName_validate,
  streetType_validate,
  suburb_validate,
  state_validate,
  postCode_validate,
  phone_validate,
  email_validate,
  branch_validate,
  salesTeam_validate,
  serviceTeam_validate,
} from "../validations/tab1_validate";
import history from "../auth/history";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    alignContent: "center",
    padding: theme.spacing(2),
    //textAlign: 'center',
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary,
  },
}));

const returnClientHome = () => {
  history.push("/client");
};

// onClick method: exit when clicking exit btn
const exit = () => {
  // console.log(ind);
  // const temp = [...tab5_modifications];
  // const tempValidate = [...tab5_validation];

  confirmAlert({
    title: "Confirm to exit",
    message: "Are you going to exit without saving values?",
    buttons: [
      {
        label: "Yes",
        onClick: () => {
          // removing the element using splice
          // temp.splice(ind, 1);
          // tempValidate.splice(ind, 1);

          // tab5_modifications = temp;
          // tab5_validation = tempValidate;

          // // updating the list
          // setTab5(temp);
          // setTab5_validation(tempValidate);

          returnClientHome();
        },
      },
      {
        label: "No",
        onClick: () => null,
      },
    ],
  });
};
//http://quotes.ibacorp.com.au/#/motor_client_web_form
const Tab1_Client = ({
  tab1_client,
  setTab1,
  tab1_validation,
  setTab1_validation,
  navigation,
}) => {
  const classes = useStyles();

  const onChangeField = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    // console.log("value" + value);
    setTab1(
      {
        ...tab1_client,
        [name]: value,
      },
      () => {
        validationAfterChange(name, value);
      }
    );
  };

  const inpType = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    // const stType = streetTypes.map(data => data.group);
    // console.log(stType.group);
    // console.log(Object.keys.value(streetTypes));
    // if (value.includes(stType[0])) {
    //   console.log("hi");
    // }
    // console.log("value" + value);
    setTab1(
      {
        ...tab1_client,
        [name]: value,
      },
      () => {
        validationAfterChange(name, value);
      }
    );
  };

  //method for not to typing in date field
  // const handleDateChangeRaw = (e) => {
  //   console.log(e);
  //   e.preventDefault();
  // }
  const setStreetType = (val) => {
    // console.log("val", val);
    // console.log(i);
    // console.log(streetType[0]);
    //  let name = e.target.name;
    if (val) {
      let name = "streetType";
      let value = val.group;
      setTab1(
        {
          ...tab1_client,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    } else {
      let name = "streetType";
      let value = " ";
      setTab1(
        {
          ...tab1_client,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    }
  };

  // call validation
  const validationAfterChange = (name, value) => {
    if (name === "clientType") {
      if (tab1_client.clientType === "Company") {
        // tab1_client.title = " ";
        tab1_client.firstName = "";
        tab1_client.lastName = "";
      } else if (tab1_client.clientType === "Individual") {
        tab1_client.companyName = "";
        tab1_client.tradingAs = "";
      }
    }

    switch (name) {
      case "clientType": {
        clientType_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      // case "title": {
      //   title_validate(value, tab1_validation, setTab1_validation);
      //   break;
      // }
      case "firstName": {
        firstName_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "lastName": {
        lastName_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "companyName": {
        companyName_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      // case "tradingAs": {
      //   tradingAs_validate(value, tab1_validation, setTab1_validation);
      //   break;
      // }

      case "streetNumber": {
        streetNumber_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "streetName": {
        // const streetNameTemp = tab1_client.streetName;
        // code to remove last word if it is exist in the street type

        streetName_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "streetType": {
        // console.log(value);
        streetType_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "suburb": {
        suburb_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "state": {
        state_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "postCode": {
        postCode_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "phone": {
        phone_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "email": {
        email_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "branch": {
        branch_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "salesTeam": {
        salesTeam_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "serviceTeam": {
        serviceTeam_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      default: {
        console.log("Not match to condition");
      }
    }
  };
  // console.log(streetType);
  return (
    <div>
      <Container maxWidth="md">
        <div className={classes.root}>
          <Grid
            container
            spacing={3}
            direction="row"
            justifyContent="center"
            alignItems="center"
          >
            <Grid
              item
              xs={12}
              textalign="center"
              justifyContent="center"
              container
            >
              <h3>GENERAL INFORMATION</h3>
            </Grid>

            {/* Clint Type,  xs means gridsize*/}
            <Grid item xs={5} className={classes.bg_color}>
              <InputLabel
                required
                htmlFor="Client Type"
                style={{ marginBottom: "5px" }}
              >
                Client Type
              </InputLabel>
            </Grid>

            <Grid item xs={7} className={classes.bg_color}>
              <Select
                name="clientType"
                margin="none"
                variant="outlined"
                autoComplete="off"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange("clientType", tab1_client.clientType)
                }
                value={tab1_client.clientType}
                style={{ marginBottom: "2px", height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Individual">Individual</MenuItem>
                <MenuItem value="Company">Company</MenuItem>
              </Select>
              {tab1_validation.clientType !== null &&
                tab1_validation.clientType !== "true" && (
                  <div className="text-danger font-italic">
                    {tab1_validation.clientType}
                  </div>
                )}
            </Grid>
            {/* <div style={{ borderTop: "1px solid #000099 ", marginLeft: 20, marginRight: 20, width: '90%' }}></div> */}

            {tab1_client.clientType === "Individual" && (
              <Grid item container xs={12} direction="row" spacing={2}>
                <Grid item xs={5} className={classes.bg_color}>
                  <InputLabel
                    htmlFor="Client Title"
                    style={{ marginBottom: "5px" }}
                    // required
                  >
                    Client Title
                  </InputLabel>
                </Grid>
                <Grid item xs={7} className={classes.bg_color}>
                  <Select
                    margin="none"
                    name="title"
                    variant="outlined"
                    size="small"
                    autoComplete="off"
                    onChange={onChangeField}
                    // onClose={() =>
                    //   validationAfterChange("title", tab1_validation.title)
                    // }
                    value={tab1_client.title}
                    style={{ height: "40px" }}
                    fullWidth
                  >
                    <MenuItem disabled value=" ">
                      Select
                    </MenuItem>
                    <MenuItem value="Mr">Mr</MenuItem>
                    <MenuItem value="Miss">Miss</MenuItem>
                    <MenuItem value="Mrs">Mrs</MenuItem>
                    <MenuItem value="Ms">Ms</MenuItem>
                    <MenuItem value="Dr">Dr</MenuItem>
                  </Select>
                  {/* {tab1_validation.title !== null &&
                  tab1_validation.title !== "true" && (
                    <div className="text-danger font-italic">
                      {tab1_validation.title}
                    </div>
                  )} */}
                </Grid>

                <Grid item xs={5} className={classes.bg_color}>
                  {/* First Name */}
                  <InputLabel
                    htmlFor="First Name"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    First Name
                  </InputLabel>
                </Grid>
                <Grid item xs={7}>
                  <TextField
                    name="firstName"
                    size="small"
                    value={tab1_client.firstName}
                    onChange={onChangeField}
                    variant="outlined"
                    onKeyPress={(e) => validationForAlpha(e)}
                    autoComplete="new-password"
                    // style={{ marginBottom: "20px" }}
                    fullWidth
                  />
                  {tab1_validation.firstName !== null &&
                    tab1_validation.firstName !== "true" && (
                      <div className="text-danger font-italic">
                        {tab1_validation.firstName}
                      </div>
                    )}
                </Grid>

                {/* Last Name */}
                <Grid item xs={5} className={classes.bg_color}>
                  <InputLabel
                    htmlFor="Last Name"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    Last Name
                  </InputLabel>
                </Grid>
                <Grid item xs={7}>
                  <TextField
                    name="lastName"
                    value={tab1_client.lastName}
                    onChange={onChangeField}
                    size="small"
                    variant="outlined"
                    autoComplete="new-password"
                    onKeyPress={(e) => validationForAlpha(e)}
                    fullWidth
                  />
                  {tab1_validation.lastName !== null &&
                    tab1_validation.lastName !== "true" && (
                      <div className="text-danger font-italic">
                        {tab1_validation.lastName}
                      </div>
                    )}
                </Grid>
              </Grid>
            )}

            {tab1_client.clientType === "Company" && (
              <Grid item container xs={12} direction="row" spacing={2}>
                {/* Company Name */}
                <Grid item xs={5} className={classes.bg_color}>
                  <InputLabel
                    htmlFor="Company Name"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    Company Name
                  </InputLabel>
                </Grid>

                <Grid item xs={7}>
                  <TextField
                    name="companyName"
                    value={tab1_client.companyName}
                    onChange={onChangeField}
                    size="small"
                    variant="outlined"
                    autoComplete="new-password"
                    onKeyPress={(e) => validationForSpecialchar(e)}
                    fullWidth
                  />
                  {tab1_validation.companyName !== null &&
                    tab1_validation.companyName !== "true" && (
                      <div className="text-danger font-italic">
                        {tab1_validation.companyName}
                      </div>
                    )}
                </Grid>

                {/* Trading As */}
                <Grid item xs={5} className={classes.bg_color}>
                  <InputLabel
                    htmlFor="Trading As"
                    style={{ marginBottom: "5px" }}
                  >
                    Trading As
                  </InputLabel>
                </Grid>
                <Grid item xs={7}>
                  <TextField
                    name="tradingAs"
                    value={tab1_client.tradingAs}
                    onChange={onChangeField}
                    size="small"
                    variant="outlined"
                    autoComplete="new-password"
                    onKeyPress={(e) => validationForAlpha(e)}
                    fullWidth
                  />
                  {tab1_validation.tradingAs !== null &&
                    tab1_validation.tradingAs !== "true" && (
                      <div className="text-danger font-italic">
                        {" "}
                        {tab1_validation.tradingAs}
                      </div>
                    )}
                </Grid>
              </Grid>
            )}

            {/* office tect reference code */}
            {/* <Grid item xs={5} className={classes.bg_color}>
            <InputLabel
              htmlFor="OfficeTech Reference Code (IBA ONLY)"
              style={{ marginBottom: "5px" }}>
              OfficeTech Reference Code (IBA ONLY)
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              name="officeTechReferenceCode"
              value={tab1_client.officeTechReferenceCode}
              onChange={onChangeField}
              size="small"
              variant="outlined"
              autoComplete="off"
              // style={{ marginBottom: "20px" }}
              fullWidth
            />
          </Grid> */}

            {/* Unit Number */}
            <Grid item xs={5} className={classes.bg_color}>
              <InputLabel
                htmlFor="Unit Number (not req for PO Box)"
                style={{ marginBottom: "5px" }}
              >
                Unit Number (not req for PO Box)
              </InputLabel>
            </Grid>
            <Grid item xs={7}>
              <TextField
                // label="Unit Number (not req for PO Box)"
                name="unitNumber"
                value={tab1_client.unitNumber}
                onChange={onChangeField}
                size="small"
                // type="number"
                // margin="normal"
                variant="outlined"
                autoComplete="off"
                onKeyPress={(e) => validationForSpecialchar(e)}
                fullWidth
              />
            </Grid>

            {/* Street Number */}
            <Grid item xs={5} className={classes.bg_color}>
              <InputLabel
                htmlFor="Street Number (not req for PO Box)"
                style={{ marginBottom: "5px" }}
                required
              >
                Street Number (not req for PO Box)
              </InputLabel>
            </Grid>
            <Grid item xs={7}>
              <TextField
                // label="Street Number (not req for PO Box)"
                name="streetNumber"
                value={tab1_client.streetNumber}
                onChange={onChangeField}
                // margin="normal"
                size="small"
                variant="outlined"
                autoComplete="new-password"
                onKeyPress={(e) => validationForSpecialchar(e)}
                fullWidth
              />
              {tab1_validation.streetNumber !== null &&
                tab1_validation.streetNumber !== "true" && (
                  <div className="text-danger font-italic">
                    {tab1_validation.streetNumber}
                  </div>
                )}
            </Grid>

            
            {/* Street Name */}
            <Grid item xs={5} className={classes.bg_color}>
              <InputLabel
                required
                htmlFor="Street Name"
                style={{ marginBottom: "5px" }}
              >
                Street Name(or PO Box)
              </InputLabel>
            </Grid>
            <Grid item xs={7}>
              <TextField
                // label="Street Name (or PO Box)"
                name="streetName"
                value={tab1_client.streetName}
                onChange={inpType}
                size="small"
                // margin="normal"
                variant="outlined"
                autoComplete="new-password"
                onKeyPress={(e) => inpTextwithSpace(e)}
                fullWidth
              />
              {tab1_validation.streetName !== null &&
                tab1_validation.streetName !== "true" && (
                  <div className="text-danger font-italic">
                    {tab1_validation.streetName}
                  </div>
                )}
            </Grid>
            
          {/* Street Type */}
          <Grid item xs={5} className={classes.bg_color}>
              <InputLabel
                htmlFor="Street Type (not req for PO Box)"
                style={{ marginBottom: "5px" }}
                required
              >
                Street Type (not req for PO Box)
              </InputLabel>
            </Grid>
            <Grid item xs={7}>
              <Autocomplete
                //  disablePortal
                // value={tab1_client.streetType}
                // getOptionSelected={(option, value) => option.value === value.value}
                // isOptionEqualToValue={(option, value) => option.id === value.id}
                options={streetTypes}
                sx={{ width: 1 }}
                isOptionEqualToValue={(option, value) => option.id === value.id}
                getOptionLabel={(option) =>
                  option.group ? option.group : tab1_client.streetType
                }
                defaultValue={" "}
                name="streetType"
                onChange={(event, value) => setStreetType(value)}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant="outlined"
                    fullWidth
                    value={tab1_client.streetType}
                    label="Search / Select"
                    required
                    // required
                    // value={tab1_client.streetType !== null ? tab1_client.streetType :"null"}
                  />
                )}
              />
              {tab1_validation.streetType !== null &&
                tab1_validation.streetType !== "true" && (
                  <div className="text-danger font-italic">
                    {tab1_validation.streetType}
                  </div>
                )}
            </Grid>
            
            {/* Suburb */}
            <Grid item xs={5} className={classes.bg_color}>
              <InputLabel
                required
                htmlFor="Suburb"
                style={{ marginBottom: "5px" }}
              >
                Suburb
              </InputLabel>
            </Grid>
            <Grid item xs={7}>
              <TextField
                // label="Suburb"
                name="suburb"
                value={tab1_client.suburb}
                onChange={onChangeField}
                size="small"
                onKeyPress={(e) => inpTextwithSpace(e)}
                variant="outlined"
                autoComplete="new-password"
                fullWidth
              />
              {tab1_validation.suburb !== null &&
                tab1_validation.suburb !== "true" && (
                  <div className="text-danger font-italic">
                    {tab1_validation.suburb}
                  </div>
                )}
            </Grid>

            {/* State */}
            <Grid item xs={5} className={classes.bg_color}>
              <InputLabel
                required
                htmlFor="State"
                style={{ marginBottom: "5px" }}
              >
                State
              </InputLabel>
            </Grid>
            <Grid item xs={7}>
              <Select
                margin="none"
                variant="outlined"
                autoComplete="off"
                value={tab1_client.state}
                name="state"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange("state", tab1_client.state)
                }
                style={{ height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="QLD">QLD</MenuItem>
                <MenuItem value="NSW">NSW</MenuItem>
                <MenuItem value="VIC">VIC</MenuItem>
                <MenuItem value="SA">SA</MenuItem>
                <MenuItem value="WA">WA</MenuItem>
                <MenuItem value="ACT">ACT</MenuItem>
                <MenuItem value="TAS">TAS</MenuItem>
                <MenuItem value="NT">NT</MenuItem>
              </Select>
              {tab1_validation.state !== null &&
                tab1_validation.state !== "true" && (
                  <div className="text-danger font-italic">
                    {tab1_validation.state}
                  </div>
                )}
            </Grid>

            {/* Post Code */}
            <Grid item xs={5} className={classes.bg_color}>
              <InputLabel
                required
                htmlFor="Post Code"
                style={{ marginBottom: "5px" }}
              >
                Post Code
              </InputLabel>
            </Grid>
            <Grid item xs={7}>
              <TextField
                name="postCode"
                value={tab1_client.postCode}
                onChange={onChangeField}
                size="small"
                // style={{ marginBottom: "20px" }}
                variant="outlined"
                type="number"
                onKeyPress={(e) => inpNum(e)} //to prevent some chars and symbols typing
                autoComplete="new-password"
                fullWidth
              />
              {tab1_validation.postCode !== null &&
                tab1_validation.postCode !== "true" && (
                  <div className="text-danger font-italic">
                    {tab1_validation.postCode}
                  </div>
                )}
            </Grid>

            {/* Phone */}
            <Grid item xs={5} className={classes.bg_color}>
              <InputLabel
                required
                htmlFor="Phone"
                style={{ marginBottom: "5px" }}
              >
                Phone
              </InputLabel>
            </Grid>
            <Grid item xs={7}>
              <TextField
                name="phone"
                value={tab1_client.phone || ""}
                // inputProps={{ inputMode: 'numeric', pattern: '[0-9]*' }}

                onChange={onChangeField}
                size="small"
                style={{ mozAppearance: "none" }}
                variant="outlined"
                type="tel"
                maxLength="10"
                onKeyPress={(e) => inpNum(e)}
                //to prevent some chars and symbols typing
                onWheel={(event) => {
                  event.preventDefault();
                }}
                autoComplete="off"
                inputProps={{ maxLength: 10 }}
                fullWidth
              />
              {tab1_validation.phone !== null &&
                tab1_validation.phone !== "true" && (
                  <div className="text-danger font-italic">
                    {tab1_validation.phone}
                  </div>
                )}
            </Grid>

            {/* E-mail */}
            <Grid item xs={5} className={classes.bg_color}>
              <InputLabel
                required
                htmlFor="E-mail"
                style={{ marginBottom: "5px" }}
              >
                E-mail
              </InputLabel>
            </Grid>
            <Grid item xs={7}>
              <TextField
                // label="E-mail"
                name="email"
                value={tab1_client.email}
                onChange={onChangeField}
                size="small"
                // style={{ marginBottom: "20px" }}
                // margin="normal"
                variant="outlined"
                autoComplete="new-password"
                fullWidth
              />
              {tab1_validation.email !== null &&
                tab1_validation.email !== "true" && (
                  <div className="text-danger font-italic">
                    {/*  {" "} */}
                    {tab1_validation.email}
                  </div>
                )}
            </Grid>

            {/* Branch */}
            {/* <Grid item xs={5} className={classes.bg_color}>
            <InputLabel
              required
              htmlFor="Branch"
              style={{ marginBottom: "5px" }}
            >
              Branch
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="branch"
              value={tab1_client.branch}
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange("branch", tab1_client.branch)
              }
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Insurance Brokers Australia">
                Insurance Brokers Australia
              </MenuItem>
              <MenuItem value="Hayward Insurance Solutions Pty Ltd">
                Hayward Insurance Solutions Pty Ltd
              </MenuItem>
            </Select>
            {tab1_validation.branch !== null &&
              tab1_validation.branch !== "true" && (
                <div className="text-danger font-italic">
                  {tab1_validation.branch}
                </div>
              )}
          </Grid> */}

            {/* Sales Team */}
            {/* <Grid item xs={5} className={classes.bg_color}>
            <InputLabel
              required
              htmlFor="Sales Team"
              style={{ marginBottom: "5px" }}
            >
              Sales Team
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="salesTeam"
              value={tab1_client.salesTeam}
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange("salesTeam", tab1_client.salesTeam)
              }
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Chris Dalton">Chris Dalton</MenuItem>
              <MenuItem value="Gary Hayward">Gary Hayward</MenuItem>
              <MenuItem value="Mark Hayward">Mark Hayward</MenuItem>
              <MenuItem value="GC(Billy)">GC(Billy)</MenuItem>
              <MenuItem value="GC Team">GC Team</MenuItem>
              <MenuItem value="Billy Noke">Billy Noke</MenuItem>
              <MenuItem value="Gerold-Grafton<">Gerold-Grafton</MenuItem>
              <MenuItem value="Gerold-Warwick">Gerold-Warwick</MenuItem>
            </Select>
            {tab1_validation.salesTeam !== null &&
              tab1_validation.salesTeam !== "true" && (
                <div className="text-danger font-italic">
                  {tab1_validation.salesTeam}
                </div>
              )}
          </Grid> */}

            {/* Service Team */}
            {/* <Grid item xs={5} className={classes.bg_color}>
            <InputLabel
              required
              htmlFor="Service Team"
              style={{ marginBottom: "5px" }}
            >
              Service Team
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="serviceTeam"
              value={tab1_client.serviceTeam}
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange("serviceTeam", tab1_client.serviceTeam)
              }
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Brisbane">Brisbane</MenuItem>
              <MenuItem value="Luanne">Luanne</MenuItem>
              <MenuItem value="Michella">Michella</MenuItem>
              <MenuItem value="Patricia">Patricia</MenuItem>
              <MenuItem value="Taryn">Taryn</MenuItem>
            </Select>
            {tab1_validation.serviceTeam !== null &&
              tab1_validation.serviceTeam !== "true" && (
                <div className="text-danger font-italic">
                  {tab1_validation.serviceTeam}
                </div>
              )}
          </Grid> */}

            {/* navigation buttons */}
            <Grid item xs={6}>
              <Button
                variant="contained"
                color="secondary"
                style={{
                  marginTop: "1rem",
                  float: "left",
                  width: "20%",
                }}
                onClick={() => exit()}
              >
                EXIT
              </Button>
            </Grid>

            <Grid item xs={6}>
              <Button
                variant="contained"
                color="primary"
                style={{
                  marginTop: "1rem",
                  float: "right",
                }}
                onClick={() => navigation.next()}
              >
                NEXT
              </Button>
            </Grid>
          </Grid>
        </div>
      </Container>
      {/* <Footer /> */}
    </div>
  );
};

export default Tab1_Client;
