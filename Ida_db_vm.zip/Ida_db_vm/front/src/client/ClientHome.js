import React from "react";
// import { makeStyles } from "@material-ui/core/styles";
import { Link } from "react-router-dom";
import "../css/homeStyle.css";
// import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Navbar } from "react-bootstrap";
import logo from "../images/logo.png";
// import iba_logo from "../images/iba_logo.png";
import { Button } from "@material-ui/core";
// import Footer from "../component/footer/Footer";

const ClientHome = () => {



  

  const clientHomeContent = () => {
    return (
      <div>
      {/* <div className="bg-image">
        <div className="button-style no-deco">
          <div className="caption">
            <h2 className="font-dif1">
              Insurance Quotation
            </h2>
            <p className="p-tag">Please choose the type of insurance quotation that you need from the options below</p>
            <br/>
              <div className="d-flex justify-content-center">
                <div className="p-2 col-example text-left">
                  <Link
                    to={`/home_client_web_form`}
                    style={{ textDecoration: "none" }}
                  >
                    <Button variant="contained" color="primary" size="large">
                      HOME & CONTENTS INSURANCE
                    </Button>
                  </Link>
                  
                </div>
                
                <div className="p-2 col-example text-left">
                <Link
                  to={`/motor_client_web_form`}
                  style={{ textDecoration: "none" }}>
                  <Button variant="contained" color="primary" size="large">
                    Personal Motor Insurance
                  </Button>
                </Link>
              </div>
              <div className="p-2 col-example text-left">
                <Link
                  to={`/landlord_client_web_form`}

                  style={{ textDecoration: "none" }}>
                  <Button variant="contained" color="primary" size="large">
                    Landlords Insurance
                  </Button>
                </Link>
              </div>
              </div>
            </div>
          </div>
        </div>
        <Footer /> */}

      </div>

    );
  };

  return (
    <div>
      {/* {logoBar()} */}
      {clientHomeContent()}
    </div>
  );
};

export default ClientHome;
