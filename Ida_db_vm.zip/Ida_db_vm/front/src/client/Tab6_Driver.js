import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { ToastContainer, toast } from "react-toastify";
// import Footer from "../component/footer/Footer";
import "react-toastify/dist/ReactToastify.css";
import {
  TextField,
  Container,
  Button,
  Select,
  InputLabel,
  MenuItem,
  Grid,
} from "@material-ui/core";
import { validationForAlpha } from "../constants/validChecker";
import DatePicker from "react-datepicker";
import {
  firstName_validate,
  surName_validate,
  gender_validate,
  dob_validate,
  YearAusDrivers_validate,
  statusDriver_validate,
  state_validate,
  demeritPoints3_validate,
  alcoholOffences_validate,
  firstOccurrence1_validate,
  firstOccurrence2_validate,
  reasonFines_validate,
  licenseSuspensions_validate,
  suspension3rd_validate,
  suspension2nd_validate,
  suspension1st_validate,
  numberClaims3_validate,
  // reasonClaims3_validate,
  // firstOccurrence3_validate,
  accidentClaim_validate,
  firstOccurrence4_validate,
  ownVehicle_validate,
  ownsAnotherVehicle_validate,
} from "../validations/tab6_validate";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import history from "../auth/history";

const returnClientHome = () => {
  history.push("/client");
};
// const App =()=> {
//   const [date, setDate] = useState(
//     moment(new Date()).format("YYYY-MM-DD")
//  );
// const currentdate = new Date();
const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    alignContent: "center",
    padding: theme.spacing(2),
    //textAlign: 'center',s
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary,
  },
}));

const notifyDeleteDriver = () =>
  toast.success("Additional Driver Deleted!", {
    position: "bottom-center",
    autoClose: 5000,
    hideProgressBar: true,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
  });

const Tab6_drivers = ({
  tab6_drivers,
  setTab6,
  tab6_validation,
  setTab6_validation,
  tab7_claims,
  setTab7,
  tab7_validation,
  setTab7_validation,
  navigation,
}) => {
  let driverArray = [...tab6_drivers];

  const classes = useStyles();

  // onClick method: exit when clicking exit btn
  const exit = () => {
    // console.log(ind);
    // const temp = [...tab5_modifications];
    // const tempValidate = [...tab5_validation];

    confirmAlert({
      title: "Confirm to exit",
      message: "Are you going to exit without saving values?",
      buttons: [
        {
          label: "Yes",
          onClick: () => {
            // removing the element using splice
            // temp.splice(ind, 1);
            // tempValidate.splice(ind, 1);

            // tab5_modifications = temp;
            // tab5_validation = tempValidate;

            // // updating the list
            // setTab5(temp);
            // setTab5_validation(tempValidate);

            returnClientHome();
          },
        },
        {
          label: "No",
          onClick: () => null,
        },
      ],
    });
  };

  //set default year reduced by 16 from current year for date of birth
  let tempDate = new Date();
  tempDate.setFullYear(tempDate.getFullYear() - 16);
  //end of method , if we setFullYear the date is getting of by 1

  // on click method: add more additional driver details
  const addMore = () => {
    setTab6((tab6_drivers) => [
      ...tab6_drivers,
      {
        driverType: "Additional",
        firstName: "",
        surName: "",
        gender: " ",
        dateBirth: tempDate,
        driversLicenseObtained: new Date(),
        stateIssued : " ",
        statusDriver: " ",
        demeritPoints3: " ",
        alcoholOffences: " ",
        firstOccurrence1: " ",
        reasonFines: " ",
        licenseSuspensions: " ",
        firstOccurrence2: " ",
        suspension1st: " ",
        suspension2nd: " ",
        suspension3rd: " ",
        numberClaims3: " ",
        // firstOccurrence3: "0",
        // reasonClaims3: " ",
        accidentClaim: " ",
        firstOccurrence4: " ",
        ownVehicle: " ",
        ownsAnotherVehicle: " ",
      },
    ]);

    setTab6_validation((tab6_validation) => [
      ...tab6_validation,
      {
        firstName: "",
        surName: "",
        gender: " ",
        dateBirth: "",
        driversLicenseObtained: "",
        stateIssued :"",
        statusDriver: "",
        demeritPoints3: "",
        alcoholOffences: "",
        firstOccurrence1: "",
        reasonFines: "",
        licenseSuspensions: "",
        firstOccurrence2: "",
        suspension1st: "",
        suspension2nd: "",
        suspension3rd: "",
        numberClaims3: "",
        // firstOccurrence3: "",
        // reasonClaims3: "",
        accidentClaim: "",
        firstOccurrence4: "",
        ownVehicle: "",
        ownsAnotherVehicle: "",
      },
    ]);
  };

  // onClick method: delete tab6_validationfication when not needed
  const deleteDriverDetails = (ind) => {
    const temp = [...tab6_drivers];
    const tempValidate = [...tab6_validation];

    confirmAlert({
      title: "Confirm to delete",
      message: "Are you sure to do this?",
      buttons: [
        {
          label: "Yes",
          onClick: () => {
            // removing the element using splice
            temp.splice(ind, 1);
            tempValidate.splice(ind, 1);
            tab6_drivers = temp;
            tab6_validation = tempValidate;

            // updating the list
            setTab6(temp);
            setTab6_validation(tempValidate);
            notifyDeleteDriver();
          },
        },
        {
          label: "No",
          onClick: () => null,
        },
      ],
    });
  };

  // on change method; to change field values according to the changes
  const onChangeField = (ind) => (event) => {
    // driver.firstName
    let name = event.target.name;
    let value = event.target.value;
    // make a copy of original list as temporary list
    let tempArr = [...tab6_drivers];
    let tempObj = tempArr[ind];

    // updating the temporary list
    tempObj = {
      ...tempObj,
      [name]: value,
    };

    // replace the list with temporary list
    tempArr[ind] = tempObj;

    setTab6(tempArr, () => {
      validationAfterChange(ind, name, value, tempArr);
    });
  };

  // method: to changeYearOnly
  const changeYearOnly = (ind) => (date) => {
    const name = "driversLicenseObtained";
    const str_date = date.toLocaleDateString();
    const value = str_date.substring(str_date.length - 4);
    // console.log("date: ", str_date)
    // console.log("date: ", value)

    let tempArr = [...tab6_drivers];
    let tempObj = tempArr[ind];

    // updating the temporary list
    tempObj = {
      ...tempObj,
      [name]: value,
    };

    // replace the list with temporary list
    tempArr[ind] = tempObj;

    setTab6(tempArr, () => {
      validationAfterChange(ind, name, value, tempArr);
    });
  };

  //method for not to typing in date field
  const handleDateChangeRaw = (e) => {
    e.preventDefault();
  };

  const dateBirth = (date, index) => {
    // console.log("dateBirth:", date);
    let name = "dateBirth";
    let value = date;
    // console.log(date.getFullYear()+16);
    // make a copy of original list as temporary list
    let tempArr = [...tab6_drivers];
    let tempObj = tempArr[index];

    // updating the temporary list
    tempObj = {
      ...tempObj,
      [name]: value,
    };

    // replace the list with temporary list
    tempArr[index] = tempObj;

    setTab6(tempArr);
    dob_validate(index, date, tab6_validation, setTab6_validation);
  };

  // modify claim details after changing the number of claim field;
  const modifyClaimDetails = (tempArr) => {
    if (tempArr) {
      setTab7([]);
      tempArr.map((driver, index) => {
        for (let i = 0; i < driver.numberClaims3; i++) {
          setTab7((tab7_claims) => [
            ...tab7_claims,
            {
              typeClaim: " ",
              driver:
                driver.driverType +
                ": " +
                driver.firstName +
                " " +
                driver.surName,
              dateClaim: new Date(),
              description: "",
              claimOutcome: " ",
              amount: "",
              driverIndex: index,
            },
          ]);

          setTab7_validation((tab7_validation) => [
            ...tab7_validation,
            {
              typeClaim: null,
              dateClaim: null,
              description: null,
              claimOutcome: null,
              amount: null,
            },
          ]);
        }
      });
    }
  }; // end of modify claim details

  // call validation
  const validationAfterChange = (index, name, value, tempArr) => {
    let tempObj = tempArr[index];
    if (name === "alcoholOffences") {
      if (value === "0") {
        tempObj = {
          ...tempObj,
          alcoholOffences: "0",
          firstOccurrence1: "0",
          reasonFines: " ",
        };
      }

      tempArr[index] = tempObj;
      setTab6(tempArr);
    } else if (name === "licenseSuspensions") {
      // let tempObj = tempArr[index];
      if (value === "0") {
        tempObj = {
          ...tempObj,
          licenseSuspensions: "0",
          firstOccurrence2: " ",
          suspension1st: " ",
          suspension2nd: " ",
          suspension3rd: " ",
        };
        tempArr[index] = tempObj;
        setTab6(tempArr);
      } else if (value === "1") {
        tempObj = {
          ...tempObj,
          licenseSuspensions: "1",
          suspension2nd: " ",
          suspension3rd: " ",
        };
        tempArr[index] = tempObj;
        setTab6(tempArr);
      } else if (value === "2") {
        tempObj = {
          ...tempObj,
          licenseSuspensions: "2",
          suspension3rd: " ",
        };
        tempArr[index] = tempObj;
        setTab6(tempArr);
      } else if (value === "3") {
        tempObj = {
          ...tempObj,
          licenseSuspensions: "3",
        };
        tempArr[index] = tempObj;
        setTab6(tempArr);
      }
    } else if (name === "accidentClaim") {
      if (value === "0" || value === " ") {
        tempObj = {
          ...tempObj,
          firstOccurrence4: " ",
        };

        tempArr[index] = tempObj;
        setTab6(tempArr);
      }
    } else if (name === "numberClaims3") {
      if (value === "0" || value === " ") {
        tempObj = {
          ...tempObj,
          // firstOccurrence3: " ",
          // reasonClaims3: " ",
        };

        tempArr[index] = tempObj;
        setTab6(tempArr);
      }
    }

    if (name === "numberClaims3") {
      modifyClaimDetails(tempArr);
    }
    switch (name) {
      case "firstName": {
        firstName_validate(index, value, tab6_validation, setTab6_validation);
        break;
      }
      case "surName": {
        surName_validate(index, value, tab6_validation, setTab6_validation);
        break;
      }
      case "gender": {
        gender_validate(index, value, tab6_validation, setTab6_validation);
        break;
      }
      case "dateBirth": {
        // console.log("Date full:"+ value);
        dob_validate(index, value, tab6_validation, setTab6_validation);
        break;
      }
      case "driversLicenseObtained": {
        YearAusDrivers_validate(
          index,
          value,
          tab6_validation,
          setTab6_validation
        );
        break;
      }
      case "stateIssued": {
        state_validate(index ,value, tab6_validation, setTab6_validation);
        break;
      }
      case "statusDriver": {
        statusDriver_validate(
          index,
          value,
          tab6_validation,
          setTab6_validation
        );
        break;
      }
      case "demeritPoints3": {
        demeritPoints3_validate(
          index,
          value,
          tab6_validation,
          setTab6_validation
        );
        break;
      }
      case "alcoholOffences": {
        alcoholOffences_validate(
          index,
          value,
          tab6_validation,
          setTab6_validation
        );
        break;
      }
      case "firstOccurrence1": {
        firstOccurrence1_validate(
          index,
          value,
          tab6_validation,
          setTab6_validation
        );
        break;
      }
      case "reasonFines": {
        reasonFines_validate(index, value, tab6_validation, setTab6_validation);
        break;
      }
      case "licenseSuspensions": {
        licenseSuspensions_validate(
          index,
          value,
          tab6_validation,
          setTab6_validation
        );
        break;
      }

      case "suspension1st": {
        suspension1st_validate(
          index,
          value,
          tab6_validation,
          setTab6_validation
        );
        break;
      }

      case "suspension2nd": {
        suspension2nd_validate(
          index,
          value,
          tab6_validation,
          setTab6_validation
        );
        break;
      }

      case "suspension3rd": {
        suspension3rd_validate(
          index,
          value,
          tab6_validation,
          setTab6_validation
        );
        break;
      }

      case "firstOccurrence2": {
        firstOccurrence2_validate(
          index,
          value,
          tab6_validation,
          setTab6_validation
        );
        break;
      }
      case "numberClaims3": {
        numberClaims3_validate(
          index,
          value,
          tab6_validation,
          setTab6_validation
        );
        break;
      }

      // case "firstOccurrence3": {
      //   firstOccurrence3_validate(
      //     index,
      //     value,
      //     tab6_validation,
      //     setTab6_validation
      //   );
      //   break;
      // }

      // case "reasonClaims3": {
      //   reasonClaims3_validate(
      //     index,
      //     value,
      //     tab6_validation,
      //     setTab6_validation
      //   );
      //   break;
      // }

      case "accidentClaim": {
        accidentClaim_validate(
          index,
          value,
          tab6_validation,
          setTab6_validation
        );
        break;
      }

      case "firstOccurrence4": {
        firstOccurrence4_validate(
          index,
          value,
          tab6_validation,
          setTab6_validation
        );
        break;
      }

      case "ownVehicle": {
        ownVehicle_validate(index, value, tab6_validation, setTab6_validation);
        break;
      }

      case "ownsAnotherVehicle": {
        ownsAnotherVehicle_validate(
          index,
          value,
          tab6_validation,
          setTab6_validation
        );
        break;
      }
      default: {
        console.log("Not match to condition");
      }
    }
  };

  // rendering the ui
  return (
    <div>
      <Container
        maxWidth="md"
        style={{ marginBottom: "20px" }}
        // className="border border-primary"
      >
        <div className={classes.root}>
          {tab6_drivers.map((driver, index) => {
            return (
              <div>
                <Grid
                  key={index}
                  container
                  spacing={3}
                  direction="row"
                  justifyContent="center"
                  alignItems="center"
                >
                  <Grid
                    item
                    xs={12}
                    textalign="center"
                    justifyContent="center"
                    container
                  >
                    <h3>
                      {/* {index + 1}: DRIVERS INFORMATION: {driver.driverType} */}
                      DRIVERS INFORMATION - {driver.driverType}
                    </h3>
                  </Grid>
                  <Grid item xs={6}>
                    <InputLabel htmlFor="First Name" required>
                      First Name
                    </InputLabel>
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      error={
                        tab6_validation[index].firstName !== "true"
                          ? true
                          : false
                      }
                      name="firstName"
                      value={driver.firstName}
                      onChange={onChangeField(index)}
                      variant="outlined"
                      autoComplete="new-password"
                      onKeyPress={(e) => validationForAlpha(e)}
                      placeholder="First name"
                      size="small"
                      fullWidth
                    />
                    {tab6_validation[index].firstName !== null &&
                      tab6_validation[index].firstName !== "true" && (
                        <div className="text-danger font-italic">
                          {tab6_validation[index].firstName}
                        </div>
                      )}
                  </Grid>
                  <Grid item xs={6}>
                    <InputLabel htmlFor="Last Name" required>
                      Last Name
                    </InputLabel>
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      placeholder="Last Name"
                      name="surName"
                      value={driver.surName}
                      onChange={onChangeField(index)}
                      variant="outlined"
                      onKeyPress={(e) => validationForAlpha(e)}
                      autoComplete="new-password"
                      size="small"
                      fullWidth
                    />
                    {tab6_validation[index].surName !== null &&
                      tab6_validation[index].surName !== "true" && (
                        <div className="text-danger font-italic">
                          {tab6_validation[index].surName}
                        </div>
                      )}
                  </Grid>

                  <Grid item xs={6}>
                    <InputLabel htmlFor="Gender" required>
                      Gender
                    </InputLabel>
                  </Grid>
                  <Grid item xs={6}>
                    <Select
                      variant="outlined"
                      autoComplete="off"
                      name="gender"
                      onChange={onChangeField(index)}
                      onClose={() =>
                        validationAfterChange(
                          index,
                          "gender",
                          driver.gender,
                          driverArray
                        )
                      }
                      value={driver.gender}
                      fullWidth
                      style={{ height: "40px" }}
                    >
                      <MenuItem disabled value=" ">
                        Please Select
                      </MenuItem>
                      <MenuItem value="Male">Male</MenuItem>
                      <MenuItem value="Female">Female</MenuItem>
                      <MenuItem value="Not Disclosed">Not Disclosed</MenuItem>
                    </Select>
                    {tab6_validation[index].gender !== null &&
                      tab6_validation[index].gender !== "true" && (
                        <div className="text-danger font-italic">
                          {tab6_validation[index].gender}
                        </div>
                      )}
                  </Grid>
                  <Grid item xs={6}>
                    <InputLabel htmlFor="Date of Birth" required>
                      Date of Birth
                    </InputLabel>
                  </Grid>
                  <Grid item xs={6}>
                    <div>
                      <DatePicker
                        selected={driver.dateBirth}
                        onChange={(date) => dateBirth(date, index)}
                        onChangeRaw={handleDateChangeRaw}
                        dateFormat="dd/MM/yyyy"
                        name="dateBirth"
                        value={driver.dateBirth}
                        className="date-picker-align"
                        yearDropdownItemNumber={100}
                        scrollableYearDropdown={true}
                        showYearDropdown
                        showMonthDropdown
                        dropdownMode="select"
                        maxDate={tempDate}
                        // isClearable
                      />
                    </div>
                  </Grid>

                  <Grid item xs={6}>
                    <InputLabel
                      htmlFor="Year Austalian Driving Licence Optained"
                      required
                    >
                      Year Australian Driving Licence Obtained <br/>and State issued
                    </InputLabel>
                  </Grid>
                  <Grid item xs={3}>
                    <DatePicker
                      name="driversLicenseObtained"
                      value={driver.driversLicenseObtained}
                      // selected={new Date()}
                      selected={new Date(driver.driversLicenseObtained)}
                      minDate={
                        new Date(
                          driver.dateBirth.getFullYear() + 15,
                          driver.dateBirth.getMonth(),
                          driver.dateBirth.getDate()
                        )
                      }
                      // minDate={new Date("2022")}
                      maxDate={new Date()}
                      //onChange={changeYearOnly(index)}
                      className="date-picker-align"
                      onSelect={changeYearOnly(index)}
                      onChangeRaw={handleDateChangeRaw}
                      showYearPicker
                      dateFormat="yyyy"
                    />
                  </Grid>
                  <Grid item xs={3}>
                  <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={driver.stateIssued}
              name="stateIssued"
              onChange={onChangeField(index)}
              onClose={() =>
                validationAfterChange(
                  index,
                  "stateIssued",
                  driver.stateIssued,
                  driverArray
                )
              }
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="QLD">QLD</MenuItem>
              <MenuItem value="NSW">NSW</MenuItem>
              <MenuItem value="VIC">VIC</MenuItem>
              <MenuItem value="SA">SA</MenuItem>
              <MenuItem value="WA">WA</MenuItem>
              <MenuItem value="ACT">ACT</MenuItem>
              <MenuItem value="TAS">TAS</MenuItem>
              <MenuItem value="NT">NT</MenuItem>

            </Select>
            {tab6_validation[index].stateIssued !== null &&
                      tab6_validation[index].stateIssued !== "true" && (
                        <div className="text-danger font-italic">
                          {tab6_validation[index].stateIssued}
                        </div>
                      )}
                  </Grid>
                  
                  <Grid item xs={6}>
                    <InputLabel
                      htmlFor="Employment status of the driver"
                      required
                    >
                      Employment status of the driver
                    </InputLabel>
                  </Grid>
                  <Grid item xs={6}>
                    <Select
                      name="statusDriver"
                      variant="outlined"
                      autoComplete="off"
                      onChange={onChangeField(index)}
                      onClose={() =>
                        validationAfterChange(
                          index,
                          "statusDriver",
                          driver.statusDriver,
                          driverArray
                        )
                      }
                      value={driver.statusDriver}
                      style={{ marginBottom: "2px", height: "40px" }}
                      fullWidth
                    >
                      <MenuItem disabled value=" ">
                        Please Select
                      </MenuItem>
                      <MenuItem value="Employed">Employed</MenuItem>
                      <MenuItem value="full time student">
                        Full time student
                      </MenuItem>
                      <MenuItem value="Home duties">Home duties</MenuItem>
                      <MenuItem value="Retired">Retired</MenuItem>
                      <MenuItem value="Self-Employed">Self-Employed</MenuItem>
                      <MenuItem value="Unemployed">Unemployed</MenuItem>
                    </Select>
                    {tab6_validation[index].statusDriver !== null &&
                      tab6_validation[index].statusDriver !== "true" && (
                        <div className="text-danger font-italic">
                          {tab6_validation[index].statusDriver}
                        </div>
                      )}
                  </Grid>

                  <Grid item xs={6}>
                    <InputLabel
                      htmlFor="Demerit points in last 3 years"
                      required
                    >
                      Demerit points accumulated in the last 3 years
                    </InputLabel>
                  </Grid>
                  <Grid item xs={6}>
                    <Select
                      variant="outlined"
                      name="demeritPoints3"
                      autoComplete="off"
                      onChange={onChangeField(index)}
                      onClose={() =>
                        validationAfterChange(
                          index,
                          "demeritPoints3",
                          driver.demeritPoints3,
                          driverArray
                        )
                      }
                      value={driver.demeritPoints3}
                      style={{ height: "40px" }}
                      fullWidth
                    >
                      <MenuItem disabled value=" ">
                        Please Select
                      </MenuItem>
                      <MenuItem value="0">0</MenuItem>
                      <MenuItem value="1-6">1 - 6</MenuItem>
                      <MenuItem value="7-12">7 - 12</MenuItem>
                      <MenuItem value="1+3">1+3</MenuItem>
                      <MenuItem value="Unsure">Unsure</MenuItem>
                    </Select>
                    {tab6_validation[index].demeritPoints3 !== null &&
                      tab6_validation[index].demeritPoints3 !== "true" && (
                        <div className="text-danger font-italic">
                          {tab6_validation[index].demeritPoints3}
                        </div>
                      )}
                  </Grid>
                  {/* <Grid item xs={6}>
              </Grid> */}
                  <Grid item xs={6}>
                    <InputLabel
                      htmlFor="Convicted, fines or penalties imposed for drug/alcohol offences"
                      required
                    >
                      Convicted, fines or penalties imposed for drug/alcohol
                      offences
                    </InputLabel>
                  </Grid>

                  <Grid item xs={6}>
                    <Select
                      name="alcoholOffences"
                      variant="outlined"
                      autoComplete="off"
                      onChange={onChangeField(index)}
                      onClose={() =>
                        validationAfterChange(
                          index,
                          "alcoholOffences",
                          driver.alcoholOffences,
                          driverArray
                        )
                      }
                      value={driver.alcoholOffences}
                      style={{ height: "40px" }}
                      fullWidth
                    >
                      <MenuItem value=" " disabled>
                        Please select
                      </MenuItem>
                      <MenuItem value="0">No Fines or Penalties</MenuItem>
                      <MenuItem value="1">1</MenuItem>
                      <MenuItem value="2">2</MenuItem>
                      <MenuItem value="3">3</MenuItem>
                    </Select>
                    {tab6_validation[index].alcoholOffences !== null &&
                      tab6_validation[index].alcoholOffences !== "true" && (
                        <div className="text-danger font-italic">
                          {tab6_validation[index].alcoholOffences}
                        </div>
                      )}
                  </Grid>

                  {driver.alcoholOffences !== "0" &&
                    driver.alcoholOffences !== " " && (
                      <Grid container xs={12} direction="row" spacing={2}>
                        <Grid item xs={6}>
                          <InputLabel
                            htmlFor="Years since first occurrence"
                            required
                          >
                            Years since first occurrence-accident
                          </InputLabel>
                        </Grid>
                        <Grid item xs={6}>
                          <Select
                            variant="outlined"
                            name="firstOccurrence1"
                            autoComplete="off"
                            onChange={onChangeField(index)}
                            onClose={() =>
                              validationAfterChange(
                                index,
                                "firstOccurrence1",
                                driver.firstOccurrence1,
                                driverArray
                              )
                            }
                            style={{ marginTop: "10px", height: "40px" }}
                            value={driver.firstOccurrence1}
                            fullWidth
                          >
                            <MenuItem disabled value=" ">
                              Please Select
                            </MenuItem>
                            <MenuItem value="1">1</MenuItem>
                            <MenuItem value="2">2</MenuItem>
                            <MenuItem value="3">3</MenuItem>
                            <MenuItem value="4">4</MenuItem>
                            <MenuItem value="5">5</MenuItem>
                            <MenuItem value="6">6</MenuItem>
                            <MenuItem value="7">7</MenuItem>
                            <MenuItem value="8">8</MenuItem>
                            <MenuItem value="9">9</MenuItem>
                            <MenuItem value="10">10</MenuItem>
                          </Select>
                          {tab6_validation[index].firstOccurrence1 !== null &&
                            tab6_validation[index].firstOccurrence1 !==
                              "true" && (
                              <div className="text-danger font-italic">
                                {tab6_validation[index].firstOccurrence1}
                              </div>
                            )}
                        </Grid>
                        <Grid item xs={6}>
                          <InputLabel
                            htmlFor="Reason for conviction, fines or penalties"
                            required
                          >
                            Reason for conviction, fines or penalties
                          </InputLabel>
                        </Grid>
                        <Grid item xs={6}>
                          <Select
                            variant="outlined"
                            name="reasonFines"
                            autoComplete="off"
                            onChange={onChangeField(index)}
                            onClose={() =>
                              validationAfterChange(
                                index,
                                "reasonFines",
                                driver.reasonFines,
                                driverArray
                              )
                            }
                            value={driver.reasonFines}
                            style={{ height: "40px" }}
                            fullWidth
                          >
                            <MenuItem disabled value=" ">
                              Please Select
                            </MenuItem>
                            <MenuItem value="Speeding">Speeding</MenuItem>
                            <MenuItem value="Driving under the influence - Drugs & Alcohol">
                              Driving under the influence - Drugs & Alcohol
                            </MenuItem>
                            <MenuItem value="Reckless driving">
                              Reckless driving
                            </MenuItem>
                            <MenuItem value="Point accumulation">
                              Point accumulation
                            </MenuItem>
                            <MenuItem value="Other">Other</MenuItem>
                          </Select>
                          {tab6_validation[index].reasonFines !== null &&
                            tab6_validation[index].reasonFines !== "true" && (
                              <div className="text-danger font-italic">
                                {tab6_validation[index].reasonFines}
                              </div>
                            )}
                        </Grid>
                      </Grid>
                    )}

                  <Grid item xs={6}>
                    <InputLabel
                      htmlFor="Number of license suspensions or cancellations in last 3 years"
                      required
                    >
                      Number of license suspensions or cancellations in last 3
                      years
                    </InputLabel>
                  </Grid>
                  <Grid item xs={6}>
                    <Select
                      variant="outlined"
                      name="licenseSuspensions"
                      autoComplete="off"
                      onChange={onChangeField(index)}
                      value={driver.licenseSuspensions}
                      style={{ height: "40px" }}
                      fullWidth
                    >
                      <MenuItem value=" " disabled>
                        Please select
                      </MenuItem>
                      <MenuItem value="0">0</MenuItem>
                      <MenuItem value="1">1</MenuItem>
                      <MenuItem value="2">2</MenuItem>
                      <MenuItem value="3">3</MenuItem>
                    </Select>
                    {tab6_validation[index].licenseSuspensions !== null &&
                      tab6_validation[index].licenseSuspensions !== "true" && (
                        <div className="text-danger font-italic">
                          {tab6_validation[index].licenseSuspensions}
                        </div>
                      )}
                  </Grid>

                  {driver.licenseSuspensions !== "0" && (
                    <Grid item container xs={12} direction="row" spacing={2}>
                      <Grid item xs={6}>
                        <InputLabel
                          htmlFor="Years since first occurrence"
                          required
                        >
                          Years since first occurrence
                        </InputLabel>
                      </Grid>
                      <Grid item xs={6}>
                        <Select
                          variant="outlined"
                          name="firstOccurrence2"
                          autoComplete="off"
                          onChange={onChangeField(index)}
                          onClose={() =>
                            validationAfterChange(
                              index,
                              "firstOccurrence2",
                              driver.firstOccurrence2,
                              driverArray
                            )
                          }
                          value={driver.firstOccurrence2}
                          style={{ height: "40px" }}
                          fullWidth
                        >
                          <MenuItem disabled value=" ">
                            Please Select
                          </MenuItem>
                          <MenuItem value="0">0</MenuItem>
                          <MenuItem value="1">1</MenuItem>
                          <MenuItem value="2">2</MenuItem>
                          <MenuItem value="3">3</MenuItem>
                          <MenuItem value="4">4</MenuItem>
                          <MenuItem value="5">5</MenuItem>
                          <MenuItem value="6">6</MenuItem>
                          <MenuItem value="7">7</MenuItem>
                          <MenuItem value="8">8</MenuItem>
                          <MenuItem value="9">9</MenuItem>
                          <MenuItem value="10">10</MenuItem>
                        </Select>

                        {tab6_validation[index].firstOccurrence2 !== null &&
                          tab6_validation[index].firstOccurrence2 !==
                            "true" && (
                            <div className="text-danger font-italic">
                              {tab6_validation[index].firstOccurrence2}
                            </div>
                          )}
                      </Grid>
                    </Grid>
                  )}

                  {(driver.licenseSuspensions === "1" ||
                    driver.licenseSuspensions === "2" ||
                    driver.licenseSuspensions === "3") && (
                    <Grid
                      container
                      xs={12}
                      direction="row"
                      spacing={2}
                      className="my-2"
                    >
                      <Grid item xs={6}>
                        <InputLabel
                          htmlFor="Reason for 1st suspension or cancellation"
                          required
                        >
                          Reason for 1st suspension or cancellation
                        </InputLabel>
                      </Grid>
                      <Grid item xs={6}>
                        <Select
                          variant="outlined"
                          name="suspension1st"
                          autoComplete="off"
                          onChange={onChangeField(index)}
                          onClose={() =>
                            validationAfterChange(
                              index,
                              "suspension1st",
                              driver.suspension1st,
                              driverArray
                            )
                          }
                          value={driver.suspension1st}
                          style={{ height: "40px" }}
                          fullWidth
                        >
                          <MenuItem disabled value=" ">
                            Please Select
                          </MenuItem>
                          <MenuItem value="Speeding">Speeding</MenuItem>
                          <MenuItem value="Driving under the influence - Drugs & Alcohol">
                            Driving under the influence - Drugs & Alcohol
                          </MenuItem>
                          <MenuItem value="Reckless driving">
                            Reckless driving
                          </MenuItem>
                          <MenuItem value="Point accumulation">
                            Point accumulation
                          </MenuItem>
                          <MenuItem value="Other">Other</MenuItem>
                        </Select>
                        {tab6_validation[index].suspension1st !== null &&
                          tab6_validation[index].suspension1st !== "true" && (
                            <div className="text-danger font-italic">
                              {tab6_validation[index].suspension1st}
                            </div>
                          )}
                      </Grid>
                    </Grid>
                  )}

                  {(driver.licenseSuspensions === "2" ||
                    driver.licenseSuspensions === "3") && (
                    <Grid
                      container
                      xs={12}
                      direction="row"
                      spacing={2}
                      className="my-2"
                    >
                      <Grid item xs={6}>
                        <InputLabel
                          htmlFor="Reason for 2nd suspension or cancellation (leave blank if only 1)"
                          required
                        >
                          Reason for 2nd suspension or cancellation (leave blank
                          if only 1)
                        </InputLabel>
                      </Grid>
                      <Grid item xs={6}>
                        <Select
                          variant="outlined"
                          name="suspension2nd"
                          autoComplete="off"
                          onChange={onChangeField(index)}
                          onClose={() =>
                            validationAfterChange(
                              index,
                              "suspension2nd",
                              driver.suspension2nd,
                              driverArray
                            )
                          }
                          value={driver.suspension2nd}
                          style={{ height: "40px" }}
                          fullWidth
                        >
                          <MenuItem disabled value=" ">
                            Please Select
                          </MenuItem>
                          <MenuItem value="Speeding">Speeding</MenuItem>
                          <MenuItem value="Driving under the influence - Drugs & Alcohol">
                            Driving under the influence - Drugs & Alcohol
                          </MenuItem>
                          <MenuItem value="Reckless driving">
                            Reckless driving
                          </MenuItem>
                          <MenuItem value="Point accumulation">
                            Point accumulation
                          </MenuItem>
                          <MenuItem value="Other">Other</MenuItem>
                        </Select>
                        {tab6_validation[index].suspension2nd !== null &&
                          tab6_validation[index].suspension2nd !== "true" && (
                            <div className="text-danger font-italic">
                              {tab6_validation[index].suspension2nd}
                            </div>
                          )}
                      </Grid>
                    </Grid>
                  )}

                  {driver.licenseSuspensions === "3" && (
                    <Grid
                      container
                      xs={12}
                      direction="row"
                      spacing={2}
                      className="my-2"
                    >
                      <Grid item xs={6}>
                        <InputLabel
                          htmlFor="Reason for 3rd suspension or cancellation (leave blank if only 2)"
                          required
                        >
                          Reason for 3rd suspension or cancellation (leave blank
                          if only 2)
                        </InputLabel>
                      </Grid>
                      <Grid item xs={6}>
                        <Select
                          variant="outlined"
                          name="suspension3rd"
                          autoComplete="off"
                          onChange={onChangeField(index)}
                          onClose={() =>
                            validationAfterChange(
                              index,
                              "suspension3rd",
                              driver.suspension3rd,
                              driverArray
                            )
                          }
                          value={driver.suspension3rd}
                          style={{ height: "40px" }}
                          fullWidth
                        >
                          <MenuItem disabled value=" ">
                            Please Select
                          </MenuItem>
                          <MenuItem value="Speeding">Speeding</MenuItem>
                          <MenuItem value="Driving under the influence - Drugs & Alcohol">
                            Driving under the influence - Drugs & Alcohol
                          </MenuItem>
                          <MenuItem value="Reckless driving">
                            Reckless driving
                          </MenuItem>
                          <MenuItem value="Point accumulation">
                            Point accumulation
                          </MenuItem>
                          <MenuItem value="Other">Other</MenuItem>
                        </Select>
                        {tab6_validation[index].suspension3rd !== null &&
                          tab6_validation[index].suspension3rd !== "true" && (
                            <div className="text-danger font-italic">
                              {tab6_validation[index].suspension3rd}
                            </div>
                          )}
                      </Grid>
                    </Grid>
                  )}

                  <Grid item xs={6}>
                    <InputLabel
                      htmlFor="Number of claims in the last 3 years"
                      required
                    >
                      Number of claims in the last 3 years
                    </InputLabel>
                  </Grid>
                  <Grid item xs={6}>
                    <Select
                      variant="outlined"
                      name="numberClaims3"
                      autoComplete="off"
                      onChange={onChangeField(index)}
                      onClose={() => {
                        validationAfterChange(
                          index,
                          "numberClaims3",
                          driver.numberClaims3,
                          driverArray
                        );
                      }}
                      value={driver.numberClaims3}
                      style={{ height: "40px" }}
                      fullWidth
                    >
                      <MenuItem disabled value=" ">
                        Please Select
                      </MenuItem>
                      <MenuItem value="0">0</MenuItem>
                      <MenuItem value="1">1</MenuItem>
                      <MenuItem value="2">2</MenuItem>
                      <MenuItem value="3">3</MenuItem>
                    </Select>
                    {tab6_validation[index].numberClaims3 !== null &&
                      tab6_validation[index].numberClaims3 !== "true" && (
                        <div className="text-danger font-italic">
                          {tab6_validation[index].numberClaims3}
                        </div>
                      )}
                  </Grid>

                  {/* {(driver.numberClaims3 === "1" ||
                  driver.numberClaims3 === "2" ||
                  driver.numberClaims3 === "3") && (
                    <Grid item container xs={12} direction="row" spacing={2}>
                      <Grid item xs={6}>
                        <InputLabel
                          htmlFor="Years since first occurrence"
                          required
                        >
                          Years since first occurrence
                        </InputLabel>
                      </Grid>
                      <Grid item xs={6}>
                        <Select
                          variant="outlined"
                          name="firstOccurrence3"
                          autoComplete="off"
                          onChange={onChangeField(index)}
                          onClose={() =>
                            validationAfterChange(
                              index,
                              "firstOccurrence3",
                              driver.firstOccurrence3,
                              driverArray
                            )
                          }
                          value={driver.firstOccurrence3}
                          style={{ height: "40px" }}
                          fullWidth
                        >
                          <MenuItem disabled value=" ">
                            Please Select
                          </MenuItem>
                          <MenuItem value="0">0</MenuItem>
                          <MenuItem value="1">1</MenuItem>
                          <MenuItem value="2">2</MenuItem>
                          <MenuItem value="3">3</MenuItem>
                          <MenuItem value="4">4</MenuItem>
                          <MenuItem value="5">5</MenuItem>
                          <MenuItem value="6">6</MenuItem>
                          <MenuItem value="7">7</MenuItem>
                          <MenuItem value="8">8</MenuItem>
                          <MenuItem value="9">9</MenuItem>
                          <MenuItem value="10">10</MenuItem>
                        </Select>
                        {tab6_validation[index].firstOccurrence3 !== null &&
                          tab6_validation[index].firstOccurrence3 !== "true" && (
                            <div className="text-danger font-italic">
                              {tab6_validation[index].firstOccurrence3}
                            </div>
                          )}
                      </Grid>
                      <Grid item xs={6}>
                        <InputLabel
                          htmlFor="Reason for claims in the last 3 years"
                          required
                        >
                          Reason for claims in the last 3 years
                        </InputLabel>
                      </Grid>
                      <Grid item xs={6}>
                        <Select
                          variant="outlined"
                          name="reasonClaims3"
                          autoComplete="off"
                          onChange={onChangeField(index)}
                          onClose={() =>
                            validationAfterChange(
                              index,
                              "reasonClaims3",
                              driver.reasonClaims3,
                              driverArray
                            )
                          }
                          value={driver.reasonClaims3}
                          style={{ height: "40px" }}
                          fullWidth
                        >
                          <MenuItem disabled value=" ">
                            Please Select
                          </MenuItem>
                          <MenuItem value="Speeding">Speeding</MenuItem>
                          <MenuItem value="Driving under the influence - Drugs & Alcohol">
                            Driving under the influence - Drugs & Alcohol
                          </MenuItem>
                          <MenuItem value="Reckless driving">
                            Reckless driving
                          </MenuItem>
                          <MenuItem value="Point accumulation">
                            Point accumulation
                          </MenuItem>
                          <MenuItem value="Other">Other</MenuItem>
                        </Select>
                        {tab6_validation[index].reasonClaims3 !== null &&
                          tab6_validation[index].reasonClaims3 !== "true" && (
                            <div className="text-danger font-italic">
                              {tab6_validation[index].reasonClaims3}
                            </div>
                          )}
                      </Grid>
                    </Grid>
                  )} */}

                  {/* had any accident */}
                  <Grid item xs={6}>
                    <InputLabel
                      htmlFor="Had any accident or claim involving a vehicle"
                      required
                    >
                      Had any accident or claim involving a vehicle
                    </InputLabel>
                  </Grid>
                  <Grid item xs={6}>
                    <Select
                      variant="outlined"
                      name="accidentClaim"
                      autoComplete="off"
                      onChange={onChangeField(index)}
                      onClose={() =>
                        validationAfterChange(
                          index,
                          "accidentClaim",
                          driver.accidentClaim,
                          driverArray
                        )
                      }
                      value={driver.accidentClaim}
                      style={{ height: "40px" }}
                      fullWidth
                    >
                      <MenuItem disabled value=" ">
                        Please Select
                      </MenuItem>
                      <MenuItem value="0">0</MenuItem>
                      <MenuItem value="1">1</MenuItem>
                      <MenuItem value="2">2</MenuItem>
                      <MenuItem value="3">3</MenuItem>
                    </Select>
                    {tab6_validation[index].accidentClaim !== null &&
                      tab6_validation[index].accidentClaim !== "true" && (
                        <div className="text-danger font-italic">
                          {tab6_validation[index].accidentClaim}
                        </div>
                      )}
                  </Grid>

                  {driver.accidentClaim !== "0" &&
                    driver.accidentClaim !== " " && (
                      <Grid item container xs={12} direction="row" spacing={2}>
                        <Grid item xs={6}>
                          <InputLabel
                            htmlFor="Years since first occurrence"
                            required
                          >
                            Years since first occurrence
                          </InputLabel>
                        </Grid>
                        <Grid item xs={6}>
                          <Select
                            variant="outlined"
                            name="firstOccurrence4"
                            autoComplete="off"
                            onChange={onChangeField(index)}
                            onClose={() =>
                              validationAfterChange(
                                index,
                                "firstOccurrence4",
                                driver.firstOccurrence4,
                                driverArray
                              )
                            }
                            value={driver.firstOccurrence4}
                            style={{ height: "40px" }}
                            fullWidth
                          >
                            <MenuItem disabled value=" ">
                              Please Select
                            </MenuItem>
                            <MenuItem value="0">0</MenuItem>
                            <MenuItem value="1">1</MenuItem>
                            <MenuItem value="2">2</MenuItem>
                            <MenuItem value="3">3</MenuItem>
                            <MenuItem value="4">4</MenuItem>
                            <MenuItem value="5">5</MenuItem>
                            <MenuItem value="6">6</MenuItem>
                            <MenuItem value="7">7</MenuItem>
                            <MenuItem value="8">8</MenuItem>
                            <MenuItem value="9">9</MenuItem>
                            <MenuItem value="10">10</MenuItem>
                          </Select>
                          {tab6_validation[index].firstOccurrence4 !== null &&
                            tab6_validation[index].firstOccurrence4 !==
                              "true" && (
                              <div className="text-danger font-italic">
                                {tab6_validation[index].firstOccurrence4}
                              </div>
                            )}
                        </Grid>
                      </Grid>
                    )}
                  <Grid item xs={6}>
                    <InputLabel htmlFor="Owns this vehicle" required>
                      Owns this vehicle
                    </InputLabel>
                  </Grid>
                  <Grid item xs={6}>
                    <Select
                      variant="outlined"
                      name="ownVehicle"
                      onChange={onChangeField(index)}
                      onClose={() =>
                        validationAfterChange(
                          index,
                          "ownVehicle",
                          driver.ownVehicle,
                          driverArray
                        )
                      }
                      autoComplete="off"
                      value={driver.ownVehicle}
                      style={{ height: "40px" }}
                      fullWidth
                    >
                      <MenuItem disabled value=" ">
                        Please Select
                      </MenuItem>
                      <MenuItem value="Yes">Yes</MenuItem>
                      <MenuItem value="No ">No</MenuItem>
                    </Select>

                    {tab6_validation[index].ownVehicle !== null &&
                      tab6_validation[index].ownVehicle !== "true" && (
                        <div className="text-danger font-italic">
                          {tab6_validation[index].ownVehicle}
                        </div>
                      )}
                  </Grid>

                  <Grid item xs={6}>
                    <InputLabel htmlFor="Owns another Vehicle" required>
                      Owns another Vehicle
                    </InputLabel>
                  </Grid>
                  <Grid item xs={6}>
                    <Select
                      variant="outlined"
                      name="ownsAnotherVehicle"
                      onChange={onChangeField(index)}
                      onClose={() =>
                        validationAfterChange(
                          index,
                          "ownsAnotherVehicle",
                          driver.ownsAnotherVehicle,
                          driverArray
                        )
                      }
                      autoComplete="off"
                      value={driver.ownsAnotherVehicle}
                      style={{ height: "40px" }}
                      fullWidth
                    >
                      <MenuItem disabled value=" ">
                        Please Select
                      </MenuItem>
                      <MenuItem value="Yes">Yes</MenuItem>
                      <MenuItem value="No">No</MenuItem>
                    </Select>
                    {tab6_validation[index].ownsAnotherVehicle !== null &&
                      tab6_validation[index].ownsAnotherVehicle !== "true" && (
                        <div className="text-danger font-italic">
                          {tab6_validation[index].ownsAnotherVehicle}
                        </div>
                      )}
                  </Grid>

                  <Grid item xs={12}>
                    {index !== 0 && (
                      <Button
                        onClick={() => deleteDriverDetails(index)}
                        variant="contained"
                        // className="btn bg-warning"
                        color="secondary"
                        style={{
                          float: "right",
                          width: "10%",
                          marginBottom: "10px",
                          // marginTop: "20px",
                          marginLeft: "820px",
                        }}
                      >
                        DELETE
                      </Button>
                    )}
                  </Grid>

                  <div
                    style={{
                      borderTop: "3px solid green",
                      // marginLeft: 10,
                      // marginTop: 5,
                      marginBottom: 20,
                      width: "100%",
                    }}
                  ></div>
                </Grid>
              </div>
            );
          })}

          <Button
            variant="outlined"
            color="default"
            className="border bg-success text-white"
            style={{
              marginTop: "1rem",
              float: "right",
              marginLeft: "300px",
              marginRight: "300px",
            }}
            onClick={addMore}
          >
            ADD ANOTHER
          </Button>
          <div style={{ marginBottom: "5rem" }}>
            <Grid>
              <Button
                variant="contained"
                color="secondary"
                style={{
                  marginTop: "1rem",
                  float: "left",
                  width: "10%",
                }}
                onClick={() => exit()}
              >
                EXIT
              </Button>
            </Grid>

            <Button
              variant="contained"
              color="primary"
              style={{
                marginTop: "1rem",
                float: "right",
                marginBottom: "20px",
                width: "10%",
              }}
              onClick={() => navigation.next()}
            >
              NEXT
            </Button>

            <Button
              variant="contained"
              color="primary"
              style={{
                marginTop: "1rem",
                marginBottom: "20px",
                float: "right",
                marginRight: "20px",
                width: "10%",
              }}
              onClick={() => navigation.previous()}
            >
              PREVIOUS
            </Button>
          </div>
        </div>
        <ToastContainer
          style={{ marginLeft: "50px", marginBottom: "-25px", width: "30%" }}
        />
      </Container>
      {/* <Footer /> */}
    </div>
  );
};

export default Tab6_drivers;
