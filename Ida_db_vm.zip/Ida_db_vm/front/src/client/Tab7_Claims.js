import React, { useEffect, useState } from "react";
import { Redirect } from "react-router-dom";
// import Footer from "../component/footer/Footer";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { inpNum } from "../constants/validChecker";
import {
  TextField,
  Container,
  Button,
  Select,
  InputLabel,
  MenuItem,
  Grid,
  Dialog,
  DialogTitle,
  List,
  ListItem,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import InputAdornment from "@material-ui/core/InputAdornment";
import {
  typeClaim_validate,
  dateClaim_validate,
  firstOccurrence_validate,
  reasonClaim_validate,
  description_validate,
  claimOutcome_validate,
  amount_validate,
} from "../validations/tab7_validate";
import history from "../auth/history";
import DatePicker from "react-datepicker";
import { confirmAlert } from "react-confirm-alert";
const returnClientHome = () => {
  history.push("/client");
};

function SimpleDialog(props) {
  const { onClose, selectedValue, open } = props;

  const handleClose = () => {
    onClose(selectedValue);
  };
  const handleListItemClick = (value) => {
    onClose(value);
  };

  return (
    <Dialog onClose={handleClose} open={open}>
      <DialogTitle>Do You Want Submit</DialogTitle>
      <List>
        <ListItem button onClick={() => handleListItemClick("test")}>
          Yes
        </ListItem>
        <ListItem button onClick={() => handleListItemClick("test")}>
          No
        </ListItem>
      </List>
    </Dialog>
  );
}

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    alignContent: "center",
    padding: theme.spacing(2),
    //textAlign: 'center',
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary,
  },
}));

const Tab7_Claims = ({
  tab6_drivers,
  tab7_claims,
  setTab7,
  tab7_validation,
  setTab7_validation,
  isAllFormsValid,
  submitAllForms,
  navigation,
}) => {
  const classes = useStyles();
  const [loaded, setLoad] = useState(false);
  const [loadClientHome, setLoadClientHome] = useState(false);

  useEffect(() => {
    if (!loaded) {
      setLoad(true);
      tab6_drivers.map((driver, index) => {
        for (let i = 0; i < driver.numberClaims3.toString(); i++) {}
      });
    }
  });

  const notify = () =>
    toast.success("Submission Status: Success!", {
      position: "bottom-center",
      autoClose: 1000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });

  const notifyFailure = () =>
    toast.error("Submission Status: Failed!", {
      position: "bottom-center",
      autoClose: 1000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });

  // onClick method: exit when clicking exit btn
  const exit =() =>{
    confirmAlert({
      title: "Confirm to exit",
      message: "Are you going to exit without saving values?",
      buttons: [
        {
          label: "Yes",
          onClick: () => {
            // removing the element using splice
            // temp.splice(ind, 1);
            // tempValidate.splice(ind, 1);

            // tab5_modifications = temp;
            // tab5_validation = tempValidate;

            // // updating the list
            // setTab5(temp);
            // setTab5_validation(tempValidate);

            returnClientHome();
          },
        },
        {
          label: "No",
        onClick: () => null,
        }
      ],
    })
  }
  // const exit = () => {
  //   confirmAlert({
  //     title: "Confirm to exit",
  //     message: "Are you going to exit without saving values?",
  //     buttons: [
  //       {
  //         label: "Yes",
  //         onClick: () => {
  //           // removing the element using splice
  //           // temp.splice(ind, 1);
  //           // tempValidate.splice(ind, 1);

  //           // tab5_modifications = temp;
  //           // tab5_validation = tempValidate;

  //           // // updating the list
  //           // setTab5(temp);
  //           // setTab5_validation(tempValidate);

  //           returnClientHome();
  //         },
  //       }]
  //     {
  //       label: "No",
  //       onClick: () => null,
  //     },
  //   })};


//method for submitting quotation
  const handleSubmit = () => {
    submitAllForms()
      .then((res) => {
        // console.log(res);
        if (res === true) {
          notify();
          setTimeout(function () {
            setLoadClientHome(true);
          }, 1000);
          // console.log("set load home page: " + res);
          // setLoadClientHome(true); // change to true to redirect to the client home page
        } else if (res === false) {
          notifyFailure();
          setTimeout(function () {
            setLoadClientHome(true);
          }, 1000);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const loadClientHomePage = () => {
    if (loadClientHome) {
      return <Redirect to="/client" />;
    }
  };

  // on change method; to change field values according to the changes
  const onChangeField = (ind) => (event) => {
    // console.log(event.target.value);
    let name = event.target.name;
    let value = event.target.value;
    // console.log(value)
    // make a copy of original list as temporary list
    let tempArr = [...tab7_claims];
    let tempObj = tempArr[ind];

    // updating the temporary list
    tempObj = {
      ...tempObj,
      [event.target.name]: event.target.value,
    };

    // replace the list with temporary list
    tempArr[ind] = tempObj;

    setTab7(tempArr, () => {
      validationAfterChange(ind, name, value);
    });
  };

  //onchange method for description
  // const onChangeFieldDes = (ind) => (event) => {
  //   // console.log(event.target.value);
  //   let name = event.target.name;
  //   let value = event.target.value;
  //   console.log(value)
  //   // make a copy of original list as temporary list
  //   let tempArr = [...tab7_claims];
  //   let tempObj = tempArr[ind];

  //   // updating the temporary list
  //   tempObj = {
  //     ...tempObj,
  //     [event.target.name]: event.target.value,
  //   };

  //   // replace the list with temporary list
  //   tempArr[ind] = tempObj;

  //   setTab7(tempArr, () => {
  //     validationAfterChange(ind, name, value);
  //   });
  // };

  //method for not to typing in date field
  const handleDateChangeRaw = (e) => {
    e.preventDefault();
  };
  // method: to update policy date from to variable
  const dateClaim = (date, index) => {
    // console.log(tab7_claims.dateClaim);
    // console.log(date);
    // setTab7({
    //   ...tab7_claims,
    //   dateClaim: date,

    // });
    let name = "dateClaim";
    let value = date;
    // make a copy of original list as temporary list
    let tempArr = [...tab7_claims];
    let tempObj = tempArr[index];

    // updating the temporary list
    tempObj = {
      ...tempObj,
      [name]: date,
    };
    // console.log(tab7_claims[index].description)
    // replace the list with temporary list
    tempArr[index] = tempObj;

    setTab7(tempArr);
    dateClaim_validate(index, date, tab7_validation, setTab7_validation);
  };
  // call validation
  const validationAfterChange = (index, name, value) => {
    //1st select other as reasonclaims and type in description field
    // then select another option description eventually field will be empty
    if (name === "reasonClaims") {
      // console.log("hi description");
      if (tab7_claims[index].description !== "Other") {
        tab7_claims[index].description = "";
      }
    }

    switch (name) {
      case "typeClaim": {
        typeClaim_validate(index, value, tab7_validation, setTab7_validation);
        break;
      }
      case "dateClaim": {
        dateClaim_validate(index, value, tab7_validation, setTab7_validation);
        break;
      }
      case "firstOccurrence": {
        firstOccurrence_validate(
          index,
          value,
          tab7_validation,
          setTab7_validation
        );
        break;
      }
      case "reasonClaims": {
        reasonClaim_validate(index, value, tab7_validation, setTab7_validation);
        break;
      }
      case "description": {
        description_validate(index, value, tab7_validation, setTab7_validation);
        break;
      }
      case "claimOutcome": {
        claimOutcome_validate(
          index,
          value,
          tab7_validation,
          setTab7_validation
        );
        break;
      }
      case "amount": {
        amount_validate(index, value, tab7_validation, setTab7_validation);
        break;
      }
      default: {
        console.log("Not match to condition");
      }
    }
  };

  // Dialog Box Testing

  const [open, setOpen] = React.useState(false);
  const [selectedValue, setSelecteValue] = React.useState("");

  // const handleClickOpen = () => {
  //   setOpen(true);
  // };

  const handleClose = (value) => {
    setOpen(false);
    setSelecteValue(value);
  };

  // const loadClientHomePage= () => {​
  // if (loadClientHome) {​
  // return <Redirectto='/client_home'/>
  //     }​
  //   }​

  // const loadClientHomePage = () => {
  //   if(loadClientHome){
  //     return <Redirect to='/client_home' />
  //   }
  // }

  // display render element
  const displayTab7 = () => {
    return (
      <div>
        <Container maxWidth="md" style={{ marginBottom: "50px" }}>
          <div className={classes.root}>
            <Grid
              container
              spacing={3}
              direction="row"
              justifyContent="center"
              alignItems="center"
            >
              <Grid
                item
                xs={12}
                alignItems="center"
                justifyContent="center"
                container
              >
                <h3>CLAIMS INFORMATION</h3>
              </Grid>

              {tab7_claims.map((claim, index) => {
                return (
                  <Grid
                    container
                    direction="row"
                    key={index}
                    style={{ marginBottom: "50px" }}
                    // className="border my-2 border-primary"
                  >
                    {/* Type of claim */}
                    <Grid item xs={4}>
                      <InputLabel htmlFor="Type of claim" required>
                        Type of claim
                      </InputLabel>
                    </Grid>
                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <Select
                        margin="none"
                        variant="outlined"
                        autoComplete="off"
                        name="typeClaim"
                        onChange={onChangeField(index)}
                        onClose={() =>
                          validationAfterChange(
                            index,
                            "typeClaim",
                            claim.typeClaim
                          )
                        }
                        value={claim.typeClaim}
                        style={{ height: "40px" }}
                        fullWidth
                      >
                        <MenuItem disabled value=" ">
                          Please Select
                        </MenuItem>
                        <MenuItem value="Bushfire">Bushfire</MenuItem>
                        <MenuItem value="Collision at fault">
                          Collision at fault
                        </MenuItem>
                        <MenuItem value="Collision not at fault">
                          Collision not at fault
                        </MenuItem>
                        <MenuItem value="Damage while parked">
                          Damage while parked
                        </MenuItem>
                        <MenuItem value="Flood">Flood</MenuItem>
                        <MenuItem value="Hail">Hail</MenuItem>
                        <MenuItem value="Other">Other</MenuItem>
                        <MenuItem value="Single vehicle accident">
                          Single vehicle accident
                        </MenuItem>
                        <MenuItem value="Storm">Storm</MenuItem>
                        <MenuItem value="Theft">Theft</MenuItem>
                        <MenuItem value="Vandalism or Malicios damage">
                          Vandalism or Malicios damage
                        </MenuItem>
                        <MenuItem value="Windscreen">Windscreen</MenuItem>
                      </Select>
                      {tab7_validation[index].typeClaim !== null &&
                        tab7_validation[index].typeClaim !== "true" && (
                          <div className="text-danger font-italic">
                            {tab7_validation[index].typeClaim}
                          </div>
                        )}
                    </Grid>

                    {/* Driver */}
                    <Grid item xs={4}>
                      <InputLabel htmlFor="Driver" required>
                        Driver
                      </InputLabel>
                    </Grid>
                    <Grid item xs={8}>
                      <TextField
                        disabled
                        name="driver"
                        value={claim.driver}
                        // onChange={onChangeField(index)}
                        size="small"
                        variant="outlined"
                        autoComplete="off"
                        style={{ marginBottom: "20px" }}
                        fullWidth
                      />
                    </Grid>

                    {/* Date of claim */}
                    <Grid item xs={4}>
                      <InputLabel htmlFor="Date of claim" required>
                        Date of claim
                      </InputLabel>
                    </Grid>
                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <div>
                        <DatePicker
                          selected={claim.dateClaim}
                          onChange={(date) => dateClaim(date, index)}
                          dateFormat="dd/MM/yyyy"
                          name="dateClaim"
                          maxDate={new Date()}
                          value={claim.dateClaim}
                          onChangeRaw={handleDateChangeRaw}
                          className="date-picker-align"
                          // style={{ marginBottom: "10px", width:"50px"}}
                          // variant="outlined"
                          // autoComplete="off"
                          // fullWidth
                        />
                      </div>

                      {/* {tab7_validation[index].dateClaim !== null &&
                      tab7_validation[index].dateClaim !== "true" && (
                        <div className="text-danger font-italic">
                          {tab7_validation[index].dateClaim}
                        </div>
                      )} */}
                    </Grid>

                    {/* years since first occurence */}
                    <Grid item xs={4}>
                      <InputLabel
                        htmlFor="Years since first occurrence"
                        required
                      >
                        Years since first occurrence
                      </InputLabel>
                    </Grid>
                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <Select
                        margin="none"
                        variant="outlined"
                        name="firstOccurrence"
                        autoComplete="off"
                        onChange={onChangeField(index)}
                        defaultValue={"Please Select"}
                        onClose={() =>
                          validationAfterChange(
                            index,
                            "firstOccurrence",
                            claim.firstOccurrence
                          )
                        }
                        value={
                          claim.firstOccurrence
                            ? claim.firstOccurrence
                            : "Please Select"
                        }
                        style={{ height: "40px" }}
                        fullWidth
                      >
                        <MenuItem disabled value="Please Select">
                          Please Select
                        </MenuItem>
                        <MenuItem value="0">0</MenuItem>
                        <MenuItem value="1">1</MenuItem>
                        <MenuItem value="2">2</MenuItem>
                        <MenuItem value="3">3</MenuItem>
                        <MenuItem value="4">4</MenuItem>
                        <MenuItem value="5">5</MenuItem>
                        <MenuItem value="6">6</MenuItem>
                        <MenuItem value="7">7</MenuItem>
                        <MenuItem value="8">8</MenuItem>
                        <MenuItem value="9">9</MenuItem>
                        <MenuItem value="10">10</MenuItem>
                      </Select>
                      {tab7_validation[index].firstOccurrence !== null &&
                        tab7_validation[index].firstOccurrence ===
                          "undefined" &&
                        tab7_validation[index].firstOccurrence !== "true" && (
                          <div className="text-danger font-italic">
                            {tab7_validation[index].firstOccurrence}
                          </div>
                        )}
                    </Grid>

                    {/* Reason for claims in the last 3 years */}
                    <Grid item xs={4}>
                      <InputLabel
                        htmlFor="Reason for claims in the last 3 years"
                        required
                      >
                        Reason for claims in the last 3 years
                      </InputLabel>
                    </Grid>
                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <Select
                        variant="outlined"
                        name="reasonClaims"
                        autoComplete="off"
                        onChange={onChangeField(index)}
                        onClose={() =>
                          validationAfterChange(
                            index,
                            "reasonClaims",
                            claim.reasonClaims
                          )
                        }
                        defaultValue={"Please Select"}
                        value={
                          claim.reasonClaims
                            ? claim.reasonClaims
                            : "Please Select"
                        }
                        style={{ height: "40px" }}
                        fullWidth
                      >
                        <MenuItem disabled value="Please Select">
                          Please Select
                        </MenuItem>
                        
                        <MenuItem value="Bushfire">Bushfire</MenuItem>
                        <MenuItem value="Collision at fault">
                          Collision at fault
                        </MenuItem>
                        <MenuItem value="Collision not at fault">
                          Collision not at fault
                        </MenuItem>
                        <MenuItem value="Damage while parked">
                          Damage while parked
                        </MenuItem>
                        <MenuItem value="Flood">Flood</MenuItem>
                        <MenuItem value="Hail">Hail</MenuItem>
                        <MenuItem value="Single vehicle accident">
                          Single vehicle accident
                        </MenuItem>
                        <MenuItem value="Storm">Storm</MenuItem>
                        <MenuItem value="Vandalism or Malicious damage">
                          Vandalism or Malicious damage
                        </MenuItem>
                        <MenuItem value="Windscreen">Windscreen</MenuItem>
                        <MenuItem value="Other">Other</MenuItem>
                      </Select>
                      {tab7_validation[index].reasonClaims !== null &&
                        tab7_validation[index].reasonClaims === "undefined" &&
                        tab7_validation[index].reasonClaims !== "true" && (
                          <div className="text-danger font-italic">
                            {tab7_validation[index].reasonClaims}
                          </div>
                        )}
                    </Grid>

                    {/* Description */}
                    {claim.reasonClaims === "Other" && (
                      <Grid
                        item
                        xs={12}
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                        }}
                      >
                        <InputLabel htmlFor="Description" required>
                          Description
                        </InputLabel>
                        <Grid item xs={8} style={{ marginBottom: "20px" }}>
                          <TextField
                            name="description"
                            value={claim.description}
                            onChange={onChangeField(index)}
                            size="small"
                            variant="outlined"
                            autoComplete="off"
                            // style={{ marginBottom: "20px" }}
                            fullWidth
                          />
                          {tab7_validation[index].description !== null &&
                            tab7_validation[index].description !== "true" && (
                              <div className="text-danger font-italic">
                                {tab7_validation[index].description}
                              </div>
                            )}
                        </Grid>
                      </Grid>
                    )}

                    

                    {/* Claim Outcome */}
                    <Grid item xs={4}>
                      <InputLabel htmlFor="Claim Outcome" required>
                        Claim Outcome
                      </InputLabel>
                    </Grid>
                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <Select
                        margin="none"
                        variant="outlined"
                        autoComplete="off"
                        name="claimOutcome"
                        onChange={onChangeField(index)}
                        onClose={() =>
                          validationAfterChange(
                            index,
                            "claimOutcome",
                            claim.claimOutcome
                          )
                        }
                        value={claim.claimOutcome}
                        style={{ height: "40px" }}
                        fullWidth
                      >
                        <MenuItem disabled value=" ">
                          Please Select
                        </MenuItem>
                        <MenuItem value="Claim lodged, result pending">
                          Claim lodged, result pending
                        </MenuItem>
                        <MenuItem value="Claim paid">Claim paid</MenuItem>
                        <MenuItem value="Claim rejected">
                          Claim rejected
                        </MenuItem>
                        <MenuItem value="Insurance Cancelled">
                          Insurance Cancelled
                        </MenuItem>
                        <MenuItem value="Insurance Declined">
                          Insurance Declined
                        </MenuItem>
                        <MenuItem value="Insurance Refused">
                          Insurance Refused
                        </MenuItem>
                        <MenuItem value="No claim bonus reduced">
                          No claim bonus reduced
                        </MenuItem>
                        <MenuItem value="No claim bonus removed">
                          No claim bonus removed
                        </MenuItem>
                        <MenuItem value="No claim lodged">
                          No claim lodged
                        </MenuItem>
                        <MenuItem value="Special Items Imposed">
                          Special Items Imposed
                        </MenuItem>
                      </Select>
                      {tab7_validation[index].claimOutcome !== null &&
                        tab7_validation[index].claimOutcome !== "true" && (
                          <div className="text-danger font-italic">
                            {tab7_validation[index].claimOutcome}
                          </div>
                        )}
                    </Grid>

                    {/* Amount */}
                    <Grid item xs={4}>
                      <InputLabel htmlFor="Amount" required>
                        Amount
                      </InputLabel>
                    </Grid>
                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <TextField
                        name="amount"
                        value={claim.amount}
                        onChange={onChangeField(index)}
                        size="small"
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">$</InputAdornment>
                          ),
                        }}
                        type="number"
                        variant="outlined"
                        autoComplete="off"
                        onKeyPress={(e) => inpNum(e)}
                        // style={{ marginBottom: "20px" }}
                        fullWidth
                      />
                      {tab7_validation[index].amount !== null &&
                        tab7_validation[index].amount !== "true" && (
                          <div className="text-danger font-italic">
                            {tab7_validation[index].amount}
                          </div>
                        )}
                    </Grid>
                    <div
                      style={{
                        borderTop: "3px solid green ",
                        // marginLeft: 10,
                        marginTop: 5,
                        width: "100%",
                      }}
                    ></div>
                  </Grid>
                );
              })}
              {tab7_claims.length === 0 && (
                <Grid item xs={12}>
                  <div className="alert alert-info">
                    No claim are provided in the driver page
                  </div>
                </Grid>
              )}

              <SimpleDialog
                selectedValue={selectedValue}
                open={open}
                onClose={handleClose}
              />
            </Grid>
            <div style={{ marginBottom: "13.8rem" }}>
              <Grid>
                {isAllFormsValid() ? (
                  <Button
                    variant="contained"
                    className="bg-warning"
                    style={{
                      marginTop: "1rem",
                      float: "right",
                      marginBottom: "50px",
                    }}
                    onClick={handleSubmit}
                  >
                    SUBMIT
                  </Button>
                ) : (
                  <Button
                    variant="contained"
                    className="bg-alert"
                    style={{
                      marginTop: "1rem",
                      float: "right",
                      marginBottom: "50px",
                    }}
                    disabled
                  >
                    SUBMIT
                  </Button>
                )}
                <ToastContainer
                  style={{
                    marginLeft: "50px",
                    marginBottom: "-25px",
                    width: "30%",
                  }}
                />
              </Grid>

              <Grid>
                <Button
                  variant="contained"
                  color="secondary"
                  style={{
                    marginTop: "1rem",
                    float: "left",
                    width: "10%",
                  }}
                  onClick={() => exit()}
                >
                  EXIT
                </Button>
              </Grid>

              <Grid>
                <Button
                  variant="contained"
                  color="primary"
                  style={{
                    marginTop: "1rem",
                    float: "right",
                    marginBottom: "50px",
                    marginRight: "20px",
                    width: "10%",
                  }}
                  onClick={() => navigation.previous()}
                >
                  PREVIOUS
                </Button>
              </Grid>
            </div>
          </div>
        </Container>
        {/* <Footer /> */}
      </div>
    );
  };

  return (
    <div>
      {displayTab7()}
      {loadClientHomePage()}
    </div>
  );
};

export default Tab7_Claims;
