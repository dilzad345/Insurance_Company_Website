import React, { useState } from "react";
// import Footer from "../component/footer/Footer";
import {
  TextField,
  Container,
  Button,
  Select,
  InputLabel,
  MenuItem,
  Grid,
} from "@material-ui/core";
import { Autocomplete, createFilterOptions } from "@mui/material";
import { makeStyles } from "@material-ui/core/styles";
import "react-datepicker/dist/react-datepicker.css";
import { inpNum } from "../constants/validChecker";
import { confirmAlert } from "react-confirm-alert";
import { interested_parties } from "../constants/dropDownData";
import InputAdornment from "@material-ui/core/InputAdornment";
import {
  // holdingBroker_validate,
  holdingUnderwriter_validate,
  
  stampDuty_validate,
  noClaimBonus_validate,
  paymentFrequency_validate,
  preferredInstallments_validate,
  broker_fee_installments_validate,
  // productType_validate,
  coverType_validate,
  sumInsured_validate,
  agreedValueAmount_validate,
  policyFromDate_validate,
  policyToDate_validate,
  roadsideAssistance_validate,
  hireCareInclusion_validate,
  windscreenExcessWaiver_validate,
  repairsVehicle_validate,
  claimBonusProtection_validate,
  restrictedDriversDiscount_validate,
  namedDriver_validate,
  toolsTrade_validate,
  restrictedDrivers_validate,
  interestedParties_validate,
  occupationPolicyholder_validate,
  commercialPurposesCaravan_validate,
  excessOption1_validate,
  excessOption2_validate,
  excessOption3_validate,
  brokerFee_validate,
  otherParty_validate,
} from "../validations/tab3_validate";
import DatePicker from "react-datepicker";
import history from "../auth/history";

const filter = createFilterOptions();
const returnClientHome = () => {
  history.push("/client");
};
// styles
const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    alignContent: "center",
    padding: theme.spacing(2),
    //textAlign: 'center',
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary,
  },
}));

// main function Tab3_PolicyCore
const Tab3_PolicyCore = ({
  tab3_policyCore,
  setTab3,
  tab3_validation,
  setTab3_validation,
  navigation,
}) => {
  const classes = useStyles();
  // onClick method: exit when clicking exit btn
  const exit = () => {
    // console.log(ind);
    // const temp = [...tab5_modifications];
    // const tempValidate = [...tab5_validation];

    confirmAlert({
      title: "Confirm to exit",
      message: "Are you going to exit without saving values?",
      buttons: [
        {
          label: "Yes",
          onClick: () => {
            // removing the element using splice
            // temp.splice(ind, 1);
            // tempValidate.splice(ind, 1);

            // tab5_modifications = temp;
            // tab5_validation = tempValidate;

            // // updating the list
            // setTab5(temp);
            // setTab5_validation(tempValidate);

            returnClientHome();
          },
        },
        {
          label: "No",
          onClick: () => null,
        },
      ],
    });
  };
  // method to set Interested party
  const setParty = (val) => {
    if (val) {
      let name = "interestedParties";

      let value; //val.party;
      // console.log(val.party);
      // console.log(typeof val.party);
      if (typeof val.party === "undefined") {
        value = val;
        // console.log(value);
        setTab3(
          {
            ...tab3_policyCore,
            [name]: value,
          },
          () => {
            // console.log(interested_parties[24]);
            validationAfterChange(name, value);
          }
        );
      } else {
        value = val.party;
        setTab3(
          {
            ...tab3_policyCore,
            [name]: value,
          },
          () => {
            // console.log(interested_parties[24]);
            validationAfterChange(name, value);
          }
        );
      }
      // console.log(value);
    } else {
      let name = "interestedParties";
      let value = " ";
      setTab3(
        {
          ...tab3_policyCore,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    }
    // return val;
  };
  const onChangeField = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    // console.log(value);
    setTab3(
      {
        ...tab3_policyCore,
        [name]: value,
      },
      () => {
        validationAfterChange(name, value);
      }
    );
  };

  //method for not to typing in date field
  const handleDateChangeRaw = (e) => {
    e.preventDefault();
  };

  // method: to update policy date from to variable
  const setFromDate = (date, value) => {
    // console.log(date);
    const tempDate = new Date(date);
    const tempToDate = tempDate.setFullYear(tempDate.getFullYear() + 1);
    //console.log(date.setFullYear(date.getFullYear() + 1));

    // console.log(new Date(tempToDate));

    setTab3({
      ...tab3_policyCore,
      policyFromDate: date,
      policyToDate: new Date(tempToDate),
    });
    policyFromDate_validate(date, tab3_validation, setTab3_validation);
  }; // end of setFromDate method

  // method: to update policy date to to variable
  const setToDate = (date) => {
    setTab3({
      ...tab3_policyCore,
      policyToDate: date,
    });
    policyToDate_validate(date, tab3_validation, setTab3_validation);
  };
  // call validation function
  const validationAfterChange = (name, value) => {
    if (name === "paymentFrequency") {
      // console.log(tab3_policyCore.paymentFrequency)
      if (tab3_policyCore.paymentFrequency === "Yearly") {
        tab3_policyCore.preferredInstallments = " ";
        tab3_policyCore.broker_fee_installments = null;
      }
    }

    if (name === "sumInsured") {
      if (tab3_policyCore.sumInsured === "Market Value") {
        // console.log(tab3_policyCore.sumInsured);
        tab3_policyCore.agreedValueAmount = "";
      }
    }
    switch (name) {
      // case "holdingBroker": {
      //   holdingBroker_validate(value, tab3_validation, setTab3_validation);
      //   break;
      // }
      case "holdingUnderwriter": {
        holdingUnderwriter_validate(value, tab3_validation, setTab3_validation);
        break;
      }
      case "stampDuty": {
        stampDuty_validate(value, tab3_validation, setTab3_validation);
        break;
      }
      case "noClaimBonus": {
        noClaimBonus_validate(value, tab3_validation, setTab3_validation);
        break;
      }
      case "paymentFrequency": {
        paymentFrequency_validate(value, tab3_validation, setTab3_validation);
        break;
      }

      case "preferredInstallments": {
        preferredInstallments_validate(
          value,
          tab3_validation,
          setTab3_validation
        );
        break;
      }

      case "broker_fee_installments": {
        broker_fee_installments_validate(
          value,
          tab3_validation,
          setTab3_validation
        );
        break;
      }

      case "coverType": {
        coverType_validate(value, tab3_validation, setTab3_validation);
        break;
      }
      // case "productType": {
      //   productType_validate(value, tab3_validation, setTab3_validation);
      //   break;
      // }
      case "sumInsured": {
        sumInsured_validate(value, tab3_validation, setTab3_validation);
        break;
      }
      case "agreedValueAmount": {
        agreedValueAmount_validate(value, tab3_validation, setTab3_validation);
        break;
      }
      case "policyFromDate": {
        policyFromDate_validate(value, tab3_validation, setTab3_validation);
        break;
      }
      case "policyToDate": {
        policyToDate_validate(value, tab3_validation, setTab3_validation);
        break;
      }
      case "roadsideAssistance": {
        roadsideAssistance_validate(value, tab3_validation, setTab3_validation);
        break;
      }
      case "hireCareInclusion": {
        hireCareInclusion_validate(value, tab3_validation, setTab3_validation);
        break;
      }
      case "windscreenExcessWaiver": {
        windscreenExcessWaiver_validate(
          value,
          tab3_validation,
          setTab3_validation
        );
        break;
      }
      case "repairsVehicle": {
        repairsVehicle_validate(value, tab3_validation, setTab3_validation);
        break;
      }
      case "claimBonusProtection": {
        claimBonusProtection_validate(
          value,
          tab3_validation,
          setTab3_validation
        );
        break;
      }
      case "restrictedDriversDiscount": {
        restrictedDriversDiscount_validate(
          value,
          tab3_validation,
          setTab3_validation
        );
        break;
      }
      case "namedDriver": {
        namedDriver_validate(value, tab3_validation, setTab3_validation);
        break;
      }
      case "toolsTrade": {
        toolsTrade_validate(value, tab3_validation, setTab3_validation);
        break;
      }
      case "restrictedDrivers": {
        // console.log(value)
        restrictedDrivers_validate(value, tab3_validation, setTab3_validation);
        break;
      }
      case "interestedParties": {
        // console.log(value);

        // console.log(tab3_policyCore.interestedParties);
        // if( value == "undefined"){

        //     value = tab3_policyCore.interestedParties;
        //     console.log(value);
        //     interestedParties_validate(setParty(val), tab3_validation, setTab3_validation)
        // }
        // else{
        // console.log(value);
        interestedParties_validate(value, tab3_validation, setTab3_validation);
        // };
        break;
      }
      case "occupationPolicyholder": {
        occupationPolicyholder_validate(
          value,
          tab3_validation,
          setTab3_validation
        );
        break;
      }
      case "commercialPurposesCaravan": {
        commercialPurposesCaravan_validate(
          value,
          tab3_validation,
          setTab3_validation
        );
        break;
      }
      case "excessOption1": {
        excessOption1_validate(value, tab3_validation, setTab3_validation);
        break;
      }
      case "excessOption2": {
        excessOption2_validate(value, tab3_validation, setTab3_validation);
        break;
      }
      case "excessOption3": {
        excessOption3_validate(value, tab3_validation, setTab3_validation);
        break;
      }
      // case "otherParty": {
      //   // console.log("hi");
      //   otherParty_validate(value, tab3_validation, setTab3_validation);
      //   break;
      // }
      case "brokerFee": {
        brokerFee_validate(value, tab3_validation, setTab3_validation);
        break;
      }
      default: {
        console.log("Condition not valid");
      }
    }
  };

  // let option = tab3_policyCore.otherParty ? tab3_policyCore.otherParty : " ";
  // console.log(option);
  return (
    <div>
      <Container maxWidth="md">
        <div className={classes.root}>
          <Grid
            container
            spacing={3}
            direction="row"
            justifyContent="center"
            alignItems="center"
          >
            <Grid xs={12} item={true} justifyContent="center" container>
              <h3>POLICY CORE</h3>
            </Grid>

            {/* Holding Broker? */}
            {/* <Grid item xs={4}>
            <InputLabel
              htmlFor="Holding Broker?"
              style={{ marginBottom: "5px" }}
              required
            >
              Holding Broker?
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              name="holdingBroker"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange(
                  "holdingBroker",
                  tab3_policyCore.holdingBroker
                )
              }
              margin="none"
              variant="outlined"
              value={tab3_policyCore.holdingBroker}
              autoComplete="off"
              style={{ marginBottom: "2px", height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {tab3_validation.holdingBroker !== null &&
              tab3_validation.holdingBroker !== "true" && (
                <div className="text-danger font-italic">
                  {tab3_validation.holdingBroker}
                </div>
              )}
          </Grid> */}

            {/* Holding Underwriter? */}
            <Grid item xs={4}>
              <InputLabel
                htmlFor="Holding Underwriter?"
                style={{ marginBottom: "5px" }}
                required
              >
                Current Insurer?
              </InputLabel>
            </Grid>
            <Grid item xs={8}>
              <Select
                name="holdingUnderwriter"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange(
                    "holdingUnderwriter",
                    tab3_policyCore.holdingUnderwriter
                  )
                }
                margin="none"
                variant="outlined"
                value={tab3_policyCore.holdingUnderwriter}
                autoComplete="off"
                style={{ marginBottom: "2px", height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="AAMI">AAMI</MenuItem>
                <MenuItem value="Ace">Ace</MenuItem>
                <MenuItem value="AIG">AIG</MenuItem>
                <MenuItem value="Allianz">Allianz</MenuItem>
                <MenuItem value="AMP">AMP</MenuItem>
                <MenuItem value="Ansvar">Ansvar</MenuItem>
                <MenuItem value="blue Zebra">Blue Zebra</MenuItem>
                <MenuItem value="Budget Direct">Budget Direct</MenuItem>
                <MenuItem value="Calliden">Calliden</MenuItem>
                <MenuItem value="CGU">CGU</MenuItem>
                <MenuItem value="Chubb">Chubb</MenuItem>
                <MenuItem value="FM">FM</MenuItem>
                <MenuItem value="GIO">GIO</MenuItem>
                <MenuItem value="IAL">IAL</MenuItem>
                <MenuItem value="Lumley">Lumley</MenuItem>
                <MenuItem value="Miramar">Miramar</MenuItem>
                <MenuItem value="NRMA">NRMA</MenuItem>
                <MenuItem value="QBE">QBE</MenuItem>
                <MenuItem value="Real insurance">Real Insurance</MenuItem>
                <MenuItem value="Suncorp">Suncorp</MenuItem>
                <MenuItem value="Vero">Vero</MenuItem>
                <MenuItem value="Youi">Youi</MenuItem>
                <MenuItem value="Zurich">Zurich</MenuItem>
                <MenuItem value="No Previous insurance">
                  No Previous Insurance
                </MenuItem>
                <MenuItem value="Other">Other</MenuItem>
              </Select>
              {tab3_validation.holdingUnderwriter !== null &&
                tab3_validation.holdingUnderwriter !== "true" && (
                  <div className="text-danger font-italic">
                    {tab3_validation.holdingUnderwriter}
                  </div>
                )}
            </Grid>

            {/* Stamp Duty Exempt? */}
            <Grid item xs={4}>
              <InputLabel
                htmlFor="Stamp Duty Exempt?"
                style={{ marginBottom: "5px" }}
                required
              >
                Stamp Duty Exempt?
              </InputLabel>
            </Grid>
            <Grid item xs={8}>
              <Select
                name="stampDuty"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange("stampDuty", tab3_policyCore.stampDuty)
                }
                margin="none"
                variant="outlined"
                autoComplete="off"
                value={tab3_policyCore.stampDuty}
                style={{ marginBottom: "2px", height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
              {tab3_validation.stampDuty !== null &&
                tab3_validation.stampDuty !== "true" && (
                  <div className="text-danger font-italic">
                    {tab3_validation.stampDuty}
                  </div>
                )}
            </Grid>

{/* No claim Bonus protection (Allianz) */}
          <Grid item xs={4}>
              <InputLabel
                htmlFor="No claim Bonus protection (Allianz)"
                style={{ marginBottom: "5px" }}
                required
              >
                No claim Bonus protection 
              </InputLabel>
            </Grid>
            <Grid item xs={8}>
              <Select
                name="claimBonusProtection"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange(
                    "claimBonusProtection",
                    tab3_policyCore.claimBonusProtection
                  )
                }
                margin="none"
                variant="outlined"
                autoComplete="off"
                value={tab3_policyCore.claimBonusProtection}
                style={{ marginBottom: "2px", height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
              {tab3_validation.claimBonusProtection !== null &&
                tab3_validation.claimBonusProtection !== "true" && (
                  <div className="text-danger font-italic">
                    {tab3_validation.claimBonusProtection}
                  </div>
                )}
            </Grid>

            {/* No claim bonus */}
            <Grid item xs={4}>
              <InputLabel
                htmlFor="No claim bonus"
                style={{ marginBottom: "5px" }}
                required
              >
                No claim bonus
              </InputLabel>
            </Grid>
            <Grid item xs={8}>
              <Select
                name="noClaimBonus"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange(
                    "noClaimBonus",
                    tab3_policyCore.noClaimBonus
                  )
                }
                margin="none"
                variant="outlined"
                autoComplete="off"
                value={tab3_policyCore.noClaimBonus}
                style={{ marginBottom: "2px", height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="60% - Level 1">60% - Level 1</MenuItem>
                <MenuItem value="50% - Level 2">50% - Level 2</MenuItem>
                <MenuItem value="40% - Level 3">40% - Level 3</MenuItem>
                <MenuItem value="30% - Level 4">30% - Level 4</MenuItem>
                <MenuItem value="20% - Level 5">20% - Level 5</MenuItem>
                <MenuItem value="0% - Level 6">0% - Level 6</MenuItem>
              </Select>
              {tab3_validation.noClaimBonus !== null &&
                tab3_validation.noClaimBonus !== "true" && (
                  <div className="text-danger font-italic">
                    {tab3_validation.noClaimBonus}
                  </div>
                )}
            </Grid>

            {/* Payment Frequency */}
            <Grid item xs={4}>
              <InputLabel
                htmlFor="Payment Frequency"
                style={{ marginBottom: "5px" }}
                required
              >
                Payment Frequency
              </InputLabel>
            </Grid>

            <Grid item xs={8}>
              <Select
                name="paymentFrequency"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange(
                    "paymentFrequency",
                    tab3_policyCore.paymentFrequency
                  )
                }
                margin="none"
                variant="outlined"
                autoComplete="off"
                value={tab3_policyCore.paymentFrequency}
                style={{ height: "40px" }}
                fullWidth
              >
                <MenuItem value=" ">Please Select</MenuItem>
                <MenuItem value="Yearly">Yearly</MenuItem>
                <MenuItem value="Monthly">Monthly</MenuItem>
              </Select>
              {tab3_validation.paymentFrequency !== null &&
                tab3_validation.paymentFrequency !== "true" && (
                  <div className="text-danger font-italic">
                    {tab3_validation.paymentFrequency}
                  </div>
                )}
            </Grid>
            {tab3_policyCore.paymentFrequency === "Monthly" && (
              <Grid container xs={12} direction="row" spacing={2}>
                {/* Preferred Day for installments" */}
                <Grid item xs={4}>
                  <InputLabel
                    htmlFor="Preferred Day for installments"
                    style={{ marginTop: "10px", marginBottom: "5px" }}
                    required
                  >
                    Preferred Day for installments
                  </InputLabel>
                </Grid>

                <Grid item xs={8}>
                  <Select
                    name="preferredInstallments"
                    onChange={onChangeField}
                    type="number"
                    size="small"
                    variant="outlined"
                    autoComplete="off"
                    onClose={() =>
                      validationAfterChange(
                        "preferredInstallments",
                        tab3_policyCore.preferredInstallments
                      )
                    }
                    value={tab3_policyCore.preferredInstallments}
                    fullWidth
                    style={{ marginTop: "10px", height: "40px" }}
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    <MenuItem value="1">1</MenuItem>
                    <MenuItem value="2">2</MenuItem>
                    <MenuItem value="3">3</MenuItem>
                    <MenuItem value="4">4</MenuItem>
                    <MenuItem value="5">5</MenuItem>
                    <MenuItem value="6">6</MenuItem>
                    <MenuItem value="7">7</MenuItem>
                    <MenuItem value="8">8</MenuItem>
                    <MenuItem value="9">9</MenuItem>
                    <MenuItem value="10">10</MenuItem>
                    <MenuItem value="11">11</MenuItem>
                    <MenuItem value="12">12</MenuItem>
                    <MenuItem value="13">13</MenuItem>
                    <MenuItem value="14">14</MenuItem>
                    <MenuItem value="15">15</MenuItem>
                    <MenuItem value="16">16</MenuItem>
                    <MenuItem value="17">17</MenuItem>
                    <MenuItem value="18">18</MenuItem>
                    <MenuItem value="19">19</MenuItem>
                    <MenuItem value="20">20</MenuItem>
                    <MenuItem value="21">21</MenuItem>
                    <MenuItem value="22">22</MenuItem>
                    <MenuItem value="23">23</MenuItem>
                    <MenuItem value="24">24</MenuItem>
                    <MenuItem value="25">25</MenuItem>
                    <MenuItem value="26">26</MenuItem>
                    <MenuItem value="27">27</MenuItem>
                    <MenuItem value="28">28</MenuItem>
                    <MenuItem value="29">29</MenuItem>
                    <MenuItem value="30">30</MenuItem>
                    <MenuItem value="31">31</MenuItem>
                  </Select>
                  {tab3_validation.preferredInstallments !== null &&
                    tab3_validation.preferredInstallments !== "true" && (
                      <div className="text-danger font-italic">
                        {tab3_validation.preferredInstallments}
                      </div>
                    )}
                </Grid>

                {/* Broker Fee */}
                <Grid item xs={4}>
                  <InputLabel
                    htmlFor="Broker Fee (installments)"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    Broker Fee (installments)
                  </InputLabel>
                </Grid>
                <Grid item xs={8}>
                  <TextField
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">$</InputAdornment>
                      ),
                    }}
                    name="broker_fee_installments"
                    value={tab3_policyCore.broker_fee_installments}
                    onChange={onChangeField}
                    type="number"
                    onKeyPress={(e) => inpNum(e)}
                    size="small"
                    variant="outlined"
                    autoComplete="off"
                    //type="number"
                    // style={{ marginBottom: "20px" }}
                    fullWidth
                  />
                  {tab3_validation.broker_fee_installments !== null &&
                    tab3_validation.broker_fee_installments !== "true" && (
                      <div className="text-danger font-italic">
                        {tab3_validation.broker_fee_installments}
                      </div>
                    )}
                </Grid>
              </Grid>
            )}

            {/* Product Type (Allianz) */}
            {/* <Grid item xs={4}>
              <InputLabel
                htmlFor="Product Type (Allianz)"
                style={{ marginBottom: "5px" }}
                required
              >
                Product Type (Allianz)
              </InputLabel>
            </Grid>
            <Grid item xs={8}>
              <Select
                name="productType"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange(
                    "productType",
                    tab3_policyCore.productType
                  )
                }
                margin="none"
                variant="outlined"
                autoComplete="off"
                value={tab3_policyCore.productType}
                style={{ marginBottom: "2px", height: "40px" }}
                fullWidth
              >
                <MenuItem value=" " disabled>
                  Please Select
                </MenuItem>
                <MenuItem value="Prestige">Prestige</MenuItem>
                <MenuItem value="Classic">Classic</MenuItem>
              </Select>
              {tab3_validation.productType !== null &&
                tab3_validation.productType !== "true" && (
                  <div className="text-danger font-italic">
                    {tab3_validation.productType}
                  </div>
                )}
            </Grid> */}

            {/* Cover Type */}
            <Grid item xs={4}>
              <InputLabel
                htmlFor="Cover Type"
                style={{ marginBottom: "5px" }}
                required
              >
                Cover Type
              </InputLabel>
            </Grid>
            <Grid item xs={8}>
              <Select
                name="coverType"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange("coverType", tab3_policyCore.coverType)
                }
                margin="none"
                variant="outlined"
                autoComplete="off"
                value={tab3_policyCore.coverType}
                style={{ marginBottom: "2px", height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Comprehensive">Comprehensive</MenuItem>
                <MenuItem value="Third Party Fire and Theft">
                  Third Party Fire and Theft
                </MenuItem>
                <MenuItem value="Third Party Property">
                  Third Party Property
                </MenuItem>
              </Select>
              {tab3_validation.coverType !== null &&
                tab3_validation.coverType !== "true" && (
                  <div className="text-danger font-italic">
                    {tab3_validation.coverType}
                  </div>
                )}
            </Grid>

            {/* Sum Insured */}
            <Grid item xs={4}>
              <InputLabel
                htmlFor="Sum Insured"
                style={{ marginBottom: "5px" }}
                required
              >
                Sum Insured
              </InputLabel>
            </Grid>
            <Grid item xs={8}>
              <Select
                name="sumInsured"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange(
                    "sumInsured",
                    tab3_policyCore.sumInsured
                  )
                }
                margin="none"
                variant="outlined"
                autoComplete="off"
                value={tab3_policyCore.sumInsured}
                style={{ marginBottom: "2px", height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Agreed Value">Agreed Value</MenuItem>
                <MenuItem value="Market Value">Market Value</MenuItem>
              </Select>
              {tab3_validation.sumInsured !== null &&
                tab3_validation.sumInsured !== "true" && (
                  <div className="text-danger font-italic">
                    {tab3_validation.sumInsured}
                  </div>
                )}
            </Grid>
            {tab3_policyCore.sumInsured === "Agreed Value" && (
              <Grid container xs={12} item={true} direction="row" spacing={2}>
                {/* Agreed Value Amount */}
                <Grid item xs={4}>
                  <InputLabel
                    htmlFor="Agreed Value Amount"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    Agreed Value Amount
                  </InputLabel>
                </Grid>
                <Grid item xs={8}>
                  <TextField
                    name="agreedValueAmount"
                    value={tab3_policyCore.agreedValueAmount}
                    onChange={onChangeField}
                    type="number"
                    onKeyPress={(e) => inpNum(e)} // to prevent chars and symbol typing
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">$</InputAdornment>
                      ),
                    }}
                    size="small"
                    variant="outlined"
                    autoComplete="off"
                    fullWidth
                  />
                  {tab3_validation.agreedValueAmount !== null &&
                    tab3_validation.agreedValueAmount !== "true" && (
                      <div className="text-danger font-italic">
                        {tab3_validation.agreedValueAmount}
                      </div>
                    )}
                </Grid>
              </Grid>
            )}

            {/* Policy From Date */}
            <Grid item xs={4}>
              <InputLabel
                htmlFor="Policy From Date"
                style={{ marginBottom: "5px" }}
                required
              >
                Policy From Date
              </InputLabel>
            </Grid>

            {/* <TextField
              name="policyFromDate"
              type="date"
              min="2013-12-25"
              size="small"
              value={tab3_policyCore.policyFromDate}
              onChange={onChangeField}
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", }}
              fullWidth
            /> */}
            <Grid item xs={8}>
              <div>
                <DatePicker
                  selected={tab3_policyCore.policyFromDate}
                  //onSelect={date => console.log(date)}
                  onChange={setFromDate}
                  dateFormat="dd/MM/yyyy"
                  name="policyFromDate"
                  minDate={new Date()}
                  value={tab3_policyCore.policyFromDate}
                  className="date-picker-align"
                  onChangeRaw={handleDateChangeRaw}
                  // style={{ marginBottom: "10px", width:"50px"}}
                  // variant="outlined"
                  // autoComplete="off"
                  // fullWidth
                />
              </div>
            </Grid>

            {/* Policy To Date */}
            <Grid item xs={4}>
              <InputLabel
                htmlFor="Policy To Date"
                style={{ marginBottom: "5px" }}
                required
              >
                Policy To Date
              </InputLabel>
            </Grid>
            <Grid item xs={8}>
              <DatePicker
                selected={tab3_policyCore.policyToDate}
                dateFormat="dd/MM/yyyy"
                name="policyToDate"
                minDate={tab3_policyCore.policyToDate}
                onChange={setToDate}
                onChangeRaw={handleDateChangeRaw}
                value={tab3_policyCore.policyToDate}
                variant="outlined"
                autoComplete="off"
                fullWidth
                className="date-picker-align"
              />
            </Grid>

            {/* Roadside Assistance */}
            <Grid item xs={4}>
              <InputLabel
                htmlFor="Roadside Assistance"
                style={{ marginBottom: "5px" }}
                required
              >
                Roadside Assistance
              </InputLabel>
            </Grid>
            <Grid item xs={8}>
              <Select
                name="roadsideAssistance"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange(
                    "roadsideAssistance",
                    tab3_policyCore.roadsideAssistance
                  )
                }
                margin="none"
                variant="outlined"
                autoComplete="off"
                value={tab3_policyCore.roadsideAssistance}
                style={{ marginBottom: "2px", height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
              {tab3_validation.roadsideAssistance !== null &&
                tab3_validation.roadsideAssistance !== "true" && (
                  <div className="text-danger font-italic">
                    {tab3_validation.roadsideAssistance}
                  </div>
                )}
            </Grid>

            {/* Hire Care Inclusion (SVU & Allianz) */}
            <Grid item xs={4}>
              <InputLabel
                htmlFor="Hire Care Inclusion (SVU & Allianz)"
                style={{ marginBottom: "5px" }}
                required
              >
                Hire Care Inclusion
              </InputLabel>
            </Grid>
            <Grid item xs={8}>
              <Select
                name="hireCareInclusion"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange(
                    "hireCareInclusion",
                    tab3_policyCore.hireCareInclusion
                  )
                }
                margin="none"
                variant="outlined"
                autoComplete="off"
                value={tab3_policyCore.hireCareInclusion}
                style={{ marginBottom: "2px", height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
              {tab3_validation.hireCareInclusion !== null &&
                tab3_validation.hireCareInclusion !== "true" && (
                  <div className="text-danger font-italic">
                    {" "}
                    {tab3_validation.hireCareInclusion}
                  </div>
                )}
            </Grid>

            {/* Windscreen Excess Waiver (SVU & Allianz) */}
            <Grid item xs={4}>
              <InputLabel
                htmlFor="Windscreen Excess Waiver (SVU & Allianz)"
                style={{ marginBottom: "5px" }}
                required
              >
                Windscreen Excess Waiver 
              </InputLabel>
            </Grid>
            <Grid item xs={8}>
              <Select
                name="windscreenExcessWaiver"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange(
                    "windscreenExcessWaiver",
                    tab3_policyCore.windscreenExcessWaiver
                  )
                }
                margin="none"
                variant="outlined"
                autoComplete="off"
                value={tab3_policyCore.windscreenExcessWaiver}
                style={{ marginBottom: "2px", height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
              {tab3_validation.windscreenExcessWaiver !== null &&
                tab3_validation.windscreenExcessWaiver !== "true" && (
                  <div className="text-danger font-italic">
                    {tab3_validation.windscreenExcessWaiver}
                  </div>
                )}
            </Grid>

            {/* Who repairs the vehicle (IAL Only) */}
            {/* <Grid item xs={4}>
            <InputLabel
              htmlFor="Who repairs the vehicle (IAL Only)"
              style={{ marginBottom: "5px" }}
              required
            >
              Who repairs the vehicle (IAL Only)
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              name="repairsVehicle"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange(
                  "repairsVehicle",
                  tab3_policyCore.repairsVehicle
                )
              }
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={tab3_policyCore.repairsVehicle}
              style={{ marginBottom: "2px", height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Insurer Decides">Insurer Decides</MenuItem>
              <MenuItem value="Policyholder Decides">
                Policyholder Decides
              </MenuItem>
            </Select>
            {tab3_validation.repairsVehicle !== null &&
              tab3_validation.repairsVehicle !== "true" && (
                <div className="text-danger font-italic">
                  {tab3_validation.repairsVehicle}
                </div>
              )}
          </Grid> */}

             
            
            {/* Restricted driver discount (Allianz) */}
            <Grid item xs={4}>
              <InputLabel
                htmlFor="Restricted driver discount (Allianz)"
                style={{ marginBottom: "5px" }}
                required
              >
                Restricted driver discount 
              </InputLabel>
            </Grid>
            <Grid item xs={8}>
              <Select
                name="restrictedDriversDiscount"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange(
                    "restrictedDriversDiscount",
                    tab3_policyCore.restrictedDriversDiscount
                  )
                }
                margin="none"
                variant="outlined"
                autoComplete="off"
                value={tab3_policyCore.restrictedDriversDiscount}
                style={{ height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
                <MenuItem value="No">No</MenuItem>
              </Select>
              {tab3_validation.restrictedDriversDiscount !== null &&
                tab3_validation.restrictedDriversDiscount !== "true" && (
                  <div className="text-danger font-italic">
                    {tab3_validation.restrictedDriversDiscount}
                  </div>
                )}
            </Grid>

            {/* Named Driver MenuItem (Allianz) */}
            <Grid item xs={4}>
              <InputLabel
                htmlFor="Named Driver MenuItem (Allianz)"
                style={{ marginBottom: "5px" }}
                required
              >
                Named Driver 
              </InputLabel>
            </Grid>
            <Grid item xs={8}>
              <Select
                name="namedDriver"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange(
                    "namedDriver",
                    tab3_policyCore.namedDriver
                  )
                }
                margin="none"
                variant="outlined"
                autoComplete="off"
                value={tab3_policyCore.namedDriver}
                style={{ marginBottom: "2px", height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
              {tab3_validation.namedDriver !== null &&
                tab3_validation.namedDriver !== "true" && (
                  <div className="text-danger font-italic">
                    {tab3_validation.namedDriver}
                  </div>
                )}
            </Grid>

            {/* Tools of Trade MenuItem (Allianz) */}
            <Grid item xs={4}>
              <InputLabel
                htmlFor="Tools of Trade MenuItem (Allianz)"
                style={{ marginBottom: "5px" }}
                required
              >
                Tools of Trade 
              </InputLabel>
            </Grid>
            <Grid item xs={8}>
              <Select
                name="toolsTrade"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange(
                    "toolsTrade",
                    tab3_policyCore.toolsTrade
                  )
                }
                margin="none"
                variant="outlined"
                autoComplete="off"
                value={tab3_policyCore.toolsTrade}
                style={{ marginBottom: "2px", height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select </MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
                <MenuItem value="No">No</MenuItem>
              </Select>
              {tab3_validation.toolsTrade !== null &&
                tab3_validation.toolsTrade !== "true" && (
                  <div className="text-danger font-italic">
                    {tab3_validation.toolsTrade}
                  </div>
                )}
            </Grid>

            {/* Restricted Drivers (Vero) */}
            {/* <Grid item xs={4}>
            <InputLabel
              htmlFor="Restricted Drivers (Vero)"
              style={{ marginBottom: "5px" }}
              required
            >
              Restricted Drivers (Vero)
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              name="restrictedDrivers"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange(
                  "restrictedDrivers",
                  tab3_policyCore.restrictedDrivers
                )
              }
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={tab3_policyCore.restrictedDrivers}
              style={{ marginBottom: "2px", height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="No Restriction">No Restriction</MenuItem>
              <MenuItem value="Under 30 Restriction">
                Under 30 Restriction
              </MenuItem>
            </Select>
            {tab3_validation.restrictedDrivers !== null &&
              tab3_validation.restrictedDrivers !== "true" && (
                <div className="text-danger font-italic">
                  {tab3_validation.restrictedDrivers}
                </div>
              )}
          </Grid> */}

            {/* Interested Parties */}
            <Grid item xs={4}>
              <InputLabel
                htmlFor="Interested Parties"
                style={{ marginBottom: "5px" }}
                required
              >
                Interested Parties
              </InputLabel>
            </Grid>
            <Grid item xs={8}>
              <Autocomplete
                // value={tab3_validation.interestedParties}
                // selectOnFocus
                // clearOnBlur
                // handleHomeEndKeys
                // id="free-solo-with-text-demo"
                // selectOnFocus
                // clearOnBlur
                // interestedParties = {[...interested_parties,{party : tab3_policyCore.interestedParties}]}
                options={interested_parties}
                sx={{ width: 1 }}
                // freeSolo
                isOptionEqualToValue={(option, value) => option.id === value.id}
                // getOptionLabel={(option) => {
                //   // (option.party ? option.party : tab3_policyCore.interestedParties)
                //   // console.log(tab3_policyCore.interestedParties);
                //   // Value selected with enter, right from the input
                //   // if (typeof option === 'string') {
                //   //   (option.group ? option.group : tab3_policyCore.interestedParties)
                //   //   return option;
                //   // }
                //   // // Add "xxx" option created dynamically
                //   // if (option.inputValue) {
                //   //   (option.group ? option.group : tab3_policyCore.interestedParties)
                //   //   return option.inputValue;
                //   // }
                //   // // Regular option
                //   // (option.group ? option.group : tab3_policyCore.interestedParties)
                //   //  return option.party;
                // }}
                getOptionLabel={(option) =>
                  option.party
                    ? option.party
                    : tab3_policyCore.interestedParties
                }
                defaultValue={"Please Select"}
                name="interestedParties"
                onChange={(event, value) => setParty(value)}
                // filterOptions={(options, params) => {
                //   const filtered = filter(options, params);

                //   const { inputValue } = params;
                //   // Suggest the creation of a new value
                //   const isExisting = options.some((option) => inputValue === option.party);
                //   if (inputValue !== '' && !isExisting) {
                //     filtered.push({
                //       inputValue,
                //       party: `Add "${inputValue}"`,
                //     });
                //     interested_parties.push({party : inputValue});
                //   }

                //   return filtered;
                // }}
                // onChange={(event, newValue) => {
                //   // console.log(value);
                //   // setParty(value);
                //   if (typeof newValue === 'string') {
                //     // setPartyVal({
                //     //   party: newValue,
                //     // });
                //     // console.log(party)
                //   //   console.log(newValue);
                //   interested_parties.push({party : newValue});
                //     setParty(newValue)
                //   } else if (newValue && newValue.inputValue) {
                //     // Create a new value from the user input
                //     // setPartyVal({
                //     //   party: newValue.inputValue,
                //     // });
                //     // console.log(party);
                //     interested_parties.push({party : newValue.inputValue});
                //     console.log(newValue.inputValue);
                //     //setPartType(interested_parties => [...interested_parties,{party :newValue.inputValue}])
                //     setParty(newValue.inputValue)
                //     console.log(interested_parties);

                //   } else {
                //     //  setPartyVal(newValue);
                //     console.log(newValue);

                //     //setPartType(interested_parties => [...interested_parties,{party :newValue}]);
                //     setParty(newValue);
                //     console.log(interested_parties)
                //     // setTheArray(currentArray => [...currentArray, newElement])
                //     // setPartType({...partyType, ...interested_parties.party.push(newValue)});
                //     // console.log(partyType);
                //   }

                // }}

                // renderOption={(props, option) => <li {...props}>{option.title}</li>}
                // renderOption={(props, option) => <li {...props}>{option.party}</li>}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant="outlined"
                    fullWidth
                    label="Search / Select"
                    value={tab3_policyCore.interestedParties}
                  />
                )}
              />
              {tab3_validation.interestedParties !== null &&
                tab3_validation.interestedParties !== "true" && (
                  <div className="text-danger font-italic">
                    {tab3_validation.interestedParties}
                  </div>
                )}
            </Grid>

            {/* {tab3_policyCore.interestedParties === "Other" && (
            <Grid item container xs={12} direction="row" spacing={2}>
              <Grid item xs={4} className={classes.bg_color}>
                <InputLabel
                  htmlFor="Client Title"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Other Party Name
                </InputLabel>
              </Grid>
              <Grid item xs={8}>
                <TextField
                  name="otherParty"
                  size="small"
                  value={tab3_policyCore.otherParty}
                  onChange={onChangeField}
                  variant="outlined"
                  autoComplete="off"
                  fullWidth
                />
                {tab3_validation.otherParty !== null &&
                  tab3_validation.otherParty !== "true" && (
                    <div className="text-danger font-italic">
                      {tab3_validation.otherParty}
                    </div>
                  )}
              </Grid>
            </Grid>
          )} */}

            {/* Occupation of Policyholder (Zurich) */}
            <Grid item xs={4}>
              <InputLabel
                htmlFor="Occupation of Policyholder (Zurich)"
                style={{ marginBottom: "5px" }}
                required
              >
                Occupation of Policyholder 
              </InputLabel>
            </Grid>
            <Grid item xs={8}>
              <Select
                name="occupationPolicyholder"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange(
                    "occupationPolicyholder",
                    tab3_policyCore.occupationPolicyholder
                  )
                }
                margin="none"
                variant="outlined"
                autoComplete="off"
                value={tab3_policyCore.occupationPolicyholder}
                style={{ marginBottom: "2px", height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Banking and Finance">
                  Banking and Finance
                </MenuItem>
                <MenuItem value="Construction / Engineering">
                  Construction / Engineering
                </MenuItem>
                <MenuItem value="Design">Design</MenuItem>
                <MenuItem value="Education">Education</MenuItem>
                <MenuItem value="Entertainment">Entertainment</MenuItem>
                <MenuItem value="Family Trust">Family Trust</MenuItem>
                <MenuItem value="Government">Government</MenuItem>
                <MenuItem value="Home Duties">Home Duties</MenuItem>
                <MenuItem value="Hospitality">Hospitality</MenuItem>
                <MenuItem value="HR">HR</MenuItem>
                <MenuItem value="Import / Export">Import / Export</MenuItem>
                <MenuItem value="Insurance">Insurance</MenuItem>
                <MenuItem value="IT">IT</MenuItem>
                <MenuItem value="Jeweler">Jeweler</MenuItem>
                <MenuItem value="Commonwealth Bank">Commonwealth Bank</MenuItem>
                <MenuItem value="Management Consultant">
                  Management Consultant
                </MenuItem>
                <MenuItem value="Media">Media</MenuItem>
                <MenuItem value="Medical">Medical</MenuItem>
                <MenuItem value="Milatary and Defence">
                  Milatary and Defence
                </MenuItem>
                <MenuItem value="Mining">Mining</MenuItem>
                <MenuItem value="Motor Industry">Motor Industry</MenuItem>
                <MenuItem value="Motor Industry">Property</MenuItem>
                <MenuItem value="Public Sector">Public Sector</MenuItem>
                <MenuItem value="Publishing / Photography">
                  Publishing / Photography
                </MenuItem>
                <MenuItem value="Retail / Sales">Retail / Sales</MenuItem>
                <MenuItem value="Science / Research">
                  Science / Research
                </MenuItem>
                <MenuItem value="Security Industry">Security Industry</MenuItem>
                <MenuItem value="Sporting Industry">Sporting Industry</MenuItem>
                <MenuItem value="Transportation">Transportation</MenuItem>
                <MenuItem value="Travel and Tourism">
                  Travel and Tourism
                </MenuItem>
                <MenuItem value="Other">Other</MenuItem>
              </Select>
              {tab3_validation.occupationPolicyholder !== null &&
                tab3_validation.occupationPolicyholder !== "true" && (
                  <div className="text-danger font-italic">
                    {tab3_validation.occupationPolicyholder}
                  </div>
                )}
            </Grid>

            {/* Is Your vehicle involved in Commercial Purposes Caravan Operations (i.e Hot Dog Vans, Food Vans, Mobile Coffee Shops etc) ? (Zurich) */}
            <Grid item xs={4}>
              <InputLabel
                htmlFor="Is Your vehicle involved in Commercial Purposes Caravan Operations (i.e Hot Dog Vans, Food Vans, Mobile Coffee Shops etc) ? (Zurich)"
                style={{ marginBottom: "5px" }}
                required
              >
                Is Your vehicle involved in Commercial Purposes Caravan
                Operations (i.e Hot Dog Vans, Food Vans, Mobile Coffee Shops
                etc) ? 
              </InputLabel>
            </Grid>
            <Grid item xs={8}>
              <Select
                name="commercialPurposesCaravan"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange(
                    "commercialPurposesCaravan",
                    tab3_policyCore.commercialPurposesCaravan
                  )
                }
                margin="none"
                variant="outlined"
                autoComplete="off"
                value={tab3_policyCore.commercialPurposesCaravan}
                style={{ marginBottom: "2px", height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
              {tab3_validation.commercialPurposesCaravan !== null &&
                tab3_validation.commercialPurposesCaravan !== "true" && (
                  <div className="text-danger font-italic">
                    {tab3_validation.commercialPurposesCaravan}
                  </div>
                )}
            </Grid>

            {/* Excess MenuItem 1 */}
            <Grid item xs={4}>
              <InputLabel
                htmlFor="Excess MenuItem 1"
                style={{ marginBottom: "5px" }}
                required
              >
                Excess Option 1
              </InputLabel>
            </Grid>
            <Grid item xs={8}>
              <Select
                name="excessOption1"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange(
                    "excessOption1",
                    tab3_policyCore.excessOption1
                  )
                }
                margin="none"
                variant="outlined"
                autoComplete="off"
                value={tab3_policyCore.excessOption1}
                style={{ marginBottom: "2px", height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="400">$400</MenuItem>
                <MenuItem value="500">$500</MenuItem>
                <MenuItem value="600">$600</MenuItem>
                <MenuItem value="700">$700</MenuItem>
                <MenuItem value="750">$750</MenuItem>
                <MenuItem value="800">$800</MenuItem>
                <MenuItem value="900">$900</MenuItem>
                <MenuItem value="1000">$1000</MenuItem>
                <MenuItem value="1200">$1200</MenuItem>
                <MenuItem value="1400">$1400</MenuItem>
                <MenuItem value="1600">$1600</MenuItem>
                <MenuItem value="1800">$1800</MenuItem>
                <MenuItem value="2000">$2000</MenuItem>
                <MenuItem value="2500">$2500</MenuItem>
                <MenuItem value="3000">$3000</MenuItem>
                <MenuItem value="5000">$5000</MenuItem>
              </Select>
              {tab3_validation.excessOption1 !== null &&
                tab3_validation.excessOption1 !== "true" && (
                  <div className="text-danger font-italic">
                    {tab3_validation.excessOption1}
                  </div>
                )}
            </Grid>

            {/* Excess MenuItem 2 */}
            {/* <Grid item xs={4}>
            <InputLabel
              htmlFor="Excess MenuItem 2"
              style={{ marginBottom: "5px" }}
              required
            >
              Excess Option 2
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              name="excessOption2"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange(
                  "excessOption2",
                  tab3_policyCore.excessOption2
                )
              }
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={tab3_policyCore.excessOption2}
              style={{ marginBottom: "2px", height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="400">$400</MenuItem>
              <MenuItem value="500">$500</MenuItem>
              <MenuItem value="600">$600</MenuItem>
              <MenuItem value="700">$700</MenuItem>
              <MenuItem value="750">$750</MenuItem>
              <MenuItem value="800">$800</MenuItem>
              <MenuItem value="900">$900</MenuItem>
              <MenuItem value="1000">$1000</MenuItem>
              <MenuItem value="1200">$1200</MenuItem>
              <MenuItem value="1400">$1400</MenuItem>
              <MenuItem value="1600">$1600</MenuItem>
              <MenuItem value="1800">$1800</MenuItem>
              <MenuItem value="2000">$2000</MenuItem>
              <MenuItem value="2500">$2500</MenuItem>
              <MenuItem value="3000">$3000</MenuItem>
              <MenuItem value="5000">$5000</MenuItem>
            </Select>
            {tab3_validation.excessOption2 !== null &&
              tab3_validation.excessOption2 !== "true" && (
                <div className="text-danger font-italic">
                  {tab3_validation.excessOption2}
                </div>
              )}
          </Grid> */}

            {/* Excess MenuItem 3 */}
            {/* <Grid item xs={4}>
            <InputLabel
              htmlFor="Excess MenuItem 3"
              style={{ marginBottom: "5px" }}
              required
            >
              Excess Option 3
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              name="excessOption3"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange(
                  "excessOption3",
                  tab3_policyCore.excessOption3
                )
              }
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={tab3_policyCore.excessOption3}
              style={{ marginBottom: "2px", height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="400">$400</MenuItem>
              <MenuItem value="500">$500</MenuItem>
              <MenuItem value="600">$600</MenuItem>
              <MenuItem value="700">$700</MenuItem>
              <MenuItem value="750">$750</MenuItem>
              <MenuItem value="800">$800</MenuItem>
              <MenuItem value="900">$900</MenuItem>
              <MenuItem value="1000">$1000</MenuItem>
              <MenuItem value="1200">$1200</MenuItem>
              <MenuItem value="1400">$1400</MenuItem>
              <MenuItem value="1600">$1600</MenuItem>
              <MenuItem value="1800">$1800</MenuItem>
              <MenuItem value="2000">$2000</MenuItem>
              <MenuItem value="2500">$2500</MenuItem>
              <MenuItem value="3000">$3000</MenuItem>
              <MenuItem value="5000">$5000</MenuItem>
            </Select>
            {tab3_validation.excessOption3 !== null &&
              tab3_validation.excessOption3 !== "true" && (
                <div className="text-danger font-italic">
                  {tab3_validation.excessOption3}
                </div>
              )}
          </Grid> */}

            {/* Broker Fee */}
            {/* <Grid item xs={4}>
            <InputLabel
              htmlFor="Broker Fee"
              style={{ marginBottom: "5px" }}
              required
            >
              Broker Fee
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <TextField
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">$</InputAdornment>
                ),
              }}
              name="brokerFee"
              value={tab3_policyCore.brokerFee}
              onChange={onChangeField}
              size="small"
              variant="outlined"
              type="number"
              autoComplete="off"
              onKeyPress={(e) => inpNum(e)}
              fullWidth
            />
            {tab3_validation.brokerFee !== null &&
              tab3_validation.brokerFee !== "true" && (
                <div className="text-danger font-italic">
                  {tab3_validation.brokerFee}
                </div>
              )}
          </Grid> */}
          </Grid>
          <div style={{ marginBottom: "5rem" }}>
            <Grid>
              <Button
                variant="contained"
                color="secondary"
                style={{
                  marginTop: "1rem",
                  float: "left",
                  width: "10%",
                }}
                onClick={() => exit()}
              >
                EXIT
              </Button>
            </Grid>

            <Grid>
              <Button
                variant="contained"
                color="primary"
                style={{
                  marginTop: "1rem",
                  float: "right",
                  marginBottom: "20px",
                }}
                onClick={() => navigation.next()}
              >
                NEXT
              </Button>

              <Grid>
                <Button
                  variant="contained"
                  color="primary"
                  style={{
                    marginTop: "1rem",
                    float: "right",
                    marginRight: "20px",
                    width: "10%",
                  }}
                  onClick={() => navigation.previous()}
                >
                  PREVIOUS
                </Button>
              </Grid>
            </Grid>
          </div>
        </div>
      </Container>
      {/* <Footer /> */}
    </div>
  );
};

// const today = new Date().toISOString().split('T')[0];
// document.getElementsByName("policyFromDate")[0].setAttribute('min', today);

// var today = new Date().toISOString().split('T')[0];
// document.getElementsByName("policyToDate")[0].setAttribute('min', today);

export default Tab3_PolicyCore;
