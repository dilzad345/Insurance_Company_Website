import React from "react";
// import { makeStyles } from "@material-ui/core/styles";
import { Link } from "react-router-dom";
import "../css/homeStyle.css";
// import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Navbar } from "react-bootstrap";
// import logo from "../images/logo.png";
import regionallogo from "../images/regionallogo.png"
import car from "../images/car.png"
import home from "../images/home.png"
import land from "../images/land.png"
// import { Button } from "@material-ui/core";


const clientRegionalInsure = () => {


    const logoBar = () => {
        return (
            <div>
                <Navbar
                    style={{ backgroundColor: "#2F5597" }}
                    bg="#70aec2"
                    variant="dark"
                >
                    <Navbar.Brand href="#client">
                        <img
                            alt="EnsureTek logo"
                            src={regionallogo}
                            width="60%"
                            height="60%"
                            // className=""
                            style={{filter: 'brightness(1.75)'}}
                        />
                    </Navbar.Brand>
                </Navbar>
            </div>
        );
    };

    const clientHomeContent = () => {
        return (
            <div>
                <h2 className="heading" >
                    PLEASE SELECT YOUR PRODUCT BELOW FOR A QUOTE </h2>
                <div className="main-content">
                    <div className="circle">
                        <img alt="home" src={land} className="imgStyle" />
                        <Link
                            to={`/home_client_web_form`}
                            style={{ textDecoration: "none" }}>
                            <span className="insurestitle">Home & Contents Insurance</span>
                        </Link>
                    </div>
                    <div className="circle">
                        <img alt="car" src={car} className="imgStyle" />
                        <Link
                            to={`/motor_client_web_form`}
                            style={{ textDecoration: "none" }}>
                            <span className="insurestitle">Motor Insurance</span>
                        </Link>

                    </div>
                    <div className="circle">
                        <img alt="land" src={home} className="imgStyle" />

                        <Link
                            to={`/client`}
                            style={{ textDecoration: "none" }}>
                            <span className="insurestitle">Landlords Insurance</span>
                        </Link>
                    </div>
                </div>

            </div>
        );
    };

    return (
        <div>
            {logoBar()}
            {clientHomeContent()}
        </div>
    );
};

export default clientRegionalInsure;
