// import { getThemeProps } from "@material-ui/styles";
import axios from "axios";
import { API } from "../config";

import { tab1_validate } from "../validations/tab1_validate";
import { tab2_validate } from "../validations/tab2_validate";
import { tab3_validate } from "../validations/tab3_validate";
import { tab4_validate } from "../validations/tab4_validate";
import { tab5_validate } from "../validations/tab5_validate";
import { tab6_validate } from "../validations/tab6_validate";
import { tab7_validate } from "../validations/tab7_validate";


export const validateAllForms = (
  tab1_client,
  tab2_importantQuestions,
  tab3_policyCore,
  tab4_vehicle,
  tab5_modifications,
  tab6_drivers,
  tab7_claims
) => {
  let isValid = true;
  isValid = isValid * tab1_validate(tab1_client);
  isValid = isValid * tab2_validate(tab2_importantQuestions);
  isValid = isValid * tab3_validate(tab3_policyCore);
  isValid = isValid * tab4_validate(tab4_vehicle);
  isValid = isValid * tab5_validate(tab5_modifications);
  isValid = isValid * tab6_validate(tab6_drivers);
  isValid = isValid * tab7_validate(tab7_claims); 
  return isValid;
};

export const addAllFormsValues = (
  tab1_client,
  tab2_importantQuestions,
  tab3_policyCore,
  tab4_vehicle,
  tab5_modifications,
  tab6_drivers,
  tab7_claims
) => {
  const data_tab1 = {
    data_tab1_client: tab1_client,
  };


  return axios
    .post(`${API}/quotation/addClient`, data_tab1)
    .then((response_tab1) => {
       console.log("Response Tab1 ",response_tab1);
      let quotationId_db = response_tab1.data.data.id;
      console.log("Id:",quotationId_db);

      const data_tab2 = {
        data_tab2_importantQuestions: tab2_importantQuestions,
        quotationId_db: quotationId_db,
      };

      return axios
        .post(`${API}/quotation/addImportantQuestions`, data_tab2)
        .then((response_tab2) => {
          // console.log(response_tab2);
          const data_tab3 = {
            data_tab3_policyCore: tab3_policyCore,
            quotationId_db: quotationId_db,
          };

          return axios
            .post(`${API}/quotation/addPolicyCore`, data_tab3)
            .then((response_tab3) => {
              // console.log(response_tab3);
              const data_tab4 = {
                data_tab4_vehicle: tab4_vehicle,
                quotationId_db: quotationId_db,
              };
              return axios
                .post(`${API}/quotation/addVehicle`, data_tab4)
                .then((response_tab4) => {
                  // console.log(response_tab4);
                  const vehicleId_db = response_tab4.data.data.id;
                  const data_tab5 = {
                    data_tab5_modifications: tab5_modifications,
                    vehicleId_db: vehicleId_db,
                  };

                  return axios
                    .post(`${API}/quotation/addModification`, data_tab5)
                    .then((response_tab5) => {
                      // console.log(response_tab5);
                      const data_tab6 = {
                        data_tab6_drivers: tab6_drivers,
                        data_tab7_claims: tab7_claims,
                        quotationId_db: quotationId_db,
                      };
                      return axios
                        .post(`${API}/quotation/addDrivers`, data_tab6)
                        .then((response_tab6) => {
                          return response_tab6;
                        })
                        .catch((error_tab6) => {
                          // console.log(error_tab6);
                        });
                    })
                    .catch((error_tab5) => {
                      // console.log(error_tab5);
                    });
                })
                .catch((error_tab4) => {
                  // console.log(error_tab4);
                });
            })
            .catch((error_tab3) => {
              // console.log(error_tab3);
            });
        })
        .catch((error_tab2) => {
          // console.log(error_tab2);
        });
    })
    .catch((error_tab1) => {
      // console.log(error_tab1);
    });
};
