import React , {useState , useEffect , createContext, useReducer}from 'react';
// import Topbar   from './component/topBar/topBar';
// import Topbar2 from "./component/topBar/topBar";
import Routes from './Routes'
// import { initialState, reducer } from './reducer/useReducer';
// import Footer from './component/footer/footer';
import { ContextProvider } from './context/AuthContext';

// export const UserContext = createContext();
const  App = () => {
 
  
  return (
    <div>
      
      <ContextProvider>
         <Routes/>
      </ContextProvider>
    </div>
  )
}

export default App;