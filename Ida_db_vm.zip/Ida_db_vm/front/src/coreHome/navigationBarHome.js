import React from "react";
// import { Button, Grid } from "@material-ui/core";
// import { Navbar } from "react-bootstrap";
// import logo from "../images/logo.png";
// import regionallogo from "../images/regionallogo.png"
import "../core/navBar.css"
import {
  Tab1_Validation_Home,
} from "../validationHome/Tab1_Validation_Home";
import { Tab2_Validation_Home } from "../validationHome/Tab2_Validation_Home";
import { Tab3_Validation_Home } from "../validationHome/Tab3_Validation_Home";
import { Tab4_Validation_Home } from "../validationHome/Tab4_Validation_Home";
import { Tab5_Validation_Home } from "../validationHome/Tab5_Validation_Home";
import { Tab6_Validation_Home } from "../validationHome/Tab6_Validation_Home";

const navigationBarHome = ({
  step,
  navigation,
  Tab1_Client_Home_var,
  Tab2_Importan_Question_Home_var,
  Tab3_Policycore_Home_Var,
  Tab4_Building_Home_Var,
  Tab5_Contents_Home_Var,
  Tab6_Claims_Home_Var,
}) => {
  const navButtonClick = (index) => {
    navigation.go(index);
  };

  return (
    <div className="btn-container">
     
     <button  
       onClick={() => {navButtonClick(0);}}
       style={{
        border: Tab1_Validation_Home(Tab1_Client_Home_var)
        ? "solid 3px #05fc81"
        : "solid 3px red",
        backgroundColor:
        step.id === "Tab1_Client_Home_var" ? "#1B1523" : "#2A3A64",
        }}
      className="btn"
     >
      Client
     </button>

     <button
     style={{
      border: Tab2_Validation_Home(Tab2_Importan_Question_Home_var)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "Tab2_Importan_Question_Home_var" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {navButtonClick(1);}}>Important Questions
    </button>
     
     <button
     style={{
      border: Tab3_Validation_Home(Tab3_Policycore_Home_Var)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "Tab3_Policycore_Home_Var" ? "#02516b" : "#2A3A64",
    }}
    onClick={() => {
      navButtonClick(2);
    }}
    className="btn"
     >Policy Core</button>

     <button
     style={{
      border: Tab4_Validation_Home(Tab4_Building_Home_Var)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "Tab4_Building_Home_Var" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {
      navButtonClick(3);
    }}>Building</button>

     <button
     style={{
      border: Tab5_Validation_Home(
        Tab5_Contents_Home_Var,
        Tab3_Policycore_Home_Var
      )
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "Tab5_Contents_Home_Var" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {
      navButtonClick(4);
    }}>Contents</button>

     <button
     style={{
      border: Tab6_Validation_Home(Tab6_Claims_Home_Var)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "Tab6_Claims_Home_Var" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {
      navButtonClick(5);
    }}>
       Claims
     </button>
    </div>
  );
};

export default navigationBarHome;
