import React, { useEffect, useState } from "react";

const EditQuotation = (props) => {
  const [quotationId, setQuotationId] = useState();

  useEffect(() => {
    //props.match.params.quotation_id;
    console.log(props);
    setQuotationId(props.match.params.quotation_id);
    console.log("quotation edit id: " + quotationId);
  }, [props.match.params.quotation_id, quotationId]);

  return <div>Edit quotation id: {quotationId}</div>;
};

export default EditQuotation;
