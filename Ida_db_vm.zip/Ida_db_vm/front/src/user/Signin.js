import React, { useContext, useState } from "react";
import { Redirect } from "react-router-dom";
import Layout from "../core/Layout";
import { signin, isAuthenticated } from "../auth";
import axios from "axios";
import { API } from "../config";
import {  validateUserEmail, validatePassword } from "./validation";
// import {UserContext} from "../App";
import { AuthContext } from "../context/AuthContext";

//import { useStateWithCallbackLazy } from "use-state-with-callback";
// import {navBarLogo} from "../core/navbarLogo"

const Signin = () => {
  // const {state, dispatch} = useContext(UserContext)
  // const {dispatch , isFetching} = useContext(AuthContext);

  const [values, setValues] = useState({
    email: "",
    password: "",
    loading: false,
    redirectToReferrer: false,
  });

  const [errors, setError] = useState({
    passwordValid: "false",
    emailValid: "false",
  });

  const [loginStatus, setLoginStatus] = useState(false);

  const { email, password, loading, error, redirectToReferrer } = values;
  //const { user } = isAuthenticated();

  const handleChange = (name) => (event) => {
    setValues({ ...values, error: false, [name]: event.target.value });
    validationAfterChange(name, event.target.value);
  };

  // method to validate fields
  const validationAfterChange = (name, value) => {
    switch (name) {
      case "email": {
        validateUserEmail(value, errors, setError);
        break;
      }
      case "password": {
        validatePassword(value, errors, setError);
        break;
      }
    }
  };

  // click submit button method
  const clickSubmit = (event) => {
    event.preventDefault();
    // dispatch({ type:"LOGIN_START"});
    setValues({ ...values, loading: true }); // make loading screen appear
    const user = { userEmail: email, userPassword: password };
    signin(user)
      .then((response) => {
        console.log(response);
        console.log(response.data.user);
        if (response.data.auth) {
          setLoginStatus(true);
          localStorage.setItem("user", JSON.stringify(response.data));
          console.log(JSON.parse(localStorage.getItem("user")));
          setValues({
            ...values,
            redirectToReferrer: true,
          });
        } else {
          console.log(response);
          setLoginStatus(false);
          setValues({
            ...values,
            loading: false,
            error: response.data.message,
          });
        }
      })
      .catch((error) => {
        setLoginStatus(false);
        console.log(error);
      });
  };

  const userAuthenticated = async (event) => {
    event.preventDefault();

    let res = await isAuthenticated();

    console.log(res);
  };

  // const register = (event) => {
  //   event.preventDefault();
  //   console.log("usr: " + email + " pass: " + password);

  //   const data = {
  //     userEmail: email,
  //     password: password,
  //   };

    
  //   axios
  //     .post(`${API}/user/addUser`, data)
  //     .then((response) => {
  //       console.log(response);
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
  // }; // end add user

  const signUpForm = () => (
    <div>
      <form>
        <div className="form-group">
          <label className="text-muted">Email</label>
          <input
            required
            onChange={handleChange("email")}
            type="email"
            className="form-control"
            value={email}
            autoComplete="new-password"
          />
          {errors.email === "Email is required" && (
            <p style={{ color: "orange" }}> {errors.email}</p>
          )}
          {errors.email === "Email is invalid" && (
            <p style={{ color: "red" }}> {errors.email}</p>
          )}
        </div>

        <div className="form-group">
          <label className="text-muted">Password</label>
          <input
            onChange={handleChange("password")}
            type="password"
            className="form-control"
            value={password}
            autoComplete="new-password"
          />
          {errors.password === "Password is required" && (
            <p style={{ color: "orange" }}>{errors.password}</p>
          )}
          {errors.password === "Password must be more than 6 characters" && (
            <p style={{ color: "red" }}>{errors.password}</p>
          )}
        </div>
        <div className="d-flex justify-content-center">
        <button onClick={clickSubmit} className="btn btn-primary rounded" style={{ width: "20%"}}>
          Login
        </button>
        </div>
        {/* <button onClick={register} className="btn mx-2 btn-warning">
          REGISTER
        </button> */}
        {/* <button onClick={sampleAddAddress}>Add address</button> */}
      </form>
      {loginStatus && (
        <button onClick={userAuthenticated}> check if authenticated..</button>
      )}
    </div>
  );

  const showError = () => (
    <div
      className="alert alert-danger"
      style={{ display: error ? "" : "none" }}
    >
      {error}
    </div>
  );

  const showLoading = () =>
    loading && (
      <div className="alert alert-info">
        <h2>Loading...</h2>
      </div>
    );

  const redirectUser = () => {
    if (redirectToReferrer) {
      const userData = JSON.parse(localStorage.getItem("user"));
      const userRole = userData.user.job_title;
      console.log(userRole);

      if (userRole === "admin") {
        return <Redirect to="/admin/dashboard" />;
      } else {
        // dispatch({type:"USER", payload :true})
        return <Redirect to="/user/dashboard" />;
      }
    }
    // if (isAuthenticated()) {
    //   return <Redirect to='/' />;
    // }
  };

const signinHeader = () => {
  return (
  <Layout
      title="Welcome"
      description="Broker Login to Jarvis"
      className="container col-md-6 offset-md-3"
    >
      {showLoading()}
      {showError()}
      {signUpForm()}
      {redirectUser()}
     
    </Layout>
  );
};

  return (
    
      <div>
      {/* {navBarLogo()} */}
      {signinHeader()}
      </div>
  );
};

export default Signin;
