export const validation = (values) => {
  let error = {};

  if (!values.email) {
    error.email = "Email is required";
    error.emailValid = false;
  } else if (!/\S+@\S+\.\S+/.test(values.email)) {
    error.email = "Email is invalid";
    error.emailValid = false;
  } else {
    error.emailValid = true;
  }
  if (!values.password) {
    error.password = "Password is required";
    error.passwordValid = false;
  } else if (values.password.length < 6) {
    error.password = "Password must be more than 6 characters";
    error.passwordValid = false;
  } else {
    error.passwordValid = true;
  }
  return error;
};

export const validateUserEmail = (value, errors, setError) => {
  if (value === null || value === "") {
    setError({
      ...errors,
      email: "Email is required",
    });
  } else if (!/\S+@\S+\.\S+/.test(value)) {
    setError({
      ...errors,
      email: "Email is invalid",
    });
  } else {
    setError({
      ...errors,
      email: "true",
    });
  }
};

export const validatePassword = (value, errors, setError) => {
  if (value === null || value === "") {
    setError({
      ...errors,
      password: "Password is required",
    });
  } else if (value.length < 6) {
    setError({
      ...errors,
      password: "Password must be more than 6 characters",
    });
  } else {
    setError({
      ...errors,
      password: "true",
    });
  }
};
