import React, { useState, useEffect } from "react";
// import { Redirect } from "react-router-dom";
import { isAuthenticated,signout } from "../auth";
import { Link } from "react-router-dom";
import axios from "axios";
import { API } from "../config";
import Menu from "../core/Menu";
import { Button, Grid } from "@material-ui/core";
import { Table } from "react-bootstrap";
import "../css/homeStyle.css";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { confirmAlert } from 'react-confirm-alert'; 
import 'react-confirm-alert/src/react-confirm-alert.css';
import history from "../auth/history";

const DashBoardforLand = () => {
    const [quotationList, setQuotationList] = useState([]);
    const [verifiedQuotation, setVerifiedQuotation] = useState(0);
    const [pendingQuotation, setPendingQuotation] = useState(0);
    const [submitQuotation, setSubmitQuotation] = useState(0);
    //const [user, setUser] = useState({});
    const [name, setName] = useState();
    const [email, setEmail] = useState();
    let loaded = false;
    let userName = "";
    let tokenError = false;

    const notify = () =>
    toast.success("Submission Status: Success!", {
      position: "bottom-center",
      autoClose: 1000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });

  const notifyFailure = () =>
    toast.error("Submission Status: Failed!", {
      position: "bottom-center",
      autoClose: 1000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
    const tokenErrorMessage = (tokenError) => {
        return(
        <div>
          {tokenError === true && (
          confirmAlert({
            title: 'Invalid User',
            message: 'Re-login to system.',
            buttons: 
            [
              {
                label: 'Login',
                onClick: () => {
                  signout(() => {
                    history.push("/login");
                  });              
                  
                }
              },
              // {
              //   label: 'No',
              //   onClick: () => null
              // }
            ]
          })
        )}</div>
        );
      }
    
      useEffect(() => {
        if (!loaded) {
          isAuthenticated()
            .then((res) => {
              loaded = true;
              userName = res.user.name;
              setEmail(res.user.email);
              setName(userName);
            })
            .catch((error) => {
              console.log(error);
            });
        }
    
        if (quotationList.length === 0) {
        //   console.log(email);
          if (email !== undefined) {
           
                const token_value = JSON.parse(localStorage.getItem("user"));  
                // console.log(token_value);        
            axios.get(`${API}/quotationLandlords/getQuotationsLand?userEmail=` + email,
              { 
                headers: token_value
              })
              .then((res) => {
                // console.log(res);
                
                if(res.data.message){
                  console.log("Error in token");
                  tokenError = true;
                  tokenErrorMessage(tokenError);
                }else{
                // ******************   has to check whether it is ZERO ************************************
                let penCount = res.data.pendingQuotation[0].pendingCount;
                let verCount = res.data.verifiedQuotation[0].verifiedCount;
                let subCount = res.data.submittedQuotation[0].submittedCount;
                // console.log(response.getQuotation);
                setQuotationList(res.data.getQuotation);
                setPendingQuotation(penCount);
                setVerifiedQuotation(verCount);
                setSubmitQuotation(subCount);
               
                }
              })
              .catch((err) => {
                console.log(err);
              });
          }
        }
      });
  // ui content: that will display the counts of quotations statusses
  const countBar = () => {
    return (
      <Grid container spacing={2} className="px-4">
        <Grid item xs={3}></Grid>
        <Grid item xs={2}>
          <div
            className="p-3 my-3 d-flex justify-content-center"
            style={{
              backgroundColor: "#207996",
              color: "white",
              borderRadius: "5px",
            }}
          >
            <div>
              <div>
                <h5>Pending: {pendingQuotation}</h5>
              </div>
            </div>
          </div>
        </Grid>
        
        {/* <Grid item xs={1}></Grid> */}
        
        <Grid item xs={2}>
          <div
            className="p-3 my-3 d-flex justify-content-center"
            style={{
              backgroundColor: "#207996",
              color: "white",
              borderRadius: "5px",
            }}
          >
            <div>
              <div>
                <h5>Verified: {verifiedQuotation} </h5>
              </div>
            </div>
          </div>
        </Grid>

        {/* <Grid item xs={1}></Grid> */}

        <Grid item xs={2}>
          <div
            className="p-3 my-3 d-flex justify-content-center"
            style={{
              backgroundColor: "#207996",
              color: "white",
              borderRadius: "5px",
            }}
          >
            <div>
              <div>
                <h5>Submitted: {submitQuotation}</h5>
              </div>
            </div>
          </div>
        </Grid>

        <Grid item xs={3}></Grid>
      </Grid>
    );
  };

  const onClickSubmit = async (quotationId) => {
    console.log("submitted id: " + quotationId);
    console.log(JSON.parse(localStorage.getItem("user")));
    return await axios
      .post(`${API}/automation/submitLand?quotationId=` + quotationId,
      {
        headers: JSON.parse(localStorage.getItem("user"))
      })
      .then((res) => {
        console.log(res.data);

        if(res.data){
          setTimeout(function () {
            window.location.reload(true);
          }, 1000);
          notify();
          
        }else{
          notifyFailure();
        }

        if(res.data.message){
          console.log("Error in token");
          tokenError = true;
          tokenErrorMessage(tokenError);
        }else{
          console.log("Valid token for submit data to UI path");
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };
  // ui content: display quotation details in a table
  const quotationTable = () => {
    return (
     
        <div
        className="container p-3 my-2 overflow-auto " 
        // style={{ backgroundColor: "#d1d1e0", borderRadius: "5px" }}
        // style={{ overFlow:"auto"}}
        style={{ maxHeight: "500px" }}
      >
            
        <Table striped bordered hover size="lg" className="table-border" variant="dark">
          <thead>
            <tr style={{ textAlign: "center"}}>
              <th style={{ width: "10%" }}>ID</th>
              <th style={{ width: "10%" }}>Code</th>
              <th style={{ width: "10%" }}>Type</th>
              <th style={{ width: "20%" }}>Name</th>
              <th style={{ width: "15%" }}>Client Type</th>
              <th style={{ width: "15%" }}>Status</th>
              <th style={{ width: "20%" }}>Options</th>
            </tr>
          </thead>
          <tbody>
            {quotationList.map((val) => {
              if (val.quotation_type !== "Completed") {
                return (
                  <tr
                    key={val.quotation_id}
                    style={{ height: "50px", textAlign: "center" }}
                    
                  >
                    <td> {val.quotation_id} </td>
                    {val.client_code_landlord === null ? (
                      <td style={{ color: "green" }}>
                        <h6>NEW</h6>
                      </td>
                    ) : (
                      <td>{val.client_code_landlord}</td>
                    )}

                    <td>{val.quotation_type}</td>
                    {val.client_type === "Individual" ? (
                      <td>
                        {val.client_firstName} {val.client_lastName}
                      </td> 
                    ) : (
                      <td>{val.company_name}</td>
                    )}

                    <td> {val.client_type}</td>
                    <td> {val.quotation_status} </td>
                    <td>
                      {/* {val.quotation_status === "Pending" ? (
                        <Link to={`/user/editLandPage/${val.quotation_id}`}>
                          <Button
                            size="small"
                            variant="contained"
                            color="primary"
                            className="mx-2"
                            style={{width:"10%"}}
                          >
                            EDIT
                          </Button>
                        </Link>
                      ) : (
                        <Button
                          size="small"
                          // disabled
                          variant="outlined"
                          color="primary"
                          className="mx-2 button-disable"
                          style={{width:"10%"}}
                        >
                          EDIT
                        </Button>
                      )} */}

                    
                        <Link to={`/user/editLandPage/${val.quotation_id}`}>
                          <Button
                            size="small"
                            variant="contained"
                            color="primary"
                            className="mx-2"
                            style={{width:"10%"}}
                          >
                            EDIT
                          </Button>
                        </Link>
                      
                      {val.quotation_status === "Verified" ? (
                        <Button
                          size="small"
                          className="mx-2"
                          onClick={() => {
                            onClickSubmit(val.quotation_id);
                          }}
                          color="secondary"
                          variant="contained"
                          style={{width:"10%"}}
                        >
                          SUBMIT
                        </Button>
                      ) : (
                        <Button
                          size="small"
                          className="mx-2 button-disable"
                          variant="outlined"
                          color="secondary"
                          style={{width:"10%"}}
                          // disabled
                        >
                          SUBMIT
                        </Button>
                      )}
                      
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </Table>
      </div>
    );
  };
  // return: component return content
  return (
    <div>
      {/* <Menu name={name} /> */}
      <div>
        {countBar()}
        {/* {sampleButton()} */}
        {quotationTable()}
        <ToastContainer style={{ marginLeft:"50px", marginBottom:"-25px", width:"30%"}}/>
      </div>
    </div>
  );
}
export default DashBoardforLand;