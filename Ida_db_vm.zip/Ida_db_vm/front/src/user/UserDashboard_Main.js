import React from "react";
// import { makeStyles } from "@material-ui/core/styles";
// import { Link } from "react-router-dom";
// import "../css/homeStyle.css";
// import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
// import { Navbar } from "react-bootstrap";
// import logo from "../images/logo.png";
// import { Button } from "@material-ui/core";
import "../pages/landingPage.css"

const ClientHome = () => {
  
  const clientHomeContent = () => {
    return (
      
      
    //   <div className="showcase-area">
    //      <div className="container">
    //        <div className="left">
    //          <div className="big-title">
    //         <h1>Insurance Quotation</h1>
           
    //          </div>
    //          <p className="text">
    //           Please choose the type of Insurance Quotation that you need to modify from the options below
    //          </p>
    //       <div className="cta">
    //         <a href="#/user/dashboard_home" className="btn">Modify Home & Contents Insurance</a>
    //         <a href="#/user/dashboard_motor" className="btn">Modify Personal Motor Insurance</a>
    //         <a href="#/user/dashboardLandlords" className="btn">Modify Landlords Insurance</a>
    //       </div>
    //     </div>

    //     <div className="right">
    //       <img src={require("../images/insure.png")} alt="insurance" className="insurance" />
    //     </div>
    //   </div>
    // </div>
    <section className="hero" id="hero">
        <div className="container">

          <div className="hero-content">
            <h1 className="h1 hero-title">Insurance Quotation</h1>

            <p className="hero-text">
            Please choose the type of Insurance Quotation that you need to modify from the options below
            </p>

            <div className="btnGroup">
                 <a href="#/user/dashboard_home" className="btnContent">Modify Home & Contents Insurance</a>
                 <a href="#/user/dashboard_motor" className="btnContent">Modify Personal Motor Insurance</a>
                 <a href="#/user/dashboardLandlords" className="btnContent">Modify Landlords Insurance</a>
              
            </div>

          </div>

          <figure className="hero-banner">
            <img src={require("../images/insure.png")} alt="Insurance"/>
          </figure>

        </div>
      </section>
    );
  };

  return (
    <div>
    
      {clientHomeContent()}
    </div>
  );
};

export default ClientHome;
