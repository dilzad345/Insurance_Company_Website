import React from "react";
import "../css/homeStyle.css";
// import Footer from "../component/footer/Footer";
// import Footer from "../component/footer/Footer";
import "../css/page.css";
import {
  TextField,
  Container,
  Button,
  Select,
  InputLabel,
  MenuItem,
  Grid,
  Box,
} from "@material-ui/core";
import { streetTypes, stateAus } from "../constants/dropDownData";
import { Autocomplete } from "@mui/material";
import { exit } from "../constants/exit";
import { validationForSpecialchar ,inpTextwithSpace , inpNum } from "../constants/validChecker";

import DatePicker from "react-datepicker";
import {
  originalYearBuilt_validate,
  provideDetails_validate,
  streetNumber_validate,
  streetName_validate,
  streetType_validate,
  suburb_validate,
  state_validate,
  postCode_validate,
} from "../validationHome/Tab4_Validation_Home";

/* const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    alignContent: "center",
    padding: theme.spacing(2),
    //textAlign: 'center',
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary,
  },

  // bg_color: {
  //   backgroundColor: "#f0f0f5",
  //   marginBottom: "5px",
  // },
})); */

/* const returnClientHome = () => {
  return <Redirect to='/client_home' />
} */

const Tab4_Building_Home = ({
  Tab4_Building_Home_Var,
  setTab4,
  Tab4_Validation_Home_Var,
  setTab4_validation,
  Tab1_Client_Home_var,
  navigation,
}) => {
  // const classes = useStyles();

  const onChangeField = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    console.log(value);
    setTab4(
      {
        ...Tab4_Building_Home_Var,
        [name]: value,
      },
      () => {
        validationAfterChange(name, value);
      }
    );
  };

  //for preventing from typing
  const handleDateChangeRaw = (e) => {
    e.preventDefault();
  };
  const setStreetType = (val) => {
    console.log("val", val);
    // console.log(i);
    // console.log(streetType[0]);
    //  let name = e.target.name;
    let name = "street_type_insured";
    if (val) {
      let value = val.group;
      setTab4(
        {
          ...Tab4_Building_Home_Var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    } else {
      let value = " ";
      setTab4(
        {
          ...Tab4_Building_Home_Var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    }
  };

  //set state for Aus
  const setStateAus = (val, event) => {
    console.log(val);
    if (val) {
      let name = "state_insured";
      let value = val.stAus;
      console.log(value);
      setTab4(
        {
          ...Tab4_Building_Home_Var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    } else {
      let name = "state_insured";
      let value = " ";
      setTab4(
        {
          ...Tab4_Building_Home_Var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    }
    //  console.log(event);
  };

  // method: to changeYearOnly
  const changeYearOnly = (date) => {
    console.log("date: ", date);
    let name = "originalYearBuilt";
    let str_date = date.toLocaleDateString();
    let value = str_date.substring(str_date.length - 4);
    console.log("date: ", str_date);
    console.log("date: ", value);

    setTab4(
      {
        ...Tab4_Building_Home_Var,
        [name]: value,
      },
      () => {
        validationAfterChange(name, value);
        //checkYearDiff(value);
      }
    );
  };

  //console.log(Tab4_Building_Home_Var.originalYearBuilt);
  // method to check years different
  const checkYearDiff = () => {
    // console.log("hi")
    let selectYearInt = parseInt(Tab4_Building_Home_Var.originalYearBuilt);
    let currentYear = new Date().toLocaleDateString();
    let currentYearStr = currentYear.substring(currentYear.length - 4);
    let currentYearInt = parseInt(currentYearStr);
    let yearDiff = currentYearInt - selectYearInt;
    // if (yearDiff < 4) {
    //   return yearDiff;
    //   // return true;
    // }
    // else if(yearDiff >50){
    //   return yearDiff;
    //   // return true;
    // }
    // else {
    //   return yearDiff;
    //   // return false;
    // }
    return yearDiff;
  }; // end of method

  const validationAfterChange = (name, value) => {
    if (name === "prptyHeritageList") {
      if (value === "No") {
        setTab4({
          ...Tab4_Building_Home_Var,
          prptyHeritageList: "No",
          provideDetails: "",
        });
      }
    }

    if (name === "smhAcres20000") {
      if (value === "No") {
        setTab4({
          ...Tab4_Building_Home_Var,
          smhAcres20000: "No",
          insuredGenerateIncome: "",
          machineryImplmtVehicles: "",
          more6Livestock: "",
          propertyUsedAnimals: "",
          nonPersonalUse: "",
          aircraftLandingStrip: "",
        });
      }
    }
    // if (name === "buildingType") {

    //   if (value === "Free Standing / House" || "Townhouse" || "Display Home") {

    //     setTab4({

    //       ...Tab4_Building_Home_Var,

    //       buildingType: value,

    //       whatTypeApartment: "",

    //       whatTypeSemiDetached: "",

    //       managemenBodyCorporate: "",

    //       dwellingDescribesHome: "",

    //       unitBuildingLevel: "",
    //     });
    //   }
    // }
    // if (name === "buildingType") {

    //   if (value === "Apartment / Unit (Ground Floor" || "Apartment / Unit (Above Ground Floor)") {

    //     setTab4({

    //       ...Tab4_Building_Home_Var,

    //       buildingType: "Apartment / Unit (Ground Floor" || "Apartment / Unit (Above Ground Floor)",

    //       whatBuiltHome: "",

    //       whatTypeSemiDetached: "",

    //       dwellingDescribesHome: "",
    //     });

    //   }

    // }
    // if (name === "buildingType") {

    //   if (value === "Semi-Detached / Terrace") {

    //     setTab4({

    //       ...Tab4_Building_Home_Var,

    //       buildingType: "Semi-Detached / Terrace",

    //       whatBuiltHome: "",

    //       whatTypeApartment: "",

    //       dwellingDescribesHome: "",

    //       unitBuildingLevel: "",
    //     });

    //   }

    // }
    // if (name === "buildingType") {

    //   if (value === "Other") {

    //     setTab4({

    //       ...Tab4_Building_Home_Var,

    //       buildingType: value,

    //       whatBuiltHome: "",

    //       whatTypeApartment: "",

    //       whatTypeSemiDetached: "",

    //       managemenBodyCorporate: "",

    //       unitBuildingLevel: "",

    //     });

    //   }

    // }
    switch (name) {
      case "streetNumber_insured": {
        streetNumber_validate(
          value,
          Tab4_Validation_Home_Var,
          setTab4_validation
        );
        break;
      }
      case "street_type_insured": {
        streetType_validate(
          value,
          Tab4_Validation_Home_Var,
          setTab4_validation
        );
        break;
      }
      case "street_name_insured": {
        streetName_validate(
          value,
          Tab4_Validation_Home_Var,
          setTab4_validation
        );
        break;
      }
      case "suburb_insured": {
        suburb_validate(value, Tab4_Validation_Home_Var, setTab4_validation);
        break;
      }
      case "state_insured": {
        state_validate(value, Tab4_Validation_Home_Var, setTab4_validation);
        break;
      }
      case "postcode_insured": {
        postCode_validate(value, Tab4_Validation_Home_Var, setTab4_validation);
        break;
      }
      case "provideDetails": {
        provideDetails_validate(
          value,
          Tab4_Validation_Home_Var,
          setTab4_validation
        );
        break;
      }
      case "originalYearBuilt": {
        originalYearBuilt_validate(
          value,
          Tab4_Validation_Home_Var,
          setTab4_validation
        );
        break;
      }
      default: {
        console.log("Not match to condition");
      }
    }
  };

  return (
    <div>
      <Container maxWidth="md" style={{ marginBottom: "30px" }}>
        <div>
          <Grid
            container
            spacing={3}
            direction="row"
            justifyContent="center"
            alignItems="center"
          >
            <Grid
              item={true}
              xs={12}
              container
              style={{ marginTop: "25px" }}
              justifyContent="center"
            >
              <h3>BUILDING INFORMATION</h3>
            </Grid>

            {/* Is insured address the same as Postal Address */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor=" Is the property heritage listed?"
                style={{ marginBottom: "5px" }}
                required
              >
                Is insured address the same as Postal Address?
              </InputLabel>
            </Grid>
            <Grid item xs={6}>
              <Select
                name="insuredAddress"
                margin="none"
                variant="outlined"
                onChange={onChangeField}
                value={Tab4_Building_Home_Var.insuredAddress}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
            </Grid>

            {Tab4_Building_Home_Var.insuredAddress === "Yes" && (
              <Grid>
                {/* box component */}
                <Box
                  component="span"
                  sx={{
                    width: "100%",
                    // height: 00,
                    p: 4,
                    // alignItems: '',
                    borderRadius: 8,
                    border: "1px solid grey",
                    display: "flex",
                    flexWrap: "wrap",
                    // alignItems:'center',
                    justifyContent: "space-between",
                    flexDirection: "row",
                  }}
                  m={2}
                  pt={3}
                >
                  <Grid item xs={12} justifyContent="center" container>
                    <Box
                      sx={{
                        border: "1px solid grey",
                        borderRadius: 8,
                        padding: "6px 8px 0px 7px",
                        // alignItems:'center',
                        // alignContent:'center',
                        margin: "0px 0px 10px 2px",
                        justifyContent: "center",
                      }}
                    >
                      <h5>INSURED ADDRESS</h5>
                    </Box>
                  </Grid>

                  {/* Unit Number */}
                  <Grid item xs={4} style={{ padding: "8px" }}>
                    <TextField
                      label="Unit Number (not req for PO Box)"
                      name="unitNumber"
                      size="small"
                      type="text"
                      // margin="normal"
                      variant="outlined"
                      autoComplete="off"
                      disabled
                      onChange={onChangeField}
                      onKeyPress={(e) => validationForSpecialchar(e)}
                      value={Tab1_Client_Home_var.unitNumber}
                      style={{ width: "100%" }}
                      InputLabelProps={{ style: { fontSize: 15 } }}
                      fullWidth
                    />
                  </Grid>
                  {/* Street Number */}
                  <Grid item xs={4} style={{ padding: "8px" }}>
                    <TextField
                      // label="Street Number (not req for PO Box)"
                      name="streetNumber"
                      label="Street Number"
                      size="small"
                      type="text"
                      variant="outlined"
                      autoComplete="new-password"
                      // onChange={onChangeField}
                      disabled
                      // onKeyPress={(e) => validationForSpecialchar(e)}
                      value={Tab1_Client_Home_var.streetNumber}
                      style={{ width: "100%" }}
                      required
                      fullWidth
                      InputLabelProps={{ style: { fontSize: 15 } }}
                    />
                  </Grid>

                  <Grid item xs={4} style={{ padding: "8px" }}>
                    <TextField
                      // label="Street Name (or PO Box)"
                      name="streetName"
                      size="small"
                      disabled
                      label="Street Name"
                      variant="outlined"
                      autoComplete="new-password"
                      // onChange={onChangeField}
                      value={Tab1_Client_Home_var.streetName}
                      style={{ width: "100%" }}
                      required
                      fullWidth
                      InputLabelProps={{ style: { fontSize: 15 } }}
                    />
                  </Grid>

                  {/* Street Type */}
                  <Grid item xs={4} style={{ padding: "8px" }}>
                    <Autocomplete
                      options={streetTypes}
                      sx={{ width: "100%" }}
                      isOptionEqualToValue={(option, value) =>
                        option.id === value.id
                      }
                      getOptionLabel={(option) =>
                        option.group
                          ? option.group
                          : Tab1_Client_Home_var.streetType
                      }
                      defaultValue={"please Select"}
                      disabled
                      name="streetType"
                      // onChange={(event, value) => setStreetType(value)}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          variant="outlined"
                          value={Tab1_Client_Home_var.streetType}
                          label="Street Type"
                          required
                          inputProps={{
                            ...params.inputProps,
                            style: { padding: "1px 0" },
                          }}
                        />
                      )}
                    />
                  </Grid>

                  {/* Suburb */}
                  <Grid item xs={4} style={{ padding: "8px" }}>
                    <TextField
                      // label="Suburb"
                      name="suburb"
                      size="small"
                      style={{ width: "100%" }}
                      label="Suburb"
                      variant="outlined"
                      disabled
                      // onChange={onChangeField}
                      autoComplete="new-password"
                      value={Tab1_Client_Home_var.suburb}
                      required
                      fullWidth
                      InputLabelProps={{ style: { fontSize: 15 } }}
                    />
                    {/* {Tab1_Validation_Home_Var.suburb !== null &&
                    Tab1_Validation_Home_Var.suburb !== "true" && (
                      <div className="text-danger font-italic">{ }
                        {Tab1_Validation_Home_Var.suburb}
                      </div>
                    )} */}
                  </Grid>

                  {/* State */}
                  <Grid item xs={4} style={{ padding: "8px" }}>
                    <Autocomplete
                      options={stateAus}
                      sx={{ width: "100%" }}
                      isOptionEqualToValue={(option, value) =>
                        option.id === value.id
                      }
                      getOptionLabel={(option) =>
                        option.stAus ? option.stAus : Tab1_Client_Home_var.state
                      }
                      disabled
                      defaultValue={"Please Select"}
                      name="state"
                      // onChange={(event, value) => setStateAus(value, event)}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          variant="outlined"
                          fullWidth
                          value={Tab1_Client_Home_var.state}
                          label="State"
                          required
                          inputProps={{
                            ...params.inputProps,
                            style: { padding: "1px 0" },
                          }}
                        />
                      )}
                    />

                    {/* {Tab1_Validation_Home_Var.state !== null &&
                    Tab1_Validation_Home_Var.state !== "true" && (
                      <div className="text-danger font-italic">{ }
                        {Tab1_Validation_Home_Var.state}
                      </div>
                    )} */}
                  </Grid>

                  {/* Post Code */}
                  <Grid item xs={4} style={{ padding: "8px" }}>
                    <TextField
                      name="postCode"
                      size="small"
                      style={{ width: "100%" }}
                      variant="outlined"
                      type="number"
                      label="PostCode"
                      autoComplete="new-password"
                      disabled
                      // onChange={onChangeField}
                      value={Tab1_Client_Home_var.postCode}
                      required
                      fullWidth
                      InputLabelProps={{ style: { fontSize: 15 } }}
                    />

                    {/* {Tab1_Validation_Home_Var.postCode !== null &&
                    Tab1_Validation_Home_Var.postCode !== "true" && (
                      <div className="text-danger font-italic">{ }
                        {Tab1_Validation_Home_Var.postCode}
                      </div>
                    )} */}
                  </Grid>
                </Box>
              </Grid>
            )}

            {Tab4_Building_Home_Var.insuredAddress === "No" && (
              <Grid>
                {/* box component */}
                <Box
                  component="span"
                  sx={{
                    width: "100%",
                    p: 4,
                    borderRadius: 8,
                    border: "1px solid grey",
                    display: "flex",
                    flexWrap: "wrap",
                    justifyContent: "space-between",
                    flexDirection: "row",
                  }}
                  m={2}
                  pt={3}
                >
                  <Grid item xs={12} justifyContent="center" container>
                    <Box
                      sx={{
                        border: "1px solid grey",
                        borderRadius: 8,
                        padding: "6px 8px 0px 7px",
                        margin: "0px 0px 10px 2px",
                        justifyContent: "center",
                      }}
                    >
                      <h5>INSURED ADDRESS</h5>
                    </Box>
                  </Grid>

                  {/* Street Number */}
                  <Grid item xs={4} style={{ padding: "8px" }}>
                    <TextField
                      name="streetNumber_insured" //this value is should be passed into value field otherwise we cannot type
                      label="Street Number"
                      size="small"
                      type="text"
                      variant="outlined"
                      autoComplete="off"
                      onChange={onChangeField}
                      onKeyPress={(e) => validationForSpecialchar(e)}
                      value={Tab4_Building_Home_Var.streetNumber_insured}
                      style={{ width: "100%" }}
                      required
                      fullWidth
                    />
                    {Tab4_Validation_Home_Var.streetNumber_insured !== null &&
                      Tab4_Validation_Home_Var.streetNumber_insured !==
                        "true" && (
                        <div className="text-danger font-italic">
                          {Tab4_Validation_Home_Var.streetNumber_insured}
                        </div>
                      )}
                  </Grid>

                  {/* Street Name */}
                  <Grid item xs={4} style={{ padding: "8px" }}>
                    <TextField
                      name="street_name_insured"
                      size="small"
                      label="Street Name"
                      variant="outlined"
                      autoComplete="off"
                      onChange={onChangeField}
                      onKeyPress={(e) => inpTextwithSpace(e)}
                      value={Tab4_Building_Home_Var.street_name_insured}
                      style={{ width: "100%" }}
                      required
                      fullWidth
                    />
                    {Tab4_Validation_Home_Var.street_name_insured !== null &&
                      Tab4_Validation_Home_Var.street_name_insured !==
                        "true" && (
                        <div className="text-danger font-italic">
                          {Tab4_Validation_Home_Var.street_name_insured}
                        </div>
                      )}
                  </Grid>
                  {/* Street Type */}
                  <Grid item xs={4} style={{ padding: "8px" }}>
                    <Autocomplete
                      options={streetTypes}
                      sx={{ width: "100%" }}
                      isOptionEqualToValue={(option, value) =>
                        option.id === value.id
                      }
                      getOptionLabel={(option) =>
                        option.group
                          ? option.group
                          : Tab4_Building_Home_Var.street_type_insured
                      }
                      defaultValue={"please Select"}
                      name="street_type_insured"
                      onChange={(event, value) => setStreetType(value)}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          variant="outlined"
                          value={Tab4_Building_Home_Var.street_type_insured}
                          label="Street Type"
                          required
                          inputProps={{
                            ...params.inputProps,
                            style: { padding: "1px 0" },
                          }}
                        />
                      )}
                    />
                    {Tab4_Validation_Home_Var.street_type_insured !== null &&
                      Tab4_Validation_Home_Var.street_type_insured !==
                        "true" && (
                        <div className="text-danger font-italic">
                          {Tab4_Validation_Home_Var.street_type_insured}
                        </div>
                      )}
                  </Grid>

                  {/* Suburb */}
                  <Grid item xs={4} style={{ padding: "8px" }}>
                    <TextField
                      name="suburb_insured"
                      size="small"
                      style={{ width: "100%" }}
                      label="Suburb"
                      variant="outlined"
                      onChange={onChangeField}
                      onKeyPress={(e) => inpTextwithSpace(e)}
                      autoComplete="off"
                      value={Tab4_Building_Home_Var.suburb_insured}
                      required
                      fullWidth
                    />
                    {Tab4_Validation_Home_Var.suburb_insured !== null &&
                      Tab4_Validation_Home_Var.suburb_insured !== "true" && (
                        <div className="text-danger font-italic">
                          {}
                          {Tab4_Validation_Home_Var.suburb_insured}
                        </div>
                      )}
                  </Grid>

                  {/* State */}
                  <Grid item xs={4} style={{ padding: "8px" }}>
                    <Autocomplete
                      options={stateAus}
                      sx={{ width: "100%" }}
                      isOptionEqualToValue={(option, value) =>
                        option.id === value.id
                      }
                      getOptionLabel={(option) =>
                        option.stAus
                          ? option.stAus
                          : Tab4_Building_Home_Var.state_insured
                      }
                      defaultValue={"Please Select"}
                      name="state_insured"
                      onChange={(event, value) => setStateAus(value, event)}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          variant="outlined"
                          fullWidth
                          value={Tab4_Building_Home_Var.state_insured}
                          label="State"
                          required
                          inputProps={{
                            ...params.inputProps,
                            style: { padding: "1px 0" },
                          }}
                        />
                      )}
                    />
                    {Tab4_Validation_Home_Var.state_insured !== null &&
                      Tab4_Validation_Home_Var.state_insured !== "true" && (
                        <div className="text-danger font-italic">
                          {}
                          {Tab4_Validation_Home_Var.state_insured}
                        </div>
                      )}
                  </Grid>

                  {/* Post Code */}
                  <Grid item xs={4} style={{ padding: "8px" }}>
                    <TextField
                      name="postcode_insured"
                      size="small"
                      style={{ width: "100%" }}
                      variant="outlined"
                      type="number"
                      label="PostCode"
                      autoComplete="off"
                      onChange={onChangeField}
                      onKeyPress={(e) => inpNum(e)}
                      value={Tab4_Building_Home_Var.postcode_insured}
                      required
                      fullWidth
                    />
                    {Tab4_Validation_Home_Var.postcode_insured !== null &&
                      Tab4_Validation_Home_Var.postcode_insured !== "true" && (
                        <div className="text-danger font-italic">
                          {}
                          {Tab4_Validation_Home_Var.postcode_insured}
                        </div>
                      )}
                  </Grid>
                </Box>
              </Grid>
            )}
            {/* Policyholder Retired */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor=" Is the property heritage listed?"
                style={{ marginBottom: "5px" }}
                required
              >
                Is the property heritage listed?
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="prptyHeritageList"
                margin="none"
                variant="outlined"
                onChange={onChangeField}
                value={Tab4_Building_Home_Var.prptyHeritageList}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
            </Grid>

            {/* If heritage listed, please provide more details? */}
            {Tab4_Building_Home_Var.prptyHeritageList === "Yes" && (
              <Grid container xs={12} direction="row" spacing={2}>
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="If heritage listed, please provide more details?"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    If heritage listed, please provide more details?
                  </InputLabel>
                </Grid>

                <Grid item xs={6}>
                  <TextField
                    name="provideDetails"
                    size="small"
                    variant="outlined"
                    autoComplete="off"
                    onChange={onChangeField}
                    value={Tab4_Building_Home_Var.provideDetails}
                    // style={{ marginBottom: "20px" }}
                    fullWidth
                  />
                  {Tab4_Validation_Home_Var.provideDetails !== null &&
                    Tab4_Validation_Home_Var.provideDetails !== "true" && (
                      <div className="text-danger font-italic">
                        {Tab4_Validation_Home_Var.provideDetails}
                      </div>
                    )}
                </Grid>
              </Grid>
            )}

            {/* What is the occupancy of the home? */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="What is the occupancy of the home?"
                style={{ marginBottom: "5px" }}
                required
              >
                What is the occupancy of the home?
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="whatOccupancyHome"
                margin="none"
                variant="outlined"
                onChange={onChangeField}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                value={Tab4_Building_Home_Var.whatOccupancyHome}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Rent/Lease">Rent/Lease</MenuItem>
                <MenuItem value="Owner Occupied">Owner Occupied</MenuItem>
                <MenuItem value="Holiday Home">Holiday Home</MenuItem>
              </Select>
            </Grid>

            {/*Building Type*/}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Building Type"
                style={{ marginBottom: "25px" }}
                required
              >
                Building Type
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="buildingType"
                margin="none"
                variant="outlined"
                onChange={onChangeField}
                style={{
                  marginBottom: "30px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                value={Tab4_Building_Home_Var.buildingType}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Free Standing / House">
                  Free Standing / House
                </MenuItem>
                <MenuItem value="Townhouse">Townhouse </MenuItem>
                <MenuItem value="Apartment / Unit (Ground Floor)">
                  Apartment / Unit (Ground Floor)
                </MenuItem>
                <MenuItem value="Apartment / Unit (Above Ground Floor)">
                  Apartment / Unit (Above Ground Floor)
                </MenuItem>
                <MenuItem value="Display Home">Display Home</MenuItem>
                <MenuItem value="Semi-Detached / Terrace">
                  Semi-Detached / Terrace
                </MenuItem>
                <MenuItem value="Other">Other</MenuItem>
              </Select>
            </Grid>

            {/*If Free Standing Home, what is it built on*/}
            {(Tab4_Building_Home_Var.buildingType === "Free Standing / House" ||
              Tab4_Building_Home_Var.buildingType === "Townhouse" ||
              Tab4_Building_Home_Var.buildingType === "Display Home") && (
              <Grid container item={true} xs={12} direction="row" spacing={2}>
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="If Free Standing Home, what is it built on"
                    style={{ marginBottom: "5px", marginLeft: "-10px" }}
                    required
                  >
                    If Free Standing Home, what is it built on
                  </InputLabel>
                </Grid>

                <Grid item xs={6}>
                  <Select
                    name="whatBuiltHome"
                    margin="none"
                    variant="outlined"
                    onChange={onChangeField}
                    style={{
                      marginBottom: "30px",
                      height: "40px",
                      marginLeft: "9px",
                      width: "450px",
                    }}
                    fullWidth
                    value={Tab4_Building_Home_Var.whatBuiltHome}
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    <MenuItem value="Concrete slab">Concrete slab</MenuItem>
                    <MenuItem value="Foundations">Foundations </MenuItem>
                    <MenuItem value="Poles">Poles</MenuItem>
                  </Select>
                </Grid>
              </Grid>
            )}

            {/*If an Apartment, what type of Apartment*/}
            {(Tab4_Building_Home_Var.buildingType ===
              "Apartment / Unit (Ground Floor)" ||
              Tab4_Building_Home_Var.buildingType ===
                "Apartment / Unit (Above Ground Floor)") && (
              <Grid container xs={12} direction="row" spacing={2}>
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="If an Apartment, what type of Apartment"
                    style={{ marginBottom: "20px" }}
                    required
                  >
                    If an Apartment, what type of Apartment
                  </InputLabel>
                </Grid>

                <Grid item xs={6}>
                  <Select
                    name="whatTypeApartment"
                    margin="none"
                    variant="outlined"
                    onChange={onChangeField}
                    style={{
                      marginBottom: "40px",
                      height: "40px",
                      marginLeft: "8px",
                      width: "450px",
                    }}
                    fullWidth
                    value={Tab4_Building_Home_Var.whatTypeApartment}
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    <MenuItem value="Ground floor">Ground floor</MenuItem>
                    <MenuItem value="Mid floor">Mid floor </MenuItem>
                    <MenuItem value="Top floor">Top floor</MenuItem>
                  </Select>
                </Grid>
              </Grid>
            )}

            {/*If Semi-Detached, what type of Semi-Detached*/}
            {Tab4_Building_Home_Var.buildingType ===
              "Semi-Detached / Terrace" && (
              <Grid container xs={12} direction="row" spacing={2}>
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="If Semi-Detached, what type of Semi-Detached"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    If Semi-Detached, what type of Semi-Detached
                  </InputLabel>
                </Grid>

                <Grid item xs={6}>
                  <Select
                    name="whatTypeSemiDetached"
                    margin="none"
                    variant="outlined"
                    onChange={onChangeField}
                    style={{
                      marginBottom: "40px",
                      height: "40px",
                      marginLeft: "9px",
                      width: "450px",
                    }}
                    fullWidth
                    value={Tab4_Building_Home_Var.whatTypeSemiDetached}
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    <MenuItem value="Duplex/Triplex">Duplex/Triplex</MenuItem>
                    <MenuItem value="Terrace">Terrace</MenuItem>
                    <MenuItem value="Townhouse">Townhouse</MenuItem>
                    <MenuItem value="Other">Other</MenuItem>
                  </Select>
                </Grid>
              </Grid>
            )}

            {/* If Semi-Detached or Apartment / Unit (Ground Floor) is there a Strata Management of Body Corporate */}
            {(Tab4_Building_Home_Var.buildingType ===
              "Apartment / Unit (Ground Floor)" ||
              Tab4_Building_Home_Var.buildingType ===
                "Apartment / Unit (Above Ground Floor)" ||
              Tab4_Building_Home_Var.buildingType ===
                "Semi-Detached / Terrace") && (
              <Grid container xs={12} direction="row" spacing={2}>
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="If Semi-Detached or Apartment / Unit (Ground Floor) is there a Strata Management of Body Corporate"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    If Semi-Detached or Apartment / Unit (Ground Floor) is there
                    a Strata Management of Body Corporate
                  </InputLabel>
                </Grid>

                <Grid item xs={6}>
                  <Select
                    name="managemenBodyCorporate"
                    margin="none"
                    variant="outlined"
                    onChange={onChangeField}
                    style={{
                      marginBottom: "40px",
                      height: "40px",
                      marginLeft: "9px",
                      width: "450px",
                    }}
                    fullWidth
                    value={Tab4_Building_Home_Var.managemenBodyCorporate}
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    <MenuItem value="No">No</MenuItem>
                    <MenuItem value="Yes">Yes</MenuItem>
                  </Select>
                </Grid>
              </Grid>
            )}

            {/*If Other Dwelling, what best describes the home */}
            {Tab4_Building_Home_Var.buildingType === "Other" && (
              <Grid container xs={12} direction="row" spacing={2}>
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="If Other Dwelling, what best describes the home"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    If Other Dwelling, what best describes the home
                  </InputLabel>
                </Grid>

                <Grid item xs={6}>
                  <Select
                    name="dwellingDescribesHome"
                    margin="none"
                    variant="outlined"
                    onChange={onChangeField}
                    style={{
                      marginBottom: "30px",
                      height: "40px",
                      marginLeft: "9px",
                      width: "450px",
                    }}
                    fullWidth
                    value={Tab4_Building_Home_Var.dwellingDescribesHome}
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    <MenuItem value="Granny flat">Granny flat</MenuItem>
                    <MenuItem value="Non-mobile caravan">
                      Non-mobile caravan
                    </MenuItem>
                    <MenuItem value="Relocatable home">
                      Relocatable home
                    </MenuItem>
                    <MenuItem value="Shed">Shed</MenuItem>
                    <MenuItem value="Storage Centre">Storage Centre</MenuItem>
                    <MenuItem value="Other">Other</MenuItem>
                  </Select>
                </Grid>
              </Grid>
            )}

            {/* Site exceeding 20,000 square meters or 2 hectares or 5 acres? */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Site exceeding 20,000 square meters or 2 hectares or 5 acres?"
                style={{ marginBottom: "20px" }}
                required
              >
                Site exceeding 20,000 square meters or 2 hectares or 5 acres?
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="smhAcres20000"
                margin="none"
                variant="outlined"
                onChange={onChangeField}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "5px",
                  width: "450px",
                }}
                fullWidth
                value={Tab4_Building_Home_Var.smhAcres20000}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
            </Grid>

            {/* If Yes, does Insured generate income */}
            {Tab4_Building_Home_Var.smhAcres20000 === "Yes" && (
              <Grid container xs={12} direction="row" spacing={2}>
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="If Yes, does Insured generate income"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    If Yes, does Insured generate income
                  </InputLabel>
                </Grid>

                <Grid item xs={6}>
                  <Select
                    name="insuredGenerateIncome"
                    margin="none"
                    variant="outlined"
                    onChange={onChangeField}
                    style={{
                      marginBottom: "20px",
                      height: "40px",
                      marginLeft: "8px",
                      width: "450px",
                    }}
                    fullWidth
                    value={Tab4_Building_Home_Var.insuredGenerateIncome}
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    <MenuItem value="No">No</MenuItem>
                    <MenuItem value="Yes">Yes</MenuItem>
                  </Select>
                </Grid>

                {/*If Yes, farm buildings, machinery, implements or vehicles */}
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="If Yes, farm buildings, machinery, implements or vehicles"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    If Yes, farm buildings, machinery, implements or vehicles
                  </InputLabel>
                </Grid>

                <Grid item xs={6}>
                  <Select
                    name="machineryImplmtVehicles"
                    margin="none"
                    variant="outlined"
                    onChange={onChangeField}
                    style={{
                      marginBottom: "20px",
                      height: "40px",
                      marginLeft: "8px",
                      width: "450px",
                    }}
                    fullWidth
                    value={Tab4_Building_Home_Var.machineryImplmtVehicles}
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    <MenuItem value="No">No</MenuItem>
                    <MenuItem value="Yes">Yes</MenuItem>
                  </Select>
                </Grid>

                {/* If Yes, is there more than 6 livestock */}
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="If Yes, is there more than 6 livestock"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    If Yes, is there more than 6 livestock
                  </InputLabel>
                </Grid>

                <Grid item xs={6}>
                  <Select
                    name="more6Livestock"
                    margin="none"
                    variant="outlined"
                    onChange={onChangeField}
                    style={{
                      marginBottom: "20px",
                      height: "40px",
                      marginLeft: "10px",
                    }}
                    fullWidth
                    value={Tab4_Building_Home_Var.more6Livestock}
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    <MenuItem value="No">No</MenuItem>
                    <MenuItem value="Yes">Yes</MenuItem>
                  </Select>
                </Grid>

                {/* If Yes, Is the property used in the agistment of other people's animals */}
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="If Yes, Is the property used in the agistment of other people's animals"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    If Yes, Is the property used in the agistment of other
                    people's animals
                  </InputLabel>
                </Grid>

                <Grid item xs={6}>
                  <Select
                    name="propertyUsedAnimals"
                    margin="none"
                    variant="outlined"
                    onChange={onChangeField}
                    style={{
                      marginBottom: "20px",
                      height: "40px",
                      marginLeft: "8px",
                      width: "450px",
                    }}
                    fullWidth
                    value={Tab4_Building_Home_Var.propertyUsedAnimals}
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    <MenuItem value="No">No</MenuItem>
                    <MenuItem value="Yes">Yes</MenuItem>
                  </Select>
                </Grid>

                {/* If Yes, Are horses being used for non-personal use */}
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="If Yes, Are horses being used for non-personal use"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    If Yes, Are horses being used for non-personal use
                  </InputLabel>
                </Grid>

                <Grid item xs={6}>
                  <Select
                    name="nonPersonalUse"
                    margin="none"
                    variant="outlined"
                    onChange={onChangeField}
                    style={{
                      marginBottom: "20px",
                      height: "40px",
                      marginLeft: "8px",
                      width: "450px",
                    }}
                    fullWidth
                    value={Tab4_Building_Home_Var.nonPersonalUse}
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    <MenuItem value="No">No</MenuItem>
                    <MenuItem value="Yes">Yes</MenuItem>
                  </Select>
                </Grid>

                {/* If Yes, Does the property have an aircraft landing strip */}
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="If Yes, Does the property have an aircraft landing strip"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    If Yes, Does the property have an aircraft landing strip
                  </InputLabel>
                </Grid>

                <Grid item xs={6}>
                  <Select
                    name="aircraftLandingStrip"
                    margin="none"
                    variant="outlined"
                    style={{
                      marginBottom: "20px",
                      height: "40px",
                      marginLeft: "8px",
                      width: "450px",
                    }}
                    fullWidth
                    value={Tab4_Building_Home_Var.aircraftLandingStrip}
                    onChange={onChangeField}
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    <MenuItem value="No">No</MenuItem>
                    <MenuItem value="Yes">Yes</MenuItem>
                  </Select>
                </Grid>
              </Grid>
            )}

            {/*Construction Period */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Construction Period"
                style={{ marginBottom: "5px" }}
                required
              >
                Construction Period
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="constructionPeriod"
                margin="none"
                variant="outlined"
                onChange={onChangeField}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                value={Tab4_Building_Home_Var.constructionPeriod}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="1960 to now (project home)">
                  1960 to now (project home)
                </MenuItem>
                <MenuItem value="1960 to now (Architect)">
                  1960 to now (Architect)
                </MenuItem>
                <MenuItem value="1946-1959">1946-1959</MenuItem>
                <MenuItem value="1914-1945">1914-1945</MenuItem>
                <MenuItem value="1891-1913">1891-1913</MenuItem>
                <MenuItem value="1840-1890">1840-1890</MenuItem>
              </Select>
            </Grid>

            {/* Original Year Built */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Original Year Built"
                // style }}
                required
              >
                Original Year Built
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <DatePicker
                wrapperClassName="dateClass"
                name="originalYearBuilt"
                value={Tab4_Building_Home_Var.originalYearBuilt}
                selected={new Date(Tab4_Building_Home_Var.originalYearBuilt)}
                maxDate={new Date()}
                className="date-picker-align"
                onSelect={(date) => changeYearOnly(date)}
                onChangeRaw={handleDateChangeRaw}
                showYearPicker
                dateFormat="yyyy"
              />
            </Grid>

            {checkYearDiff() < 4 && (
              <Grid item xs={12} style={{ display: "flex", flexWrap: "wrap" }}>
                <Grid item xs={5}>
                  {" "}
                  <InputLabel
                    htmlFor="Has property an occupancy certificate"
                    style={{ marginLeft: "5px" }}
                    required
                  >
                    Does the property have an occupancy certificate?
                  </InputLabel>
                </Grid>

                <Grid item xs={7}>
                  <Select
                    name="occupancyCertificate"
                    margin="none"
                    onChange={onChangeField}
                    variant="outlined"
                    style={{
                      marginLeft: "18%",
                      height: "40px",
                      width: "450px",
                      display: "flex",
                    }}
                    fullWidth
                    value={Tab4_Building_Home_Var.occupancyCertificate}
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    {/* <MenuItem value="N/A">N/A</MenuItem> */}
                    <MenuItem value="No">No</MenuItem>
                    <MenuItem value="Yes">Yes</MenuItem>
                  </Select>
                </Grid>
                {/* </Grid> */}
              </Grid>
            )}

            {checkYearDiff() > 50 && (
              <Grid item xs={12} style={{ display: "flex", flexWrap: "wrap" }}>
                {/* Has the house been re-roofed */}
                <Grid item xs={5}>
                  {" "}
                  <InputLabel
                    htmlFor="Has the house been re-roofed?"
                    style={{ marginLeft: "5px" }}
                    required
                  >
                    Has the house been re-roofed?
                  </InputLabel>
                </Grid>
                <Grid item xs={7}>
                  <Select
                    name="housebeenReroofed"
                    margin="none"
                    onChange={onChangeField}
                    variant="outlined"
                    style={{
                      marginLeft: "18%",
                      height: "40px",
                      width: "450px",
                      display: "flex",
                      marginBottom: "20px",
                    }}
                    fullWidth
                    value={Tab4_Building_Home_Var.housebeenReroofed}
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    {/* <MenuItem value="N/A">N/A</MenuItem> */}
                    <MenuItem value="No">No</MenuItem>
                    <MenuItem value="Yes">Yes</MenuItem>
                  </Select>
                </Grid>

                {/* Has the house been re-plumbed */}
                <Grid item xs={5}>
                  {" "}
                  <InputLabel
                    htmlFor="Has the house been re-plumbed?"
                    style={{ marginLeft: "5px" }}
                    required
                  >
                    Has the house been re-plumbed?
                  </InputLabel>
                </Grid>
                <Grid item xs={7}>
                  <Select
                    name="housebeenReplumbed"
                    margin="none"
                    onChange={onChangeField}
                    variant="outlined"
                    style={{
                      marginLeft: "18%",
                      height: "40px",
                      width: "450px",
                      display: "flex",
                      marginBottom: "20px",
                    }}
                    fullWidth
                    value={Tab4_Building_Home_Var.housebeenReplumbed}
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    {/* <MenuItem value="N/A">N/A</MenuItem> */}
                    <MenuItem value="No">No</MenuItem>
                    <MenuItem value="Yes">Yes</MenuItem>
                  </Select>
                </Grid>

                {/* Has the house been re-wired */}
                <Grid item xs={5}>
                  {" "}
                  <InputLabel
                    htmlFor="Has the house been re-wired?"
                    style={{ marginLeft: "5px" }}
                    required
                  >
                    Has the house been re-wired?
                  </InputLabel>
                </Grid>
                <Grid item xs={7}>
                  <Select
                    name="housebeenRewired"
                    margin="none"
                    onChange={onChangeField}
                    variant="outlined"
                    style={{
                      marginLeft: "18%",
                      height: "40px",
                      width: "450px",
                      display: "flex",
                      marginBottom: "20px",
                    }}
                    fullWidth
                    value={Tab4_Building_Home_Var.housebeenRewired}
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    {/* <MenuItem value="N/A">N/A</MenuItem> */}
                    <MenuItem value="No">No</MenuItem>
                    <MenuItem value="Yes">Yes</MenuItem>
                  </Select>
                </Grid>
              </Grid>
            )}

            {/*Construction of the walls*/}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Construction of the walls"
                style={{ marginBottom: "5px" }}
                required
              >
                Construction of the walls
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="constructionWalls"
                margin="none"
                variant="outlined"
                onChange={onChangeField}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                value={Tab4_Building_Home_Var.constructionWalls}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Concrete">Concrete</MenuItem>
                <MenuItem value="Aluminium / Metal">
                  Aluminium / Metal{" "}
                </MenuItem>
                <MenuItem value="Blockwork">Blockwork </MenuItem>
                <MenuItem value="Brick Veneer">Brick Veneer</MenuItem>
                <MenuItem value="Double Brick">Double Brick</MenuItem>
                <MenuItem value="Fibrecement (Asbestos)">
                  Fibrecement (Asbestos)
                </MenuItem>
                <MenuItem value="Mudbrick">Mudbrick </MenuItem>
                <MenuItem value="Straw">Straw</MenuItem>
                <MenuItem value="EPS/Sandwich Panel">
                  EPS/Sandwich Panel{" "}
                </MenuItem>
                <MenuItem value="Sheet Cladding">Sheet Cladding</MenuItem>
                <MenuItem value="Stonework">Stonework </MenuItem>
                <MenuItem value="Weatherboard - Timber">
                  Weatherboard - Timber
                </MenuItem>
                <MenuItem value="Other (Not EPS)">Other (Not EPS)</MenuItem>
              </Select>
            </Grid>

            {/*Roof construction*/}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Roof construction"
                style={{ marginBottom: "5px" }}
                required
              >
                Roof Construction
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="roofConstruction"
                margin="none"
                variant="outlined"
                onChange={onChangeField}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                value={Tab4_Building_Home_Var.roofConstruction}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Colourbond">Colourbond</MenuItem>
                <MenuItem value="Concrete Tile">Concrete Tile</MenuItem>
                <MenuItem value="Fibrecement (Asbestos)">
                  Fibrecement (Asbestos)
                </MenuItem>
                <MenuItem value="Fibrecement (Not Asbestos)">
                  Fibrecement (Not Asbestos)
                </MenuItem>
                <MenuItem value="Metal Covering">Metal Covering</MenuItem>
                <MenuItem value="EPS/Sandwich Panel">
                  EPS/Sandwich Panel
                </MenuItem>
                <MenuItem value="Slate">Slate</MenuItem>
                <MenuItem value="Terracotta">Terracotta</MenuItem>
                <MenuItem value="Timber Shingles">Timber Shingles</MenuItem>
                <MenuItem value="Other">Other</MenuItem>
              </Select>
            </Grid>

            {/*Construction quality of home*/}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Construction quality of home"
                style={{ marginBottom: "5px" }}
                required
              >
                Construction quality of home
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="consQualityofHome"
                margin="none"
                variant="outlined"
                onChange={onChangeField}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                value={Tab4_Building_Home_Var.consQualityofHome}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Standard">Standard</MenuItem>
                <MenuItem value="Quality">Quality</MenuItem>
                <MenuItem value="Prestige">Prestige</MenuItem>
              </Select>
            </Grid>

            {/*Number of Storeys does the property have*/}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Number of Storeys does the property have"
                style={{ marginBottom: "5px" }}
                required
              >
                Number of Storeys does the property have
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="numberOfPropertyHave"
                margin="none"
                variant="outlined"
                onChange={onChangeField}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                value={Tab4_Building_Home_Var.numberOfPropertyHave}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="1">1</MenuItem>
                <MenuItem value="2">2</MenuItem>
                <MenuItem value="3 or more">3 or more</MenuItem>
              </Select>
            </Grid>

            {/*Unit Building Level*/}
            {(Tab4_Building_Home_Var.buildingType ===
              "Apartment / Unit (Ground Floor)" ||
              Tab4_Building_Home_Var.buildingType ===
                "Apartment / Unit (Above Ground Floor)") && (
              <Grid container xs={12} direction="row" spacing={2}>
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="Unit Building Level"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    Unit Building Level
                  </InputLabel>
                </Grid>

                <Grid item xs={6}>
                  <Select
                    name="unitBuildingLevel"
                    margin="none"
                    variant="outlined"
                    onChange={onChangeField}
                    style={{
                      marginBottom: "20px",
                      height: "40px",
                      marginLeft: "6px",
                      width: "450px",
                    }}
                    fullWidth
                    value={Tab4_Building_Home_Var.unitBuildingLevel}
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    <MenuItem value="1">1</MenuItem>
                    <MenuItem value="2">2</MenuItem>
                    <MenuItem value="3">3</MenuItem>
                    <MenuItem value="4">4</MenuItem>
                    <MenuItem value="5">5</MenuItem>
                    <MenuItem value="6">6</MenuItem>
                    <MenuItem value="7">7</MenuItem>
                    <MenuItem value="8">8</MenuItem>
                    <MenuItem value="9">9</MenuItem>
                    <MenuItem value="10">10</MenuItem>
                    <MenuItem value="11">11</MenuItem>
                    <MenuItem value="12">12</MenuItem>
                    <MenuItem value="13">13</MenuItem>
                    <MenuItem value="14">14</MenuItem>
                    <MenuItem value="15">15</MenuItem>
                    <MenuItem value="16">16</MenuItem>
                  </Select>
                </Grid>
              </Grid>
            )}

            {/* House within 250m of named water course or effected by flood */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="House within 250m of named water course or effected by flood"
                style={{ marginBottom: "5px" }}
                required
              >
                House within 250m of named water course or effected by flood
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="effectByWtaer"
                margin="none"
                variant="outlined"
                onChange={onChangeField}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                value={Tab4_Building_Home_Var.effectByWtaer}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
            </Grid>

            {/* Mains Water Supply */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Mains Water Supply"
                style={{ marginBottom: "5px" }}
                required
              >
                Mains Water Supply
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="mainsWaterSupply"
                margin="none"
                variant="outlined"
                onChange={onChangeField}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                value={Tab4_Building_Home_Var.mainsWaterSupply}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
            </Grid>

            {/*Window Security*/}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Window Security"
                style={{ marginBottom: "5px" }}
                required
              >
                Window Security
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="windowSecurity"
                margin="none"
                variant="outlined"
                onChange={onChangeField}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                value={Tab4_Building_Home_Var.windowSecurity}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Key Operated Locks">
                  Key Operated Locks
                </MenuItem>
                <MenuItem value="No accessible windows">
                  No accessible windows
                </MenuItem>
                <MenuItem value="Security screens">Security screens</MenuItem>
                <MenuItem value="None of these">None of these</MenuItem>
              </Select>
            </Grid>

            {/*Door Security*/}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Door Security"
                style={{ marginBottom: "5px" }}
                required
              >
                Door Security
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="doorSecurity"
                margin="none"
                variant="outlined"
                onChange={onChangeField}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                value={Tab4_Building_Home_Var.doorSecurity}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Key operated dead locks/bolts">
                  Key operated dead locks/bolts
                </MenuItem>
                <MenuItem value="Double key operated dead locks/bolts">
                  Double key operated dead locks/bolts
                </MenuItem>
                <MenuItem value="Security cards">Security cards</MenuItem>
                <MenuItem value="None of the above">None of the above</MenuItem>
              </Select>
            </Grid>

            {/*Burglar Alarm*/}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Burglar Alarm"
                style={{ marginBottom: "5px" }}
                required
              >
                Burglar Alarm
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="burglarAlarm"
                margin="none"
                variant="outlined"
                onChange={onChangeField}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                value={Tab4_Building_Home_Var.burglarAlarm}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Back to base">Back to base</MenuItem>
                <MenuItem value="Local">Local</MenuItem>
                {/* <MenuItem value="Security cards">Security cards</MenuItem> */}
                <MenuItem value="None">None</MenuItem>
              </Select>
            </Grid>

            {/*Smoke Detectors*/}
            {/* <Grid item xs={6}>
            <InputLabel
              htmlFor="Burglar Alarm"
              style={{ marginBottom: "5px" }}
              required

            >
              Smoke Detectors
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="smokeDetectors"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" , marginLeft: "6px", width: "450px"  }}
              fullWidth
              value={Tab4_Building_Home_Var.smokeDetectors}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Back to base">Back to base</MenuItem>
              <MenuItem value="Local">Local</MenuItem>
              <MenuItem value="Security cards">Security cards</MenuItem>
              <MenuItem value="None">None</MenuItem>

            </Select>
          </Grid> */}

            {/* Building or construction in the next 12 months */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Building or construction in the next 12 months"
                style={{ marginBottom: "5px" }}
                required
              >
                Building or construction in the next 12 months
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="builtConstNextMnth"
                margin="none"
                variant="outlined"
                onChange={onChangeField}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                value={Tab4_Building_Home_Var.builtConstNextMnth}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
            </Grid>

            {/* Does the property have an inground swimming pool */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Does the property have an inground swimming pool"
                style={{ marginBottom: "5px" }}
                required
              >
                Does the property have an inground swimming pool
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="swimmingPool"
                margin="none"
                variant="outlined"
                onChange={onChangeField}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                value={Tab4_Building_Home_Var.swimmingPool}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
            </Grid>

            {/* Is there any portion of the Building or Contents located below ground level? e.g. basement, garage, storage room */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Is there any portion of the Building or Contents located below ground level? e.g. basement, garage, storage room"
                style={{ marginBottom: "5px" }}
                required
              >
                Is there any portion of the Building or Contents located below
                ground level? e.g. basement, garage, storage room
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="locatedbelowgRoundLevel"
                margin="none"
                variant="outlined"
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                onChange={onChangeField}
                value={Tab4_Building_Home_Var.locatedbelowgRoundLevel}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
            </Grid>

            {/* Are there any private flood mitigation measures at your property? */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Are there any private flood mitigation measures at your property?"
                style={{ marginBottom: "5px" }}
                required
              >
                Are there any private flood mitigation measures at your
                property?
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="privateFlood"
                margin="none"
                onChange={onChangeField}
                variant="outlined"
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                value={Tab4_Building_Home_Var.privateFlood}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
            </Grid>

            {/* Has property an occupancy certificate */}
          </Grid>
          <div style={{ marginBottom: "5rem" }}>
            <Grid>
              <Button
                variant="contained"
                color="secondary"
                style={{
                  marginTop: "1rem",
                  float: "left",
                  width: "10%",
                }}
                onClick={() => exit()}
              >
                EXIT
              </Button>
            </Grid>

            <Grid>
              <Button
                variant="contained"
                color="primary"
                style={{
                  marginTop: "1rem",
                  float: "right",
                  width: "10%",
                }}
                onClick={() => navigation.next()}
              >
                NEXT
              </Button>
            </Grid>
            <Grid>
              <Button
                variant="contained"
                color="primary"
                style={{
                  marginTop: "1rem",
                  marginBottom: "1rem",
                  float: "right",
                  marginRight: "20px",
                  width: "10%",
                }}
                onClick={() => navigation.previous()}
              >
                PREVIOUS
              </Button>
            </Grid>
          </div>
        </div>
      </Container>
      {/* <Footer /> */}
    </div>
  );
};

export default Tab4_Building_Home;
