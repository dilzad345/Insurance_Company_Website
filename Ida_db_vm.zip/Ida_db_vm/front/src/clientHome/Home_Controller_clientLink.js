// import { getThemeProps } from "@material-ui/styles";
import axios from "axios";
import { API } from "../config";

import { Tab1_Validation_Home } from "../validationHome/Tab1_Validation_Home";
import { Tab2_Validation_Home } from "../validationHome/Tab2_Validation_Home";
import { Tab3_Validation_Home } from "../validationHome/Tab3_Validation_Home";
import { Tab4_Validation_Home } from "../validationHome/Tab4_Validation_Home";
import { Tab5_Validation_Home } from "../validationHome/Tab5_Validation_Home";
import { Tab6_Validation_Home } from "../validationHome/Tab6_Validation_Home";

export const validateAllForms = (
    Tab1_Client_Home_var,
    Tab2_Importan_Question_Home_var,
    Tab3_Policycore_Home_Var,
    Tab4_Building_Home_Var,
    Tab5_Contents_Home_Var,
    Tab6_Claims_Home_Var
) => {
    let isValid = true;
    isValid = isValid * Tab1_Validation_Home(Tab1_Client_Home_var);
    isValid = isValid * Tab2_Validation_Home(Tab2_Importan_Question_Home_var);
    isValid = isValid * Tab3_Validation_Home(Tab3_Policycore_Home_Var);
    isValid = isValid * Tab4_Validation_Home(Tab4_Building_Home_Var);
    isValid = isValid * Tab5_Validation_Home(Tab5_Contents_Home_Var,Tab3_Policycore_Home_Var);
    isValid = isValid * Tab6_Validation_Home(Tab6_Claims_Home_Var);
    return isValid;
};

export const addAllFormsValues = (
    Tab1_Client_Home_var,
    Tab2_Importan_Question_Home_var,
    Tab3_Policycore_Home_Var,
    Tab4_Building_Home_Var,
    Tab5_Contents_Home_Var,
    Tab6_Claims_Home_Var
) => {

    
    // add all form data to the db one by one and get response.
    const data_tab1 = {
        data_tab1_home_client: Tab1_Client_Home_var,
    };
    // const data_tab3 = {
    //     data_tab3_policyCorehome: Tab3_Policycore_Home_Var,
    //     //quotationId_db: quotationId_db,
    // };
    //console.log("Policy Home: ", data_tab3);

    return axios
        .post(`${API}/quotationHome/addHomeClient`, data_tab1)
        .then((response_tab1) => {
            //console.log("Response Tab1 ",response_tab1.data.data.id);

            let quotationId_db = response_tab1.data.data.id;
            //console.log("Quotation Id:", quotationId_db);

            const data_tab2 = {
                data_tab2_importantQuestions_home: Tab2_Importan_Question_Home_var,
                quotationId_db: quotationId_db,
            };
            return axios
                .post(`${API}/quotationHome/addImportantQuestionsforHome`, data_tab2)
                .then((response_tab2) => {
                    //console.log(response_tab2);
                    const data_tab3 = {
                        data_tab3_policyCorehome: Tab3_Policycore_Home_Var,
                        quotationId_db: quotationId_db,
                    };
                    return axios
                        .post(`${API}/quotationHome/addPolicyHome`, data_tab3)
                        .then((response_tab3) => {
                            //console.log("Tab3:" ,response_tab3);
                            const data_tab4 = {
                                data_tab4_buildinghome: Tab4_Building_Home_Var,
                                quotationId_db: quotationId_db,
                            };
                            return axios
                                .post(`${API}/quotationHome/addBuildingDetailsHome`, data_tab4)
                                .then((response_tab4) => {
                                    //console.log("Tab4:" ,response_tab4);
                                    const data_tab5 = {
                                        data_tab5_contentshome: Tab5_Contents_Home_Var,
                                        quotationId_db: quotationId_db,
                                    };
                                    return axios
                                        .post(`${API}/quotationHome/addContentsHome`, data_tab5)
                                        .then((response_tab5) => {
                                            //console.log("Tab5:", response_tab5);
                                            const data_tab6 = {
                                                data_tab6_claimshome: Tab6_Claims_Home_Var,
                                                quotationId_db: quotationId_db,
                                            };
                                            return axios
                                                .post(`${API}/quotationHome/addClaimsHome`, data_tab6)
                                                .then((response_tab6) => {
                                                    //console.log("Tab6: ", response_tab6);
                                                    return response_tab6;
                                                }).catch((error_tab6) => {

                                                });
                                        }).catch((error_tab5) => {

                                        });
                                }).catch((error_tab4) => {

                                });
                        }).catch((error_tab3) => {

                        });
                }).catch((error_tab2)=>{

                });
        }).catch((error_tab1)=>{

        });
   
};
