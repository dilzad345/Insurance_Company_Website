import React from "react";
// import Footer from "../component/footer/Footer";
import "../css/homeStyle.css";
import {
  TextField,
  Container,
  Button,
  Select,
  InputLabel,
  MenuItem,
  Grid
} from "@material-ui/core";
// import { makeStyles } from "@material-ui/core/styles";
// import { Redirect } from 'react-router-dom';
import DatePicker from "react-datepicker";
import InputAdornment from "@material-ui/core/InputAdornment";
import {
  validationForAlpha,
  validationForNumbOnly,
} from "../constants/validChecker";
import { exit } from "../constants/exit";
import { preferredDays } from "../constants/dropDownData";
import {
  buildingSumInsured_validate,
  contentsSumInsuredAmount_validate,
  fromHomeBusinessName_validate,
  preferredinstallments_validate,
  brokerFee_validate,
  policyToDate_validate,
  policyFromDate_validate,
  dobOldestInsured_validate,
} from "../validationHome/Tab3_Validation_Home";


const Tab3_Policycore_Home = ({
  Tab3_Policycore_Home_Var,
  setTab3,
  Tab3_Validation_Home_Var,
  setTab3_validation,
  navigation,
}) => {
  // const classes = useStyles();
  // const [startDate, setStartDate] = useState(new Date());
  // console.log(startDate);
  const onChangeField = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    // console.log(name);
    // console.log(value)
   
    setTab3(
      {
        ...Tab3_Policycore_Home_Var,
        [name]: value,
      },
      () => {
        validationAfterChange(name, value);
      }
    );
  };

  //method for preventing user typing
  const handleDateChangeRaw = (e) => {
    e.preventDefault();
  };

  // method: to update policy date from to variable
  const setFromDate = (date, value) => {
    // console.log(date);
    const tempDate = new Date(date);
    const tempToDate = tempDate.setFullYear(tempDate.getFullYear() + 1);
    // console.log(new Date(tempToDate));
    setTab3({
      ...Tab3_Policycore_Home_Var,
      policyFromDate: date,
      policyToDate: new Date(tempToDate),
    });
    policyFromDate_validate(date, Tab3_Validation_Home_Var, setTab3_validation);
  };

  // method: to update policy date to to variable
  const setToDate = (date) => {
    // console.log("v" + date);
    setTab3({
      ...Tab3_Policycore_Home_Var,
      policyToDate: date,
    });
    policyToDate_validate(date, Tab3_Validation_Home_Var, setTab3_validation);
  };

  //set default year reduced by 16 from current year for date of birth
  // let tempYear= new Date();
  // tempYear.setFullYear(tempYear.getFullYear()-16);

  // method: to update policy dob Oldest Insured to variable
  const setDOBDate = (date, value) => {
    // console.log(date);
    setTab3({
      ...Tab3_Policycore_Home_Var,
      dobOldestInsured: date,
    });
    dobOldestInsured_validate(
      date,
      Tab3_Validation_Home_Var,
      setTab3_validation
    );
  };

  // method for displaying unspecified valuables in contents tab
  // const displayUnspecifiedValuables = (tempArr) => {
  //   if (tempArr) {
  //     setTab5([]);
  //     tempArr.map((contentTab, index) => {
  //       // for (let i = 0; i < contentTab.numberClaims3; i++) {
  //         setTab5((tab5_contents) => [
  //           ...tab5_contents,
  //           {

  //             unspecifiedValuables : " ",
  //             contentsIndex: index,
  //           },
  //         ]);

  //         setTab5_validation((tab5_validation) => [
  //           ...tab5_validation,
  //           {
  //             unspecifiedValuables: null
  //           },
  //         ]);
  //       // }
  //     });
  //   }
  // }; // end of modify claim details

  //set default year reduced by 16 from current year for date of birth
  let tempDate = new Date();
  tempDate.setFullYear(tempDate.getFullYear() - 16);
  const validationAfterChange = (name, value) => {
    if (name === "buildingOrContents") {
      if (value === "Building only") {
        setTab3({
          ...Tab3_Policycore_Home_Var,
          buildingOrContents: "Building only",
          buildingSumInsured: "",
        });
      }
    }

    if (name === "buildingOrContents") {
      if (value === "Contents only") {
        setTab3({
          ...Tab3_Policycore_Home_Var,
          buildingOrContents: "Contents only",
          contentsSumInsuredAmount: "",
        });
      }
    }

    if (name === "conductedFromHome") {
      if (value === "No") {
        setTab3({
          ...Tab3_Policycore_Home_Var,
          conductedFromHome: "No",
          fromHomeBusinessName: "",
          fromHomeWhatBusiness: "",
          fromHomeAnnualRevenue: "",
          fromHomeBusnsOccupyFloorArea: "",
        });
      }
    }

    if (name === "paymentFrequency") {
      if (value === "Monthly") {
        setTab3({
          ...Tab3_Policycore_Home_Var,
          paymentFrequency: "Monthly",
          preferredinstallments: "Please Select",
          brokerFeeinstallments: "",
        });
      }
    }
    switch (name) {
      case "buildingSumInsured": {
        buildingSumInsured_validate(
          value,
          Tab3_Validation_Home_Var,
          setTab3_validation
        );
        break;
      }

      case "contentsSumInsuredAmount": {
        contentsSumInsuredAmount_validate(
          value,
          Tab3_Validation_Home_Var,
          setTab3_validation
        );
        break;
      }

      case "fromHomeBusinessName": {
        fromHomeBusinessName_validate(
          value,
          Tab3_Validation_Home_Var,
          setTab3_validation
        );
        break;
      }

      case "preferredinstallments": {
        preferredinstallments_validate(
          value,
          Tab3_Validation_Home_Var,
          setTab3_validation
        );
        break;
      }

      case "policyToDate": {
        policyToDate_validate(
          value,
          Tab3_Validation_Home_Var,
          setTab3_validation
        );
        break;
      }

      case "policyFromDate": {
        policyFromDate_validate(
          value,
          Tab3_Validation_Home_Var,
          setTab3_validation
        );
        break;
      }

      case "dobOldestInsured": {
        dobOldestInsured_validate(
          value,
          Tab3_Validation_Home_Var,
          setTab3_validation
        );
        break;
      }

      case "brokerFee": {
        brokerFee_validate(value, Tab3_Validation_Home_Var, setTab3_validation);
        break;
      }

      default: {
        console.log("Not match to condition");
      }
    }
  };

  //console.log(Tab3_Policycore_Home_Var.coverType);

  return (
    <div>
      <Container maxWidth="md" style={{ marginBottom: "30px" }}>
        <div>
          <Grid
            container
            spacing={3}
            direction="row"
            justifyContent="center"
            alignItems="center"
          >
            <Grid
              item={true}
              xs={12}
              justifyContent="center"
              container
              style={{ marginTop: "25px" }}
            >
              <h3>POLICY CORE INFORMATION</h3>
            </Grid>

            {/* Cover Type (Accidental Damage or Defined Events only) */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Cover Type (Accidental Damage or Defined Events only)"
                style={{ marginBottom: "5px" }}
                required
              >
                Cover Type (Accidental Damage or Defined Events only)
              </InputLabel>
            </Grid>
            <Grid item xs={6}>
              <Select
                name="coverType"
                margin="none"
                variant="outlined"
                autoComplete="off"
                onChange={onChangeField}
                value={Tab3_Policycore_Home_Var.coverType}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "8px",
                  width: "450px",
                }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Accidental Damage">Accidental Damage</MenuItem>
                <MenuItem value="Defined Events">Defined Events </MenuItem>
              </Select>
            </Grid>

            {/* Basis of settlement) */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Basis of settlement)"
                style={{ marginBottom: "5px" }}
                required
              >
                Basis of settlement
              </InputLabel>
            </Grid>
            <Grid item xs={6}>
              <Select
                name="basisOfSettlement"
                margin="none"
                variant="outlined"
                autoComplete="off"
                onChange={onChangeField}
                value={Tab3_Policycore_Home_Var.basisOfSettlement}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "7px",
                  width: "450px",
                }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Replacement">Replacement</MenuItem>
                <MenuItem value="Indemnity">Indemnity</MenuItem>
              </Select>
            </Grid>

            {/* Building or Contents) */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Building or Contents"
                style={{ marginBottom: "5px" }}
                required
              >
                Building or Contents
              </InputLabel>
            </Grid>
            <Grid item xs={6}>
              <Select
                name="buildingOrContents"
                margin="none"
                variant="outlined"
                autoComplete="off"
                onChange={onChangeField}
                value={Tab3_Policycore_Home_Var.buildingOrContents}
                style={{
                  marginBottom: "30px",
                  height: "40px",
                  marginLeft: "7px",
                  width: "450px",
                }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Building only">Building only</MenuItem>
                <MenuItem value="Contents only">Contents only</MenuItem>
                <MenuItem value="Building and Contents">
                  Building and Contents
                </MenuItem>
              </Select>
            </Grid>

            {/* Building Sum Insured) */}
            {(Tab3_Policycore_Home_Var.buildingOrContents === "Building only" ||
              Tab3_Policycore_Home_Var.buildingOrContents ===
                "Building and Contents") && (
              <Grid item={true} container xs={12} direction="row" spacing={2}>
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="Building Sum Insured"
                    style={{ marginBottom: "25px" }}
                    required
                  >
                    Building Sum Insured
                  </InputLabel>
                </Grid>

                <Grid item xs={6}>
                  <TextField
                    type="number"
                    name="buildingSumInsured"
                    size="small"
                    variant="outlined"
                    autoComplete="off"
                    onChange={onChangeField}
                    onKeyPress={(e) => validationForNumbOnly(e)}
                    value={Tab3_Policycore_Home_Var.buildingSumInsured}
                    style={{
                      marginBottom: "30px",
                      marginLeft: "10px",
                      width: "450px",
                    }}
                    fullWidth
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">$</InputAdornment>
                      ),
                    }}
                  />
                  {Tab3_Validation_Home_Var.buildingSumInsured !== null &&
                    Tab3_Validation_Home_Var.buildingSumInsured !== "true" && (
                      <div className="text-danger font-italic">
                        {Tab3_Validation_Home_Var.buildingSumInsured}
                      </div>
                    )}
                </Grid>
              </Grid>
            )}

            {(Tab3_Policycore_Home_Var.buildingOrContents === "Contents only" ||
              Tab3_Policycore_Home_Var.buildingOrContents ===
                "Building and Contents") && (
              <Grid container xs={12} direction="row" spacing={2}>
                {/* Contents Sum Insured Amount) */}
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="Contents Sum Insured Amount"
                    style={{ marginBottom: "5px", marginLeft: "10px" }}
                    required
                  >
                    Contents Sum Insured
                  </InputLabel>
                </Grid>

                <Grid item xs={6}>
                  <TextField
                    type="number"
                    name="contentsSumInsuredAmount"
                    size="small"
                    variant="outlined"
                    autoComplete="off"
                    onChange={onChangeField}
                    onKeyPress={(e) => validationForNumbOnly(e)}
                    value={Tab3_Policycore_Home_Var.contentsSumInsuredAmount}
                    style={{
                      marginBottom: "30px",
                      marginLeft: "10px",
                      width: "450px",
                    }}
                    fullWidth
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">$</InputAdornment>
                      ),
                    }}
                  />
                  {Tab3_Validation_Home_Var.contentsSumInsuredAmount !== null &&
                    Tab3_Validation_Home_Var.contentsSumInsuredAmount !==
                      "true" && (
                      <div className="text-danger font-italic">
                        {Tab3_Validation_Home_Var.contentsSumInsuredAmount}
                      </div>
                    )}
                </Grid>
              </Grid>
            )}

            {/* Policy From Date */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Policy From Date"
                style={{ marginBottom: "5px" }}
                required
              >
                Policy From Date
              </InputLabel>
            </Grid>
            <Grid item xs={6}>
              <div
                style={{
                  marginBottom: "15px",
                  marginLeft: "6px",
                  width: "450px",
                }}
              >
                <DatePicker
                  selected={Tab3_Policycore_Home_Var.policyFromDate}
                  dateFormat="dd/MM/yyyy"
                  name="policyFromDate"
                  minDate={new Date()}
                  onChange={setFromDate}
                  onChangeRaw={handleDateChangeRaw}
                  value={Tab3_Policycore_Home_Var.policyFromDate}
                  className="date-picker-align"
                />
              </div>

              <div className="text-danger font-italic"></div>
            </Grid>

            {/* Policy To Date */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Policy To Date"
                style={{ marginBottom: "5px" }}
                required
              >
                Policy To Date
              </InputLabel>
            </Grid>
            <Grid item xs={6}>
              <div
                style={{
                  marginBottom: "15px",
                  marginLeft: "6px",
                  width: "450px",
                }}
              >
                <DatePicker
                  selected={Tab3_Policycore_Home_Var.policyToDate}
                  dateFormat="dd/MM/yyyy"
                  name="policyToDate"
                  minDate={Tab3_Policycore_Home_Var.policyToDate}
                  onChange={setToDate}
                  onChangeRaw={handleDateChangeRaw}
                  value={Tab3_Policycore_Home_Var.policyToDate}
                  variant="outlined"
                  autoComplete="off"
                  fullWidth
                  className="date-picker-align"
                />
              </div>
              <div className="text-danger font-italic"></div>
            </Grid>

            {/* Date of Birth of oldest insured */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Date of Birth of oldest insured"
                style={{ marginBottom: "5px" }}
                required
              >
                Date of Birth of oldest insured
              </InputLabel>
            </Grid>
            <Grid item xs={6}>
              <div
                style={{
                  marginBottom: "15px",
                  marginLeft: "6px",
                  width: "450px",
                }}
              >
                <DatePicker
                  selected={Tab3_Policycore_Home_Var.dobOldestInsured}
                  dateFormat="dd/MM/yyyy"
                  name="dobOldestInsured"
                  value={Tab3_Policycore_Home_Var.dobOldestInsured}
                  onChange={setDOBDate}
                  onChangeRaw={handleDateChangeRaw}
                  yearDropdownItemNumber={700}
                  scrollableYearDropdown={true}
                  showYearDropdown
                  showMonthDropdown
                  dropdownMode="select"
                  // maxDate={new Date()}
                  maxDate={tempDate}
                  variant="outlined"
                  autoComplete="off"
                  fullWidth
                  className="date-picker-align"
                />
              </div>

              <div className="text-danger font-italic"></div>
            </Grid>

            {/* Industry of Policyholder */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Industry of Policyholder"
                style={{ marginBottom: "5px" }}
                required
              >
                Industry of Policyholder
              </InputLabel>
            </Grid>
            <Grid item xs={6}>
              <Select
                name="industryPolicyHolder"
                margin="none"
                variant="outlined"
                autoComplete="off"
                value={Tab3_Policycore_Home_Var.industryPolicyHolder}
                onChange={onChangeField}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Banking and Finance">
                  Banking and Finance
                </MenuItem>
                <MenuItem value="Construction / Engineering">
                  Construction / Engineering
                </MenuItem>
                <MenuItem value="Design">Design</MenuItem>
                <MenuItem value="Education">Education</MenuItem>
                <MenuItem value="Entertainment">Entertainment</MenuItem>
                <MenuItem value="Family Trust">Family Trust</MenuItem>
                <MenuItem value="Government">Government</MenuItem>
                <MenuItem value="Home Duties">Home Duties</MenuItem>
                <MenuItem value="AHospitality">Hospitality</MenuItem>
                <MenuItem value="HR">HR</MenuItem>
                <MenuItem value="AImport / Export">Import / Export</MenuItem>
                <MenuItem value="Insurance">Insurance</MenuItem>
                <MenuItem value="IT">IT</MenuItem>
                <MenuItem value="Jeweler">Jeweler</MenuItem>
                <MenuItem value="Legal Profession">Legal Profession</MenuItem>
                <MenuItem value="Management Consultant">
                  Management Consultant
                </MenuItem>
                <MenuItem value="Media">Media</MenuItem>
                <MenuItem value="Medical">Medical</MenuItem>
                <MenuItem value="Milatary and Defence">
                  Milatary and Defence
                </MenuItem>
                <MenuItem value="Mining">Mining</MenuItem>
                <MenuItem value="Motor Industry">Motor Industry</MenuItem>
                <MenuItem value="Property">Property</MenuItem>
                <MenuItem value="Public Sector">Public Sector</MenuItem>
                <MenuItem value="Publishing / Photography">
                  Publishing / Photography
                </MenuItem>
                <MenuItem value="Retail / Sales">Retail / Sales</MenuItem>
                <MenuItem value="Science / Research">
                  Science / Research
                </MenuItem>
                <MenuItem value="Security Industry">Security Industry</MenuItem>
                <MenuItem value="Sporting Industry">Sporting Industry</MenuItem>
                <MenuItem value="Transportation">Transportation</MenuItem>
                <MenuItem value="Travel and Tourism">
                  Travel and Tourism
                </MenuItem>
                <MenuItem value="Other">Other</MenuItem>
              </Select>
            </Grid>

            {/* Policyholder Retired */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Policyholder Retired"
                style={{ marginBottom: "5px" }}
                required
              >
                Policyholder Retired
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="policyHolderRetired"
                margin="none"
                variant="outlined"
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                onChange={onChangeField}
                fullWidth
                value={Tab3_Policycore_Home_Var.policyHolderRetired}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
            </Grid>

            {/* Is business conducted from home */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Is business conducted from home"
                style={{ marginBottom: "5px" }}
                required
              >
                Is business conducted from home
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="conductedFromHome"
                margin="none"
                variant="outlined"
                onChange={onChangeField}
                value={Tab3_Policycore_Home_Var.conductedFromHome}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
            </Grid>

            {/* If Business Conducted from home, Name of the Business) */}
            {Tab3_Policycore_Home_Var.conductedFromHome === "Yes" && (
              <Grid container xs={12} direction="row" spacing={2}>
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="If Business Conducted from home, Name of the Business"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    If Business Conducted from home, Name of the Business
                  </InputLabel>
                </Grid>

                <Grid item xs={6}>
                  <TextField
                    name="fromHomeBusinessName"
                    size="small"
                    variant="outlined"
                    autoComplete="off"
                    onChange={onChangeField}
                    onKeyPress={(e) => validationForAlpha(e)}
                    value={Tab3_Policycore_Home_Var.fromHomeBusinessName}
                    style={{
                      marginBottom: "20px",
                      height: "40px",
                      marginLeft: "9px",
                      width: "450px",
                    }}
                    fullWidth
                  />
                  {Tab3_Validation_Home_Var.fromHomeBusinessName !== null &&
                    Tab3_Validation_Home_Var.fromHomeBusinessName !==
                      "true" && (
                      <div className="text-danger font-italic">
                        {Tab3_Validation_Home_Var.fromHomeBusinessName}
                      </div>
                    )}
                </Grid>

                {/* If Business Conducted from home, what type of business */}
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="If Business Conducted from home, what type of business"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    If Business Conducted from home, what type of business
                  </InputLabel>
                </Grid>
                <Grid item xs={6}>
                  <Select
                    name="fromHomeWhatBusiness"
                    margin="none"
                    variant="outlined"
                    onChange={onChangeField}
                    autoComplete="off"
                    value={Tab3_Policycore_Home_Var.fromHomeWhatBusiness}
                    style={{
                      marginBottom: "20px",
                      height: "40px",
                      marginLeft: "9px",
                      width: "450px",
                    }}
                    fullWidth
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    <MenuItem value="Accounting">Accounting</MenuItem>
                    <MenuItem value="Advertising">Advertising</MenuItem>
                    <MenuItem value="Antique and Used Goods Retailing">
                      Antique and Used Goods Retailing
                    </MenuItem>
                    <MenuItem value="Architectural and Surveying ">
                      Architectural & Surveying{" "}
                    </MenuItem>
                    <MenuItem value="Audio and Visual Media">
                      Audio & Visual Media
                    </MenuItem>
                    <MenuItem value="Blogging">Blogging</MenuItem>
                    <MenuItem value="Business and Professional Association">
                      Business and Professional Association
                    </MenuItem>
                    <MenuItem value="Child Care (Gov Approved)">
                      Child Care (Gov Approved)
                    </MenuItem>
                    <MenuItem value="Chiropractic and Osteopathic">
                      Chiropractic and Osteopathic{" "}
                    </MenuItem>
                    <MenuItem value="Clinical Pilates">
                      Clinical Pilates
                    </MenuItem>
                    <MenuItem value="Clothing Manufacturing and Alterations">
                      Clothing Manufacturing and Alterations
                    </MenuItem>
                    <MenuItem value="Commercial Art">Commercial Art</MenuItem>
                    <MenuItem value="Commission based direct sales">
                      Commission based direct sales
                    </MenuItem>
                    <MenuItem value="Counselling">Counselling</MenuItem>
                    <MenuItem value="Digital Marketing and Research">
                      Digital Marketing and Research
                    </MenuItem>
                    <MenuItem value="Electronic Information Storage">
                      Electronic Information Storage
                    </MenuItem>
                    <MenuItem value="Engineering Design and Consulting">
                      Engineering Design and Consulting
                    </MenuItem>
                    <MenuItem value="Exercise Physiologist">
                      Exercise Physiologist
                    </MenuItem>
                    <MenuItem value="Fashion Design">Fashion Design</MenuItem>
                    <MenuItem value="Financial Asset Investing and Broking">
                      Financial Asset Investing and Broking
                    </MenuItem>
                    <MenuItem value="Freelance Artists & Performers">
                      Freelance Artists & Performers
                    </MenuItem>
                    <MenuItem value="Freelance Writing & Publishing">
                      Freelance Writing & Publishing
                    </MenuItem>
                    <MenuItem value="Gift Basket retailing">
                      Gift Basket retailing
                    </MenuItem>
                    <MenuItem value="Gift card making business">
                      Gift card making business
                    </MenuItem>
                    <MenuItem value="Graphic design">Graphic design</MenuItem>
                    <MenuItem value="Hair & Beauty">Hair & Beauty</MenuItem>
                    <MenuItem value="Interior design">Interior design</MenuItem>
                    <MenuItem value="Jewellery Design">
                      Jewellery Design
                    </MenuItem>
                    <MenuItem value="Legal services">Legal services</MenuItem>
                    <MenuItem value="Management Consulting">
                      Management Consulting
                    </MenuItem>
                    <MenuItem value="Marriage celebrant">
                      Marriage celebrant
                    </MenuItem>
                    <MenuItem value="Music Publishing & Recording">
                      Music Publishing & Recording
                    </MenuItem>
                    <MenuItem value="Nutritionist & Dietician">
                      Nutritionist & Dietician
                    </MenuItem>
                    <MenuItem value="Occupational Therapist">
                      Occupational Therapist
                    </MenuItem>
                    <MenuItem value="Personal Training">
                      Personal Training
                    </MenuItem>
                    <MenuItem value="Photographic">Photographic</MenuItem>
                    <MenuItem value="Physiotherapy">Physiotherapy</MenuItem>
                    <MenuItem value="Podiatry">Podiatry</MenuItem>
                    <MenuItem value="Private Tutoring">
                      Private Tutoring
                    </MenuItem>
                    <MenuItem value="Psychology">Psychology</MenuItem>
                    <MenuItem value="Social media consulting">
                      Social media consulting
                    </MenuItem>
                    <MenuItem value="Software design consulting">
                      Software design consulting
                    </MenuItem>
                    <MenuItem value="Speech Pathologist">
                      Speech Pathologist
                    </MenuItem>
                    <MenuItem value="Sports Massage">Sports Massage</MenuItem>
                    <MenuItem value="Textile Design">Textile Design</MenuItem>
                    <MenuItem value="Travel and Tour Arrangement">
                      Travel and Tour Arrangement
                    </MenuItem>
                    <MenuItem value="Vocational Education and Training">
                      Vocational Education and Training
                    </MenuItem>
                    <MenuItem value="Food preparation (consumption off-site)">
                      Food preparation (consumption off-site)
                    </MenuItem>
                    <MenuItem value="Jewellery Making">
                      Jewellery Making
                    </MenuItem>
                    <MenuItem value="Wedding / Party Planner">
                      Wedding / Party Planner
                    </MenuItem>
                    <MenuItem value="Ironing Services">
                      Ironing Services
                    </MenuItem>
                  </Select>
                </Grid>

                {/* If Business Conducted from home, annual revenue */}
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="If Business Conducted from home, annual revenue"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    If Business Conducted from home, annual revenue
                  </InputLabel>
                </Grid>

                <Grid item xs={6}>
                  <TextField
                    name="fromHomeAnnualRevenue"
                    size="small"
                    variant="outlined"
                    autoComplete="off"
                    onChange={onChangeField}
                    onKeyPress={(e) => validationForNumbOnly(e)}
                    value={Tab3_Policycore_Home_Var.fromHomeAnnualRevenue}
                    style={{
                      marginBottom: "20px",
                      height: "40px",
                      marginLeft: "8px",
                      width: "450px",
                    }}
                    fullWidth
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">$</InputAdornment>
                      ),
                    }}
                  />
                  <div className="text-danger font-italic"></div>
                </Grid>

                {/* If Business Conducted from home, Business occupy more than 20% floor area? */}
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="If Business Conducted from home, Business occupy more than 20% floor area?"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    If Business Conducted from home, Business occupy more than
                    20% floor area?
                  </InputLabel>
                </Grid>

                <Grid item xs={6}>
                  <Select
                    name="fromHomeBusnsOccupyFloorArea"
                    margin="none"
                    variant="outlined"
                    style={{
                      marginBottom: "20px",
                      height: "40px",
                      marginLeft: "8px",
                      width: "450px",
                    }}
                    fullWidth
                    onChange={onChangeField}
                    value={
                      Tab3_Policycore_Home_Var.fromHomeBusnsOccupyFloorArea
                    }
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    <MenuItem value="No">No</MenuItem>
                    <MenuItem value="Yes">Yes</MenuItem>
                  </Select>
                </Grid>
              </Grid>
            )}

            {/* Is the property under construction? */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Is the property under construction?"
                style={{ marginBottom: "5px" }}
                required
              >
                Is the property under construction?
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="underConstruction"
                margin="none"
                variant="outlined"
                value={Tab3_Policycore_Home_Var.underConstruction}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                onChange={onChangeField}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
            </Grid>

            {/* Is the property in poor condition or poorly maintained? */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Is the property in poor condition or poorly maintained?"
                style={{ marginBottom: "5px" }}
                required
              >
                Is the property in poor condition or poorly maintained?
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="poorlyMaintained"
                margin="none"
                value={Tab3_Policycore_Home_Var.poorlyMaintained}
                variant="outlined"
                onChange={onChangeField}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
            </Grid>

            {/* Is the property Currently or will be unoccupied for more than 90 days? */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Is the property Currently or will be unoccupied for more than 90 days?"
                style={{ marginBottom: "5px" }}
                required
              >
                Is the property Currently or will be unoccupied for more than 90
                days?
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="unoccupiedDays"
                margin="none"
                variant="outlined"
                onChange={onChangeField}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                value={Tab3_Policycore_Home_Var.unoccupiedDays}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Up to 60 days">Up to 60 days</MenuItem>
                <MenuItem value="Up to 90 days">Up to 90 days</MenuItem>
                <MenuItem value="Up to 120 days">Up to 120 days</MenuItem>
              </Select>
            </Grid>

            {/* Is the property used as a hostel, bed and breakfast or guesthouse? */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Is the property used as a hostel, bed and breakfast or guesthouse?"
                style={{ marginBottom: "5px" }}
                required
              >
                Is the property used as a hostel, bed and breakfast or
                guesthouse?
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="guestHouse"
                margin="none"
                variant="outlined"
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                onChange={onChangeField}
                fullWidth
                value={Tab3_Policycore_Home_Var.guestHouse}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
            </Grid>

            {/* Is the property used for community housing or public housing? */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Is the property used for community housing or public housing?"
                style={{ marginBottom: "5px" }}
                required
              >
                Is the property used for community housing or public housing?
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="publicHousing"
                margin="none"
                variant="outlined"
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                onChange={onChangeField}
                value={Tab3_Policycore_Home_Var.publicHousing}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="No">No</MenuItem>
                <MenuItem value="Yes">Yes</MenuItem>
              </Select>
            </Grid>

            {/*Policyholder currently hold insurance */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Policyholder currently hold insurance"
                style={{ marginBottom: "5px" }}
                required
              >
                Policyholder currently hold insurance
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="currentlyInsurance"
                margin="none"
                variant="outlined"
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                onChange={onChangeField}
                value={Tab3_Policycore_Home_Var.currentlyInsurance}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="0-1 Years">0-1 Years</MenuItem>
                <MenuItem value="1-5 years">1-5 years</MenuItem>
                <MenuItem value="5-10 years">5-10 years</MenuItem>
                <MenuItem value="Over 10 years">Over 10 years</MenuItem>
              </Select>
            </Grid>

            {/*Interested Parties*/}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Interested Parties"
                style={{ marginBottom: "5px" }}
                required
              >
                Interested Parties
              </InputLabel>
            </Grid>
            <Grid item xs={6}>
              <Select
                name="interestedParties"
                margin="none"
                variant="outlined"
                autoComplete="off"
                value={Tab3_Policycore_Home_Var.interestedParties}
                onChange={onChangeField}
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Adelaide Bank">Adelaide Bank</MenuItem>
                <MenuItem value="AMP">AMP</MenuItem>
                <MenuItem value="AArab Bank">Arab Bank</MenuItem>
                <MenuItem value="Aussie Home Loans">Aussie Home Loans</MenuItem>
                <MenuItem value="Aussie Mortgages">Aussie Mortgages</MenuItem>
                <MenuItem value="ANZ">ANZ</MenuItem>
                <MenuItem value="Bank of Melbourn">Bank of Melbourn</MenuItem>
                <MenuItem value="Bank of Queensland">
                  Bank of Queensland
                </MenuItem>
                <MenuItem value="Bank of Australia">
                  Bank of South Australia
                </MenuItem>
                <MenuItem value="Bank of West Australia">
                  Bank of West Australia
                </MenuItem>
                <MenuItem value="bank Weast">Bank Weast</MenuItem>
                <MenuItem value="Bendigo Bank">Bendigo Bank</MenuItem>
                <MenuItem value="Citibank">Citibank</MenuItem>
                <MenuItem value="Colonial State Bank">
                  Colonial State Bank
                </MenuItem>
                <MenuItem value="Commonwealth Bank">Commonwealth Bank</MenuItem>
                <MenuItem value="Greater Building Society">
                  Greater Building Society
                </MenuItem>
                <MenuItem value="Homesafe Solutions">
                  Homesafe Solutions
                </MenuItem>
                <MenuItem value="ING">ING</MenuItem>
                <MenuItem value="Macquarie Bank">Macquarie Bank</MenuItem>
                <MenuItem value="Members Equity">Members Equity</MenuItem>
                <MenuItem value="NAB">NAB</MenuItem>
                <MenuItem value="State George">St George</MenuItem>
                <MenuItem value="Suncorp">Suncorp</MenuItem>
                <MenuItem value="Westpac">Westpac</MenuItem>
                <MenuItem value="Other">Other</MenuItem>
              </Select>
            </Grid>

            {/*Is there a Jetty attached to the property? */}
            {/* <Grid item xs={6}>
            <InputLabel
              htmlFor="Is there a Jetty attached to the property?"
              style={{ marginBottom: "5px" }}
              required
            >
              Is there a Jetty attached to the property?
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="jettyAttachedProperty"
              margin="none"
              variant="outlined"
              style={{ marginBottom: "20px", height: "40px", marginLeft: "6px", width: "450px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Home_Var.jettyAttachedProperty}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid> */}

            {/*SVU Excess Option 1 */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="SVU Excess Option 1"
                style={{ marginBottom: "5px" }}
                required
              >
                Excess Option 1
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="svuExcessOption1"
                margin="none"
                variant="outlined"
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                onChange={onChangeField}
                value={Tab3_Policycore_Home_Var.svuExcessOption1}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="500">$500</MenuItem>
                <MenuItem value="600">$600</MenuItem>
                <MenuItem value="700">$700</MenuItem>
                <MenuItem value="750">$750</MenuItem>
                <MenuItem value="800">$800</MenuItem>
                <MenuItem value="1000">$1000</MenuItem>
                <MenuItem value="1250">$1250</MenuItem>
                <MenuItem value="1500">$1500</MenuItem>
                <MenuItem value="1750">$1750</MenuItem>
                <MenuItem value="2000">$2000</MenuItem>
                <MenuItem value="2500">$2500</MenuItem>
                <MenuItem value="3000">$3000</MenuItem>
                <MenuItem value="5000">$5000</MenuItem>
                <MenuItem value="7500">$7500</MenuItem>
                <MenuItem value="10000">$10000</MenuItem>
              </Select>
            </Grid>

            {/*SVU Excess Option 2 */}
            {/* <Grid item xs={6}>
            <InputLabel
              htmlFor="SVU Excess Option 2"
              style={{ marginBottom: "5px" }}
              required
            >
               Excess Option 2
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="svuExcessOption2"
              margin="none"
              variant="outlined"
              style={{ marginBottom: "20px", height: "40px", marginLeft: "6px", width: "450px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Home_Var.svuExcessOption2}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="400">$400</MenuItem>
              <MenuItem value="500">$500</MenuItem>
              <MenuItem value="600">$600</MenuItem>
              <MenuItem value="700">$700</MenuItem>
              <MenuItem value="750">$750</MenuItem>
              <MenuItem value="800">$800</MenuItem>
              <MenuItem value="900">$900</MenuItem>
              <MenuItem value="1000">$1000</MenuItem>
              <MenuItem value="1200">$1200</MenuItem>
              <MenuItem value="1400">$1400</MenuItem>
              <MenuItem value="1600">$1600</MenuItem>
              <MenuItem value="1800">$1800</MenuItem>
              <MenuItem value="2000">$2000</MenuItem>
              <MenuItem value="2500">$2500</MenuItem>
              <MenuItem value="3000">$3000</MenuItem>
              <MenuItem value="5000">$5000</MenuItem>
            </Select>
          </Grid> */}

            {/*SVU Excess Option 3 */}
            {/* <Grid item xs={6}>
            <InputLabel
              htmlFor="SVU Excess Option 3"
              style={{ marginBottom: "5px" }}
              required
            >
               Excess Option 3
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="svuExcessOption3"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px", marginLeft: "6px", width: "450px" }}
              fullWidth
              value={Tab3_Policycore_Home_Var.svuExcessOption3}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="400">$400</MenuItem>
              <MenuItem value="500">$500</MenuItem>
              <MenuItem value="600">$600</MenuItem>
              <MenuItem value="700">$700</MenuItem>
              <MenuItem value="750">$750</MenuItem>
              <MenuItem value="800">$800</MenuItem>
              <MenuItem value="900">$900</MenuItem>
              <MenuItem value="1000">$1000</MenuItem>
              <MenuItem value="1200">$1200</MenuItem>
              <MenuItem value="1400">$1400</MenuItem>
              <MenuItem value="1600">$1600</MenuItem>
              <MenuItem value="1800">$1800</MenuItem>
              <MenuItem value="2000">$2000</MenuItem>
              <MenuItem value="2500">$2500</MenuItem>
              <MenuItem value="3000">$3000</MenuItem>
              <MenuItem value="5000">$5000</MenuItem>
            </Select>
          </Grid> */}

            {/* Broker Fee) */}
            {/* <Grid item xs={6}>
            <InputLabel
              htmlFor="Broker Fee"
              style={{ marginBottom: "5px" }}
              required
            >
              Broker Fee
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <TextField
              type="number"
              name="brokerFee"
              size="small"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              style={{ marginBottom: "20px", marginLeft: "6px", width: "450px" }}
              fullWidth
              value={Tab3_Policycore_Home_Var.brokerFee}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">$</InputAdornment>
                ),
              }}
            />
            {Tab3_Validation_Home_Var.brokerFee !== null &&
              Tab3_Validation_Home_Var.brokerFee !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Home_Var.brokerFee}
                </div>
              )}
          </Grid> */}

            {/*Payment Frequency */}
            <Grid item xs={6}>
              <InputLabel
                htmlFor="Payment Frequency"
                style={{ marginBottom: "5px" }}
                required
              >
                Payment Frequency
              </InputLabel>
            </Grid>

            <Grid item xs={6}>
              <Select
                name="paymentFrequency"
                margin="none"
                variant="outlined"
                style={{
                  marginBottom: "20px",
                  height: "40px",
                  marginLeft: "6px",
                  width: "450px",
                }}
                fullWidth
                onChange={onChangeField}
                value={Tab3_Policycore_Home_Var.paymentFrequency}
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Yearly">Yearly</MenuItem>
                <MenuItem value="Monthly">Monthly</MenuItem>
              </Select>
            </Grid>

            {Tab3_Policycore_Home_Var.paymentFrequency === "Monthly" && (
              <Grid container xs={12} direction="row" spacing={2}>
                {/* Preferred Day for installments */}
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="Preferred Day for installments"
                    style={{ marginBottom: "20px" }}
                    required
                  >
                    Preferred Day for installments
                  </InputLabel>
                </Grid>


                 <Grid item xs={6}>
                  <Select 
                    name="preferredinstallments"
                    onChange={onChangeField}
                    value={Tab3_Policycore_Home_Var.preferredinstallments}
                    variant="outlined"
                    fullWidth
                    style={{
                     marginBottom: "20px",
                     height: "40px",
                     marginLeft: "6px",
                     width: "450px",
                         }}
                  >
                   {preferredDays.map(({day} , index) => (
                    <MenuItem  
                     key ={day}
                     disabled={index === 0}
                     value={day}
                    >
                     {day}
                     </MenuItem>
                     ))}
                  </Select>              
                </Grid>

                {/* Broker Fee (installments) */}
                <Grid item xs={6}>
                  <InputLabel
                    htmlFor="Broker Fee (installments)"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    Broker Fee (installments)
                  </InputLabel>
                </Grid>

                <Grid item xs={6}>
                  <TextField
                    type="number"
                    name="brokerFeeinstallments"
                    size="small"
                    variant="outlined"
                    autoComplete="off"
                    onChange={onChangeField}
                    onKeyPress={(e) => validationForNumbOnly(e)}
                    value={Tab3_Policycore_Home_Var.brokerFeeinstallments}
                    style={{ marginBottom: "20px", width: "450px" }}
                    fullWidth
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">$</InputAdornment>
                      ),
                    }}
                  />
                  <div className="text-danger font-italic"></div>
                </Grid>
              </Grid>
            )}
          </Grid>
          <div style={{ marginBottom: "5rem" }}>
            <Grid>
              <Button
                variant="contained"
                color="secondary"
                style={{
                  marginTop: "1rem",
                  float: "left",
                  width: "10%",
                }}
                onClick={() => exit()}
              >
                EXIT
              </Button>
            </Grid>

            <Grid>
              <Button
                variant="contained"
                color="primary"
                style={{
                  marginTop: "1rem",
                  float: "right",
                  width: "10%",
                }}
                onClick={() => navigation.next()}
              >
                NEXT
              </Button>
            </Grid>
            <Grid>
              <Button
                variant="contained"
                color="primary"
                style={{
                  marginTop: "1rem",
                  marginBottom: "1rem",
                  float: "right",
                  marginRight: "20px",
                  width: "10%",
                }}
                onClick={() => navigation.previous()}
              >
                PREVIOUS
              </Button>
            </Grid>
          </div>
        </div>
      </Container>
      {/* <Footer /> */}
    </div>
  );
};

export default Tab3_Policycore_Home;
