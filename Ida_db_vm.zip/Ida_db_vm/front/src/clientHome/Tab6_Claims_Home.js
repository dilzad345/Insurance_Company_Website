import React, { useState } from "react";
// import Footer from "../component/footer/Footer";
import {
  TextField,
  Container,
  Button,
  InputLabel,
  MenuItem,
  Select,
  Grid,
} from "@material-ui/core";
// import { makeStyles } from "@material-ui/core/styles";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import InputAdornment from "@material-ui/core/InputAdornment";
import DatePicker from "react-datepicker";
import { Autocomplete } from "@mui/material";
import { insurerValues } from "../constants/dropDownData";
import { Redirect } from "react-router-dom";
import { exit } from "../constants/exit";
import {
  validationForNumbOnly, validationForSpecialchar
} from "../constants/validChecker";

import {
  typeClaim_validate,
  dateClaim_validate,
  description_validate,
  amount_validate,
  insurer_validate,
} from "../validationHome/Tab6_Validation_Home";

const notifyDeleteModification = () =>
  toast.success("Claim Deleted!", {
    position: "bottom-center",
    autoClose: 5000,
    hideProgressBar: true,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
  });

const Tab6_Claims_Home = ({
  Tab6_Claims_Home_Var,
  setTab6,
  Tab6_Validation_Home_Var,
  setTab6_validation,
  isAllFormsValid,
  navigation,
  submitAllForms,
}) => {
  // const modiCount = Tab6_Claims_Home_Var.length;
  // const classes = useStyles();
  // const [loaded, setLoad] = useState(false);
  const [loadClientHome, setLoadClientHome] = useState(false);

  const notify = () =>
    toast.success("Submission Status: Success!", {
      position: "bottom-center",
      autoClose: 800,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });

  const notifyFailure = () =>
    toast.error("Submission Status: Failed!", {
      position: "bottom-center",
      autoClose: 800,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });

  const handleSubmit = () => {
    submitAllForms()
      .then((res) => {
        console.log(res);
        if (res === true) {
          notify();
          setTimeout(function () {
            setLoadClientHome(true);
          }, 1000);
          console.log("set load home page: " + res);
          // setLoadClientHome(true); // change to true to redirect to the client home page
        } else if (res === false) {
          notifyFailure();
          setTimeout(function () {
            setLoadClientHome(true);
          }, 1000);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const loadClientHomePage = () => {
    if (loadClientHome) {
      return <Redirect to="/client" />;
    }
  };

  // add a home claims modifications
  const addMore = () => {
    setTab6((Tab6_Claims_Home_Var) => [
      ...Tab6_Claims_Home_Var,
      {
        typeClaim: " ",
        dateClaim: new Date(),
        description: "",
        amount: "",
        insurer: "",
      },
    ]);
    setTab6_validation((Tab6_Validation_Home_Var) => [
      ...Tab6_Validation_Home_Var,
      {
        typeClaim: " ",
        dateClaim: " ",
        description: "",
        amount: "",
        insurer: "",
      },
    ]);
  };

  // const [startDate, setStartDate] = useState(new Date());
  // onClick method: delete modification when not needed
  const deleteModi = (ind) => {
    console.log(ind);
    const temp = [...Tab6_Claims_Home_Var];
    const tempValidate = [...Tab6_Validation_Home_Var];

    confirmAlert({
      title: "Confirm to delete",
      message: "Are you sure to do this?",
      buttons: [
        {
          label: "Yes",
          onClick: () => {
            // removing the element using splice
            temp.splice(ind, 1);
            tempValidate.splice(ind, 1);

            Tab6_Claims_Home_Var = temp;
            Tab6_Validation_Home_Var = tempValidate;

            // updating the list
            setTab6(temp);
            setTab6_validation(tempValidate);

            notifyDeleteModification();
          },
        },
        {
          label: "No",
          onClick: () => null,
        },
      ],
    });
  };

  // set insurer field when selecting
  const setInsurer = (ind, val) => {
    console.log(ind);
    console.log(val);
    let name = "insurer";
    let value;
    let tempArr = [...Tab6_Claims_Home_Var];
    let tempObj = tempArr[ind];

    if (val) {
      value = val.insurAus;
      tempObj = {
        ...tempObj,
        [name]: value,
      };
      tempArr[ind] = tempObj;
      //console.log(tempArr);

      setTab6(tempArr, () => {
        validationAfterChange(ind, name, value);
      });
    } else {
      value = " ";
      tempObj = {
        ...tempObj,
        [name]: value,
      };
      tempArr[ind] = tempObj;
      //console.log(tempArr);

      setTab6(tempArr, () => {
        validationAfterChange(ind, name, value);
      });
    }
  };

  // on change method; to change field values according to the changes
  const onChangeField = (ind) => (event) => {
    let name = event.target.name;
    let value = event.target.value;
    console.log(name);
    // make a copy of original list as temporary list
    let tempArr = [...Tab6_Claims_Home_Var];
    let tempObj = tempArr[ind];

    // updating the temporary list
    tempObj = {
      ...tempObj,
      [event.target.name]: event.target.value,
    };

    // replace the list with temporary list
    tempArr[ind] = tempObj;
    //console.log(tempArr);

    setTab6(tempArr, () => {
      validationAfterChange(ind, name, value);
    });
  };

  //not to be allowed user typing
  const handleDateChangeRaw = (e) => {
    e.preventDefault();
  };
  //for date claim
  const dateClaim = (date, index) => {
    console.log(date);
    // setTab7({
    //   ...tab7_claims,
    //   dateClaim: date,

    // });
    let name = "dateClaim";
    let value = date;
    console.log("value:", value);
    console.log("index:", index);
    // make a copy of original list as temporary list
    let tempArr = [...Tab6_Claims_Home_Var];
    let tempObj = tempArr[index];

    // updating the temporary list
    tempObj = {
      ...tempObj,
      [name]: value,
    };

    // replace the list with temporary list
    tempArr[index] = tempObj;
    console.log("temparr:", tempArr);
    setTab6(tempArr);
    //console.log(setTab6);
    dateClaim_validate(
      index,
      value,
      Tab6_Validation_Home_Var,
      setTab6_validation
    );
  };
  // call validation
  const validationAfterChange = (index, name, value) => {
    switch (name) {
      case "typeClaim": {
        typeClaim_validate(
          index,
          value,
          Tab6_Validation_Home_Var,
          setTab6_validation
        );
        break;
      }
      case "dateClaim": {
        dateClaim_validate(
          index,
          value,
          Tab6_Validation_Home_Var,
          setTab6_validation
        );
        break;
      }
      case "description": {
        description_validate(
          index,
          value,
          Tab6_Validation_Home_Var,
          setTab6_validation
        );
        break;
      }
      case "amount": {
        amount_validate(
          index,
          value,
          Tab6_Validation_Home_Var,
          setTab6_validation
        );
        break;
      }
      case "insurer": {
        insurer_validate(
          index,
          value,
          Tab6_Validation_Home_Var,
          setTab6_validation
        );
        break;
      }
      default: {
        return "Not match to condition";
      }
    }
  };
  const displayTab6 = () => {
    return (
      <div>
        <Container maxWidth="md" style={{ marginBottom: "50px" }}>
          <div className="container p-3 my-3dark text-dark">
            <Grid item={true} xs={12} justifyContent="center" container>
              <h3>Add button below to add claims in the last 5 years </h3>
            </Grid>
            {Tab6_Claims_Home_Var.map((modi, index) => {
              return (
                <div>
                  <Grid
                    // className=""
                    // style={{ marginBottom: "100px" }}
                    key={index}
                    // direction="row"
                    container
                    spacing={3}
                    direction="row"
                    justifyContent="center"
                    alignItems="center"
                    style={{ marginBottom: "20px", marginTop: "20px" }}
                  >
                    <Grid item xs={4}>
                      <InputLabel
                        htmlFor="typeClaim"
                        style={{ marginBottom: "5px" }}
                        required
                      >
                        Type of Claim
                      </InputLabel>
                    </Grid>

                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <Select
                        name="typeClaim"
                        variant="outlined"
                        autoComplete="off"
                        onChange={onChangeField(index)}
                        onClose={() =>
                          validationAfterChange(
                            index,
                            "typeClaim",
                            modi.typeClaim
                          )
                        }
                        value={modi.typeClaim}
                        style={{ height: "40px" }}
                        fullWidth
                      >
                        <MenuItem disabled value=" ">
                          Please Select
                        </MenuItem>
                        <MenuItem value="Earthquake, storm, cyclone or hail">
                          Earthquake, storm, cyclone or hail
                        </MenuItem>
                        <MenuItem value="Bushfire">Bushfire</MenuItem>
                        <MenuItem value="Flood - Current Address">
                          Flood - Current Address
                        </MenuItem>
                        <MenuItem value="Flood - Previous Address">
                          Flood - Previous Address
                        </MenuItem>
                        <MenuItem value="House fire (not bushfire)">
                          House fire (not bushfire)
                        </MenuItem>
                        <MenuItem value="Theft (without break in)">
                          Theft (without break in)
                        </MenuItem>
                        <MenuItem value="Burglary (with break in)">
                          Burglary (with break in)
                        </MenuItem>
                        <MenuItem value="Damage from water from pipes and drains">
                          Damage from water from pipes and drains
                        </MenuItem>
                        <MenuItem value="Damage cause by children, pets or other accidental damage">
                          Damage cause by children, pets or other accidental
                          damage
                        </MenuItem>
                        <MenuItem value="Other claim type">
                          Other claim type
                        </MenuItem>
                      </Select>
                      {Tab6_Validation_Home_Var[index].typeClaim !== null &&
                        Tab6_Validation_Home_Var[index].typeClaim !==
                          "true" && (
                          <div className="text-danger font-italic">
                            {Tab6_Validation_Home_Var[index].typeClaim}
                          </div>
                        )}
                    </Grid>

                    <Grid item xs={4}>
                      <InputLabel
                        htmlFor="dateClaim"
                        style={{ marginBottom: "5px" }}
                        required
                      >
                        Date of Claim
                      </InputLabel>
                    </Grid>

                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <div>
                        <DatePicker
                          selected={modi.dateClaim}
                          dateFormat="dd/MM/yyyy"
                          name="dateClaim"
                          className="date-picker-align"
                          variant="outlined"
                          autoComplete="off"
                          onChange={(date) => dateClaim(date, index)}
                          onChangeRaw={handleDateChangeRaw}
                          value={modi.dateClaim}
                          maxDate={new Date()}
                          // style={{ height: "40px" }}
                          // fullWidth
                        />
                      </div>

                      {Tab6_Validation_Home_Var[index].dateClaim !== null &&
                        Tab6_Validation_Home_Var[index].dateClaim !==
                          "true" && (
                          <div className="text-danger font-italic">
                            {Tab6_Validation_Home_Var[index].dateClaim}
                          </div>
                        )}
                    </Grid>

                    <Grid item xs={4}>
                      <InputLabel
                        htmlFor="Description"
                        style={{ marginBottom: "5px" }}
                        required
                      >
                        Description
                      </InputLabel>
                    </Grid>

                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <TextField
                        name="description"
                        value={modi.description}
                        onChange={onChangeField(index)}
                        onKeyPress={(e) => validationForSpecialchar(e)}
                        size="small"
                        variant="outlined"
                        autoComplete="off"
                        // style={{ marginBottom: "20px" }}
                        required
                        fullWidth
                      />
                      {Tab6_Validation_Home_Var[index].description !== null &&
                        Tab6_Validation_Home_Var[index].description !==
                          "true" && (
                          <div className="text-danger font-italic">
                            {Tab6_Validation_Home_Var[index].description}
                          </div>
                        )}
                    </Grid>

                    <Grid item xs={4}>
                      <InputLabel
                        htmlFor="amount"
                        style={{ marginBottom: "5px" }}
                        required
                      >
                        Amount
                      </InputLabel>
                    </Grid>

                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <TextField
                        type="number"
                        name="amount"
                        value={modi.amount}
                        onChange={onChangeField(index)}
                        onKeyPress={(e) => validationForNumbOnly(e)}
                        size="small"
                        variant="outlined"
                        autoComplete="off"
                        // style={{ marginBottom: "20px" }}
                        required
                        fullWidth
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">$</InputAdornment>
                          ),
                        }}
                      />
                      {Tab6_Validation_Home_Var[index].amount !== null &&
                        Tab6_Validation_Home_Var[index].amount !== "true" && (
                          <div className="text-danger font-italic">
                            {Tab6_Validation_Home_Var[index].amount}
                          </div>
                        )}
                    </Grid>

                    {/* insurer field */}
                    <Grid item xs={4}>
                      <InputLabel
                        htmlFor="insurer"
                        style={{ marginBottom: "5px" }}
                        required
                      >
                        Insurer
                      </InputLabel>
                    </Grid>

                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <Autocomplete
                        options={insurerValues}
                        sx={{ width: 1 }}
                        isOptionEqualToValue={(option, value) =>
                          option.id === value.id
                        }
                        getOptionLabel={(option) =>
                          option.insurAus ? option.insurAus : "Please Select"
                        }
                        defaultValue={"please Select"}
                        name="insurer"
                        onChange={(event, val) => setInsurer(index, val)}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            variant="outlined"
                            value={modi.insurer}
                            label="Insurer"
                            required
                          />
                        )}
                      />
                      {Tab6_Validation_Home_Var[index].insurer !== null &&
                        Tab6_Validation_Home_Var[index].insurer !== "true" && (
                          <div className="text-danger font-italic">
                            {Tab6_Validation_Home_Var[index].insurer}
                          </div>
                        )}
                    </Grid>
                  </Grid>

                  <div>
                    <Button
                      style={{
                        float: "right",
                        width: "10%",
                        marginBottom: "30px",
                      }}
                      onClick={() => deleteModi(index)}
                      // className="bg-warning"
                      variant="contained"
                      color="secondary"
                    >
                      DELETE
                    </Button>

                    <br />
                    <hr
                      style={{
                        color: "red",
                        backgroundColor: "green",
                        height: 1,
                        marginTop: "50px",
                      }}
                    />
                  </div>
                </div>
              );
            })}
            <Grid
              direction="row"
              container
              justifyContent="center"
              alignItems="center"
            >
              <Grid item xs={12} style={{ marginTop: "20px" }}>
                <div className="alert alert-info">
                  {/* Add More Content by Pressing 'ADD MORE' button */}
                  Add button below to add claims in the last 5 years
                </div>
              </Grid>
              <Grid item={true} xs={4}></Grid>
              <Grid
                item
                xs={4}
                container
                justifyContent="center"
                alignItems="center"
              >
                <Button
                  fullWidth
                  onClick={addMore}
                  className="bg-success text-white"
                >
                  ADD MORE
                </Button>
              </Grid>
              <Grid item={true} xs={4}></Grid>
            </Grid>
          </div>

          <Grid>
            {isAllFormsValid() ? (
              <Button
                variant="contained"
                className="bg-warning"
                style={{
                  marginTop: "1rem",
                  float: "right",
                  marginBottom: "50px",
                }}
                onClick={handleSubmit}
              >
                SUBMIT
              </Button>
            ) : (
              <Button
                variant="contained"
                className="bg-alert"
                style={{
                  marginTop: "1rem",
                  float: "right",
                  marginBottom: "50px",
                }}
                disabled
              >
                SUBMIT
              </Button>
            )}
            <ToastContainer
              style={{
                marginLeft: "50px",
                marginBottom: "-25px",
                width: "30%",
              }}
            />
          </Grid>
          <div style={{ marginBottom: "14.8rem" }}>
            <Grid>
              <Button
                variant="contained"
                color="secondary"
                style={{
                  marginTop: "1rem",
                  float: "left",
                  width: "10%",
                }}
                onClick={() => exit()}
              >
                EXIT
              </Button>
            </Grid>

            {/* <Button
        variant="contained"
        color="primary"
        type="Submit"
        style={{
          marginTop: "1rem",
          float: "right",
          marginBottom: "50px",
          width: "10%",
        }}
        onClick={() => navigation.next()}
      >
        NEXT
      </Button> */}

            <Button
              variant="contained"
              color="primary"
              // className="bg-warning"
              style={{
                marginTop: "1rem",
                float: "right",
                marginBottom: "50px",
                marginRight: "20px",
                width: "10%",
              }}
              onClick={() => navigation.previous()}
            >
              PREVIOUS
            </Button>
          </div>
          <ToastContainer
            style={{ marginLeft: "50px", marginBottom: "-25px", width: "30%" }}
          />
        </Container>
        {/* <Footer /> */}
      </div>
    );
  };

  return (
    <div>
      {displayTab6()}
      {loadClientHomePage()}
    </div>
  );
};

export default Tab6_Claims_Home;
