// imports
import React, { useState } from "react";
import { useStep } from "react-hooks-helper";
import { useStateWithCallbackLazy } from "use-state-with-callback";

// local imports
import Tab1_Client_Home from './Tab1_Client_Home';
import Tab2_Importan_Question_Home from './Tab2_Importan_Question_Home';
import Tab3_Policycore_Home from './Tab3_Policycore_Home';
import Tab4_Building_Home from './Tab4_Building_Home';
import Tab5_Contents_Home from './Tab5_Contents_Home';
import Tab6_Claims_Home from './Tab6_Claims_Home';
// import navigationBarHome from './coreHome/navigationBarHome';
import navigationBarHome from '../coreHome/navigationBarHome';
import { addAllFormsValues, validateAllForms } from "./Home_Controller_clientLink";

const steps = [
  { id: "Tab1_Client_Home" },
  { id: "Tab2_Importan_Question_Home" },
  { id: "Tab3_Policycore_Home" },
  { id: "Tab4_Building_Home" },
  { id: "Tab5_Contents_Home" },
  { id: "Tab6_Claims_Home" },

];

const ClientHomeLink = () => {
  const { step, navigation } = useStep({
    steps,
    initialStep: 0,
  });


  // tab1 variable object defined
  const [Tab1_Client_Home_var, setTab1] = useStateWithCallbackLazy({
    clientType: " ",
    title: " ",
    firstName: "",
    lastName: "",
    companyName: "",
    tradingAs: "",
    officeTechReferenceCode: null,
    unitNumber: null,
    streetNumber: null,
    streetName: "",
    streetType: "Please Select",
    suburb: "",
    state: "Please Select",
    postCode: null,
    phone: "",
    email: null,
    branch: " ",
    salesTeam: " ",
    serviceTeam: " ",
    // //branch: "Insurance Brokers Australia",
    // //salesTeam: "Chris Dalton",
    // //serviceTeam: "Brisbane",

    //set default values at starting
    // clientType: "Individual",
    // title: "Mr",
    // firstName: "John",
    // lastName: "Smith",
    // companyName: "KaayalTek",
    // tradingAs: "Software Solutions",
    // officeTechReferenceCode: "0000",
    // unitNumber: 111,
    // streetNumber: 18,
    // streetName: "Carver",
    // streetType: "CRESCENT",
    // suburb: "Baulkham Hills",
    // state: "NSW",
    // postCode: '2156',
    // phone: "0117788985",
    // email: "sample@mail.com",
    // branch: "Insurance Brokers Australia",
    // salesTeam: "Chris Dalton",
    // serviceTeam: "Brisbane",
  });

  // tab1 validation
  const [Tab1_Validation_Home_Var, setTab1_validation] = useState({
    clientType: null,
    title: null,
    firstName: null,
    lastName: null,
    companyName: null,
    tradingAs: null,
    tab1_fullValidation: null,
    streetNumber: "",
    streetName: "",
    streetType: " ",
    suburb: "",
    state: " ",
    postCode: "",
    phone: "",
    email: "",
    branch: "",
    salesTeam: "",
    serviceTeam: "",
  });


  // tab2 variable object defined
  const [Tab2_Importan_Question_Home_var, setTab2] = useStateWithCallbackLazy({
    insPolcyCancellLast5Years: "No",
    hadClaimDeclained: "No",
    maliciousDamage: "No",
    homeUnderConstruction: "No",
    Bankruptcy: "No",
    buildingFlooded: "No",
  });

  // tab3 variable object defined
  let myCurrentToDate = new Date();
  // console.log(myCurrentToDate.getFullYear());
  myCurrentToDate.setFullYear(myCurrentToDate.getFullYear() + 1);


  // set default year reduced by 16 from current year for date of birth
  let tempYear= new Date();
  tempYear.setFullYear(tempYear.getFullYear()-16);

  const [Tab3_Policycore_Home_Var, setTab3] = useStateWithCallbackLazy({
    coverType: " ",
    basisOfSettlement: " ",
    buildingOrContents: " ",
    buildingSumInsured: null,
    contentsSumInsuredAmount: null,
    policyFromDate: new Date(),
    policyToDate: myCurrentToDate,
    // dobOldestInsured: new Date(),  //dob:date of birth
    dobOldestInsured: tempYear,  //dob:date of birth
    industryPolicyHolder: " ",
    policyHolderRetired: " ",
    conductedFromHome: " ",
    fromHomeBusinessName: " ",
    fromHomeWhatBusiness: " ",
    fromHomeAnnualRevenue: null,
    fromHomeBusnsOccupyFloorArea: " ",
    underConstruction: " ",
    poorlyMaintained: " ",
    unoccupiedDays: " ",
    guestHouse: " ",
    publicHousing: " ",
    currentlyInsurance: " ",
    interestedParties: " ",
    jettyAttachedProperty: null,
    svuExcessOption1: " ",
    svuExcessOption2: " ",
    ////svuExcessOption2: "600",
    ////svuExcessOption3: "700",
     svuExcessOption3: " ",
    brokerFee: null,
    ////brokerFee: "",
    paymentFrequency: " ",
    preferredinstallments: "Please Select",
    brokerFeeinstallments: null,
    unspecifiedValues: " ",

    //set default values at starting
    // coverType: "Accidental Damage",
    // basisOfSettlement: "Replacement",
    // buildingOrContents: "Building only",
    // buildingSumInsured: "1000",
    // contentsSumInsuredAmount: "1000",
    // policyFromDate: new Date(),
    // policyToDate: myCurrentToDate,
    // dobOldestInsured: new Date(),  //dob:date of birth
    // industryPolicyHolder: "Banking and Finance",
    // policyHolderRetired: "No",
    // conductedFromHome: "No",
    // fromHomeBusinessName: "ABC",
    // fromHomeWhatBusiness: "Accounting",
    // fromHomeAnnualRevenue: "1000",
    // fromHomeBusnsOccupyFloorArea: "No",
    // underConstruction: "No",
    // poorlyMaintained: "No",
    // unoccupiedDays: "No",
    // guestHouse: "No",
    // publicHousing: "No",
    // currentlyInsurance: "0-1 Years",
    // interestedParties: "Adelaide Bank",
    // jettyAttachedProperty: "No",
    // svuExcessOption1: "500",
    ////svuExcessOption2: "600",
    ////svuExcessOption3: "700",
    // brokerFee: "800",
    // paymentFrequency: "Yearly",
    // preferredinstallments: "600",
    // brokerFeeinstallments: "700",
    // unspecifiedValues: " ",

  });

  // tab3 validation
  const [Tab3_Validation_Home_Var, setTab3_validation] = useState({
    buildingSumInsured: "",
    contentsSumInsuredAmount: "",
    fromHomeBusinessName: "",
    preferredinstallments: "",
  });
  // tab4 variable object defined

  const [Tab4_Building_Home_Var, setTab4] = useStateWithCallbackLazy({
    //these fields is not assigned
    insuredAddress: " ",
    streetNumber_insured: "",
    street_name_insured: "",
    street_type_insured: "Please Select",
    suburb_insured: "",
    state_insured: "Please Select",
    postcode_insured: "",
    prptyHeritageList: " ",
    provideDetails: " ",
    whatOccupancyHome: " ",
    buildingType: " ",
    whatBuiltHome: " ",
    whatTypeApartment: " ",
    whatTypeSemiDetached: " ",
    managemenBodyCorporate: " ",
    dwellingDescribesHome: " ",
    smhAcres20000: " ",
    insuredGenerateIncome: " ",
    machineryImplmtVehicles: " ",
    more6Livestock: " ",
    propertyUsedAnimals: " ",
    nonPersonalUse: " ",
    aircraftLandingStrip: " ",
    constructionPeriod: " ",
    originalYearBuilt: "2016",
    constructionWalls: " ",
    roofConstruction: " ",
    consQualityofHome: " ",
    numberOfPropertyHave: " ",
    unitBuildingLevel: "1",
    effectByWtaer: " ",
    mainsWaterSupply: " ",
    windowSecurity: " ",
    doorSecurity: " ",
    burglarAlarm: " ",
    smokeDetectors: null,
    builtConstNextMnth: " ",
    swimmingPool: " ",
    locatedbelowgRoundLevel: " ",
    privateFlood: " ",
    occupancyCertificate: " ",
    housebeenReroofed:" ",
    housebeenReplumbed:" ",
    housebeenRewired :" ",

    //set default values at starting
    
    // insuredAddress: "Yes",
    // streetNumber_insured: " ",
    // street_name_insured: " ",
    // street_type_insured: " ",
    // suburb_insured: " ",
    // state_insured: " ",
    // postcode_insured: " ",
    // prptyHeritageList: "No",
    // provideDetails: "Australia",
    // whatOccupancyHome: "Rent/Lease",
    // buildingType: "Free Standing / House",
    // whatBuiltHome: "Concrete slab",
    // whatTypeApartment: "Ground floor",
    // whatTypeSemiDetached: "Duplex/Triplex",
    // managemenBodyCorporate: "No",
    // dwellingDescribesHome: "Granny flat",
    // smhAcres20000: "No",
    // insuredGenerateIncome: "No",
    // machineryImplmtVehicles: "No",
    // more6Livestock: "No",
    // propertyUsedAnimals: "No",
    // nonPersonalUse: "No",
    // aircraftLandingStrip: "No",
    // constructionPeriod: "1960 to now (project home)",
    // originalYearBuilt: "1971",
    // constructionWalls: "Concrete",
    // roofConstruction: "Concrete Tile",
    // consQualityofHome: "Standard",
    // numberOfPropertyHave: "1",
    // unitBuildingLevel: "1",
    // effectByWtaer: "No",
    // mainsWaterSupply: "No",
    // windowSecurity: "Key Operated Locks",
    // doorSecurity: "Key operated dead locks/bolts",
    // burglarAlarm: "Back to base",
    // smokeDetectors: null,
    // builtConstNextMnth: "No",
    // swimmingPool: "No",
    // locatedbelowgRoundLevel: "No",
    // privateFlood: "No",
    // occupancyCertificate: " ",
  });

  // tab4 validation
  const [Tab4_Validation_Home_Var, setTab4_validation] = useState({
    // originalYearBuilt: "",

  });


  const [Tab5_Contents_Home_Var, setTab5] = useStateWithCallbackLazy([]);

  const [Tab5_Validation_Home_Var, setTab5_validation] = useState([]);


  const [Tab6_Claims_Home_Var, setTab6] = useStateWithCallbackLazy([
           
  ]);

  const [Tab6_Validation_Home_Var, setTab6_validation] = useState([
    {
      typeClaim: "",
      dateClaim: "",
      description: "",
      amount: "",
      insurer: ""
    }
  ]);

  // submit all forms
  const submitAllForms = () => {
    return addAllFormsValues(
      Tab1_Client_Home_var,
      Tab2_Importan_Question_Home_var,
      Tab3_Policycore_Home_Var,
      Tab4_Building_Home_Var,
      Tab5_Contents_Home_Var,
      Tab6_Claims_Home_Var
    ).then((res) => {
      //console.log(res);
      if (res.status === 201) {
        return true;
      } else {
        return false;
      }

    }).catch((error) => {
      console.log(error);
      return false;
    });
  }; // end of submit function

  // validate all forms
  const isAllFormsValid = () => {
    const isValid = validateAllForms(
      Tab1_Client_Home_var,
      Tab2_Importan_Question_Home_var,
      Tab3_Policycore_Home_Var,
      Tab4_Building_Home_Var,
      Tab5_Contents_Home_Var,
      Tab6_Claims_Home_Var,
    );
    return isValid;
  };

  // props: tab1, creating props to provide to every tab components
  const props1 = {
    Tab1_Client_Home_var,
    setTab1,
    Tab1_Validation_Home_Var,
    setTab1_validation,
    navigation,
  };

  // props: tab2, creating props to provide to every tab components
  const props2 = {
    Tab2_Importan_Question_Home_var,
    setTab2,
    navigation,
  };

  const props3 = {
    Tab3_Policycore_Home_Var,
    setTab3,
    Tab3_Validation_Home_Var,
    setTab3_validation,
    navigation,

  };

  let coverType = props3.Tab3_Policycore_Home_Var.coverType;

  // console.log(coverType);
  const props4 = {
    Tab4_Building_Home_Var,
    setTab4,
    Tab4_Validation_Home_Var,
    setTab4_validation,
    Tab1_Client_Home_var,
    // setTab1,
    navigation,
  };

  const props5 = {
    Tab5_Contents_Home_Var,
    setTab5,
    Tab5_Validation_Home_Var,
    setTab5_validation,
    coverType,
    Tab3_Policycore_Home_Var,
    setTab3,
    Tab3_Validation_Home_Var,
    setTab3_validation,
    navigation,

  };

  const props6 = {
    Tab6_Claims_Home_Var,
    setTab6,
    Tab6_Validation_Home_Var,
    setTab6_validation,
    isAllFormsValid,
    submitAllForms,
    navigation,
  };


  const displayTabs = () => {
    switch (step.id) {
      default: return <Tab1_Client_Home />;
      case "Tab1_Client_Home": return <Tab1_Client_Home {...props1} />;
      case "Tab2_Importan_Question_Home": return <Tab2_Importan_Question_Home {...props2} />;
      case "Tab3_Policycore_Home": return <Tab3_Policycore_Home {...props3} />;
      case "Tab4_Building_Home": return <Tab4_Building_Home {...props4} />;
      case "Tab5_Contents_Home": return <Tab5_Contents_Home  {...props5} />;
      case "Tab6_Claims_Home": return <Tab6_Claims_Home {...props6} />;
    }
  }

  // set props to navigation bar
  const propsNavBarHome = {
    step,
    navigation,
    Tab1_Client_Home_var,
    Tab2_Importan_Question_Home_var,
    Tab3_Policycore_Home_Var,
    Tab4_Building_Home_Var,
    Tab5_Contents_Home_Var,
    Tab6_Claims_Home_Var,

  };



  // return ui content
  return (<div>
    {navigationBarHome(propsNavBarHome)}
    {displayTabs()}
  </div>);
}

export default ClientHomeLink;