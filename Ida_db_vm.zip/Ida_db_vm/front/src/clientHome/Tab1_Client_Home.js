import React from "react";
// import Footer from "../component/footer/Footer";
import "../css/homeStyle.css";

import {
  TextField,
  Container,
  Button,
  Select,
  InputLabel,
  MenuItem,
  Grid,
  Box,
} from "@material-ui/core";
// import { makeStyles } from "@material-ui/core/styles";
import { Autocomplete } from "@mui/material";
import { Redirect } from "react-router-dom";
import { streetTypes, stateAus } from "../constants/dropDownData";
import {
  validationForSpecialchar,
  inText,
  validationForAlpha,
  inpNum,
  validationForNumbOnly,
  inpTextwithSpace,
} from "../constants/validChecker";
import {
  clientType_validate,
  title_validate,
  firstName_validate,
  lastName_validate,
  companyName_validate,
  tradingAs_validate,
  streetNumber_validate,
  streetName_validate,
  streetType_validate,
  suburb_validate,
  state_validate,
  postCode_validate,
  phone_validate,
  email_validate,
  branch_validate,
  salesTeam_validate,
  serviceTeam_validate,
} from "../validationHome/Tab1_Validation_Home";
import { exit } from "../constants/exit";
// const useStyles = makeStyles((theme) => ({
//   root: {
//     flexGrow: 1,
//     alignContent: "center",
//     padding: theme.spacing(2),
//     //textAlign: 'center',
//   },
//   paper: {
//     padding: theme.spacing(2),
//     textAlign: "center",
//     color: theme.palette.text.secondary,
//   },

//   // bg_color: {
//   //   backgroundColor: "#f0f0f5",
//   //   marginBottom: "5px",
//   // },
// }));

// const returnClientHome = () => {
//   return <Redirect to="/client_home_link" />;
// };

const Tab1_Client_Home = ({
  Tab1_Client_Home_var,
  setTab1,
  Tab1_Validation_Home_Var,
  setTab1_validation,
  navigation,
}) => {
  // const classes = useStyles();

  const onChangeField = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    setTab1(
      {
        ...Tab1_Client_Home_var,
        [name]: value,
      },
      () => {
        validationAfterChange(name, value);
      }
    );
  };

  const setStreetType = (val) => {
    let name = "streetType";
    if (val) {
      let value = val.group;
      setTab1(
        {
          ...Tab1_Client_Home_var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    } else {
      let value = " ";
      setTab1(
        {
          ...Tab1_Client_Home_var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    }
  };

  //set state for Aus
  const setStateAus = (val, event) => {
    console.log(val);
    if (val) {
      let name = "state";
      let value = val.stAus;
      console.log(value);
      setTab1(
        {
          ...Tab1_Client_Home_var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    } else {
      let name = "state";
      let value = " ";
      setTab1(
        {
          ...Tab1_Client_Home_var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    }
    //  console.log(event);
  };

  // call validation
  const validationAfterChange = (name, value) => {
    if (name === "clientType") {
      if (Tab1_Client_Home_var.clientType === "Company") {
        Tab1_Client_Home_var.title = " ";
        Tab1_Client_Home_var.firstName = "";
        Tab1_Client_Home_var.lastName = "";
      } else if (Tab1_Client_Home_var.clientType === "Individual") {
        Tab1_Client_Home_var.companyName = "";
        Tab1_Client_Home_var.tradingAs = "";
      }
    }

    switch (name) {
      case "clientType": {
        clientType_validate(
          value,
          Tab1_Validation_Home_Var,
          setTab1_validation
        );
        break;
      }
      case "title": {
        title_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "firstName": {
        firstName_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "lastName": {
        lastName_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "companyName": {
        companyName_validate(
          value,
          Tab1_Validation_Home_Var,
          setTab1_validation
        );
        break;
      }
      case "tradingAs": {
        tradingAs_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }

      case "streetNumber": {
        streetNumber_validate(
          value,
          Tab1_Validation_Home_Var,
          setTab1_validation
        );
        break;
      }
      case "streetName": {
        streetName_validate(
          value,
          Tab1_Validation_Home_Var,
          setTab1_validation
        );
        break;
      }
      case "streetType": {
        console.log(value);
        streetType_validate(
          value,
          Tab1_Validation_Home_Var,
          setTab1_validation
        );
        break;
      }
      case "suburb": {
        suburb_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "state": {
        console.log(value);
        state_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "postCode": {
        postCode_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "phone": {
        phone_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "email": {
        email_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "branch": {
        branch_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "salesTeam": {
        salesTeam_validate(value, Tab1_Validation_Home_Var, setTab1_validation);
        break;
      }
      case "serviceTeam": {
        serviceTeam_validate(
          value,
          Tab1_Validation_Home_Var,
          setTab1_validation
        );
        break;
      }
      default: {
        console.log("Not match to condition");
      }
    }
  };

  return (
    <div>
      <Container maxWidth="md" style={{ marginBottom: "30px" }}>
        <div>
          <Grid
            container
            spacing={3}
            direction="row"
            justifyContent="center"
            alignItems="center"
          >
            <Grid
              item
              xs={12}
              textalign="center"
              justifyContent="center"
              container
            >
              <h3>GENERAL INFORMATION</h3>
            </Grid>

            {/* CLIENT TYPE */}
            <Grid item xs={5}>
              <InputLabel
                required
                htmlFor="Client Type"
                style={{ marginBottom: "5px" }}
              >
                Client Type
              </InputLabel>
            </Grid>

            <Grid item xs={7}>
              <Select
                name="clientType"
                margin="none"
                variant="outlined"
                autoComplete="off"
                onChange={onChangeField}
                value={Tab1_Client_Home_var.clientType}
                onClose={() =>
                  validationAfterChange(
                    "clientType",
                    Tab1_Client_Home_var.clientType
                  )
                }
                style={{
                  marginBottom: "2px",
                  height: "40px",
                  marginLeft: "5px",
                  width: "500px",
                }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Individual">Individual</MenuItem>
                <MenuItem value="Company">Company</MenuItem>
              </Select>

              {Tab1_Validation_Home_Var.clientType !== null &&
                Tab1_Validation_Home_Var.clientType !== "true" && (
                  <div className="text-danger font-italic">
                    {Tab1_Validation_Home_Var.clientType}
                  </div>
                )}
            </Grid>

            {Tab1_Client_Home_var.clientType === "Individual" && (
              <Grid item container xs={12} direction="row" spacing={2}>
                <Grid item xs={5}>
                  <InputLabel
                    htmlFor="Client Title"
                    style={{ marginBottom: "5px" }}
                    // required
                  >
                    Client Title
                  </InputLabel>
                </Grid>
                <Grid item xs={7}>
                  <Select
                    margin="none"
                    name="title"
                    variant="outlined"
                    size="small"
                    autoComplete="off"
                    value={Tab1_Client_Home_var.title}
                    onChange={onChangeField}
                    // onClose={() =>
                    //   validationAfterChange("title")
                    // }
                    style={{
                      height: "40px",
                      marginLeft: "7px",
                      width: "500px",
                    }}
                    fullWidth
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    <MenuItem value="Mr">Mr</MenuItem>
                    <MenuItem value="Miss">Miss</MenuItem>
                    <MenuItem value="Mrs">Mrs</MenuItem>
                    <MenuItem value="Ms">Ms</MenuItem>
                    <MenuItem value="Dr">Dr</MenuItem>
                  </Select>
                  {Tab1_Validation_Home_Var.title !== null &&
                    Tab1_Validation_Home_Var.title !== "true" && (
                      <div className="text-danger font-italic">
                        {Tab1_Validation_Home_Var.title}
                      </div>
                    )}
                </Grid>

                <Grid item xs={5}>
                  {/* First Name */}
                  <InputLabel
                    htmlFor="First Name"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    First Name
                  </InputLabel>
                </Grid>
                <Grid item xs={7}>
                  <TextField
                    name="firstName"
                    size="small"
                    variant="outlined"
                    autoComplete="off"
                    onChange={onChangeField}
                    onKeyPress={(e) => validationForAlpha(e)}
                    value={Tab1_Client_Home_var.firstName}
                    style={{
                      marginBottom: "5px",
                      marginLeft: "7px",
                      width: "500px",
                    }}
                    fullWidth
                  />
                  {Tab1_Validation_Home_Var.firstName !== null &&
                    Tab1_Validation_Home_Var.firstName !== "true" && (
                      <div className="text-danger font-italic">
                        {Tab1_Validation_Home_Var.firstName}
                      </div>
                    )}
                </Grid>

                <Grid item xs={5}>
                  {/* Last Name */}
                  <InputLabel
                    htmlFor="Last Name"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    Last Name
                  </InputLabel>
                </Grid>
                <Grid item xs={7}>
                  <TextField
                    name="lastName"
                    size="small"
                    variant="outlined"
                    autoComplete="off"
                    onChange={onChangeField}
                    onKeyPress={(e) => validationForAlpha(e)}
                    value={Tab1_Client_Home_var.lastName}
                    style={{ marginLeft: "7px", width: "500px" }}
                    fullWidth
                  />
                  {Tab1_Validation_Home_Var.lastName !== null &&
                    Tab1_Validation_Home_Var.lastName !== "true" && (
                      <div className="text-danger font-italic">
                        {Tab1_Validation_Home_Var.lastName}
                      </div>
                    )}
                </Grid>
              </Grid>
            )}

            {Tab1_Client_Home_var.clientType === "Company" && (
              <Grid item container xs={12} direction="row" spacing={2}>
                <Grid item xs={5}>
                  <InputLabel
                    htmlFor="Company Name"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    Company Name
                  </InputLabel>
                </Grid>

                <Grid item xs={7}>
                  <TextField
                    name="companyName"
                    size="small"
                    variant="outlined"
                    autoComplete="off"
                    // onClose={() =>
                    //   validationAfterChange("companyName")
                    // }
                    value={Tab1_Client_Home_var.companyName}
                    onChange={onChangeField}
                    onKeyPress={(e) => validationForSpecialchar(e)}
                    style={{
                      marginBottom: "10px",
                      marginLeft: "8px",
                      width: "500px",
                    }}
                    fullWidth
                  />
                  {Tab1_Validation_Home_Var.companyName !== null &&
                    Tab1_Validation_Home_Var.companyName !== "true" && (
                      <div className="text-danger font-italic">
                        {Tab1_Validation_Home_Var.companyName}
                      </div>
                    )}
                </Grid>

                {/* Trading As */}
                <Grid item xs={5}>
                  <InputLabel
                    htmlFor="Trading As"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    Trading As
                  </InputLabel>
                </Grid>
                <Grid item xs={7}>
                  <TextField
                    name="tradingAs"
                    // onkeypress="return /[a-z]/i.test(event.key)"
                    size="small"
                    variant="outlined"
                    autoComplete="off"
                    onChange={onChangeField}
                    onKeyPress={(e) => validationForAlpha(e)}
                    // onClose={() =>
                    //   validationAfterChange("tradingAs")
                    // }
                    value={Tab1_Client_Home_var.tradingAs}
                    style={{ marginLeft: "7px", width: "500px" }}
                    fullWidth
                  />

                  {Tab1_Validation_Home_Var.tradingAs !== null &&
                    Tab1_Validation_Home_Var.tradingAs !== "true" && (
                      <div className="text-danger font-italic">
                        {Tab1_Validation_Home_Var.tradingAs}
                      </div>
                    )}
                </Grid>
              </Grid>
            )}

            {/* office tect reference code */}
            {/* <Grid item xs={5}>
            <InputLabel
              htmlFor="OfficeTech Reference Code (IBA ONLY)"
              style={{ marginBottom: "5px" }}
            >
              OfficeTech Reference Code (IBA ONLY)
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              name="officeTechReferenceCode"
              size="small"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              value={Tab1_Client_Home_var.officeTechReferenceCode}
              style={{ marginLeft: "5px", width: "500px" }}
              fullWidth
            />
            {Tab1_Validation_Home_Var.officeTechReferenceCode !== null &&
              Tab1_Validation_Home_Var.officeTechReferenceCode !== "true" && (
                <div className="text-danger font-italic">
                  {Tab1_Validation_Home_Var.officeTechReferenceCode}
                </div>
              )}
          </Grid> */}

            {/* box component */}
            <Box
              component="span"
              sx={{
                width: "100%",
                p: 4,
                borderRadius: 8,
                border: "1px solid grey",
                display: "flex",
                flexWrap: "wrap",
                justifyContent: "space-around",
                // flexDirection: 'column',
              }}
              m={2}
              pt={3}
            >
              <Grid item xs={12} justifyContent="center" container>
                <Box
                  sx={{
                    border: "1px solid grey",
                    borderRadius: 8,
                    padding: "6px 8px 0px 7px",
                    // alignItems:'center',
                    // alignContent:'center',
                    margin: "0px 0px 10px 2px",
                    justifyContent: "center",
                  }}
                >
                  <h5>POSTAL ADDRESS</h5>
                </Box>
              </Grid>

              {/* Unit Number */}
              <Grid item xs={4} style={{ padding: "8px" }}>
                <TextField
                  label="Unit Number (not req for PO Box)"
                  name="unitNumber"
                  size="small"
                  type="text"
                  // margin="normal"
                  variant="outlined"
                  autoComplete="off"
                  onChange={onChangeField}
                  onKeyPress={(e) => validationForSpecialchar(e)}
                  value={Tab1_Client_Home_var.unitNumber}
                  style={{ width: "100%" }}
                  InputLabelProps={{ style: { fontSize: 15 } }}
                  fullWidth
                />
                {Tab1_Validation_Home_Var.unitNumber !== null &&
                  Tab1_Validation_Home_Var.unitNumber !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab1_Validation_Home_Var.unitNumber}
                    </div>
                  )}
              </Grid>

              {/* Street Number */}
              <Grid item xs={4} style={{ padding: "8px" }}>
                <TextField
                  name="streetNumber"
                  label="Street Number"
                  size="small"
                  type="text"
                  variant="outlined"
                  autoComplete="off"
                  onChange={onChangeField}
                  onKeyPress={(e) => validationForSpecialchar(e)}
                  value={Tab1_Client_Home_var.streetNumber}
                  style={{ width: "100%" }}
                  InputLabelProps={{ style: { fontSize: 15 } }}
                  required
                  fullWidth
                />
                {Tab1_Validation_Home_Var.streetNumber !== null &&
                  Tab1_Validation_Home_Var.streetNumber !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab1_Validation_Home_Var.streetNumber}
                    </div>
                  )}
              </Grid>

              {/* Street Name */}
              <Grid item xs={4} style={{ padding: "8px" }}>
                {/* <InputLabel
                required
                htmlFor="Street Name"
                style={{ marginBottom: "5px" }}
              >
                Street Name
              </InputLabel> */}
                <TextField
                  // label="Street Name (or PO Box)"
                  name="streetName"
                  size="small"
                  // margin="normal"
                  label="Street Name"
                  variant="outlined"
                  autoComplete="off"
                  onChange={onChangeField}
                  onKeyPress={(e) => inpTextwithSpace(e)}
                  value={Tab1_Client_Home_var.streetName}
                  style={{ width: "100%" }}
                  InputLabelProps={{ style: { fontSize: 15 } }}
                  required
                  fullWidth
                />

                {Tab1_Validation_Home_Var.streetName !== null &&
                  Tab1_Validation_Home_Var.streetName !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab1_Validation_Home_Var.streetName}
                    </div>
                  )}
              </Grid>

              {/* Street Type */}
              <Grid item xs={4} style={{ padding: "8px" }}>
                <Autocomplete
                  options={streetTypes}
                  sx={{ width: "100%" }}
                  isOptionEqualToValue={(option, value) =>
                    option.id === value.id
                  }
                  getOptionLabel={(option) =>
                    option.group
                      ? option.group
                      : Tab1_Client_Home_var.streetType
                  }
                  defaultValue={"please Select"}
                  name="streetType"
                  onChange={(event, value) => setStreetType(value)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      variant="outlined"
                      // fullwidth
                      value={Tab1_Client_Home_var.streetType}
                      label="Street Type"
                      required
                      inputProps={{
                        ...params.inputProps,
                        style: { padding: "1px 0" },
                      }}
                      InputLabelProps={{ style: { fontSize: 15 } }}
                    />
                  )}
                />

                {Tab1_Validation_Home_Var.streetType !== null &&
                  Tab1_Validation_Home_Var.streetType !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab1_Validation_Home_Var.streetType}
                    </div>
                  )}
              </Grid>
              {/* Suburb */}
              <Grid item xs={4} style={{ padding: "8px" }}>
                <TextField
                  // label="Suburb"
                  name="suburb"
                  size="small"
                  style={{ width: "100%" }}
                  label="Suburb"
                  variant="outlined"
                  onChange={onChangeField}
                  autoComplete="off"
                  onKeyPress={(e) => inpTextwithSpace(e)}
                  value={Tab1_Client_Home_var.suburb}
                  required
                  InputLabelProps={{ style: { fontSize: 15 } }}
                  fullWidth
                />
                {Tab1_Validation_Home_Var.suburb !== null &&
                  Tab1_Validation_Home_Var.suburb !== "true" && (
                    <div className="text-danger font-italic">
                      {}
                      {Tab1_Validation_Home_Var.suburb}
                    </div>
                  )}
              </Grid>

              {/* State */}
              <Grid item xs={4} style={{ padding: "8px" }}>
                <Autocomplete
                  options={stateAus}
                  sx={{ width: "100%" }}
                  isOptionEqualToValue={(option, value) =>
                    option.id === value.id
                  }
                  getOptionLabel={(option) =>
                    option.stAus ? option.stAus : Tab1_Client_Home_var.state
                  }
                  defaultValue={"Please Select"}
                  name="state"
                  onChange={(event, value) => setStateAus(value, event)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      variant="outlined"
                      fullWidth
                      value={Tab1_Client_Home_var.state}
                      label="State"
                      required
                      inputProps={{
                        ...params.inputProps,
                        style: { padding: "1px 0" },
                      }}
                    />
                  )}
                />

                {Tab1_Validation_Home_Var.state !== null &&
                  Tab1_Validation_Home_Var.state !== "true" && (
                    <div className="text-danger font-italic">
                      {}
                      {Tab1_Validation_Home_Var.state}
                    </div>
                  )}
              </Grid>

              {/* Post Code */}
              <Grid item xs={4} style={{ padding: "8px" }}>
                <TextField
                  name="postCode"
                  size="small"
                  style={{ width: "100%" }}
                  variant="outlined"
                  type="number"
                  label="PostCode"
                  autoComplete="off"
                  onChange={onChangeField}
                  onKeyPress={(e) => inpNum(e)}
                  value={Tab1_Client_Home_var.postCode}
                  required
                  InputLabelProps={{ style: { fontSize: 15 } }}
                  fullWidth
                />

                {Tab1_Validation_Home_Var.postCode !== null &&
                  Tab1_Validation_Home_Var.postCode !== "true" && (
                    <div className="text-danger font-italic">
                      {}
                      {Tab1_Validation_Home_Var.postCode}
                    </div>
                  )}
              </Grid>
            </Box>

            {/* Phone */}
            <Grid item xs={5}>
              <InputLabel
                required
                htmlFor="Phone"
                style={{ marginBottom: "5px", width: "500px" }}
                maxLength="10"
              >
                Phone
              </InputLabel>
            </Grid>
            <Grid item xs={7}>
              <TextField
                name="phone"
                size="small"
                style={{ marginLeft: "5px", width: "500px" }}
                variant="outlined"
                type="tel"
                maxLength="10"
                value={Tab1_Client_Home_var.phone}
                autoComplete="new-password"
                inputProps={{ maxLength: 10 }}
                fullWidth
                onChange={onChangeField}
                onKeyPress={(e) => validationForNumbOnly(e)}
              />
              {Tab1_Validation_Home_Var.phone !== null &&
                Tab1_Validation_Home_Var.phone !== "true" && (
                  <div className="text-danger font-italic">
                    {}
                    {Tab1_Validation_Home_Var.phone}
                  </div>
                )}
            </Grid>

            {/* E-mail */}
            <Grid item xs={5}>
              <InputLabel
                required
                htmlFor="E-mail"
                style={{ marginBottom: "5px" }}
              >
                E-mail
              </InputLabel>
            </Grid>
            <Grid item xs={7}>
              <TextField
                // label="E-mail"
                name="email"
                value={Tab1_Client_Home_var.email}
                size="small"
                style={{ marginLeft: "5px", width: "500px" }}
                // margin="normal"
                pattern="[a-zA-Z0-9.]+\@[a-zA-Z0-9.]+\.[a-zA-Z]+"
                variant="outlined"
                autoComplete="off"
                fullWidth
                onChange={onChangeField}
              />
              {Tab1_Validation_Home_Var.email !== null &&
                Tab1_Validation_Home_Var.email !== "true" && (
                  <div className="text-danger font-italic">
                    {}
                    {Tab1_Validation_Home_Var.email}
                  </div>
                )}
            </Grid>

            {/* Branch */}
            {/* <Grid item xs={5}>
            <InputLabel
              required
              htmlFor="Branch"
              style={{ marginBottom: "5px" }}
            >
              Branch
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="branch"
              value={Tab1_Client_Home_var.branch}
              style={{ height: "40px", marginLeft: "5px", width: "500px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Insurance Brokers Australia">
                Insurance Brokers Australia
              </MenuItem>
              <MenuItem value="Hayward Insurance Solutions Pty Ltd">
                Hayward Insurance Solutions Pty Ltd
              </MenuItem>
            </Select>

            {Tab1_Validation_Home_Var.branch !== null &&
              Tab1_Validation_Home_Var.branch !== "true" && (
                <div className="text-danger font-italic">{ }
                  {Tab1_Validation_Home_Var.branch}
                </div>
              )}

          </Grid> */}

            {/* Sales Team */}
            {/* <Grid item xs={5}>
            <InputLabel
              required
              htmlFor="Sales Team"
              style={{ marginBottom: "5px" }}
            >
              Sales Team
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="salesTeam"
              onChange={onChangeField}
              value={Tab1_Client_Home_var.salesTeam}
              style={{ height: "40px", marginLeft: "5px", width: "500px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Chris Dalton">Chris Dalton</MenuItem>
              <MenuItem value="Gary Hayward">Gary Hayward</MenuItem>
              <MenuItem value="Mark Hayward">Mark Hayward</MenuItem>
              <MenuItem value="GC(Billy)">GC(Billy)</MenuItem>
              <MenuItem value="GC Team">GC Team</MenuItem>
              <MenuItem value="Billy Noke">Billy Noke</MenuItem>
              <MenuItem value="Gerold-Grafton<">Gerold-Grafton</MenuItem>
              <MenuItem value="Gerold-Warwick">Gerold-Warwick</MenuItem>
            </Select>

            {Tab1_Validation_Home_Var.salesTeam !== null &&
              Tab1_Validation_Home_Var.salesTeam !== "true" && (
                <div className="text-danger font-italic">{ }
                  {Tab1_Validation_Home_Var.salesTeam}
                </div>
              )}

          </Grid> */}

            {/* Service Team */}
            {/* <Grid item xs={5}>
            <InputLabel
              required
              htmlFor="Service Team"
              style={{ marginBottom: "5px" }}
            >
              Service Team
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="serviceTeam"
              onChange={onChangeField}
              value={Tab1_Client_Home_var.serviceTeam}
              style={{ height: "40px", marginLeft: "5px", width: "500px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Brisbane">Brisbane</MenuItem>
              <MenuItem value="Luanne">Luanne</MenuItem>
              <MenuItem value="Michella">Michella</MenuItem>
              <MenuItem value="Patricia">Patricia</MenuItem>
              <MenuItem value="Taryn">Taryn</MenuItem>
            </Select>

            {Tab1_Validation_Home_Var.serviceTeam !== null &&
              Tab1_Validation_Home_Var.serviceTeam !== "true" && (
                <div className="text-danger font-italic">{ }
                  {Tab1_Validation_Home_Var.serviceTeam}
                </div>
              )}

          </Grid> */}

            {/* navigation buttons */}
            <Grid item xs={6}>
              <Button
                variant="contained"
                color="secondary"
                style={{
                  marginTop: "1rem",
                  float: "left",
                  width: "20%",
                }}
                onClick={() => {
                  exit();
                }}
              >
                EXIT
              </Button>
            </Grid>

            <Grid item xs={6}>
              <Button
                variant="contained"
                color="primary"
                style={{
                  marginTop: "1rem",
                  float: "right",
                }}
                onClick={() => navigation.next()}
              >
                NEXT
              </Button>
            </Grid>
          </Grid>
        </div>
      </Container>
      
    </div>
  );
};

//   };
export default Tab1_Client_Home;
