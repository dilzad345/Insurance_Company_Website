import React from "react";
import {
  TextField,
  Container,
  Button,
  Select,
  InputLabel,
  MenuItem,
  Grid, Box
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import { Autocomplete } from '@mui/material';
import { confirmAlert } from "react-confirm-alert";
import { inpNum, validationForSpecialchar } from "../constants/validChecker"
import InputAdornment from "@material-ui/core/InputAdornment";
import { streetTypes } from "../constants/dropDownData"
import {
  streetNumber_validate,
  streetName_validate,
  streetType_validate,
  suburb_validate,
  state_validate,
  postCode_validate,
  registrationVehicle_validate,
  stateIssued_validate,
  vehicleYear_validate,
  vehicleUsage_validate,
  numberKMsYear_validate,
  vehicleParkedNight_validate,
  previouslyInsured_validate,
  vehicleUnregistered_validate,
  usedDriver_validate,
  specialisedPaint_validate,
  superCharger_validate,
  hydrogenFuel_validate,
  racingHarnesses_validate,
  vehicleFinanced_validate,
  hailDamage_validate,
  // purchaseDate_validate,
  purchasePrice_validate,
} from "../validations/tab4_validate";
import DatePicker from "react-datepicker";
import history from "../auth/history";

const returnDashBoard = () => {
  history.push('/user/dashboard_motor');
}
const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    alignContent: "center",
    padding: theme.spacing(2),
    //textAlign: 'center',
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary,
  },
}));

const Tab4_vehicle = ({
  tab4_vehicle,
  setTab4,
  tab4_validation,
  setTab4_validation,
  navigation,
}) => {
  const classes = useStyles();
  // console.log(tab4_vehicle);
// onClick method: exit when clicking exit btn
const exit = () => {
  // console.log(ind);
  // const temp = [...tab5_modifications];
  // const tempValidate = [...tab5_validation];

  confirmAlert({
    title: "Confirm to exit",
    message: "Are you going to exit without saving any data to the database ?",
    buttons: [
      {
        label: "Yes",
        onClick: () => {
          // removing the element using splice
          // temp.splice(ind, 1);
          // tempValidate.splice(ind, 1);

          // tab5_modifications = temp;
          // tab5_validation = tempValidate;

          // // updating the list
          // setTab5(temp);
          // setTab5_validation(tempValidate);

          returnDashBoard();
        },
      },
      {
        label: "No",
        onClick: () => null,
      },
    ],
  });
};
  const onChangeField = (e) => {
    // let target = e.target;
    let name = e.target.name;
    let value = e.target.value;

    setTab4(
      {
        ...tab4_vehicle,
        [name]: value,
      },
      () => {
        validationAfterChange(name, value);
      }
    );
  };

  //method for not to typing in date field
  const handleDateChangeRaw = (e) => {
    e.preventDefault();
  }


  let myCurrentDate = new Date();
  let myPastDate = new Date(myCurrentDate);
  myPastDate.setDate(myPastDate.getDate() - 1);

  const purchaseDate = (date, value) => {
    console.log(date);
    setTab4({
      ...tab4_vehicle,
      purchaseDate: date,

    });
    // purchaseDate_validate(date, tab4_validation, setTab4_validation);
  };

  //set Street Type
  const setStreetType = (val) => {
    console.log("val", val);
    // console.log(i);
    // console.log(streetType[0]);
    //  let name = e.target.name;
    if (val) {
      let name = "streetType";
      let value = val.group;
      setTab4(
        {
          ...tab4_vehicle,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    } else {
      let name = "streetType";
      let value = " ";
      setTab4(
        {
          ...tab4_vehicle,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    }
  }
  // call validation
  const validationAfterChange = (name, value) => {
    switch (name) {
      /* case "unitNumber":{
        unitNumber_validate(value, tab4_validation, setTab4_validation);
        break;
      } */
      case "streetNumber": {
        streetNumber_validate(value, tab4_validation, setTab4_validation);
        break;
      }
      case "streetName": {
        streetName_validate(value, tab4_validation, setTab4_validation);
        break;
      }
      case "streetType": {
        streetType_validate(value, tab4_validation, setTab4_validation);
        break;
      }
      case "suburb": {
        suburb_validate(value, tab4_validation, setTab4_validation);
        break;
      }
      case "state": {
        state_validate(value, tab4_validation, setTab4_validation);
        break;
      }
      case "postCode": {
        postCode_validate(value, tab4_validation, setTab4_validation);
        break;
      }
      case "registrationVehicle": {
        registrationVehicle_validate(
          value,
          tab4_validation,
          setTab4_validation
        );
        break;
      }
      case "stateIssued": {
        stateIssued_validate(
          value,
          tab4_validation,
          setTab4_validation
        );
        break;
      }
      case "vehicleYear": {
        vehicleYear_validate(value, tab4_validation, setTab4_validation);
        break;
      }
      case "vehicleUsage": {
        vehicleUsage_validate(value, tab4_validation, setTab4_validation);
        break;
      }
      case "numberKMsYear": {
        numberKMsYear_validate(value, tab4_validation, setTab4_validation);
        break;
      }
      case "vehicleParkedNight": {
        vehicleParkedNight_validate(value, tab4_validation, setTab4_validation);
        break;
      }
      case "previouslyInsured": {
        previouslyInsured_validate(value, tab4_validation, setTab4_validation);
        break;
      }
      case "vehicleUnregistered": {
        vehicleUnregistered_validate(value, tab4_validation, setTab4_validation);
        break;
      }
      case "usedDriver": {
        usedDriver_validate(value, tab4_validation, setTab4_validation);
        break;
      }
      case "specialisedPaint": {
        specialisedPaint_validate(value, tab4_validation, setTab4_validation);
        break;
      }
      case "superCharger": {
        superCharger_validate(value, tab4_validation, setTab4_validation);
        break;
      }
      case "hydrogenFuel": {
        hydrogenFuel_validate(value, tab4_validation, setTab4_validation);
        break;
      }
      case "racingHarnesses": {
        racingHarnesses_validate(value, tab4_validation, setTab4_validation);
        break;
      }
      case "vehicleFinanced": {
        vehicleFinanced_validate(value, tab4_validation, setTab4_validation);
        break;
      }
      case "hailDamage": {
        hailDamage_validate(value, tab4_validation, setTab4_validation);
        break;
      }
      // case "purchaseDate": {
      //   purchaseDate_validate(value, tab4_validation, setTab4_validation);
      //   break;
      // }

      case "purchasePrice": {
        purchasePrice_validate(value, tab4_validation, setTab4_validation);
        break;
      }

      default: {
        console.log("Not match to condition");
      }
    }
  };

  // const { tab1_client, lastName, age } = formData;

  return (
    <Container maxWidth="md" style={{ marginBottom: "50px" }}>
      <div className={classes.root}>
        <Grid
          container
          spacing={3}
          direction="row"
          justifyContent="center"
          alignItems="center"
        >
          <Grid xs={12} item={true} justifyContent="center" container>
            <h3>VEHICLE INFORMATION</h3>
          </Grid>


          {/* Unit Number */}
          <Box component="span"
            sx={{
              width: '100%',
              // height: 00,
              p: 4,
              // alignItems: '',
              borderRadius: 8,
              border: '1px solid grey',
              display: 'flex',
              flexWrap: 'wrap',
              // alignItems:'center',
              justifyContent: 'space-between',
              flexDirection: 'row',

            }} m={2} pt={3}>

            <Grid item xs={12} justifyContent="center" container>
              <Box sx={{
                border: '1px solid grey',
                borderRadius: 8,
                padding: '6px 8px 0px 7px',
                // alignItems:'center',
                // alignContent:'center',
                margin: '0px 0px 10px 2px',
                justifyContent: 'center'
              }}><h5> VEHICLE GARAGING INFORMATION</h5></Box>
            </Grid>
            <Grid item xs={4} style={{ padding: '10px' }} >
              <InputLabel
                htmlFor="Unit Number (not req for PO Box)"
                style={{ marginBottom: "5px" }}>
                {/* Unit Number (not req for PO Box) */}
                Unit Number
              </InputLabel>
              <TextField
                // label="Unit Number (not req for PO Box)"
                name="unitNumber"
                value={tab4_vehicle.unitNumber}
                onChange={onChangeField}
                // margin="normal"
                size="small"
                // type="number"
                variant="outlined"
                autoComplete="off"
                onKeyPress={(e) => validationForSpecialchar(e)}
                fullWidth
              //required
              />
            </Grid>

            {/* Street Number */}
            <Grid item xs={4} style={{ padding: '10px' }} >
              <InputLabel
                htmlFor="Street Number (not req for PO Box)"
                style={{ marginBottom: "5px" }}
                required>
                Street Number
              </InputLabel>
              <TextField
                name="streetNumber"
                value={tab4_vehicle.streetNumber}
                onChange={onChangeField}
                // type="number"
                size="small"
                variant="outlined"
                autoComplete="off"
                fullWidth
                onKeyPress={(e) => validationForSpecialchar(e)}
              />
              {tab4_validation.streetNumber !== null &&
                tab4_validation.streetNumber !== "true" && (
                  <div className="text-danger font-italic">
                    {tab4_validation.streetNumber}
                  </div>
                )}
            </Grid>
            {/* <Grid item xs={8}>
              <TextField
                name="streetNumber"
                value={tab4_vehicle.streetNumber}
                onChange={onChangeField}
                type="number"
                size="small"
                variant="outlined"
                autoComplete="off"
                fullWidth
                onKeyPress={(e) => inpNum(e)}
              />
              {tab4_validation.streetNumber !== null &&
                tab4_validation.streetNumber !== "true" && (
                  <div className="text-danger font-italic">
                    {tab4_validation.streetNumber}
                  </div>
                )}
            </Grid> */}

            {/* Street Type */}
            <Grid item xs={4} style={{ padding: '10px' }}>
              <InputLabel
                htmlFor="Street Type (not req for PO Box)"
                style={{ marginBottom: "5px" }}
                required>
                Street Type
              </InputLabel>

              <Autocomplete
                // disablePortal
                // getOptionSelected={(option, value) => option.value === value.value}
                isOptionEqualToValue={(option, value) => option.id === value.id}
                options={streetTypes}
                sx={{
                  width: 1,
                }}
                // isOptionEqualToValue={(option, value) => option.id === value.id}
                getOptionLabel={(option) => (option.group ? option.group : tab4_vehicle.streetType)}
                name="streetType"
                defaultValue={"Please Select"}
                onChange={(event, value) => setStreetType(value)}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant="outlined"
                    fullWidth
                    value={tab4_vehicle.streetType}

                  // InputProps={{
                  //   style: {
                  //     padding: '2px'
                  //   }
                  // }}
                  />
                )} />
              {tab4_validation.streetType !== null &&
                tab4_validation.streetType !== "true" && (
                  <div className="text-danger font-italic">
                    {tab4_validation.streetType}
                  </div>
                )}
            </Grid>
            {/* <Grid item xs={8}>
              
             
              <Autocomplete
                // disablePortal
                // getOptionSelected={(option, value) => option.value === value.value}
                isOptionEqualToValue={(option, value) => option.id === value.id}
                options={streetTypes}
                sx={{
                  width: 1,
                }}
                // isOptionEqualToValue={(option, value) => option.id === value.id}
                getOptionLabel={(option) => (option.group ? option.group : tab4_vehicle.streetType)}
                name="streetType"
                defaultValue={"Please Select"}
                onChange={(event, value) => setStreetType(value)}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant="outlined"
                    fullWidth
                    value={tab4_vehicle.streetType}

                  // InputProps={{
                  //   style: {
                  //     padding: '2px'
                  //   }
                  // }}
                  />
                )} />
              {tab4_validation.streetType !== null &&
                tab4_validation.streetType !== "true" && (
                  <div className="text-danger font-italic">
                    {tab4_validation.streetType}
                  </div>
                )}
            </Grid> */}

            {/* Street Name */}
            <Grid item xs={4} style={{ padding: '10px' }}>
              <InputLabel
                htmlFor="Street Name (or PO Box)"
                style={{ marginBottom: "5px" }}
                required
              >
                Street Name
              </InputLabel>
              <TextField
                name="streetName"
                value={tab4_vehicle.streetName}
                placeholder="Ex: Railway Stations"
                onChange={onChangeField}
                size="small"
                variant="outlined"
                autoComplete="off"
                fullWidth
              />
              {tab4_validation.streetName !== null &&
                tab4_validation.streetName !== "true" && (
                  <div className="text-danger font-italic">
                    {tab4_validation.streetName}
                  </div>
                )}
            </Grid>
           
            {/* Suburb */}
            <Grid item xs={4} style={{ padding: '10px' }}>
              <InputLabel
                htmlFor="Suburb"
                style={{ marginBottom: "5px" }}
                required>
                Suburb
              </InputLabel>
              <TextField
                name="suburb"
                value={tab4_vehicle.suburb}
                onChange={onChangeField}
                size="small"
                variant="outlined"
                autoComplete="off"
                style={{ marginBottom: "2px", height: "40px" }}
                fullWidth
              />
              {tab4_validation.suburb !== null &&
                tab4_validation.suburb !== "true" && (
                  <div className="text-danger font-italic">
                    {tab4_validation.suburb}
                  </div>
                )}
            </Grid>
            
            {/* State */}
            <Grid item xs={4} style={{ padding: '10px' }} >
              <InputLabel
                htmlFor="State"
                style={{ marginBottom: "5px" }}
                required
              >
                State
              </InputLabel>
              <Select
                margin="none"
                name="state"
                variant="outlined"
                autoComplete="off"
                onChange={onChangeField}
                onClose={() => validationAfterChange("state", tab4_vehicle.state)}
                value={tab4_vehicle.state}
                style={{ height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="QLD">QLD</MenuItem>
                <MenuItem value="NSW">NSW</MenuItem>
                <MenuItem value="VIC">VIC</MenuItem>
                <MenuItem value="SA">SA</MenuItem>
                <MenuItem value="WA">WA</MenuItem>
                <MenuItem value="MACT">ACT</MenuItem>
                <MenuItem value="TASS">TAS</MenuItem>
                <MenuItem value="NT">NT</MenuItem>
              </Select>
              {tab4_validation.state !== null &&
                tab4_validation.state !== "true" && (
                  <div className="text-danger font-italic">
                    {tab4_validation.state}
                  </div>
                )}
            </Grid>
            {/* <Grid item xs={8}>
              <Select
                margin="none"
                name="state"
                variant="outlined"
                autoComplete="off"
                onChange={onChangeField}
                onClose={() => validationAfterChange("state", tab4_vehicle.state)}
                value={tab4_vehicle.state}
                style={{ height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="QLD">QLD</MenuItem>
                <MenuItem value="NSW">NSW</MenuItem>
                <MenuItem value="VIC">VIC</MenuItem>
                <MenuItem value="SA">SA</MenuItem>
                <MenuItem value="WA">WA</MenuItem>
                <MenuItem value="MACT">ACT</MenuItem>
                <MenuItem value="TASS">TAS</MenuItem>
                <MenuItem value="NT">NT</MenuItem>
              </Select>
              {tab4_validation.state !== null &&
                tab4_validation.state !== "true" && (
                  <div className="text-danger font-italic">
                    {tab4_validation.state}
                  </div>
                )}
            </Grid> */}

            {/* Post Code */}
            <Grid item xs={4} style={{ padding: '10px' }}>
              <InputLabel
                htmlFor="Post Code"
                style={{ marginBottom: "5px" }}
                required
              >
                Post Code
              </InputLabel>
              <TextField
                name="postCode"
                value={tab4_vehicle.postCode}
                onChange={onChangeField}
                type="number"
                size="small"
                variant="outlined"
                autoComplete="off"
                fullWidth
                onKeyPress={(e) => inpNum(e)}
              />
              {tab4_validation.postCode !== null &&
                tab4_validation.postCode !== "true" && (
                  <div className="text-danger font-italic">
                    {tab4_validation.postCode}
                  </div>
                )}
            </Grid>
            {/* .Where is the vehicle parked during the day? */}
            <Grid item xs={4} style={{ padding: '10px' }}>
              <InputLabel
                htmlFor="Vehicle parked Day"
                style={{ marginBottom: "5px" }}
                required
              >
                Where is the vehicle parked during the day?
              </InputLabel>
              <Select
                margin="none"
                variant="outlined"
                name="vehicleParkedDay"
                autoComplete="off"
                onChange={onChangeField}
                value={tab4_vehicle.vehicleParkedDay}
                style={{ height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Carport">Carport</MenuItem>
                <MenuItem value="Driveway / On the property">Driveway / On the property</MenuItem>
                <MenuItem value="Garage / Security Parking">Garage / Security Parking</MenuItem>
                <MenuItem value="Other">Other</MenuItem>
                <MenuItem value="On the street">On the street</MenuItem>
                <MenuItem value="Unknown">Unknown</MenuItem>
              </Select>
            </Grid>

            {/* Where is the vehicle parked at night */}
            <Grid item xs={4} style={{ padding: '10px' }}>
              <InputLabel
                htmlFor="Where is the vehicle parked at night"
                style={{ marginBottom: "5px" }}
                required
              >
                Where is the vehicle parked at night
              </InputLabel>
              <Select
                margin="none"
                variant="outlined"
                autoComplete="off"
                name="vehicleParkedNight"
                onChange={onChangeField}
                onClose={() =>
                  validationAfterChange(
                    "vehicleParkedNight",
                    tab4_vehicle.vehicleParkedNight
                  )
                }
                value={tab4_vehicle.vehicleParkedNight}
                style={{ height: "40px" }}
                fullWidth
              >
                <MenuItem disabled value=" ">
                  Please Select
                </MenuItem>
                <MenuItem value="Carport">Carport</MenuItem>
                <MenuItem value="Driveway / On the property">
                  Driveway / On the property
                </MenuItem>
                <MenuItem value="Garage / Security Parking">
                  Garage / Security Parking
                </MenuItem>
                <MenuItem value="On the street">On the street</MenuItem>
                <MenuItem value="Unknown">Unknown</MenuItem>
                <MenuItem value="Other">Other</MenuItem>
              </Select>
              {tab4_validation.vehicleParkedNight !== null &&
                tab4_validation.vehicleParkedNight !== "true" && (
                  <div className="text-danger font-italic">
                    {tab4_validation.vehicleParkedNight}
                  </div>
                )}
            </Grid>
            {/* <Grid item xs={8}>
              <TextField
                name="postCode"
                value={tab4_vehicle.postCode}
                onChange={onChangeField}
                type="number"
                size="small"
                variant="outlined"
                autoComplete="off"
                fullWidth
                onKeyPress={(e) => inpNum(e)}
              />
              {tab4_validation.postCode !== null &&
                tab4_validation.postCode !== "true" && (
                  <div className="text-danger font-italic">
                    {tab4_validation.postCode}
                  </div>
                )}
            </Grid> */}

          </Box>
          {/* Unit Number */}
          {/* <Grid item xs={4}>
            <InputLabel
              htmlFor="Unit Number (not req for PO Box)"
              style={{ marginBottom: "5px" }}
            >
             
              Unit Number
            </InputLabel>
          </Grid> */}

          {/* <Grid item xs={8}>
            <TextField
              name="unitNumber"
              value={tab4_vehicle.unitNumber}
              type="number"
              onChange={onChangeField}
              size="small"
              variant="outlined"
              autoComplete="off"
              onKeyPress={(e) => inpNum(e)}
              fullWidth
            />
            {/*  {tab4_validation.unitNumber !== null &&
                  tab4_validation.unitNumber !== "true" && (
                    <div className="text-danger font-italic">
                      {tab4_validation.unitNumber}
                    </div>
                  )} */}
          {/* </Grid> */}

          {/* Street Number */}
          {/* <Grid item xs={4}>
            <InputLabel
              htmlFor="Street Number (not req for PO Box)"
              style={{ marginBottom: "5px" }}
              required
            >
              Street Number
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <TextField
              name="streetNumber"
              value={tab4_vehicle.streetNumber}
              onChange={onChangeField}
              size="small"
              variant="outlined"
              autoComplete="off"
              fullWidth
              type="number"
              onKeyPress={(e) => inpNum(e)}
            />
            {tab4_validation.streetNumber !== null &&
              tab4_validation.streetNumber !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.streetNumber}
                </div>
              )}
          </Grid> */}

          {/* Street Type */}
          {/* <Grid item xs={4}>
            <InputLabel
              htmlFor="Street Type (not req for PO Box)"
              style={{ marginBottom: "5px" }}
              required
            >
              Street Type
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              margin="none"
              variant="outlined"
              name="streetType"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange("streetType", tab4_vehicle.streetType)
              }
              value={tab4_vehicle.streetType}
              autoComplete="off"
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="street">Street</MenuItem>
              <MenuItem value="Road">Road</MenuItem>
              <MenuItem value="Avenue">Avenue</MenuItem>
              <MenuItem value="Close">Close</MenuItem>
              <MenuItem value="Court">Court</MenuItem>
              <MenuItem value="Circuit">Circuit</MenuItem>
              <MenuItem value="Teerace">Teerace</MenuItem>
              <MenuItem value="drive">Drive</MenuItem>
              <MenuItem value="Lane">Lane</MenuItem>
              <MenuItem value="Parade">Parade</MenuItem>
              <MenuItem value="Quay">Quay</MenuItem>
              <MenuItem value="Way">Way</MenuItem>
            </Select>
            {tab4_validation.streetType !== null &&
              tab4_validation.streetType !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.streetType}
                </div>
              )}
          </Grid> */}


          {/* Street Name */}
          {/* <Grid item xs={4}>
            <InputLabel
              htmlFor="Street Name (or PO Box)"
              style={{ marginBottom: "5px" }}
              required
            >
              Street Name
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <TextField
              name="streetName"
              value={tab4_vehicle.streetName}
              onChange={onChangeField}
              size="small"
              variant="outlined"
              fullWidth

            />
            {tab4_validation.streetName !== null &&
              tab4_validation.streetName !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.streetName}
                </div>
              )}
          </Grid> */}


          {/* Suburb */}
          {/* <Grid item xs={4}>
            <InputLabel
              htmlFor="Suburb"
              style={{ marginBottom: "5px" }}
              required
            >
              Suburb
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <TextField
              name="suburb"
              value={tab4_vehicle.suburb}
              onChange={onChangeField}
              size="small"
              variant="outlined"
              autoComplete="off"
              style={{ height: "40px" }}
              fullWidth
            />
            {tab4_validation.suburb !== null &&
              tab4_validation.suburb !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.suburb}
                </div>
              )}
          </Grid> */}

          {/* State */}
          {/* <Grid item xs={4}>
            <InputLabel
              htmlFor="State"
              style={{ marginBottom: "5px" }}
              required
            >
              State
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              margin="none"
              name="state"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange("state", tab4_vehicle.state)
              }
              value={tab4_vehicle.state}
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="QLD">QLD</MenuItem>
              <MenuItem value="NSW">NSW</MenuItem>
              <MenuItem value="VIC">VIC</MenuItem>
              <MenuItem value="SA">SA</MenuItem>
              <MenuItem value="WA">WA</MenuItem>
              <MenuItem value="MACT">MACT</MenuItem>
              <MenuItem value="TASS">TASS</MenuItem>
              <MenuItem value="NT">NT</MenuItem>
            </Select>
            {tab4_validation.state !== null &&
              tab4_validation.state !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.state}
                </div>
              )}
          </Grid> */}

          {/* Post Code */}
          {/* <Grid item xs={4}>
            <InputLabel
              htmlFor="Post Code"
              style={{ marginBottom: "5px" }}
              required
            >
              Post Code
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <TextField
              name="postCode"
              value={tab4_vehicle.postCode}
              onChange={onChangeField}
              size="small"
              variant="outlined"
              autoComplete="off"
              style={{ height: "40px" }}
              fullWidth
              type="number"
              onKeyPress={(e) => inpNum(e)}
            />
            {tab4_validation.postCode !== null &&
              tab4_validation.postCode !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.postCode}
                </div>
              )}
          </Grid> */}

          {/* Registration of vehicle and year */}
            
          <Grid item xs={4}>
            <InputLabel
              htmlFor="Registration of Vehicle"
              style={{ marginBottom: "5px" }}
              required
            >
              Registration of Vehicle & State
            </InputLabel>
          </Grid>
          <Grid item xs={4}>
            <TextField
              name="registrationVehicle"
              value={tab4_vehicle.registrationVehicle}
              onChange={onChangeField}
              size="small"
              variant="outlined"
              autoComplete="off"
              style={{ height: "40px" }}
              fullWidth
            />
            {tab4_validation.registrationVehicle !== null &&
              tab4_validation.registrationVehicle !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.registrationVehicle}
                </div>
              )}
          </Grid>
          <Grid item xs={4}>
              <Select
              variant="outlined"
              autoComplete="off"
              value={tab4_vehicle.stateIssued}
              name="stateIssued"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange(
                  "stateIssued",
                  tab4_vehicle.stateIssued
                )
              }
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="QLD">QLD</MenuItem>
              <MenuItem value="NSW">NSW</MenuItem>
              <MenuItem value="VIC">VIC</MenuItem>
              <MenuItem value="SA">SA</MenuItem>
              <MenuItem value="WA">WA</MenuItem>
              <MenuItem value="ACT">ACT</MenuItem>
              <MenuItem value="TAS">TAS</MenuItem>
              <MenuItem value="NT">NT</MenuItem>

              </Select>
              {tab4_validation.stateIssued !== null &&
                      tab4_validation.stateIssued !== "true" && (
                        <div className="text-danger font-italic">
                          {tab4_validation.stateIssued}
                        </div>
                      )}
          </Grid>

          {/* Vehicle Colour */}
          <Grid item xs={4}>
            <InputLabel
              htmlFor="Vehicle Colour"
              style={{ marginBottom: "5px" }}
            >
              Vehicle Colour
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              margin="none"
              variant="outlined"
              name="vehicleColour"
              autoComplete="off"
              onChange={onChangeField}
              value={tab4_vehicle.vehicleColour}
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Beige">Beige</MenuItem>
              <MenuItem value="Black">Black</MenuItem>
              <MenuItem value="Black">Blue</MenuItem>
              <MenuItem value="Brown">Brown</MenuItem>
              <MenuItem value="Brown">Burgundy</MenuItem>
              <MenuItem value="Champagne">Champagne</MenuItem>
              <MenuItem value="Charcoal">Charcoal</MenuItem>
              <MenuItem value="Gold">Gold</MenuItem>
              <MenuItem value="Green">Green</MenuItem>
              <MenuItem value="Grey">Grey</MenuItem>
              <MenuItem value="Maroon">Maroon</MenuItem>
              <MenuItem value="Orange">Orange</MenuItem>
              <MenuItem value="Pink">Pink</MenuItem>
              <MenuItem value="Purple">Purple</MenuItem>
              <MenuItem value="Red">Red</MenuItem>
              <MenuItem value="Silver">Silver</MenuItem>
              <MenuItem value="White">White</MenuItem>
              <MenuItem value="Yellow">Yellow</MenuItem>
              <MenuItem value="Unknown">Unknown</MenuItem>
            </Select>
          </Grid>

          {/* Vehicle Year */}
          <Grid item xs={4}>
            <InputLabel htmlFor="Vehicle Year" style={{ marginBottom: "5px" }}>
              Vehicle Year
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <TextField
              name="vehicleYear"
              value={tab4_vehicle.vehicleYear}
              onChange={onChangeField}
              size="small"
              variant="outlined"
              autoComplete="off"
              type="tel"
              style={{ height: "40px" }}
              fullWidth
              onKeyPress={(e) => inpNum(e)}
              inputProps={{
                maxLength: 4,
              }}
            />
            {tab4_validation.vehicleYear != null &&
              tab4_validation.vehicleYear !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.vehicleYear}
                </div>
              )}
          </Grid>

          {/* Vehicle Make */}
          <Grid item xs={4}>
            <InputLabel htmlFor="Vehicle Make" style={{ marginBottom: "5px" }}>
              Vehicle Make
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <TextField
              name="vehicleMake"
              value={tab4_vehicle.vehicleMake}
              onChange={onChangeField}
              size="small"
              variant="outlined"
              autoComplete="off"
              style={{ height: "40px" }}
              fullWidth
            />
          </Grid>

          {/* Vehicle Model */}
          <Grid item xs={4}>
            <InputLabel htmlFor="Vehicle Model" style={{ marginBottom: "5px" }}>
              Vehicle Model
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <TextField
              name="vehicleModel"
              value={tab4_vehicle.vehicleModel}
              onChange={onChangeField}
              size="small"
              variant="outlined"
              autoComplete="off"
              style={{ height: "40px" }}
              fullWidth
            />
          </Grid>

          {/* Vehicle Type */}
          <Grid item xs={4}>
            <InputLabel htmlFor="Vehicle Type" style={{ marginBottom: "5px" }}>
              Vehicle Type
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <TextField
              name="vehicleType"
              value={tab4_vehicle.vehicleType}
              onChange={onChangeField}
              size="small"
              variant="outlined"
              autoComplete="off"
              fullWidth
            />
          </Grid>


          {/* Security Device Fitted */}
          <Grid item xs={4}>
            <InputLabel
              htmlFor="Security Device Fitted"
              style={{ marginBottom: "5px" }}
            >
              Security Device Fitted
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="securityDeviceFitted"
              onChange={onChangeField}
              value={tab4_vehicle.securityDeviceFitted}
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem value="None">None</MenuItem>
              <MenuItem value="24hr Tracking Device">
                24hr Tracking Device
              </MenuItem>
              <MenuItem value="Alarm & Immobiliser">
                Alarm & Immobiliser
              </MenuItem>
              <MenuItem value="Alarm only">Alarm Only</MenuItem>
              <MenuItem value="Immobiliser only">Immobiliser Only</MenuItem>
              <MenuItem value="Micro Dotting">Micro Dotting</MenuItem>
            </Select>
          </Grid>

          {/* .How many years has the owner owned a vehicle of similar power, style and performance? */}
          <Grid item xs={4}>
            <InputLabel
              htmlFor="Vehicle of similar power"
              style={{ marginBottom: "5px" }}
              required
            >
              How many years has the owner owned a vehicle of similar power, style and performance?
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              margin="none"
              variant="outlined"
              name="similarPowerOfVehicle"
              autoComplete="off"
              onChange={onChangeField}
              value={tab4_vehicle.similarPowerOfVehicle}
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="NEVER OWNED">NEVER OWNED</MenuItem>
              <MenuItem value="1 YEAR">1 YEAR</MenuItem>
              <MenuItem value="2 YEARS">2 YEARS</MenuItem>
              <MenuItem value="3 YEARS">3 YEARS</MenuItem>
              <MenuItem value="4 YEARS">4 YEARS</MenuItem>
              <MenuItem value="5 YEARS">5 YEARS</MenuItem>
              <MenuItem value="6 YEARS">6 YEARS</MenuItem>
              <MenuItem value="OVER 6 YEARS">OVER 6 YEARS</MenuItem>
            </Select>
          </Grid>


          {/* .Where is the vehicle parked during the day? */}
          <Grid item xs={4}>
            <InputLabel
              htmlFor="Vehicle parked Day"
              style={{ marginBottom: "5px" }}
              required
            >
              Where is the vehicle parked during the day?
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              margin="none"
              variant="outlined"
              name="vehicleParkedDay"
              autoComplete="off"
              onChange={onChangeField}
              value={tab4_vehicle.vehicleParkedDay}
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Carport">Carport</MenuItem>
              <MenuItem value="Driveway / On the property">Driveway / On the property</MenuItem>
              <MenuItem value="Garage / Security Parking">Garage / Security Parking</MenuItem>
              <MenuItem value="Other">Other</MenuItem>
              <MenuItem value="On the street">On the street</MenuItem>
              <MenuItem value="Unknown">Unknown</MenuItem>
            </Select>
          </Grid>

          {/* Vehicle Usage */}
          <Grid item xs={4}>
            <InputLabel
              htmlFor="Vehicle Usage"
              style={{ marginBottom: "5px" }}
              required
            >
              Vehicle Usage
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="vehicleUsage"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange(
                  "vehicleUsage",
                  tab4_vehicle.vehicleUsage
                )
              }
              value={tab4_vehicle.vehicleUsage}
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Private Use Only">Private Use Only</MenuItem>
              <MenuItem value="For hire or taxi or courier">
                For hire or taxi or courier
              </MenuItem>
              <MenuItem value="Ride share eg Uber">Ride share eg Uber</MenuItem>
              <MenuItem value="Primarily business use (>=50%)">
                Primarily business use (=50%)
              </MenuItem>
              <MenuItem value="Some business use (<50%)">
                Some business use (50%)
              </MenuItem>
            </Select>
            {tab4_validation.vehicleUsage !== null &&
              tab4_validation.vehicleUsage !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.vehicleUsage}
                </div>
              )}
          </Grid>

          {/* On average, number of KMs per year */}
          <Grid item xs={4}>
            <InputLabel
              htmlFor="On average, number of KMs per year"
              style={{ marginBottom: "5px" }}
              required
            >
              On average, number of KMs per year
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="numberKMsYear"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange(
                  "numberKMsYear",
                  tab4_vehicle.numberKMsYear
                )
              }
              value={tab4_vehicle.numberKMsYear}
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="0 - 5000">0 - 5000</MenuItem>
              <MenuItem value="5001 - 10000">5001 - 10000</MenuItem>
              <MenuItem value="10001 - 15000">10001 - 15000</MenuItem>
              <MenuItem value="15001 - 20000">15001 - 20000</MenuItem>
              <MenuItem value="20001 - 30000">20001 - 30000</MenuItem>
              <MenuItem value="30001+">30001+</MenuItem>
            </Select>
            {tab4_validation.numberKMsYear !== null &&
              tab4_validation.numberKMsYear !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.numberKMsYear}
                </div>
              )}
          </Grid>

          {/* Where is the vehicle parked at night */}
          <Grid item xs={4}>
            <InputLabel
              htmlFor="Where is the vehicle parked at night"
              style={{ marginBottom: "5px" }}
              required
            >
              Where is the vehicle parked at night
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="vehicleParkedNight"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange(
                  "vehicleParkedNight",
                  tab4_vehicle.vehicleParkedNight
                )
              }
              value={tab4_vehicle.vehicleParkedNight}
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Carport">Carport</MenuItem>
              <MenuItem value="Driveway / On the property">
                Driveway / On the property
              </MenuItem>
              <MenuItem value="Garage / Security Parking">
                Garage / Security Parking
              </MenuItem>
              <MenuItem value="Other">Other</MenuItem>
              <MenuItem value="On the street">On the street</MenuItem>
              <MenuItem value="Unknown">Unknown</MenuItem>
            </Select>
            {tab4_validation.vehicleParkedNight !== null &&
              tab4_validation.vehicleParkedNight !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.vehicleParkedNight}
                </div>
              )}
          </Grid>

          {/* Policyholder previously Insured */}
          <Grid item xs={4}>
            <InputLabel
              htmlFor="Policyholder previously Insured"
              style={{ marginBottom: "5px" }}
              required
            >
              Policyholder previously Insured
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="previouslyInsured"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange(
                  "previouslyInsured",
                  tab4_vehicle.previouslyInsured
                )
              }
              value={tab4_vehicle.previouslyInsured}
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="None">None</MenuItem>
              <MenuItem value="0 - 1 year">0 - 1 year</MenuItem>
              <MenuItem value="1 - 5 years">1 - 5 years</MenuItem>
              <MenuItem value="5 - 10 years">5 - 10 years</MenuItem>
              <MenuItem value="Over 10 years">Over 10 years</MenuItem>
            </Select>
            {tab4_validation.previouslyInsured !== null &&
              tab4_validation.previouslyInsured !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.previouslyInsured}
                </div>
              )}
          </Grid>

          {/* Is the vehicle unregistered? */}
          <Grid item xs={4}>
            <InputLabel
              htmlFor="Is the vehicle unregistered?"
              style={{ marginBottom: "5px" }}
              required
            >
              Is the vehicle unregistered?
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="vehicleUnregistered"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange(
                  "vehicleUnregistered",
                  tab4_vehicle.vehicleUnregistered
                )
              }
              value={tab4_vehicle.vehicleUnregistered}
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
              <MenuItem value="No">No</MenuItem>
            </Select>
            {tab4_validation.vehicleUnregistered !== null &&
              tab4_validation.vehicleUnregistered !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.vehicleUnregistered}
                </div>
              )}
          </Grid>

          {/* Used for Driver Education / Racing / Sporting events / Courier / Delivery */}
          <Grid item xs={4}>
            <InputLabel
              htmlFor="Used for Driver Education / Racing / Sporting events / Courier / Delivery"
              style={{ marginBottom: "5px" }}
              required
            >
              Used for Driver Education / Racing / Sporting events / Courier /
              Delivery
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="usedDriver"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange("usedDriver", tab4_vehicle.usedDriver)
              }
              value={tab4_vehicle.usedDriver}
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
              <MenuItem value="No">No</MenuItem>
            </Select>
            {tab4_validation.usedDriver !== null &&
              tab4_validation.usedDriver !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.usedDriver}
                </div>
              )}
          </Grid>

          {/* Used as a hire car / Removalist vehicle / Fleet or Pool vehicle / Airside */}
          <Grid item xs={4}>
            <InputLabel
              htmlFor="Used as a hire car / Removalist vehicle / Fleet or Pool vehicle / Airside"
              style={{ marginBottom: "5px" }}
              required
            >
              Used as a hire car / Removalist vehicle / Fleet or Pool vehicle /
              Airside
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="usedHireCar"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange("title", tab4_vehicle.title)
              }
              value={tab4_vehicle.usedHireCar}
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
              <MenuItem value="No">No</MenuItem>
            </Select>
            {tab4_validation.usedHireCar !== null &&
              tab4_validation.usedHireCar !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.usedHireCar}
                </div>
              )}
          </Grid>

          {/* Does the vehicle have Specialised Paint? */}
          <Grid item xs={4}>
            <InputLabel
              htmlFor="Does the vehicle have Specialised Paint?"
              style={{ marginBottom: "5px" }}
              required
            >
              Does the vehicle have Specialised Paint?
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="specialisedPaint"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange(
                  "specialisedPaint",
                  tab4_vehicle.specialisedPaint
                )
              }
              value={tab4_vehicle.specialisedPaint}
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
              <MenuItem value="No">No</MenuItem>
            </Select>
            {tab4_validation.specialisedPaint !== null &&
              tab4_validation.specialisedPaint !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.specialisedPaint}
                </div>
              )}
          </Grid>

          {/* Does the vehicle have Turbo / Supercharger? */}
          <Grid item xs={4}>
            <InputLabel
              htmlFor="Does the vehicle have Turbo / Supercharger?"
              style={{ marginBottom: "5px" }}
              required
            >
              Does the vehicle have Turbo / Supercharger?
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="superCharger"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange(
                  "superCharger",
                  tab4_vehicle.superCharger
                )
              }
              value={tab4_vehicle.superCharger}
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
              <MenuItem value="No">No</MenuItem>
            </Select>
            {tab4_validation.superCharger !== null &&
              tab4_validation.superCharger !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.superCharger}
                </div>
              )}
          </Grid>

          {/* Does the vehicle have Nitro / Hydrogen Fuel? */}
          <Grid item xs={4}>
            <InputLabel
              htmlFor="Does the vehicle have Nitro / Hydrogen Fuel?"
              style={{ marginBottom: "5px" }}
              required
            >
              Does the vehicle have Nitro / Hydrogen Fuel?
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="hydrogenFuel"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange(
                  "hydrogenFuel",
                  tab4_vehicle.hydrogenFuel
                )
              }
              value={tab4_vehicle.hydrogenFuel}
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
              <MenuItem value="No">No</MenuItem>
            </Select>
            {tab4_validation.hydrogenFuel !== null &&
              tab4_validation.hydrogenFuel !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.hydrogenFuel}
                </div>
              )}
          </Grid>

          {/* Does the vehicle have a Roll bar / Roll cage / Racing harnesses? */}
          <Grid item xs={4}>
            <InputLabel
              htmlFor="Does the vehicle have a Roll bar / Roll cage / Racing harnesses?"
              style={{ marginBottom: "5px" }}
              required
            >
              Does the vehicle have a Roll bar / Roll cage / Racing harnesses?
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="racingHarnesses"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange(
                  "racingHarnesses",
                  tab4_vehicle.racingHarnesses
                )
              }
              value={tab4_vehicle.racingHarnesses}
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
              <MenuItem value="No">No</MenuItem>
            </Select>
            {tab4_validation.racingHarnesses !== null &&
              tab4_validation.racingHarnesses !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.racingHarnesses}
                </div>
              )}
          </Grid>

          {/* Vehicle Financed */}
          <Grid item xs={4}>
            <InputLabel
              htmlFor="Vehicle Financed"
              style={{ marginBottom: "5px" }}
              required
            >
              Vehicle Financed
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="vehicleFinanced"
              value={tab4_vehicle.vehicleFinanced}
              onChange={onChangeField}
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem value="No Finance">No Finance</MenuItem>
              <MenuItem value="Bank Loan (secured)">
                Bank Loan (secured)
              </MenuItem>
              <MenuItem value="Bill of Sale">Bill of Sale</MenuItem>
              <MenuItem value="Corporate Hite Purchase">
                Corporate Hite Purchase
              </MenuItem>
              <MenuItem value="Credit Union (Secured)">
                Credit Union (Secured)
              </MenuItem>
              <MenuItem value="Finance Co (Secured)">
                Finance Co (Secured)
              </MenuItem>
              <MenuItem value="Hire Purchase">Hire Purchase</MenuItem>
              <MenuItem value="Home Equity Loan">Home Equity Loan</MenuItem>
              <MenuItem value="Lease">Lease</MenuItem>
              <MenuItem value="Novated Lease">Novated Lease</MenuItem>
              <MenuItem value="Personal Loan (Secured)">
                Personal Loan (Secured)
              </MenuItem>
              <MenuItem value="Personal Loan (Unsecured)">
                Personal Loan (Unsecured)
              </MenuItem>
            </Select>
            {tab4_validation.vehicleFinanced !== null &&
              tab4_validation.vehicleFinanced !== "true" && (
                <div className="text-danger font-italic">
                  {" "}
                  {tab4_validation.vehicleFinanced}
                </div>
              )}
          </Grid>

          {/* Does the vehicle have hail damage? */}
          <Grid item xs={4}>
            <InputLabel
              htmlFor="Does the vehicle have hail damage?"
              style={{ marginBottom: "5px" }}
              required
            >
              Does the vehicle have hail damage?
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="hailDamage"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange("hailDamage", tab4_vehicle.hailDamage)
              }
              value={tab4_vehicle.hailDamage}
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
              <MenuItem value="No">No</MenuItem>
            </Select>
            {tab4_validation.hailDamage !== null &&
              tab4_validation.hailDamage !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.hailDamage}
                </div>
              )}
          </Grid>

          {/* Purchase Date */}
          <Grid item xs={4}>
            <InputLabel htmlFor="Purchase Date" style={{ marginBottom: "5px" }}>
              Purchase Date
            </InputLabel>
          </Grid>
          <Grid item xs={8}>

            <div>
              <DatePicker
                // selected={tab4_vehicle.purchaseDate}
                selected={tab4_vehicle.purchaseDate}
                onChange={purchaseDate}
                dateFormat="dd/MM/yyyy"
                name="policyFromDate"
                maxDate={myPastDate}
                // maxDate={new Date(tab4_vehicle.purchaseDate)}
                value={tab4_vehicle.purchaseDate}
                onChangeRaw={handleDateChangeRaw}
                className="date-picker-align"
                yearDropdownItemNumber={100}
                scrollableYearDropdown={true}
                showYearDropdown
                showMonthDropdown
                dropdownMode='select'
                autoComplete="off"
                isClearable
              />
            </div>
            {/* {tab4_validation.purchaseDate !== null &&
              tab4_validation.purchaseDate !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.purchaseDate}
                </div>
              )} */}
          </Grid>

          {/* Purchase Price */}
          <Grid item xs={4}>
            <InputLabel
              htmlFor="Purchase Price"
              style={{ marginBottom: "5px" }}
            >
              Purchase Price
            </InputLabel>
          </Grid>
          <Grid item xs={8}>
            <TextField
              name="purchasePrice"
              value={tab4_vehicle.purchasePrice}
              onChange={onChangeField}
              size="small"
              variant="outlined"
              autoComplete="off"
              fullWidth
              type="number"
              onKeyPress={(e) => inpNum(e)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">$</InputAdornment>
                ),
              }}
            />
            {tab4_validation.purchasePrice !== null &&
              tab4_validation.purchasePrice !== "true" && (
                <div className="text-danger font-italic">
                  {tab4_validation.purchasePrice}
                </div>
              )}
          </Grid>
        </Grid>

        <Grid>
          <Button
            variant="contained"
            color="secondary"
            style={{
              marginTop: "1rem",
              float: "left",
              width: "10%",
            }}
            onClick={() => exit()}
          >
            EXIT
          </Button>
        </Grid>

        <Grid>
          <Button
            variant="contained"
            color="primary"
            style={{
              marginTop: "1rem",
              float: "right",
              width: "10%"
            }}
            onClick={() => navigation.next()}
          >
            NEXT
          </Button>
        </Grid>
        <Grid>
          <Button
            variant="contained"
            color="primary"
            style={{
              marginTop: "1rem",
              marginBottom: "1rem",
              float: "right",
              marginRight: "20px",
              width: "10%",
            }}
            onClick={() => navigation.previous()}
          >
            PREVIOUS
          </Button>
        </Grid>
      </div>
    </Container>
  );
};

export default Tab4_vehicle;
