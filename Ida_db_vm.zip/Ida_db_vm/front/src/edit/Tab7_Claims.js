import React, { useEffect, useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import { Redirect } from "react-router-dom";
import "react-toastify/dist/ReactToastify.css";
import {
  TextField,
  Container,
  Button,
  Select,
  InputLabel,
  MenuItem,
  Grid,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import DatePicker from "react-datepicker";
import { inpNum } from "../constants/validChecker"
import {
  typeClaim_validate,
  dateClaim_validate,
  firstOccurrence_validate,
  reasonClaim_validate,
  description_validate,
  claimOutcome_validate,
  amount_validate,
} from "../validations/tab7_validate";
import { confirmAlert } from "react-confirm-alert";
import InputAdornment from "@material-ui/core/InputAdornment";
import history from "../auth/history";

const returnDashBoard = () => {
  history.push('/user/dashboard_motor');
}
const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    alignContent: "center",
    padding: theme.spacing(2),
    //textAlign: 'center',
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary,
  },
}));

const Tab7_Claims = ({
  tab6_drivers,
  tab7_claims,
  setTab7,
  tab7_validation,
  setTab7_validation,
  isAllFormsValid,
  updateAllForm,
  navigation,
}) => {
  const classes = useStyles();
  const [loaded, setLoad] = useState(false);
  const [loadDashboard, setLoadDashboard] = useState(false);

  useEffect(() => {
    if (!loaded) {
      setLoad(true);
      //setTab7([]);
      tab6_drivers.map((driver, index) => {
        //console.log( index + ": " + driver.driverType + ": " + driver.numberClaims3);
        for (let i = 0; i < driver.numberClaims3.toString(); i++) { }
      });
    }
  });
  // onClick method: exit when clicking exit btn
  const exit = () => {
    // console.log(ind);
    // const temp = [...tab5_modifications];
    // const tempValidate = [...tab5_validation];

    confirmAlert({
      title: "Confirm to exit",
      message: "Are you going to exit without modifying any data to the database ?",
      buttons: [
        {
          label: "Yes",
          onClick: () => {
            returnDashBoard();
          },
        },
        {
          label: "No",
          onClick: () => null,
        },
      ],
    });
  };

  const notify = () =>
    toast.success("Verify Status: Success!", {
      position: "bottom-center",
      autoClose: 5000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });

  const notifyFailure = () =>
    toast.error("Verify Status: Failed!", {
      position: "bottom-center",
      autoClose: 5000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });

  const handleSubmit = () => {
    updateAllForm()
      .then((res) => {
        if (res === true) {
          notify();
          setTimeout(function () {
            setLoadDashboard(true);
          }, 2000);
          console.log("set load home page: " + res);
          // setLoadClientHome(true); // change to true to redirect to the client home page
        } else if (res === false) {
          notifyFailure();
          setTimeout(function () {
            setLoadDashboard(true);
          }, 2000);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const loadDashboardPage = () => {
    if (loadDashboard) {
      return <Redirect to="/user/dashboard_motor" />;
    }
  };

  // on change method; to change field values according to the changes
  const onChangeField = (ind) => (event) => {
    // console.log(event.target.value);
    let name = event.target.name;
    let value = event.target.value;
    // make a copy of original list as temporary list
    let tempArr = [...tab7_claims];
    let tempObj = tempArr[ind];

    // updating the temporary list
    tempObj = {
      ...tempObj,
      [event.target.name]: event.target.value,
    };

    // replace the list with temporary list
    tempArr[ind] = tempObj;

    setTab7(tempArr, () => {
      validationAfterChange(ind, name, value);
    });
  }; // end of on change field

  //method for not to typing in date field
  const handleDateChangeRaw = (e) => {
    e.preventDefault();
  }
  // method: to update policy date from to variable
  const dateClaim = (date, index) => {
    console.log(date);
    // setTab7({
    //   ...tab7_claims,
    //   dateClaim: date,

    // });
    let name = "dateClaim"
    let value = date;
    // make a copy of original list as temporary list
    let tempArr = [...tab7_claims];
    let tempObj = tempArr[index];

    // updating the temporary list
    tempObj = {
      ...tempObj,
      [name]: value,
    };

    // replace the list with temporary list
    tempArr[index] = tempObj;

    setTab7(tempArr);
    dateClaim_validate(date, index, tab7_validation, setTab7_validation);
  };
  // method: to call validations
  const validationAfterChange = (index, name, value) => {
    if (name === "reasonClaims") {
      // console.log("hi description");
      if (tab7_claims[index].description !== "Other") {
        tab7_claims[index].description = "";
      }
    }
    switch (name) {
      case "typeClaim": {
        typeClaim_validate(index, value, tab7_validation, setTab7_validation);
        break;
      }
      case "dateClaim": {
        dateClaim_validate(index, value, tab7_validation, setTab7_validation);
        break;
      }
      case "firstOccurrence": {
        firstOccurrence_validate(index, value, tab7_validation, setTab7_validation);
        break;
      }
      case "reasonClaims": {
        reasonClaim_validate(index, value, tab7_validation, setTab7_validation);
        break;
      }
      case "description": {
        description_validate(index, value, tab7_validation, setTab7_validation);
        break;
      }
      case "claimOutcome": {
        claimOutcome_validate(
          index,
          value,
          tab7_validation,
          setTab7_validation
        );
        break;
      }
      case "amount": {
        amount_validate(index, value, tab7_validation, setTab7_validation);
        break;
      }
      default: {
        console.log("Not match to condition");
      }
    }
  }; // end of validation after change

  // method: handle submit
  // const handleSubmit = () => {
  //   updateAllForm()
  //     .then((res) => {
  //       console.log(res);
  //     })
  //     .catch((err) => {
  //       console.log(err);
  //     });
  // }; // end of handle submit

  // display render element
  const displayTab7 = () => {
    return (
      <Container maxWidth="md">
        <div>
          <div className={classes.root}>
            <Grid
              container
              spacing={3}
              direction="row"
              justifyContent="center"
              alignItems="center"
            >
              <Grid
                item
                xs={12}
                alignItems="center"
                justifyContent="center"
                container
              >
                <h3>CLAIMS INFORMATION</h3>
              </Grid>

              {tab7_claims.map((claim, index) => {
                return (
                  <Grid
                    container
                    direction="row"
                    key={index}
                  // className="border my-2 border-primary"
                  >
                    {/* Type of claim */}
                    <Grid item xs={4}>
                      <InputLabel htmlFor="Type of claim">
                        Type of claim
                      </InputLabel>
                    </Grid>
                    <Grid item xs={8}>
                      <Select
                        margin="none"
                        variant="outlined"
                        autoComplete="off"
                        name="typeClaim"
                        onChange={onChangeField(index)}
                        onClose={() =>
                          validationAfterChange(
                            index,
                            "typeClaim",
                            claim.typeClaim
                          )
                        }
                        value={claim.typeClaim}
                        style={{ height: "40px" }}
                        fullWidth
                      >
                        <MenuItem disabled value=" ">
                          Please Select
                        </MenuItem>
                        <MenuItem value="Bushfire">Bushfire</MenuItem>
                        <MenuItem value="Collision at fault">
                          Collision at fault
                        </MenuItem>
                        <MenuItem value="Collision not at fault">
                          Collision not at fault
                        </MenuItem>
                        <MenuItem value="Damage while parked">
                          Damage while parked
                        </MenuItem>
                        <MenuItem value="Flood">Flood</MenuItem>
                        <MenuItem value="Hail">Hail</MenuItem>
                        <MenuItem value="Other">Other</MenuItem>
                        <MenuItem value="Single vehicle accident">
                          Single vehicle accident
                        </MenuItem>
                        <MenuItem value="Storm">Storm</MenuItem>
                        <MenuItem value="Theft">Theft</MenuItem>
                        <MenuItem value="Vandalism or Malicios damage">
                          Vandalism or Malicios damage
                        </MenuItem>
                        <MenuItem value="Windscreen">Windscreen</MenuItem>
                      </Select>
                      {tab7_validation[index].typeClaim !== null &&
                        tab7_validation[index].typeClaim !== "true" && (
                          <div
                            style={{ marginBottom: "20px" }}
                            className="text-danger font-italic"
                          >
                            {tab7_validation[index].typeClaim}
                          </div>
                        )}
                    </Grid>

                    {/* Driver */}
                    <Grid item xs={4}>
                      <InputLabel htmlFor="Driver">Driver</InputLabel>
                    </Grid>
                    <Grid item xs={8}>
                      <TextField
                        disabled
                        name="driver"
                        value={claim.driver}
                        onChange={onChangeField(index)}
                        size="small"
                        variant="outlined"
                        autoComplete="off"
                        style={{ marginBottom: "20px" }}
                        fullWidth
                      />
                    </Grid>

                    {/* Date of claim */}
                    <Grid item xs={4}>
                      <InputLabel htmlFor="Date of claim">
                        Date of claim
                      </InputLabel>
                    </Grid>
                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <div>
                        <DatePicker
                          selected={claim.dateClaim}
                          // onChange={dateClaim}
                          onChange={(date) => dateClaim(date, index)}
                          dateFormat="dd/MM/yyyy"
                          name="dateClaim"
                          maxDate={new Date()}
                          value={claim.dateClaim}
                          className="date-picker-align"
                          onChangeRaw={handleDateChangeRaw}
                        // style={{ marginBottom: "10px", width:"50px"}}
                        // variant="outlined"
                        // autoComplete="off"
                        // fullWidth
                        />
                      </div>
                      {tab7_validation[index].dateClaim !== null &&
                        tab7_validation[index].dateClaim !== "true" && (
                          <div className="text-danger font-italic">
                            {tab7_validation[index].dateClaim}
                          </div>
                        )}
                    </Grid>

                    {/* years since first occurence */}
                    <Grid item xs={4}>
                      <InputLabel
                        htmlFor="Years since first occurrence"
                        required
                      >
                        Years since first occurrence
                      </InputLabel>
                    </Grid>
                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <Select
                        margin="none"
                        variant="outlined"
                        name="firstOccurrence"
                        autoComplete="off"
                        onChange={onChangeField(index)}
                        defaultValue={"Please Select"}
                        onClose={() =>
                          validationAfterChange(
                            index,
                            "firstOccurrence",
                            claim.firstOccurrence
                          )
                        }
                        value={claim.firstOccurrence ? claim.firstOccurrence : "Please Select"}
                        style={{ height: "40px" }}
                        fullWidth
                      >
                        <MenuItem disabled value="Please Select">
                          Please Select
                        </MenuItem>
                        <MenuItem value="0">0</MenuItem>
                        <MenuItem value="1">1</MenuItem>
                        <MenuItem value="2">2</MenuItem>
                        <MenuItem value="3">3</MenuItem>
                        <MenuItem value="4">4</MenuItem>
                        <MenuItem value="5">5</MenuItem>
                        <MenuItem value="6">6</MenuItem>
                        <MenuItem value="7">7</MenuItem>
                        <MenuItem value="8">8</MenuItem>
                        <MenuItem value="9">9</MenuItem>
                        <MenuItem value="10">10</MenuItem>
                      </Select>
                      {tab7_validation[index].firstOccurrence !== null &&
                        tab7_validation[index].firstOccurrence === "undefined" &&
                        tab7_validation[index].firstOccurrence !== "true" && (
                          <div className="text-danger font-italic">
                            {tab7_validation[index].firstOccurrence}
                          </div>
                        )}
                    </Grid>

                    {/* Reason for claims in the last 3 years */}
                    <Grid item xs={4}>
                      <InputLabel
                        htmlFor="Reason for claims in the last 3 years"
                        required
                      >
                        Reason for claims in the last 3 years
                      </InputLabel>
                    </Grid>
                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <Select
                        variant="outlined"
                        name="reasonClaims"
                        autoComplete="off"
                        onChange={onChangeField(index)}
                        onClose={() =>
                          validationAfterChange(
                            index,
                            "reasonClaims",
                            claim.reasonClaims
                          )
                        }
                        defaultValue={"Please Select"}
                        value={claim.reasonClaims ? claim.reasonClaims : "Please Select"}
                        style={{ height: "40px" }}
                        fullWidth
                      >
                        <MenuItem disabled value="Please Select">
                          Please Select
                        </MenuItem>
                        {/* <MenuItem value="Speeding">Speeding</MenuItem>
                        <MenuItem value="Driving under the influence - Drugs & Alcohol">
                          Driving under the influence - Drugs & Alcohol
                        </MenuItem>
                        <MenuItem value="Reckless driving">
                          Reckless driving
                        </MenuItem>
                        <MenuItem value="Point accumulation">
                          Point accumulation
                        </MenuItem> */}
                        <MenuItem value="Bushfire">Bushfire</MenuItem>
                        <MenuItem value="Collision at fault">Collision at fault</MenuItem>
                        <MenuItem value="Collision not at fault">Collision not at fault</MenuItem>
                        <MenuItem value="Damage while parked">Damage while parked</MenuItem>
                        <MenuItem value="Flood">Flood</MenuItem>
                        <MenuItem value="Hail">Hail</MenuItem>
                        <MenuItem value="Single vehicle accident">Single vehicle accident</MenuItem>
                        <MenuItem value="Storm">Storm</MenuItem>
                        <MenuItem value="Vandalism or Malicious damage">Vandalism or Malicious damage</MenuItem>
                        <MenuItem value="Windscreen">Windscreen</MenuItem>
                        <MenuItem value="Other">Other</MenuItem>
                      </Select>
                      {tab7_validation[index].reasonClaims !== null &&
                        tab7_validation[index].reasonClaims === "undefined" &&
                        tab7_validation[index].reasonClaims !== "true" && (
                          <div className="text-danger font-italic">
                            {tab7_validation[index].reasonClaims}
                          </div>
                        )}
                    </Grid>

                    {/* Description */}
                    {claim.reasonClaims === "Other" && (
                      <Grid item xs={12} style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <InputLabel htmlFor="Description" required>
                          Description
                        </InputLabel>
                        <Grid item xs={8} style={{ marginBottom: "20px" }}>
                          <TextField
                            name="description"
                            value={claim.description}
                            onChange={onChangeField(index)}
                            size="small"
                            variant="outlined"
                            autoComplete="off"
                            // style={{ marginBottom: "20px" }}
                            fullWidth
                          />
                          {tab7_validation[index].description !== null &&
                            tab7_validation[index].description !== "true" && (
                              <div className="text-danger font-italic">
                                {tab7_validation[index].description}
                              </div>
                            )}
                        </Grid>
                      </Grid>

                    )}



                    {/* Description */}
                    {/* <Grid item xs={4}>
                      <InputLabel htmlFor="Description">Description</InputLabel>
                    </Grid>
                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <TextField
                        name="description"
                        value={claim.description}
                        onChange={onChangeField(index)}
                        size="small"
                        variant="outlined"
                        autoComplete="off"
                        fullWidth
                      />
                      {tab7_validation[index].description !== null &&
                        tab7_validation[index].description !== "true" && (
                          <div className="text-danger font-italic">
                            {tab7_validation[index].description}
                          </div>
                        )}
                    </Grid> */}

                    {/* Claim Outcome */}
                    <Grid item xs={4}>
                      <InputLabel htmlFor="Claim Outcome">
                        Claim Outcome
                      </InputLabel>
                    </Grid>
                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <Select
                        margin="none"
                        variant="outlined"
                        autoComplete="off"
                        name="claimOutcome"
                        onChange={onChangeField(index)}
                        onClose={() =>
                          validationAfterChange(
                            index,
                            "claimOutcome",
                            claim.claimOutcome
                          )
                        }
                        value={claim.claimOutcome}
                        style={{ height: "40px" }}
                        fullWidth
                      >
                        <MenuItem disabled value=" ">
                          Please Select
                        </MenuItem>
                        <MenuItem value="Claim lodged, result pending">
                          Claim lodged, result pending
                        </MenuItem>
                        <MenuItem value="Claim paid">Claim paid</MenuItem>
                        <MenuItem value="Claim rejected">
                          Claim rejected
                        </MenuItem>
                        <MenuItem value="Insurance Cancelled">
                          Insurance Cancelled
                        </MenuItem>
                        <MenuItem value="Insurance Declined">
                          Insurance Declined
                        </MenuItem>
                        <MenuItem value="Insurance Refused">
                          Insurance Refused
                        </MenuItem>
                        <MenuItem value="No claim bonus reduced">
                          No claim bonus reduced
                        </MenuItem>
                        <MenuItem value="No claim bonus removed">
                          No claim bonus removed
                        </MenuItem>
                        <MenuItem value="No claim lodged">
                          No claim lodged
                        </MenuItem>
                        <MenuItem value="Special Items Imposed">
                          Special Items Imposed
                        </MenuItem>
                      </Select>
                      {tab7_validation[index].claimOutcome !== null &&
                        tab7_validation[index].claimOutcome !== "true" && (
                          <div className="text-danger font-italic">
                            {tab7_validation[index].claimOutcome}
                          </div>
                        )}
                    </Grid>

                    {/* Amount */}
                    <Grid item xs={4}>
                      <InputLabel htmlFor="Amount">Amount</InputLabel>
                    </Grid>
                    <Grid item xs={8} style={{ marginBottom: "20px" }}>
                      <TextField
                        name="amount"
                        value={claim.amount}
                        onChange={onChangeField(index)}
                        size="small"
                        variant="outlined"
                        autoComplete="off"
                        type="number"
                        onKeyPress={(e) => inpNum(e)}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">$</InputAdornment>
                          ),
                        }}
                        
                        fullWidth
                      />
                      {tab7_validation[index].amount !== null &&
                        tab7_validation[index].amount !== "true" && (
                          <div className="text-danger font-italic">
                            {tab7_validation[index].amount}
                          </div>
                        )}
                    </Grid>
                    <div
                      style={{
                        borderTop: "3px solid green ",
                        // marginLeft: 10,
                        marginTop: 20,
                        marginBottom: 20,
                        width: "100%",
                      }}
                    ></div>
                  </Grid>
                );
              })}
              {tab7_claims.length === 0 && (
                <Grid item xs={12}>
                  <div className="alert alert-info">
                    No claim are provided in the driver page
                  </div>
                </Grid>
              )}
            </Grid>

            <Grid>
              {isAllFormsValid() ? (
                <Button
                  variant="contained"
                  className="bg-warning"
                  style={{
                    marginTop: "1rem",
                    float: "right",
                    width: "10%",
                  }}
                  onClick={handleSubmit}
                >
                  Verify
                </Button>
              ) : (
                <Button
                  variant="contained"
                  className="bg-alert"
                  disabled
                  style={{
                    marginTop: "1rem",
                    float: "right",
                    width: "10%",
                  }}
                //onClick={() => submitAllForms()}
                >
                  Verify
                </Button>
              )}

              <ToastContainer
                style={{
                  marginLeft: "50px",
                  marginBottom: "-25px",
                  width: "30%",
                }}
              />
            </Grid>

            <Grid>
              <Button
                variant="contained"
                color="secondary"
                style={{
                  marginTop: "1rem",
                  float: "left",
                  width: "10%",
                }}
                onClick={() => exit()}
              >
                EXIT
              </Button>
            </Grid>

            <Grid>
              <Button
                variant="contained"
                color="primary"
                style={{
                  marginTop: "1rem",
                  float: "right",
                  marginRight: "20px",
                  width: "10%",
                  marginBottom: "1rem",
                }}
                onClick={() => navigation.previous()}
              >
                PREVIOUS
              </Button>
            </Grid>
          </div>
        </div>
      </Container>
    );
  };

  return (
    <div>
      {displayTab7()}
      {loadDashboardPage()}
    </div>
  );
};

export default Tab7_Claims;
