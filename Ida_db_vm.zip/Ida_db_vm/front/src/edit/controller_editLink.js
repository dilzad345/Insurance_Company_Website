import axios from "axios";
import { API } from "../config";
// import catchAsync from "../utils/catchAsync";

import { tab1_validateedit } from "../validations/tab1_validate";
import { tab3_validate } from "../validations/tab3_validate";
import { tab4_validate } from "../validations/tab4_validate";
import { tab5_validateEdit } from "../validations/tab5_validate";
import { tab6_validate } from "../validations/tab6_validate";
import { tab7_validate } from "../validations/tab7_validate";

export const validateAllForms = (
  tab1_client,
  tab3_policyCore,
  tab4_vehicle,
  tab5_modifications,
  tab6_drivers,
  tab7_claims
) => {
  let isValid = true;
  isValid = isValid * tab1_validateedit(tab1_client);
  isValid = isValid * tab3_validate(tab3_policyCore);
  isValid = isValid * tab4_validate(tab4_vehicle);
  isValid = isValid * tab5_validateEdit(tab5_modifications);
  isValid = isValid * tab6_validate(tab6_drivers);
  isValid = isValid * tab7_validate(tab7_claims);

  return isValid;
};

// method: get all form details of a quotation using quotation id;
export const getQuotationDetail = (quotationId) => {

  return axios
    .get(`${API}/quotation/quotation?quotationId=` + quotationId,
      {
        headers: JSON.parse(localStorage.getItem("user"))
      })
    .then((result) => {
      return result;
    })
    .catch((error) => {
      console.log(error);
    });
}; // end of get quotation details

// method: update quotation details;
export const updateAllForms = (
  tab1_client,
  tab2_importantQuestions,
  tab3_policyCore,
  tab4_vehicle,
  tab5_modifications,
  tab6_drivers,
  tab7_claims,
  quotationId) => {

  const data = {
    data_tab1: tab1_client,
    data_tab2: tab2_importantQuestions,
    data_tab3: tab3_policyCore,
    data_tab4: tab4_vehicle,
    data_tab5: tab5_modifications,
    data_tab6: tab6_drivers,
    data_tab7: tab7_claims,
    quotationId: quotationId,
  }
  console.log(data);
  return axios.post(`${API}/quotation/updateQuotation`, data)
    .then((result) => {
      console.log(result);
      return result;
    }).catch((err) => {
      console.log(err);
      return false;
    })

} // end of update all forms

export const assignValue_tab1 = (dataClient, tab1_client, setTab1) => {
  setTab1({
    ClientIdFromUipath: dataClient.client.client_code,
    clientType: dataClient.client.client_type,
    title: dataClient.client.client_title,
    firstName: dataClient.client.client_first_name,
    lastName: dataClient.client.client_last_name,
    companyName: dataClient.client.company_name,
    tradingAs: dataClient.client.trading_as,
    officeTechReferenceCode: dataClient.client.reference_code,
    addressId: dataClient.address.address_id,
    unitNumber: dataClient.address.unit_number,
    streetNumber: dataClient.address.street_number,
    streetName: dataClient.address.street_name,
    streetType: dataClient.address.street_type,
    suburb: dataClient.address.suburb,
    state: dataClient.address.state,
    postCode: dataClient.address.postcode,
    contactId: dataClient.contact.contact_id,
    phone: dataClient.contact.phone,
    email: dataClient.contact.email,
    branch: dataClient.contact.branch,
    salesTeam: dataClient.contact.sales_team,
    serviceTeam: dataClient.contact.service_team,
    clientId : dataClient.client.client_id

  });
};

export const assignValue_tab2 = (dataImp, tab2_importantQuestions, setTab2) => {
  setTab2({
    importantQuestionId: dataImp.important_question_motor_id,
    insurancePolicyCancelledLast_12_months: dataImp.insurance_policy_dc_5_years,
    insurancePolicyCancelledLast_5_years:
      dataImp.insurance_policy_dc_last_12_month,
    hadClaimDeclained: dataImp.claim_declined,
    reasonClaimDecalined: dataImp.reason_for_decline,
    maliciousDamage: dataImp.any_criminal_conviction,
    existingDamage: dataImp.existing_damage_vehicle,
    wouldAnswerYes: dataImp.would_you_answer_yes,
    declaredBankrupt: dataImp.bankrupt_or_insolvent_last_5_years,
    reasonBankrupt: dataImp.reason_bankrupt_or_insolvent_last_5_years,
    criminalOffence: dataImp.criminal_offence_past_5_years,
    reasonCriminalOffence: dataImp.reason_criminal_offence_past_5_years,
  });
};

export const assignValue_tab3 = (dataPolicyCore, tab3_policyCore, setTab3) => {

  setTab3({
    policyCoreId: dataPolicyCore.policy_core_motor_id,
    holdingBroker: dataPolicyCore.holding_broker,
    holdingUnderwriter: dataPolicyCore.holding_underwriter,
    stampDuty: dataPolicyCore.stamp_duty_exempt,
    noClaimBonus: dataPolicyCore.no_claim_bonus,
    paymentFrequency: dataPolicyCore.payment_frequency,
    preferredInstallments: dataPolicyCore.preferred_day_for_installments,
    broker_fee_installments: dataPolicyCore.broker_fee_installments,
    // productType: dataPolicyCore.product_type_allianz,
    coverType: dataPolicyCore.cover_type,
    sumInsured: dataPolicyCore.sum_insured,
    agreedValueAmount: dataPolicyCore.agreed_value_amount,
    policyFromDate: new Date(dataPolicyCore.policy_from_date),
    policyToDate: new Date(dataPolicyCore.policy_to_date),
    // policyFromDate: dataPolicyCore.policy_from_date.substring(0, 10),
    // policyToDate: dataPolicyCore.policy_to_date.substring(0, 10),
    roadsideAssistance: dataPolicyCore.roadside_assistance,
    hireCareInclusion: dataPolicyCore.hire_care_inclusion_SVU_allianz,
    windscreenExcessWaiver: dataPolicyCore.windscreen_excess_waiver_SVU_allianz,
    repairsVehicle: dataPolicyCore.who_repairs_the_vehicle_IAL_only,
    claimBonusProtection: dataPolicyCore.no_claim_bonus_protection_allianz,
    restrictedDriversDiscount:
      dataPolicyCore.restricted_driver_discount_allianz,
    namedDriver: dataPolicyCore.named_driver_option_allianz,
    toolsTrade: dataPolicyCore.tools_of_trade_option_allianz,
    restrictedDrivers: dataPolicyCore.restricted_drivers_vero,
    interestedParties: dataPolicyCore.interested_parties,
    occupationPolicyholder: dataPolicyCore.occupation_of_policyholder_zurich,
    commercialPurposesCaravan:
      dataPolicyCore.commercial_purposes_caravan_operations,
    excessOption1: dataPolicyCore.excess_option_1,
    excessOption2: dataPolicyCore.excess_option_2,
    excessOption3: dataPolicyCore.excess_option_3,
    brokerFee: dataPolicyCore.broker_fee,
  });
};

export const assignValue_tab4 = (dataVehicle, tab4_vehicle, setTab4) => {
  const vehicle = dataVehicle.vehicle;
  const address = dataVehicle.address;

  let purchaseDate = vehicle.purchase_date;
  // console.log("Pur date:"+purchaseDate);
  if (vehicle.purchase_date === null) {
    purchaseDate = null
  }
  else {
    purchaseDate = new Date(purchaseDate.substring(0, 10));
    console.log(purchaseDate);
  }
  

  setTab4({
    addressId: address.address_id,
    unitNumber: address.unit_number,
    streetNumber: address.street_number,
    streetName: address.street_name,
    streetType: address.street_type,
    suburb: address.suburb,
    state: address.state,
    postCode: address.postcode, // 7 variables

    vehicleId: vehicle.vehicle_info_id,
    registrationVehicle: vehicle.registration_of_vehicle,
    stateIssued : vehicle.state_issued,
    vehicleColour: vehicle.vehicle_color,
    vehicleYear: vehicle.vehicle_year,
    vehicleMake: vehicle.vehicle_make,
    vehicleModel: vehicle.vehicle_model,
    vehicleType: vehicle.vehicle_type,
    securityDeviceFitted: vehicle.security_device_fitted, // 7 variables
    similarPowerOfVehicle: vehicle.vehicle_owned_years,
    vehicleParkedDay: vehicle.where_is_parked,
    vehicleUsage: vehicle.vehicle_usage,
    numberKMsYear: vehicle.avg_num_of_km_per_year,
    vehicleParkedNight: vehicle.vehicle_parked_at_night,
    previouslyInsured: vehicle.policyHolder_previously_insured,
    vehicleUnregistered: vehicle.vehicle_unregistered,
    usedDriver:
      vehicle.driver_education_racing_sporting_events_courier_delivery,
    usedHireCar:
      vehicle.hire_car_removalist_vehicle_fleet_or_pool_vehicle_airside,
    specialisedPaint: vehicle.vehicle_has_specialised_paint,
    superCharger: vehicle.vehicle_has_turbo_supercharger,
    hydrogenFuel: vehicle.vehicle_has_nitro_hydrogen_fuel,
    racingHarnesses: vehicle.vehicle_has_a_Roll_bar_rollcage_racing_harnesses,
    vehicleFinanced: vehicle.vehicle_financed,
    hailDamage: vehicle.vehicle_have_hail_damage,
    purchaseDate: purchaseDate,
    //  purchaseDate: new Date(purchaseDate),
    purchasePrice: vehicle.Purchase_Price, // 15 variables
  });
};

/* dataModi, tab5_modifications, setTab5,tab5_validation,
              setTab5_validation */
export const assignValue_tab5 = (
  dataModi,
  tab5_modifications,
  setTab5,
  tab5_validation,
  setTab5_validation
) => {
  dataModi.map((modi) => {
    setTab5((tab5_modificationss) => [
      ...tab5_modificationss,
      {
        modiId: modi.nsam_id,
        edit: 'OLD',
        type: modi.type,
        category: modi.category,
        description: modi.description,
        value: modi.value,
      },
    ]);

    setTab5_validation((tab5_validation) => [
      ...tab5_validation,
      {
        type: true,
        category: true,
        description: true,
        value: true,
      },
    ]);
    //console.log(tab5_modifications);
  });
};

export const assignValue_tab6 = (
  dataDrivers,
  tab6_drivers,
  setTab6,
  tab6_validation,
  setTab6_validation
) => {
  // console.log(dataDrivers);
  dataDrivers.map((driver) => {
    setTab6_validation((tab6_validation) => [
      ...tab6_validation,
      {
        firstName: "",
        surName: "",
        gender: "",
        dateBirth: "",
        driversLicenseObtained: "",
        stateIssued : "",
        statusDriver: "",
        demeritPoints3: "",
        alcoholOffences: "",
        firstOccurrence1: "",
        reasonFines: "",
        licenseSuspensions: "",
        firstOccurrence2: "",
        suspension1st: "",
        suspension2nd: "",
        suspension3rd: "",
        numberClaims3: "",
        // firstOccurrence3: "",
        // reasonClaims3: "",
        accidentClaim: "",
        firstOccurrence4: "",
        ownVehicle: "",
        ownsAnotherVehicle: "",
      },
    ]);

    let dateBirth = driver.driver_dob;
    console.log("license year:" +driver.year_australian_drivers_license_obtained);
    // console.log("Date:"+driver.driver_dob);
    if (dateBirth !== null) {
      dateBirth = dateBirth.substring(0, 10);
    }

    setTab6((tab6_drivers) => [
      ...tab6_drivers,
      {
        driverId: driver.driver_info_id,
        edit: 'OLD',
        driverType: driver.driver_type,
        firstName: driver.driver_first_name,
        surName: driver.driver_surname,
        gender: driver.driver_gender,
        dateBirth: new Date(dateBirth),
        //dateBirt: driver.driver_dob.substring(0, 10), // 7 vars

        //driversLicenseObtained: new Date(),
        driversLicenseObtained: driver.year_australian_drivers_license_obtained.toString(),
        stateIssued : driver.state_issued,
        statusDriver: driver.employment_status_of_the_driver,
        demeritPoints3: driver.demerit_points_in_last_3_years,
        alcoholOffences: driver.fines_penalties_imposed_drugalcohol_offences.toString(),
        firstOccurrence1: driver.penalties_years_since_first_occurrence,
        reasonFines: driver.reason_for_conviction_fines_or_penalties, // 6 vars

        licenseSuspensions: driver.num_of_license_suspensions_cancellations_3y,
        firstOccurrence2: driver.suspensions_years_since_first_occurrence,
        suspension1st: driver.reason_for_1st_suspension_or_cancellation,
        suspension2nd: driver.reason_for_2nd_suspension_or_cancellation,
        suspension3rd: driver.reason_for_3rd_suspension_or_cancellation,
        numberClaims3: driver.number_of_claims_in_the_last_3_years, // 6 vars

        // firstOccurrence3: driver.claims_years_since_firstOccurrence,
        // reasonClaims3: driver.reason_for_claims_last_3years,
        accidentClaim: driver.had_any_accident_or_claim_involving_a_vehicle,
        firstOccurrence4: driver.accident_years_since_firstOccurrence,
        // firstOccurrence4: driver.claims_years_since_firstOccurrence,
        ownVehicle: driver.owns_this_vehicle,
        ownsAnotherVehicle: driver.owns_another_Vehicle, // 6 vars
      },
    ]);
  });
};

export const assignValue_tab7 = (dataClaims, tab7_claims, setTab7, tab7_validation, setTab7_validation) => {
  dataClaims.map((claimArray, index) => {
    const arrClaim = claimArray.dataClaims;
    arrClaim.map((claim, indexClaim) => {
      setTab7((tab7_claims) => [
        ...tab7_claims,
        {
          claimId: claim.claim_id,
          typeClaim: claim.claim_type,
          dateClaim: new Date(claim.claim_date),
          firstOccurrence: claim.claims_years_since_firstOccurrence,
          reasonClaims: claim.reason_for_claims_last_3years,
          description: claim.claim_description,
          claimOutcome: claim.claim_outcome,
          amount: claim.claim_amount,
          driver: claimArray.driver[0].driver_type + ": " + claimArray.driver[0].driver_first_name + " " + claimArray.driver[0].driver_surname,
          driverId: claim.driver_info_id_fk,
        }
      ])

      setTab7_validation((tab7_validation) => [
        ...tab7_validation,
        {
          typeClaim: null,
          dateClaim: null,
          description: null,
          claimOutcome: null,
          amount: null,
        }
      ])
    })
  })
};
