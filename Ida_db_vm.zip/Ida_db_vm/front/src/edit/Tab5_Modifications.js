import React from "react";
import {
  TextField,
  Container,
  Button,
  InputLabel,
  MenuItem,
  Select,
  Grid,
} from "@material-ui/core";
// import { makeStyles } from "@material-ui/core/styles";
import {
  type_validate,
  category_validate,
  description_validate,
  value_validate,
} from "../validations/tab5_validate";
import InputAdornment from "@material-ui/core/InputAdornment";
import { confirmAlert } from 'react-confirm-alert'; 
import 'react-confirm-alert/src/react-confirm-alert.css';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import {inpNum} from "../constants/validChecker"
// const useStyles = makeStyles((theme) => ({
//   root: {
//     flexGrow: 1,
//     alignContent: "center",
//     padding: theme.spacing(2),
//     //textAlign: 'center',
//   },
//   paper: {
//     padding: theme.spacing(2),
//     textAlign: "center",
//     color: theme.palette.text.secondary,
//   },
// }));
import history from "../auth/history";

const returnDashBoard = () => {
  history.push('/user/dashboard_motor');
}
const Tab5_Modifications = ({
  tab5_modifications,
  setTab5,
  tab5_validation,
  setTab5_validation,
  navigation,
}) => {
  // const modiCount = tab5_modifications.length;

  const notifyDeleteModification = () =>
  toast.success("Modification Deleted!", {
    position: "bottom-center",
    autoClose: 5000,
    hideProgressBar: true,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
  });

  // onClick method: exit when clicking exit btn
const exit = () => {
  // console.log(ind);
  // const temp = [...tab5_modifications];
  // const tempValidate = [...tab5_validation];

  confirmAlert({
    title: "Confirm to exit",
    message: "Are you going to exit without saving any data to the database ?",
    buttons: [
      {
        label: "Yes",
        onClick: () => {
          // removing the element using splice
          // temp.splice(ind, 1);
          // tempValidate.splice(ind, 1);

          // tab5_modifications = temp;
          // tab5_validation = tempValidate;

          // // updating the list
          // setTab5(temp);
          // setTab5_validation(tempValidate);

          returnDashBoard();
        },
      },
      {
        label: "No",
        onClick: () => null,
      },
    ],
  });
};

  // add a vehicle modifications
  const addMore = () => {
    setTab5((tab5_modifications) => [
      ...tab5_modifications,
      { edit: "NEW", type: " ", category: " ", description: "", value: "" },
    ]);
    setTab5_validation((tab5_validation) => [
      ...tab5_validation,
      { type: " ", category: " ", description: "", value: "" },
    ]);
  };

  // onClick method: delete modification when not needed
  const deleteModi = (ind) => {
    let tempArr = [...tab5_modifications];
    // console.log("tab5 modications: ",tempArr);
    let tempObj = tempArr[ind];

    confirmAlert({
      title: 'Confirm to delete',
      message: 'Are you sure to do this?',
      buttons: [
        {
          label: 'Yes',
          onClick: () => 
          {
            if (tempObj.edit === "NEW") {
              console.log("new delete: " + ind);
              const temp = [...tab5_modifications];
              const tempValidate = [...tab5_validation];
              temp.splice(ind, 1); // removing the element using splice
              tempValidate.splice(ind, 1);
              tab5_modifications = temp;
              tab5_validation = tempValidate;
              setTab5(temp); // updating the list
              setTab5_validation(tempValidate);
            } else {
              tempObj = {
                // updating the temporary list
                ...tempObj,
                edit: "DELETED",
              };
              tempArr[ind] = tempObj; // replace the list with temporary list
              console.log("ind: " + ind + " edit: " + tempArr[ind].edit);
              setTab5(tempArr);
            }
            notifyDeleteModification();
          }
        },
        {
          label: 'No',
          onClick: () => null
        }
      ]
    });
    
  };

  // on change method; to change field values according to the changes
  const onChangeField = (ind) => (event) => {
    let name = event.target.name;
    let value = event.target.value;
    // make a copy of original list as temporary list
    let tempArr = [...tab5_modifications];
    let tempObj = tempArr[ind];

    // updating the temporary list
    tempObj = {
      ...tempObj,
      [event.target.name]: event.target.value,
    };

    // replace the list with temporary list
    tempArr[ind] = tempObj;
    //console.log(tempArr);

    setTab5(tempArr, () => {
      validationAfterChange(ind, name, value);
    });
  };

  // call validation
  const validationAfterChange = (index, name, value) => {
    switch (name) {
      case "type": {
        type_validate(index, value, tab5_validation, setTab5_validation);
        break;
      }
      case "category": {
        category_validate(index, value, tab5_validation, setTab5_validation);
        break;
      }
      case "description": {
        description_validate(index, value, tab5_validation, setTab5_validation);
        break;
      }
      case "value": {
        value_validate(index, value, tab5_validation, setTab5_validation);
        break;
      }
      default:{
        console.log("Not match to condition");
      }
    }
  };

  return (
    <Container maxWidth="md" style={{ marginBottom: "50px" }}>
      <div className="container p-3 my-3 text-dark">
        <Grid xs={12} item={true} justifyContent="center" container>
          <h3>MODIFICATIONS/ACCESSORIES </h3>
        </Grid>
        <div>
        {tab5_modifications.map((modi, index) => {
          if (modi.edit !== "DELETED") {
            return (
              <div>
                <Grid
                  key={index}
                  container
                  spacing={3}
                  direction="row"
                  justifyContent="center"
                  alignItems="center"
                  style={{ marginBottom: "20px", marginTop: "20px" }}>
                  <Grid item xs={4}>
                    <InputLabel htmlFor="Type" style={{ marginBottom: "5px" }} required>
                      Type: {modi.edit}
                    </InputLabel>
                  </Grid>

                  <Grid item xs={8} className="my-2">
                    <Select
                      name="type"
                      variant="outlined"
                      autoComplete="off"
                      onChange={onChangeField(index)}
                      onClose={() =>
                        validationAfterChange(index, "type", modi.type)
                      }
                      value={modi.type}
                      style={{ height: "40px" }}
                      fullWidth
                    >
                      <MenuItem disabled value=" ">
                        Please Select
                      </MenuItem>
                      <MenuItem value="Modifications">Modification</MenuItem>
                      <MenuItem value="Accessories">
                        Non-standard accessories
                      </MenuItem>
                    </Select>
                    {tab5_validation[index].type !== null &&
                      tab5_validation[index].type !== "true" && (
                        <div className="text-danger font-italic">
                          {tab5_validation[index].type}
                        </div>
                      )}
                  </Grid>

                  <Grid item xs={4}>
                    <InputLabel
                      htmlFor="Category"
                      style={{ marginBottom: "5px" }}
                      required
                    >
                      Category
                    </InputLabel>
                  </Grid>

                  <Grid item xs={8} className="my-2">
                    <Select
                      name="category"
                      variant="outlined"
                      autoComplete="off"
                      onChange={onChangeField(index)}
                      onClose={() =>
                        validationAfterChange(index, "category", modi.category)
                      }
                      value={modi.category}
                      style={{ height: "40px" }}
                      fullWidth
                    >
                      <MenuItem disabled value=" ">
                        Please Select
                      </MenuItem>
                      <MenuItem value="Roll Bar/ Roll Cage">
                        Roll Bar/ Roll Cage
                      </MenuItem>
                      <MenuItem value="Brakes">Brakes</MenuItem>
                      <MenuItem value="Bull Bars or Tow Bars">
                        Bull Bars or Tow Bars
                      </MenuItem>
                      <MenuItem value="Engine and Exhaust">
                        Engine and Exhaust
                      </MenuItem>
                      <MenuItem value="Four wheel drive equipment">
                        Four wheel drive equipment
                      </MenuItem>
                      <MenuItem value="Fuel System">Fuel System</MenuItem>
                      <MenuItem value="Other">Other</MenuItem>
                    </Select>
                    {tab5_validation[index].category !== null &&
                      tab5_validation[index].category !== "true" && (
                        <div className="text-danger font-italic">
                          {tab5_validation[index].category}
                        </div>
                      )}
                  </Grid>

                  <Grid item xs={4}>
                    <InputLabel
                      htmlFor="Description"
                      style={{ marginBottom: "5px" }}
                      // required
                    >
                      Description
                    </InputLabel>
                  </Grid>

                  <Grid item xs={8} className="my-2">
                    <TextField
                      name="description"
                      value={modi.description}
                      onChange={onChangeField(index)}
                      size="small"
                      variant="outlined"
                      autoComplete="off"
                      required
                      fullWidth
                    />
                    {/* {tab5_validation[index].description !== null &&
                      tab5_validation[index].description !== "true" && (
                        <div className="text-danger font-italic">
                          {tab5_validation[index].description}
                        </div>
                      )} */}
                  </Grid>

                  <Grid item xs={4}>
                    <InputLabel htmlFor="Value" style={{ marginBottom: "5px" }} required>
                      Value
                    </InputLabel>
                  </Grid>

                  <Grid item xs={8} className="my-2">
                    <TextField
                      name="value"
                      type="number"
                      value={modi.value}
                      onChange={onChangeField(index)}
                      size="small"
                      variant="outlined"
                      autoComplete="off"
                      
                      required
                      fullWidth
                      onKeyPress={(e) => inpNum(e)}
                     
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">$</InputAdornment>
                        ),
                        
                      }}
                    />
                    {tab5_validation[index].value !== null &&
                      tab5_validation[index].value !== "true" && (
                        <div className="text-danger font-italic">
                          {tab5_validation[index].value}
                        </div>
                      )}
                  </Grid>
                </Grid>

                <Button
                  style={{ float: "right", width: "10%", marginBottom: "30px" }}
                  onClick={() =>  deleteModi(index)}
                  // className="bg-warning"
                  variant="contained"
                  color="secondary"
                >
                  DELETE
                </Button>

                <br />
                <hr
                  style={{
                    color: "red",
                    backgroundColor: "green",
                    height: 1,
                    marginTop: "50px",
                  }}
                />
              </div>
            );
          }
        }
        )
        }
        </div>
        <Grid
          direction="row"
          container
          justifyContent="center"
          alignItems="center"
        >
          {/* <Grid item xs={12} style={{ marginTop: "20px" }}>
            <div className="alert alert-info">
              Add More Modificaton by Pressing 'ADD MORE' button
            </div>
          </Grid> */}
          <Grid item xs={4}></Grid>
          <Grid
            item
            xs={4}
            container
            justifyContent="center"
            alignItems="center"
          >
            <Button
              fullWidth
              onClick={addMore}
              className="bg-success text-white"
            >
              ADD ANOTHER
            </Button>
          </Grid>
          <Grid item xs={4}></Grid>
        </Grid>

        <Grid>
            <Button
              variant="contained"
              color="secondary"
              style={{
                marginTop: "1rem",
                float: "left",
                width: "10%",
              }}
              onClick={() => exit()}
            >
              EXIT
            </Button>
          </Grid>

        <Button
          variant="contained"
          color="primary"
          type="Submit"
          style={{ marginTop: "1rem", marginBottom: "1rem", float: "right",width: "10%" }}
          onClick={() => navigation.next()}
        >
          NEXT
        </Button>
        <Button
          variant="contained"
          color="primary"
          style={{
            marginTop: "1rem",
            width: "10%",
            float: "right",
            marginRight: "20px",
          }}
          onClick={() => navigation.previous()}
        >
          PREVIOUS
        </Button>
      </div>
      <ToastContainer style={{ marginLeft:"50px", marginBottom:"-25px", width:"30%"}}/>
    </Container>
  );
};

export default Tab5_Modifications;
