import React, { useEffect, useState } from "react";
import Tab1_Client from "./Tab1_Client";
import Tab2_ImportantQuestions from "./Tab2_ImportantQuestions";
import Tab3_PolicyCore from "./Tab3_PolicyCore";
import Tab4_vehicle from "./Tab4_Vehicle";
import Tab5_Modifications from "./Tab5_Modifications";
import Tab6_drivers from "./Tab6_Driver";
import Tab7_Claims from "./Tab7_Claims";
import { useStep } from "react-hooks-helper";
import { navigationBarEdit } from "../core/navigationBar";
import { useStateWithCallbackLazy } from "use-state-with-callback";
import { updateAllForms } from "./controller_editLink";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import history from "../auth/history";
import { signout } from "../auth";
import {
  validateAllForms,
  // assignValuesToEveryForm,
  getQuotationDetail,
  // getClientDetail,
  assignValue_tab3,
  assignValue_tab1,
  assignValue_tab2,
  assignValue_tab4,
  assignValue_tab5,
  assignValue_tab6,
  assignValue_tab7,
} from "./controller_editLink";

// import { agreedValueAmount_validate } from "../validations/tab3_validate";
let tokenError = false;

//Error message for invalid token
const tokenErrorMessage = (tokenError) => {
  return (
    <div>
      {tokenError === true &&
        confirmAlert({
          title: "Invalid User",
          message: "Re-login to system.",
          buttons: [
            {
              label: "Login",
              onClick: () => {
                signout(() => {
                  history.push("/signin");
                });
              },
            },
            // {
            //   label: 'No',
            //   onClick: () => null
            // }
          ],
        })}
    </div>
  );
};

// navigation helper
const steps = [
  { id: "tab1_client" },
  { id: "tab2_importantQuestions" },
  { id: "tab3_policyCore" },
  { id: "tab4_vehicle" },
  { id: "tab5_modifications" },
  { id: "tab6_drivers" },
  { id: "tab7_claims" },
];

const EditLink = (props) => {
  // const [quotationEdit, set_quotationEdit] = useStateWithCallbackLazy({});
  // console.log(props.id);
  const [quotationId, setQuotationId] = useStateWithCallbackLazy();

  const { step, navigation } = useStep({
    steps,
    initialStep: 0,
  }); // end of useStep

  // get all quotation details from the db and assign values to the related variables
  useEffect(() => {
    setQuotationId(props.id, () => {
      assignValuesToEveryForm(props.id);
      console.log(props.id)
      //set_quotationEdit(result_quotationEdit, () => {console.log(quotationEdit);});
    });
  });

  //
  const assignValuesToEveryForm = async (quotationId) => {
    if (quotationId) {
      await getQuotationDetail(quotationId)
        .then(async (resQuote) => {
          //console.log(resQuote.data.message);
          // console.log("data: ",resQuote.data);
          if (resQuote.data.message) {
            console.log("Error in token");
            tokenError = true;
            tokenErrorMessage(tokenError);
          } else {
            const dataClient = resQuote.data.data.dataClient;
            console.log(dataClient);
            const dataModi = resQuote.data.data.dataModifications;
            const dataImp = resQuote.data.data.dataImportantQuestion;
            const dataPolicyCore = resQuote.data.data.dataPolicyCore;
            const dataVehicle = resQuote.data.data.dataVehicle;
            const dataDrivers = resQuote.data.data.dataDrivers;
            const dataClaims = resQuote.data.data.dataClaim;

            assignValue_tab1(dataClient, tab1_client, setTab1);
            assignValue_tab2(dataImp, tab2_importantQuestions, setTab2);
            assignValue_tab3(dataPolicyCore, tab3_policyCore, setTab3);
            assignValue_tab4(dataVehicle, tab4_vehicle, setTab4);
            assignValue_tab5(
              dataModi,
              tab5_modifications,
              setTab5,
              tab5_validation,
              setTab5_validation
            );
            assignValue_tab6(
              dataDrivers,
              tab6_drivers,
              setTab6,
              tab6_validation,
              setTab6_validation
            );
            assignValue_tab7(
              dataClaims,
              tab7_claims,
              setTab7,
              tab7_validation,
              setTab7_validation
            );
          }
        })
        .catch((error) => {
          console.log(error);
        });
    }
  };

  // tab1 variable object defined
  const [tab1_client, setTab1] = useStateWithCallbackLazy({
    ClientIdFromUipath: "",
    clientType: " ",
    title: "",
    firstName: "",
    lastName: "",
    companyName: "",
    tradingAs: "",
    officeTechReferenceCode: "",
    unitNumber: 0,
    streetNumber: 0,
    streetName: "",
    streetType: " ",
    suburb: "",
    state: " ",
    postCode: 0,
    phone: "",
    email: "",
    branch: "",
    salesTeam: " ",
    serviceTeam: " ",
  });

  // tab1 validation
  const [tab1_validation, setTab1_validation] = useState({
    clientType: null,
    title: null,
    firstName: null,
    lastName: null,
    companyName: null,
    tradingAs: null,
    tab1_fullValidation: null,
  });

  // tab2 variable object defined
  const [tab2_importantQuestions, setTab2] = useStateWithCallbackLazy({
    insurancePolicyCancelledLast_12_months: "No",
    insurancePolicyCancelledLast_5_years: "No",
    hadClaimDeclained: "No",
    reasonClaimDecalined: "",
    maliciousDamage: "No",
    existingDamage: "No",
    wouldAnswerYes: "",
    declaredBankrupt: "No",
    reasonBankrupt: "",
    criminalOffence: "No",
    reasonCriminalOffence: "",
  });

  // tab2 validation
  const [tab2_validation, setTab2_validation] = useState({});

  // tab3 variable object defined
  const [tab3_policyCore, setTab3] = useStateWithCallbackLazy({
    holdingBroker: "No",
    holdingUnderwriter: "AIG",
    stampDuty: "No",
    noClaimBonus: "60% - Level 1",
    paymentFrequency: "Yearly",
    preferredInstallments: "sss",
    brokerFeeInstallment: "100",
    productType: "Classic",
    coverType: "Comprehensive",
    sumInsured: "Agreed Value",
    agreedValueAmount: "200",
    policyFromDate: "2021-02-02",
    policyToDate: "2022-02-02",
    roadsideAssistance: "No",
    hireCareInclusion: "No",
    windscreenExcessWaiver: "No",
    repairsVehicle: "Insurer Decides",
    claimBonusProtection: "No",
    restrictedDriversDiscount: "Insurer Decides",
    namedDriver: "No",
    toolsTrade: "Insurer Decides",
    restrictedDrivers: "No Restriction",
    interestedParties: "AMP",
    occupationPolicyholder: "Design",
    commercialPurposesCaravan: "Design",
    excessOption1: "500",
    excessOption2: "600",
    excessOption3: "700",
    brokerFee: "800",
  });

  const [tab3_validation, setTab3_validation] = useState({
    holdingBroker: " ",
    holdingUnderwriter: " ",
    stampDuty: " ",
    noClaimBonus: " ",
    paymentFrequency: " ",
    preferredInstallments: "",
    broker_fee_installments: "",
    productType: " ",
    coverType: " ",
    sumInsured: " ",
    agreedValueAmount: "",
    policyFromDate: "",
    policyToDate: "",
    roadsideAssistance: " ",
    hireCareInclusion: " ",
    windscreenExcessWaiver: " ",
    repairsVehicle: " ",
    claimBonusProtection: " ",
    namedDriver: " ",
    restrictedDriversDiscount: " ",
    toolsTrade: " ",
    restrictedDrivers: " ",
    interestedParties: " ",
    occupationPolicyholder: " ",
    commercialPurposesCaravan: " ",
    excessOption1: " ",
    excessOption2: " ",
    excessOption3: " ",
    brokerFee: "",
  });

  const [tab4_vehicle, setTab4] = useStateWithCallbackLazy({
    unitNumber: "0",
    streetNumber: "10",
    streetName: "sasaa",
    streetType: "street",
    suburb: "sddd",
    state: "QLD",
    postCode: "1222", // 7 variables

    registrationVehicle: "ssss",
    vehicleColour: "Black",
    vehicleYear: "1998",
    vehicleMake: "Make",
    vehicleModel: "Model",
    vehicleType: "Type",
    securityDeviceFitted: "None", // 7 variables
    similarPowerOfVehicle: "NEVER OWNED",
    vehicleParkedDay: "Carport",
    vehicleUsage: "Private Use Only",
    numberKMsYear: "0 - 5000",
    vehicleParkedNight: "Carport",
    previouslyInsured: "None",
    vehicleUnregistered: "Yes",
    usedDriver: "Yes",
    usedHireCar: "Yes",
    specialisedPaint: "No",
    superCharger: "No",
    hydrogenFuel: "No",
    racingHarnesses: "Yes",
    vehicleFinanced: "No Finance",
    hailDamage: "Yes",
    purchaseDate: null,
    purchasePrice: "25000", // 15 variables
  });

  const [tab4_validation, setTab4_validation] = useState({
    streetNumber: " ",
    streetName: " ",
    streetType: " ",
    suburb: "",
    state: " ",
    postCode: " ",

    registrationVehicle: " ",
    vehicleUsage: " ",
    numberKMsYear: " ",
    vehicleParkedNight: " ",
    previouslyInsured: " ",
    vehicleUnregistered: " ",
    usedDriver: " ",
    usedHireCar: " ",
    specialisedPaint: " ",
    superCharger: " ",
    hydrogenFuel: " ",
    racingHarnesses: " ",
    vehicleFinanced: " ",
    hailDamage: " ",
  });

  const [tab5_modifications, setTab5] = useStateWithCallbackLazy([]);

  const [tab5_validation, setTab5_validation] = useState([]);

  const [tab6_drivers, setTab6] = useStateWithCallbackLazy([
    //  {
    //   driverType: "Main",
    //   firstName: "Name",
    //   surName: "sur name",
    //   gender: "Male",
    //   dateBirt: "1995-02-02", // 7 vars
    //   driversLicenseObtained: "2000",
    //   statusDriver: "Employed",
    //   demeritPoints3: "0",
    //   alcoholOffences: "0",
    //   firstOccurrence1: "1",
    //   reasonFines: "Speeding", // 6 vars
    //   licenseSuspensions: "0",
    //   firstOccurrence2: "1",
    //   suspension1st: "Speeding",
    //   suspension2nd: "Speeding",
    //   suspension3rd: "Speeding",
    //   numberClaims3: "2", // 6 vars
    //   firstOccurrence3: "1",
    //   reasonClaims3: "Speeding",
    //   accidentClaim: "0",
    //   firstOccurrence4: "1",
    //   ownVehicle: "Yes",
    //   ownsAnotherVehicle: "No", // 6 vars
    //  },
  ]);

  const [tab6_validation, setTab6_validation] = useState([
    // {
    //   firstName: "",
    //   surName: "",
    //   gender: " ",
    //   dateBirth: "",
    //   driversLicenseObtained: "",
    //   statusDriver: "",
    //   demeritPoints3: "",
    //   alcoholOffences: "",
    //   firstOccurrence1: "",
    //   reasonFines: "",
    //   licenseSuspensions: "",
    //   firstOccurrence2: "",
    //   suspension1st: "",
    //   suspension2nd: "",
    //   suspension3rd: "",
    //   numberClaims3: "",
    //   firstOccurrence3: "",
    //   reasonClaims3: "",
    //   accidentClaim: "",
    //   firstOccurrence4: "",
    //   ownVehicle: "",
    //   ownsAnotherVehicle: "",
    // },
  ]);

  const [tab7_claims, setTab7] = useStateWithCallbackLazy([]);

  const [tab7_validation, setTab7_validation] = useState([
    {
      typeClaim: "",
      dateClaim: "",
      description: "",
      claimOutcome: "",
      amount: "",
    },
  ]);

  // submit all forms
  const updateAllForm = () => {
    return updateAllForms(
      tab1_client,
      tab2_importantQuestions,
      tab3_policyCore,
      tab4_vehicle,
      tab5_modifications,
      tab6_drivers,
      tab7_claims,
      quotationId
    )
      .then((res) => {
        console.log(res.status);
        if (res.status === 201) {
          console.log("No Error");
          return true;
        } else {
          console.log("Error");
          return false;
        }
      })
      .catch((err) => {
        console.log(err);
        return false;
      });
  }; // end of submit function

  // validate all forms
  const isAllFormsValid = () => {
    const isValid = validateAllForms(
      tab1_client,
      tab3_policyCore,
      tab4_vehicle,
      tab5_modifications,
      tab6_drivers,
      tab7_claims
    );
    return isValid;
  };

  // props: tab1, creating props to provide to every tab components
  const props1 = {
    tab1_client,
    setTab1,
    tab1_validation,
    setTab1_validation,
    navigation,
  };
  const props2 = {
    tab2_importantQuestions,
    setTab2,
    tab2_validation,
    setTab2_validation,
    navigation,
  };

  const props3 = {
    tab3_policyCore,
    setTab3,
    tab3_validation,
    setTab3_validation,
    navigation,
  };

  const props4 = {
    tab4_vehicle,
    setTab4,
    tab4_validation,
    setTab4_validation,
    navigation,
  };

  const props5 = {
    tab5_modifications,
    setTab5,
    tab5_validation,
    setTab5_validation,
    navigation,
  };
// console.log("props5: ",props5);
  const props6 = {
    tab6_drivers,
    setTab6,
    tab6_validation,
    setTab6_validation,
    tab7_claims,
    setTab7,
    tab7_validation,
    setTab7_validation,
    navigation,
  };

  const props7 = {
    tab6_drivers,
    tab7_claims,
    setTab7,
    tab7_validation,
    setTab7_validation,
    isAllFormsValid,
    updateAllForm,
    navigation,
  };

  // return function to display all tabs
  const displayTabs = () => {
    switch (step.id) {
      default:
        return <Tab1_Client {...props1} />;
      case "tab1_client":
        return <Tab1_Client {...props1} />;
      case "tab2_importantQuestions":
        return <Tab2_ImportantQuestions {...props2} />;
      case "tab3_policyCore":
        return <Tab3_PolicyCore {...props3} />;
      case "tab4_vehicle":
        return <Tab4_vehicle {...props4} />;
      case "tab5_modifications":
        return <Tab5_Modifications {...props5} />;
      case "tab6_drivers":
        return <Tab6_drivers {...props6} />;
      case "tab7_claims":
        return <Tab7_Claims {...props7} />;
    }
  };

  // set props to navigation bar
  const propsNavBar = {
    step,
    navigation,
    tab1_client,
    tab2_importantQuestions,
    tab3_policyCore,
    tab4_vehicle,
    tab5_modifications,
    tab6_drivers,
    tab7_claims,
  };

  // render return
  return (
    // <div className="container-fluid">
    <div>
      {navigationBarEdit(propsNavBar)}
      {displayTabs()}
      <ToastContainer
        style={{ marginLeft: "50px", marginBottom: "-25px", width: "30%" }}
      />
    </div>
  );
};

export default EditLink;
