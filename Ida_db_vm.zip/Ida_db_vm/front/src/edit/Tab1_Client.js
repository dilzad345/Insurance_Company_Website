import React from "react";
import {
  TextField,
  Container,
  Button,
  Select,
  InputLabel,
  MenuItem,
  Grid,
} from "@material-ui/core";
import { Autocomplete } from '@mui/material';
import { makeStyles } from "@material-ui/core/styles";
import { streetTypes } from "../constants/dropDownData"
import {
  ClientIdFromUipath_validate,
  clientType_validate,
  title_validate,
  firstName_validate,
  lastName_validate,
  companyName_validate,
  // tradingAs_validate,
  streetNumber_validate,
  streetName_validate,
  streetType_validate,
  suburb_validate,
  state_validate,
  postCode_validate,
  phone_validate,
  email_validate,
  branch_validate,
  salesTeam_validate,
  serviceTeam_validate,
} from "../validations/tab1_validate";
import { confirmAlert } from "react-confirm-alert";
//import { timePickerDefaultProps } from "@material-ui/pickers/constants/prop-types";
import { inpNum , validationForSpecialchar} from "../constants/validChecker"

import history from "../auth/history";

const returnDashBoard = () => {
  history.push('/user/dashboard_motor');
}
const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    alignContent: "center",
    padding: theme.spacing(2),
    //textAlign: 'center',
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary,
  },

  // bg_color: {
  //   backgroundColor: "#f0f0f5",
  //   marginBottom: "5px",
  // },
}));

const Tab1_Client = ({
  tab1_client,
  setTab1,
  tab1_validation,
  setTab1_validation,
  navigation,
}) => {
  const classes = useStyles();

  // onClick method: exit when clicking exit btn
const exit = () => {
  // console.log(ind);
  // const temp = [...tab5_modifications];
  // const tempValidate = [...tab5_validation];

  confirmAlert({
    title: "Confirm to exit",
    message: "Are you going to exit without saving any data to the database?",
    buttons: [
      {
        label: "Yes",
        onClick: () => {
          returnDashBoard();
        },
      },
      {
        label: "No",
        onClick: () => null,
      },
    ],
  });
};

  const onChangeField = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    setTab1(
      {
        ...tab1_client,
        [name]: value,
      },
      () => {
        console.log("kkk")
        validationAfterChange(name, value);
      }
    );
  };

  const setStreetType = (val) => {
    // console.log("val", val);
    // console.log(i);
    // console.log(streetType[0]);
    //  let name = e.target.name;
    if (val) {
      let name = "streetType";
      let value = val.group;
      setTab1(
        {
          ...tab1_client,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    } else {
      let name = "streetType";
      let value = " ";
      setTab1(
        {
          ...tab1_client,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    }
  }
  // call validation
  const validationAfterChange = (name, value) => {
    if (name === "clientType") {
      if (tab1_client.clientType === "Company") {
        // tab1_client.title = "";
        tab1_client.firstName = "";
        tab1_client.lastName = "";
      } else if (tab1_client.clientType === "Individual") {
        tab1_client.companyName = "";
        tab1_client.tradingAs = "";
      }
    }
    // console.log("Name:" + name);
    // console.log("Value:" + value);
    switch (name) {
      case "ClientIdFromUipath": {
        ClientIdFromUipath_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "clientType": {
        clientType_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "title": {
        title_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "firstName": {
        firstName_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "lastName": {
        lastName_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "companyName": {
        companyName_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      // case "tradingAs": {
      //   tradingAs_validate(value, tab1_validation, setTab1_validation);
      //   break;
      // }

      case "streetNumber": {
        streetNumber_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "streetName": {
        streetName_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "streetType": {
        // console.log(value);
        streetType_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "suburb": {
        suburb_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "state": {
        state_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "postCode": {
        postCode_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "phone": {
        phone_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "email": {
        email_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "branch": {
        branch_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "salesTeam": {
        salesTeam_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      case "serviceTeam": {
        serviceTeam_validate(value, tab1_validation, setTab1_validation);
        break;
      }
      default: {
        console.log("Not match to condition");
      }
    }
  };

  return (
    <Container maxWidth="md">
      <div className={classes.root}>
        <Grid
          container
          spacing={3}
          direction="row"
          justifyContent="center"
          alignItems="center"
        >
          <Grid
            item
            xs={12}
            textalign="center"
            justifyContent="center"
            container
          >
            <h3>GENERAL INFORMATION</h3>
          </Grid>



          {/* Client Code */}
          <Grid item xs={5} className={classes.bg_color}>
            <InputLabel
              htmlFor="Unit Number (not req for PO Box)"
              style={{ marginBottom: "5px" }} required>
              Client ID
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              error ={tab1_validation.ClientIdFromUipath !== "true"
              ? true
              : false}
              name="ClientIdFromUipath"
              value={tab1_client.ClientIdFromUipath}
              onChange={onChangeField}
              size="small"
              type="number"
              variant="outlined"
              autoComplete="off"
              fullWidth />
            {tab1_validation.ClientIdFromUipath !== null &&
              tab1_validation.ClientIdFromUipath !== "true" && (
                <div className="text-danger font-italic">
                  {tab1_validation.ClientIdFromUipath}
                </div>
              )}
          </Grid>



          {/* Clint Type */}
          <Grid item xs={5} className={classes.bg_color}>
            <InputLabel htmlFor="Client Type" style={{ marginBottom: "5px" }} required>
              Client Type
            </InputLabel>
          </Grid>

          <Grid item xs={7} className={classes.bg_color}>
            <Select
              name="clientType"
              margin="none"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange("clientType", tab1_client.clientType)
              }
              value={tab1_client.clientType}
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Individual">Individual</MenuItem>
              <MenuItem value="Company">Company</MenuItem>
            </Select>
            {tab1_validation.clientType !== null &&
              tab1_validation.clientType !== "true" && (
                <div className="text-danger font-italic">
                  {tab1_validation.clientType}
                </div>
              )}
          </Grid>
          {/* <div style={{ borderTop: "1px solid #000099 ", marginLeft: 20, marginRight: 20, width: '90%' }}></div> */}

          {tab1_client.clientType === "Individual" && (
            <Grid item container xs={12} direction="row" spacing={2}>
              <Grid item xs={5} className={classes.bg_color}>
                <InputLabel
                  htmlFor="Client Title"
                  style={{ marginBottom: "5px" }}
                  
                >
                  Client Title
                </InputLabel>
              </Grid>
              <Grid item xs={7} className={classes.bg_color}>
                <Select
                  margin="none"
                  name="title"
                  variant="outlined"
                  size="small"
                  autoComplete="off"
                  onChange={onChangeField}
                  // onClose={() =>
                  //   validationAfterChange("title", tab1_client.title)
                  // }
                  value={tab1_client.title}
                  style={{ height: "40px" }}
                  fullWidth
                >
                  <MenuItem disabled value=" ">
                    Select
                  </MenuItem>
                  <MenuItem value="Mr">Mr</MenuItem>
                  <MenuItem value="Miss">Miss</MenuItem>
                  <MenuItem value="Mrs">Mrs</MenuItem>
                  <MenuItem value="Ms">Ms</MenuItem>
                  <MenuItem value="Dr">Dr</MenuItem>
                </Select>
                {/* {tab1_validation.title !== null &&
                  tab1_validation.title !== "true" && (
                    <div className="text-danger font-italic">
                      {tab1_validation.title}
                    </div>
                  )} */}
              </Grid>

              <Grid item xs={5} className={classes.bg_color}>
                {/* First Name */}
                <InputLabel
                  htmlFor="First Name"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  First Name
                </InputLabel>
              </Grid>
              <Grid item xs={7}>
                <TextField
                  name="firstName"
                  size="small"
                  value={tab1_client.firstName}
                  onChange={onChangeField}
                  variant="outlined"
                  autoComplete="off"
                  fullWidth
                />
                {tab1_validation.firstName !== null &&
                  tab1_validation.firstName !== "true" && (
                    <div className="text-danger font-italic">
                      {tab1_validation.firstName}
                    </div>
                  )}
              </Grid>

              {/* Last Name */}
              <Grid item xs={5} className={classes.bg_color}>
                <InputLabel htmlFor="Last Name" style={{ marginBottom: "5px" }} required>
                  Last Name
                </InputLabel>
              </Grid>
              <Grid item xs={7}>
                <TextField
                  name="lastName"
                  value={tab1_client.lastName}
                  onChange={onChangeField}
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  fullWidth
                />
                {tab1_validation.lastName !== null &&
                  tab1_validation.lastName !== "true" && (
                    <div className="text-danger font-italic">
                      {tab1_validation.lastName}
                    </div>
                  )}
              </Grid>
            </Grid>
          )}

          {tab1_client.clientType === "Company" && (
            <Grid item container xs={12} direction="row" spacing={2}>
              {/* Company Name */}
              <Grid item xs={5} className={classes.bg_color}>
                <InputLabel
                  htmlFor="Company Name"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Company Name
                </InputLabel>
              </Grid>

              <Grid item xs={7}>
                <TextField
                  name="companyName"
                  value={tab1_client.companyName}
                  onChange={onChangeField}
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  fullWidth
                />
                {tab1_validation.companyName !== null &&
                  tab1_validation.companyName !== "true" && (
                    <div className="text-danger font-italic">
                      {tab1_validation.companyName}
                    </div>
                  )}
              </Grid>

              {/* Trading As */}
              <Grid item xs={5} className={classes.bg_color}>
                <InputLabel
                  htmlFor="Trading As"
                  style={{ marginBottom: "5px" }}
                >
                  Trading As
                </InputLabel>
              </Grid>
              <Grid item xs={7}>
                <TextField
                  name="tradingAs"
                  value={tab1_client.tradingAs}
                  onChange={onChangeField}
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  fullWidth
                />
                {tab1_validation.tradingAs !== null &&
                  tab1_validation.tradingAs !== "true" && (
                    <div className="text-danger font-italic">
                      {tab1_validation.tradingAs}
                    </div>
                  )}
              </Grid>
            </Grid>
          )}

          {/* office tect reference code */}
          <Grid item xs={5} className={classes.bg_color}>
            <InputLabel
              htmlFor="OfficeTech Reference Code (IBA ONLY)"
              style={{ marginBottom: "5px" }}
            >
              OfficeTech Reference Code (IBA ONLY)
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              name="officeTechReferenceCode"
              value={tab1_client.officeTechReferenceCode}
              onChange={onChangeField}
              size="small"
              variant="outlined"
              autoComplete="off"
              fullWidth
            />
          </Grid>

          {/* Unit Number */}
          <Grid item xs={5} className={classes.bg_color}>
            <InputLabel
              htmlFor="Unit Number (not req for PO Box)"
              style={{ marginBottom: "5px" }}
            >
              Unit Number (not req for PO Box)
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              name="unitNumber"
              value={tab1_client.unitNumber}
              onChange={onChangeField}
              size="small"
              // type="number"
              variant="outlined"
              autoComplete="off"
              onKeyPress={(e) => validationForSpecialchar(e)}
              fullWidth
            />
          </Grid>

          {/* Street Number */}
          <Grid item xs={5} className={classes.bg_color}>
            <InputLabel
              htmlFor="Street Number (not req for PO Box)"
              style={{ marginBottom: "5px" }}
              required
            >
              Street Number (not req for PO Box)
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              name="streetNumber"
              value={tab1_client.streetNumber}
              onChange={onChangeField}
              size="small"
              // type="number"
              variant="outlined"
              autoComplete="off"
              fullWidth
              onKeyPress={(e) => validationForSpecialchar(e)}
            />
            {tab1_validation.streetNumber !== null &&
              tab1_validation.streetNumber !== "true" && (
                <div className="text-danger font-italic">
                  {tab1_validation.streetNumber}
                </div>
              )}
          </Grid>
         

          {/* Street Name */}
          <Grid item xs={5} className={classes.bg_color}>
            <InputLabel htmlFor="Street Name" style={{ marginBottom: "5px" }} required>
              Street Name(or PO Box)
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              name="streetName"
              value={tab1_client.streetName}
              onChange={onChangeField}
              size="small"
              variant="outlined"
              autoComplete="off"
              fullWidth
            />
            {tab1_validation.streetName !== null &&
              tab1_validation.streetName !== "true" && (
                <div className="text-danger font-italic">
                  {tab1_validation.streetName}
                </div>
              )}
          </Grid>

 {/* Street Type */}
 <Grid item xs={5} className={classes.bg_color}>
            <InputLabel
              htmlFor="Street Type (not req for PO Box)"
              style={{ marginBottom: "5px" }}
              required
            >
              Street Type (not req for PO Box)
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            {/* <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={tab1_client.streetType}
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange("streetType", tab1_validation.streetType)
              }
              name="streetType"
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="street">Street</MenuItem>
              <MenuItem value="Road">Road</MenuItem>
              <MenuItem value="Avenue">Avenue</MenuItem>
              <MenuItem value="Close">Close</MenuItem>
              <MenuItem value="Court">Court</MenuItem>
              <MenuItem value="Circuit">Circuit</MenuItem>
              <MenuItem value="Teerace">Teerace</MenuItem>
              <MenuItem value="drive">Drive</MenuItem>
              <MenuItem value="Lane">Lane</MenuItem>
              <MenuItem value="Parade">Parade</MenuItem>
              <MenuItem value="Quay">Quay</MenuItem>
              <MenuItem value="Way">Way</MenuItem>
            </Select> */}
            <Autocomplete
              //  disablePortal
              // value={tab1_client.streetType}
              // getOptionSelected={(option, value) => option.value === value.value}
              // isOptionEqualToValue={(option, value) => option.id === value.id}
              options={streetTypes}
              sx={{ width: 1 }}
              isOptionEqualToValue={(option, value) => option.id === value.id}
              getOptionLabel={(option) =>
                (option.group ? option.group : tab1_client.streetType)}
             
                defaultValue={"Please Select"}
              name="streetType"
              onChange={(event, value) => setStreetType(value)}
              renderInput={(params) =>
                <TextField {...params}
                  variant="outlined"
                  fullWidth
                  value={tab1_client.streetType}
                  label="Search / Select"
                // required
                // value={tab1_client.streetType !== null ? tab1_client.streetType :"null"}
                />
              }

            />
            {tab1_validation.streetType !== null &&
              tab1_validation.streetType !== "true" && (
                <div className="text-danger font-italic">
                  {tab1_validation.streetType}
                </div>
              )}
          </Grid>

          {/* Suburb */}
          <Grid item xs={5} className={classes.bg_color}>
            <InputLabel htmlFor="Suburb" style={{ marginBottom: "5px" }} required>
              Suburb
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              name="suburb"
              value={tab1_client.suburb}
              onChange={onChangeField}
              size="small"
              variant="outlined"
              autoComplete="off"
              fullWidth
            />
            {tab1_validation.suburb !== null &&
              tab1_validation.suburb !== "true" && (
                <div className="text-danger font-italic">
                  {tab1_validation.suburb}
                </div>
              )}
          </Grid>

          {/* State */}
          <Grid item xs={5} className={classes.bg_color}>
            <InputLabel htmlFor="State" style={{ marginBottom: "5px" }} required>
              State
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <Select
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={tab1_client.state}
              name="state"
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange("state", tab1_validation.state)
              }
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="QLD">QLD</MenuItem>
              <MenuItem value="NSW">NSW</MenuItem>
              <MenuItem value="VIC">VIC</MenuItem>
              <MenuItem value="SA">SA</MenuItem>
              <MenuItem value="WA">WA</MenuItem>
              <MenuItem value="ACT">ACT</MenuItem>
              <MenuItem value="TAS">TAS</MenuItem>
              <MenuItem value="NT">NT</MenuItem>
            </Select>
            {tab1_validation.state !== null &&
              tab1_validation.state !== "true" && (
                <div className="text-danger font-italic">
                  {tab1_validation.state}
                </div>
              )}
          </Grid>

          {/* Post Code */}
          <Grid item xs={5} className={classes.bg_color}>
            <InputLabel htmlFor="Post Code" style={{ marginBottom: "5px" }} required>
              Post Code
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              name="postCode"
              value={tab1_client.postCode}
              onChange={onChangeField}
              size="small"
              variant="outlined"
              type="number"
              onKeyPress={(e) => inpNum(e)}
              // onKeyDown={(evt) => (evt.key === 'e' || evt.key === 'E' || evt.key === '+' || evt.key === '-' || evt.key === '.')
              //   && evt.preventDefault()}
              autoComplete="off"
              fullWidth
            />
            {tab1_validation.postCode !== null &&
              tab1_validation.postCode !== "true" && (
                <div className="text-danger font-italic">
                  {tab1_validation.postCode}
                </div>
              )}
          </Grid>

          {/* Phone */}
          <Grid item xs={5} className={classes.bg_color}>
            <InputLabel htmlFor="Phone" style={{ marginBottom: "5px" }} required>
              Phone
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              name="phone"
              value={tab1_client.phone}
              onChange={onChangeField}
              size="small"
              variant="outlined"
              type="number"
              autoComplete="off"
              fullWidth
              onKeyPress={(e) => inpNum(e)}
            // onKeyDown={(evt) => (evt.key === 'e' || evt.key === 'E' || evt.key === '+' ||
            //   evt.key === '-' || evt.key === '.') && evt.preventDefault()}

            />
            {tab1_validation.phone !== null &&
              tab1_validation.phone !== "true" && (
                <div className="text-danger font-italic">
                  {tab1_validation.phone}
                </div>
              )}
          </Grid>

          {/* E-mail */}
          <Grid item xs={5} className={classes.bg_color}>
            <InputLabel htmlFor="E-mail" style={{ marginBottom: "5px" }} required>
              E-mail
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              name="email"
              value={tab1_client.email}
              onChange={onChangeField}
              size="small"
              variant="outlined"
              autoComplete="off"
              fullWidth
            />
            {tab1_validation.email !== null &&
              tab1_validation.email !== "true" && (
                <div className="text-danger font-italic">
                  {tab1_validation.email}
                </div>
              )}
          </Grid>

          {/* Branch */}
          <Grid item xs={5} className={classes.bg_color}>
            <InputLabel htmlFor="Branch" style={{ marginBottom: "5px" }} required>
              Branch
            </InputLabel>
          </Grid>
         
          <Grid item xs={7}>
            <Select
              error ={tab1_validation.branch !== "true" ? true : false}
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="branch"
              value={tab1_client.branch}
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange("branch", tab1_client.branch)
              }
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Insurance Brokers Australia">Insurance Brokers Australia</MenuItem>
              <MenuItem value="Hayward Insurance Solutions Pty Ltd">Hayward Insurance Solutions Pty Ltd</MenuItem>
            </Select>
            {tab1_validation.branch !== null &&
              tab1_validation.branch !== "true" && (
                <div className="text-danger font-italic">
                  {tab1_validation.branch}
                </div>
              )}
          </Grid>

          {/* Sales Team */}
          <Grid item xs={5} className={classes.bg_color}>
            <InputLabel htmlFor="Sales Team" style={{ marginBottom: "5px" }} required>
              Sales Team
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <Select
              error ={tab1_validation.salesTeam !== "true" ? true : false}
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="salesTeam"
              value={tab1_client.salesTeam}
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange("salesTeam", tab1_validation.salesTeam)
              }
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Chris Dalton">Chris Dalton</MenuItem>
              <MenuItem value="Gary Hayward">Gary Hayward</MenuItem>
              <MenuItem value="Mark Hayward">Mark Hayward</MenuItem>
              <MenuItem value="GC(Billy)">GC(Billy)</MenuItem>
              <MenuItem value="GC Team">GC Team</MenuItem>
              <MenuItem value="Billy Noke">Billy Noke</MenuItem>
              <MenuItem value="Gerold-Grafton<">Gerold-Grafton</MenuItem>
              <MenuItem value="Gerold-Warwick">Gerold-Warwick</MenuItem>
            </Select>
            {tab1_validation.salesTeam !== null &&
              tab1_validation.salesTeam !== "true" && (
                <div className="text-danger font-italic">
                  {tab1_validation.salesTeam}
                </div>
              )}
          </Grid>

          {/* Service Team */}
          <Grid item xs={5} className={classes.bg_color}>
            <InputLabel htmlFor="Service Team" style={{ marginBottom: "5px" }} required>
              Service Team
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <Select
              error ={tab1_validation.serviceTeam !== "true" ? true : false}
              margin="none"
              variant="outlined"
              autoComplete="off"
              name="serviceTeam"
              value={tab1_client.serviceTeam}
              onChange={onChangeField}
              onClose={() =>
                validationAfterChange(
                  "serviceTeam",
                  tab1_validation.serviceTeam
                )
              }
              style={{ height: "40px" }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Brisbane">Brisbane</MenuItem>
              <MenuItem value="Luanne">Luanne</MenuItem>
              <MenuItem value="Michella">Michella</MenuItem>
              <MenuItem value="Patricia">Patricia</MenuItem>
              <MenuItem value="Taryn">Taryn</MenuItem>
            </Select>
            {tab1_validation.serviceTeam !== null &&
              tab1_validation.serviceTeam !== "true" && (
                <div className="text-danger font-italic">
                  {tab1_validation.serviceTeam}
                </div>
              )}
          </Grid>

          {/* navigation buttons */}
          <Grid container>
            <Grid item xs={6}>
              <Button
                variant="contained"
                color="secondary"
                style={{
                  marginTop: "1rem",
                  float: "left",
                  width: "10%",
                }}
                onClick={() => exit()}
              >
                EXIT
              </Button>
            </Grid>

            <Grid item xs={6}>
              <Button
                variant="contained"
                color="primary"
                style={{
                  marginTop: "1rem",
                  float: "right",
                  marginBottom: "50px",
                }}
                onClick={() => navigation.next()}
              >
                NEXT
              </Button>
            </Grid>
          </Grid>
        </Grid>
      </div>
    </Container>
  );
};

export default Tab1_Client;
