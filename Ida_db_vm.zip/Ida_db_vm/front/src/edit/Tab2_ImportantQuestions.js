import React from "react";
import {
  TextField,
  Container,
  Button,
  Select,
  InputLabel,
  MenuItem,
  Grid,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import { confirmAlert } from "react-confirm-alert";
import {
  reasonBankrupt_validate,
  reasonCriminalOffence_validate,
} from "../validations/tab2_validate";
import history from "../auth/history";

const returnDashBoard = () => {
  history.push('/user/dashboard_motor');
}
const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    alignContent: "center",
    padding: theme.spacing(2),
    //textAlign: 'center',
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary,
  },

  bg_color: {
    backgroundColor: "#f2f2f2",
    marginBottom: "5px",
  },
}));

const Tab2_ImportantQuestions = ({
  tab2_importantQuestions,
  setTab2,
  tab2_validation,
  setTab2_validation,
  navigation,
}) => {
  const classes = useStyles();

  // console.log(tab2_importantQuestions);

  // const onChangeField = (e) => {
  //   let target = e.target;
  //   setTab2({
  //     ...tab2_importantQuestions,
  //     [target.name]: target.value,
  //   });
  // };
// onClick method: exit when clicking exit btn
const exit = () => {
  // console.log(ind);
  // const temp = [...tab5_modifications];
  // const tempValidate = [...tab5_validation];

  confirmAlert({
    title: "Confirm to exit",
    message: "Are you going to exit without saving any data to the database ?",
    buttons: [
      {
        label: "Yes",
        onClick: () => {
          // removing the element using splice
          // temp.splice(ind, 1);
          // tempValidate.splice(ind, 1);

          // tab5_modifications = temp;
          // tab5_validation = tempValidate;

          // // updating the list
          // setTab5(temp);
          // setTab5_validation(tempValidate);

          returnDashBoard();
        },
      },
      {
        label: "No",
        onClick: () => null,
      },
    ],
  });
};

  const onChangeField = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    setTab2(
      {
        ...tab2_importantQuestions,
        [name]: value,
      },
      () => {
        validationAfterChange(name, value);
      }
    );
  };

  // call validation function
  const validationAfterChange = (name, value) => {
    if (name === "declaredBankrupt") {
      if (value === "No") {
        setTab2({
          ...tab2_importantQuestions,
          declaredBankrupt: "No",
          reasonBankrupt: "",
        });
      }
    }

    if (name === "criminalOffence") {
      if (value === "No") {
        setTab2({
          ...tab2_importantQuestions,
          criminalOffence: "No",
          reasonCriminalOffence: "",
        });
      }
    }

    if (name === "existingDamage") {
      if (value === "No") {
        setTab2({
          ...tab2_importantQuestions,
          existingDamage: "No",
          wouldAnswerYes: "",
        });
      }
    }
    if (name === "hadClaimDeclained") {
      if (value === "No") {
        setTab2({
          ...tab2_importantQuestions,
          hadClaimDeclained: "No",
          reasonClaimDecalined: "",
        });
      }
    }

    switch (name) {
      case "reasonBankrupt": {
        reasonBankrupt_validate(value, tab2_validation, setTab2_validation);
        break;
      }

      case "reasonCriminalOffence": {
        reasonCriminalOffence_validate(
          value,
          tab2_validation,
          setTab2_validation
        );
        break;
      }
      default: {
        console.log("Not match to condition");
      }
    }
  };

  //const { tab1_client, lastName, age } = formData;

  return (
    <Container maxWidth="md">
      <div className={classes.root}>
        <Grid
          container
          spacing={3}
          direction="row"
          justifyContent="center"
          alignItems="center"
        >
          <Grid xs={12} item={true} justifyContent="center" container>
            <h3>IMPORTANT QUESTIONS</h3>
          </Grid>

          {/* Insurence Policy */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Insurence Policy"
              style={{ marginBottom: "5px" }}
              required
            >
              Any insurance policy declined or cancelled by the insurer in the
              last 12 month
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="insurancePolicyCancelledLast_12_months"
              margin="none"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              value={
                tab2_importantQuestions.insurancePolicyCancelledLast_12_months
              }
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Last 12 months">Last 12 months</MenuItem>
              <MenuItem value="Last 24 months">Last 24 months</MenuItem>
              <MenuItem value="Last 5 years">Last 5 years</MenuItem>
            </Select>
          </Grid>

          {/* Any insurance policy declined or cancelled by the insurer in the last 5 years */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Any insurance policy declined or cancelled by the insurer in the last 5 years"
              style={{ marginBottom: "5px" }}
              required
            >
              Any insurance policy declined or cancelled by the insurer in the
              last 5 years
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="insurancePolicyCancelledLast_5_years"
              margin="none"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              value={
                tab2_importantQuestions.insurancePolicyCancelledLast_5_years
              }
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Last 12 months">Last 12 months</MenuItem>
              <MenuItem value="Last 24 months">Last 24 months</MenuItem>
              <MenuItem value="Last 5 years">Last 5 years</MenuItem>
            </Select>
          </Grid>

          {/* Had a claim declined */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Had a claim declined"
              style={{ marginBottom: "5px" }}
              required
            >
              Had a claim declined
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="hadClaimDeclained"
              margin="none"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              value={tab2_importantQuestions.hadClaimDeclained}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Last 1 year">Last 1 year</MenuItem>
              <MenuItem value="Last 2 years">Last 2 years</MenuItem>
              <MenuItem value="Last 3 years">Last 3 years</MenuItem>
              <MenuItem value="Last 4 years">Last 4 years</MenuItem>
              <MenuItem value="Last 5 years">Last 5 years</MenuItem>
            </Select>
          </Grid>

          {tab2_importantQuestions.hadClaimDeclained !== "No" && (
            <Grid item container xs={12} direction="row" spacing={2}>
              {/* Reason for decline */}
              <Grid item xs={6} className={classes.bg_color}>
                <InputLabel
                  htmlFor="Reason for decline"
                  style={{ marginBottom: "5px" }}
                >
                  Reason for decline
                </InputLabel>
              </Grid>
              <Grid item xs={6}>
                <TextField
                  name="reasonClaimDecalined"
                  onChange={onChangeField}
                  size="small"
                  variant="outlined"
                  style={{ marginBottom: "20px" }}
                  autoComplete="off"
                  value={tab2_importantQuestions.reasonClaimDecalined}
                  fullWidth
                />
              </Grid>
            </Grid>
          )}

          {/* Had any criminal conviction relating to fraud, theft, dishonesty, arson, or malicious damage (excluding any convictions that are not legally required to be disclosed)? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Had any criminal conviction relating to fraud, theft, dishonesty, arson, or malicious damage (excluding any convictions that are not legally required to be disclosed)?"
              style={{ marginBottom: "5px" }}
              required
            >
              Had any criminal conviction relating to fraud, theft, dishonesty,
              arson, or malicious damage (excluding any convictions that are not
              legally required to be disclosed)?
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="maliciousDamage"
              margin="none"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              value={tab2_importantQuestions.maliciousDamage}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Last 1 year">Last 1 year</MenuItem>
              <MenuItem value="Last 2 years">Last 2 years</MenuItem>
              <MenuItem value="Last 3 years">Last 3 years</MenuItem>
              <MenuItem value="Last 4 years">Last 4 years</MenuItem>
              <MenuItem value="Last 5 years">Last 5 years</MenuItem>
            </Select>
          </Grid>

          {/* Existing damage to the vehicle */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Existing damage to the vehicle"
              style={{ marginBottom: "5px" }}
              required
            >
              Existing damage to the vehicle
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="existingDamage"
              margin="none"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              value={tab2_importantQuestions.existingDamage}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Last 1 year">Last 1 year</MenuItem>
              <MenuItem value="Last 2 years">Last 2 years</MenuItem>
              <MenuItem value="Last 3 years">Last 3 years</MenuItem>
              <MenuItem value="Last 4 years">Last 4 years</MenuItem>
              <MenuItem value="Last 5 years">Last 5 years</MenuItem>
            </Select>
          </Grid>

          {tab2_importantQuestions.existingDamage !== "No" && (
            <Grid item container xs={12} direction="row" spacing={2}>
              {/* Would you answer Yes to any of the following */}
              <Grid item xs={6}>
                <InputLabel
                  htmlFor="Would you answer Yes to any of the following"
                  style={{ marginBottom: "5px" }}
                >
                  Would you answer Yes to any of the following
                </InputLabel>
              </Grid>
              <Grid item xs={6}>
                <TextField
                  name="wouldAnswerYes"
                  onChange={onChangeField}
                  size="small"
                  variant="outlined"
                  style={{ marginBottom: "20px" }}
                  autoComplete="off"
                  value={tab2_importantQuestions.wouldAnswerYes}
                  fullWidth
                />
              </Grid>
            </Grid>
          )}

          {/* been declared bankrupt or insolvent during the past 5 years */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="been declared bankrupt or insolvent during the past 5 years"
              style={{ marginBottom: "5px" }}
              required
            >
              Been declared bankrupt or insolvent during the past 5 years
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="declaredBankrupt"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              value={tab2_importantQuestions.declaredBankrupt}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

          {tab2_importantQuestions.declaredBankrupt === "Yes" && (
            <Grid item container xs={12} direction="row" spacing={2}>
              {/* Reason for been declared bankrupt or insolvent during the past 5 years */}
              <Grid item xs={6}>
                <InputLabel
                  htmlFor="Reason for been declared bankrupt or insolvent during the past 5 years"
                  style={{ marginBottom: "5px" }}
                >
                  Reason for been declared bankrupt or insolvent during the past
                  5 years
                </InputLabel>
              </Grid>
              <Grid item xs={6}>
                <TextField
                  name="reasonBankrupt"
                  onChange={onChangeField}
                  size="small"
                  variant="outlined"
                  style={{ marginBottom: "20px" }}
                  autoComplete="off"
                  value={tab2_importantQuestions.reasonBankrupt}
                  fullWidth
                />
                {/* {tab2_validation.reasonBankrupt !== null &&
                  tab2_validation.reasonBankrupt !== "true" && (
                    <div className="text-danger font-italic">
                      {tab2_validation.reasonBankrupt}
                    </div>
                  )} */}
              </Grid>
            </Grid>
          )}

          {/* been convicted of a criminal offence during the past 5 years */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="been convicted of a criminal offence during the past 5 years"
              style={{ marginBottom: "5px" }}
              required
            >
              Been convicted of a criminal offence during <br/> the past 5 years
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="criminalOffence"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              value={tab2_importantQuestions.criminalOffence}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

          {tab2_importantQuestions.criminalOffence === "Yes" && (
            <Grid item container xs={12} direction="row" spacing={2}>
              {/* Reason for been convicted of a criminal offence during the past 5 years */}
              <Grid item xs={6}>
                <InputLabel
                  htmlFor="Reason for been convicted of a criminal offence during the past 5 years"
                  style={{ marginBottom: "5px" }}
                >
                  Reason for been convicted of a criminal offence during the
                  past 5 years
                </InputLabel>
              </Grid>
              <Grid item xs={6}>
                <TextField
                  name="reasonCriminalOffence"
                  onChange={onChangeField}
                  size="small"
                  variant="outlined"
                  style={{ marginBottom: "20px" }}
                  autoComplete="off"
                  value={tab2_importantQuestions.reasonCriminalOffence}
                  fullWidth
                />
              </Grid>
            </Grid>
          )}
        </Grid>

        <Grid>
            <Button
              variant="contained"
              color="secondary"
              style={{
                marginTop: "1rem",
                float: "left",
                width: "10%",
              }}
              onClick={() => exit()}
            >
              EXIT
            </Button>
          </Grid>

        <Grid>
          <Button
            variant="contained"
            color="primary"
            style={{ marginTop: "1rem", float: "right", width: "10%" }}
            onClick={() => navigation.next()}
          >
            NEXT
          </Button>
        </Grid>

        <Grid>
          <Button
            variant="contained"
            color="primary"
            style={{
              marginTop: "1rem",
              float: "right",
              marginRight: "20px",
              width: "10%",
              marginBottom: "1rem",
            }}
            onClick={() => navigation.previous()}
          >
            PREVIOUS
          </Button>
        </Grid>
      </div>
    </Container>
  );
};

export default Tab2_ImportantQuestions;
