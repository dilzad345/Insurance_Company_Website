export const tab7_validate = (tab7_claims) => {
  let result = true;
  tab7_claims.forEach((element, index) => {
    result = result * (element.typeClaim !== " " && element.typeClaim !== null);
    result = result * (element.dateClaim !== "" && element.dateClaim !== null);
    result = result * (element.firstOccurrence !== "" 
    && element.firstOccurrence !== null 
    && typeof element.firstOccurrence !== "undefined")

    result = result * (element.reasonClaims !== "" 
    && element.reasonClaims !== null
    && typeof element.reasonClaims !== "undefined")
    
    if(element.reasonClaims === "Other"){
      // element.description = "";
      result =
      result * (element.description !== " " && element.description !== "" );
    }
    
    // result =
    //   result * (element.description !== " " && element.description !== "");
    result =
      result * (element.claimOutcome !== " " && element.claimOutcome !== "");
    result = result * (element.amount !== " " && element.amount !== "");
 
  });
  // console.log(result)
  return result;
};

export const typeClaim_validate = (
  index,
  value,
  tab7_validation,
  setTab7_validation
) => {
  if (value === null || value === " ") {
    let tempArr = [...tab7_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      typeClaim: "Type of claim: Must select an option",
    };

    tempArr[index] = tempObj;

    setTab7_validation(tempArr);
  } else {
    let tempArr = [...tab7_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      typeClaim: "true",
    };

    tempArr[index] = tempObj;

    setTab7_validation(tempArr);
  }
};

export const dateClaim_validate = (
  index,
  value,
  tab7_validation,
  setTab7_validation
) => {
  // console.log(value);
  if (value === null || value === " ") {
    let tempArr = [...tab7_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      dateClaim: "Date of claim: Must select an option",
    };

    tempArr[index] = tempObj;

    setTab7_validation(tempArr);
  } else {
    let tempArr = [...tab7_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      dateClaim: "true",
    };

    tempArr[index] = tempObj;

    setTab7_validation(tempArr);
  }
};

export const firstOccurrence_validate = (
  index,
  value,
  tab7_validation,
  setTab7_validation
) =>{
  // console.log(value);
  if (value === null || value === " " || typeof value === "undefined"  ) {
    // console.log("hhhhh");
    let tempArr = [...tab7_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      firstOccurrence: "Years Since First Occurrence: Must select an option",
    };

    tempArr[index] = tempObj;

    setTab7_validation(tempArr);
  } else {
    let tempArr = [...tab7_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      firstOccurrence: "true",
    };

    tempArr[index] = tempObj;

    setTab7_validation(tempArr);
  }

}
export const reasonClaim_validate = (
  index,
  value,
  tab7_validation,
  setTab7_validation
) =>{
  // console.log(value);
  if (value === null || value === " " || typeof value === "undefined") {
    let tempArr = [...tab7_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      reasonClaims: "Reason for claims in the last 3 years: Must select an option",
    };

    tempArr[index] = tempObj;

    setTab7_validation(tempArr);
  } else {
    let tempArr = [...tab7_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      reasonClaims: "true",
    };

    tempArr[index] = tempObj;

    setTab7_validation(tempArr);
  }

}

export const description_validate = (
  index,
  value,
  tab7_validation,
  setTab7_validation
) => {
  if (value === " ") {
    let tempArr = [...tab7_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      description: "Description: Must have a value",
    };

    tempArr[index] = tempObj;

    setTab7_validation(tempArr);
  } else {
    let tempArr = [...tab7_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      description: "true",
    };

    tempArr[index] = tempObj;

    setTab7_validation(tempArr);
  }
};

export const claimOutcome_validate = (
  index,
  value,
  tab7_validation,
  setTab7_validation
) => {
  if (value === null || value === " ") {
    let tempArr = [...tab7_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      claimOutcome: "Claim Outcome: Must select an option",
    };

    tempArr[index] = tempObj;

    setTab7_validation(tempArr);
  } else {
    let tempArr = [...tab7_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      claimOutcome: "true",
    };

    tempArr[index] = tempObj;

    setTab7_validation(tempArr);
  }
};

export const amount_validate = (
  index,
  value,
  tab7_validation,
  setTab7_validation
) => {
  const amount_validate_check = /(?:\.\d{0,1})$/;

  let tempArr = [...tab7_validation];
  let tempObj = tempArr[index];
  if (value === "") {
    tempObj = {
      ...tempObj,
      amount: "Amount : must have a value",
    };

    tempArr[index] = tempObj;

    setTab7_validation(tempArr);
  } else if (value === "0") {
    tempObj = {
      ...tempObj,
      amount: "Amount : Amount cannot be zero.",
    };
    tempArr[index] = tempObj;

    setTab7_validation(tempArr);
  }else if (value < 0) {
    tempObj = {
      ...tempObj,
      amount: "Amount : Amount cannot be negative.",
    };
    tempArr[index] = tempObj;

    setTab7_validation(tempArr);
  } else if (amount_validate_check.test(value)) {
    tempObj = {
      ...tempObj,
      amount: "Amount : Enter valid amount(Eg. $800.00)",
    };
    tempArr[index] = tempObj;

    setTab7_validation(tempArr);
  } else {
    let tempArr = [...tab7_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      amount: "true",
    };

    tempArr[index] = tempObj;

    setTab7_validation(tempArr);
  }
};
