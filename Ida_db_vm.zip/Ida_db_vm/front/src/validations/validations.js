import {tab1_validation, setTab1_validation, tab1_client} from '../client/ClientLink';

export const validations = (tab1_client) => {
    
}

// export const tab1_validate = (fieldName) => {
// }

// export const tab2_validate = () => {

// }

// export const tab3_validate = () => {

// }

// export const tab4_validate = () => {

// }

// export const tab5_validate = () => {

// }

// export const tab6_validate = () => {

// }

// export const tab7_validate = () => {

// }