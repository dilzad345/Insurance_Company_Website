

import {  digit_valid_check } from "../constants/validChecker";
export const tab6_validate = (tab6_drivers) => {
  ///console.log("inside validate 6")
  let result = true;
  //console.log("inside validate 6")
  tab6_drivers.forEach((element, index) => {
    
    if (!element.firstName.replace(/\s/g, '').length) {
      element.firstName = "";
      result =
      result *
      (element.firstName !== " " && element.firstName !== "" );

    }

    if (!element.surName.replace(/\s/g, '').length) {
      element.surName = "";
      result =
      result *
      (element.surName !== " " && element.surName !== "");
    }
    

    result = result * (element.gender !== " " && element.gender !== null);
    
    result =
      result *
      (element.dateBirth !== null &&
        element.dateBirth !== "" &&
        element.dateBirth !== "yyyy-MM-dd");

    // const licenseYr_valid = () => {
    //   if (!digit_valid_check.digit_valid_checker.test((element.driversLicenseObtained))) {
    //     console.log("Hello " + element.driversLicenseObtained);
    //     return true;
    //   }
    // }
    // result =
    //   result *
    //   (element.driversLicenseObtained !== " " &&
    //     element.driversLicenseObtained !== "" && 
    //     !licenseYr_valid() &&  element.driversLicenseObtained.toString().length===4);

    result =
      result * (element.stateIssued !== " " && element.stateIssued !== null);
 
    result =
      result * (element.statusDriver !== " " && element.statusDriver !== null);

    result =
      result * (element.demeritPoints3 !== " " && element.demeritPoints3 !== "" && element.demeritPoints3 !== null);


    result =
      result *
      (element.alcoholOffences !== " " && element.alcoholOffences !== null);

    if (element.alcoholOffences !== "0" && element.alcoholOffences !== " ") {
      result =
        result *
        (element.firstOccurrence1 !== " " && element.firstOccurrence1 !== null);
      result =
        result * (element.reasonFines !== " " && element.reasonFines !== null);
    }

    if (element.licenseSuspensions !== "0") {
      result =
        result *
        (element.firstOccurrence2 !== " " && element.firstOccurrence2 !== null);
    }

    if (element.licenseSuspensions === "1") {
      result =
        result *
        (element.suspension1st !== " " && element.suspension1st !== null);
    } else if (element.licenseSuspensions === "2") {
      result =
        result *
        (element.suspension1st !== " " && element.suspension1st !== null);

      result =
        result *
        (element.suspension2nd !== " " && element.suspension2nd !== null);
    } else if (element.licenseSuspensions === "3") {
      result =
        result *
        (element.suspension1st !== " " && element.suspension1st !== null);

      result =
        result *
        (element.suspension2nd !== " " && element.suspension2nd !== null);

      result =
        result *
        (element.suspension3rd !== " " && element.suspension3rd !== null);
    }

    result =
      result *
      (element.numberClaims3 !== " " && element.numberClaims3 !== null);

    // if (
    //   element.numberClaims3 === "1" ||
    //   element.numberClaims3 === "2" ||
    //   element.numberClaims3 === "3"
    // ) {
    //   // result =
    //   //   result *
    //   //   (element.firstOccurrence3 !== " " && element.firstOccurrence3 !== null);

    //   // result =
    //   //   result *
    //   //   (element.reasonClaims3 !== " " && element.reasonClaims3 !== null);

    //   }

    result =
      result *
      (element.accidentClaim !== " " && element.accidentClaim !== null);

    if (
      element.accidentClaim !== " " &&
      element.accidentClaim !== null &&
      element.accidentClaim !== "0"
    ) {
      result =
        result *
        (element.firstOccurrence4 !== " " && element.firstOccurrence4 !== null);
    }

    result =
      result *
      (element.ownsAnotherVehicle !== " " &&
        element.ownsAnotherVehicle !== null);

    result =
      result * (element.ownVehicle !== " " && element.ownVehicle !== null);
  });

  return result;
}; // end of tab6_validate


// navBar validation for edit page
export const tab6_validateEdit = (tab6_drivers) => {
  let result = true;
  tab6_drivers.forEach((element, index) => {
    if (element.edit !== "DELETED") {
      result = result * (element.firstName !== " " && element.firstName !== "");
      result = result * (element.surName !== " " && element.surName !== "");
      result = result * (element.gender !== " " && element.gender !== null);
      result =
        result * (element.dateBirth !== null && element.dateBirth !== "");

      result =
        result *
        (element.driversLicenseObtained !== " " &&
          element.driversLicenseObtained !== "");

      result =
        result *
        (element.statusDriver !== " " && element.statusDriver !== null);

      result =
        result *
        (element.alcoholOffences !== " " && element.alcoholOffences !== null);

      if (element.alcoholOffences !== "0") {
        result =
          result *
          (element.firstOccurrence1 !== " " &&
            element.firstOccurrence1 !== null);
        result =
          result *
          (element.reasonFines !== " " && element.reasonFines !== null);
      }

      if (element.licenseSuspensions !== "0") {
        result =
          result *
          (element.firstOccurrence2 !== " " &&
            element.firstOccurrence2 !== null);
      }

      if (element.licenseSuspensions === "1") {
        result =
          result *
          (element.suspension1st !== " " && element.suspension1st !== null);
      } else if (element.licenseSuspensions === "2") {
        result =
          result *
          (element.suspension1st !== " " && element.suspension1st !== null);

        result =
          result *
          (element.suspension2nd !== " " && element.suspension2nd !== null);
      } else if (element.licenseSuspensions === "3") {
        result =
          result *
          (element.suspension1st !== " " && element.suspension1st !== null);

        result =
          result *
          (element.suspension2nd !== " " && element.suspension2nd !== null);

        result =
          result *
          (element.suspension3rd !== " " && element.suspension3rd !== null);
      }

      result =
        result *
        (element.numberClaims3 !== " " && element.numberClaims3 !== null);

      // if (
      //   element.numberClaims3 === "1" ||
      //   element.numberClaims3 === "2" ||
      //   element.numberClaims3 === "3"
      // ) {
      //   result =
      //     result *
      //     (element.firstOccurrence3 !== " " &&
      //       element.firstOccurrence3 !== null);

      //   result =
      //     result *
      //     (element.reasonClaims3 !== " " && element.reasonClaims3 !== null);
      // }

      result =
        result *
        (element.accidentClaim !== " " && element.accidentClaim !== null);

      if (
        element.accidentClaim !== " " &&
        element.accidentClaim !== null &&
        element.accidentClaim !== "0"
      ) {
        result =
          result *
          (element.firstOccurrence4 !== " " &&
            element.firstOccurrence4 !== null);
      }

      result =
        result *
        (element.ownsAnotherVehicle !== " " &&
          element.ownsAnotherVehicle !== null);

      result =
        result * (element.ownVehicle !== " " && element.ownVehicle !== null);
    }
  });
  return result;
}; // end of edit navBar validation

export const firstName_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {

  if (value === "") {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      firstName: "First Name : Must have a value",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
  // else if (!char_valid_check.char_valid_checker.test(value)) {
  //   let tempArr = [...tab6_validation];
  //   let tempObj = tempArr[index];

  //   tempObj = {
  //     ...tempObj,
  //     firstName: "Firste Name: Incorrect Type",
  //   };

  //   tempArr[index] = tempObj;

  //   setTab6_validation(tempArr);
  // }
  else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      firstName: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const surName_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  if (value === "") {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      surName: "Last Name : Must have a value",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
  // else if (!char_valid_check.char_valid_checker.test(value)) {
  //   let tempArr = [...tab6_validation];
  //   let tempObj = tempArr[index];

  //   tempObj = {
  //     ...tempObj,
  //     surName: "Incorrect type",
  //   };

  //   tempArr[index] = tempObj;

  //   setTab6_validation(tempArr);
  // }
  else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      surName: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const gender_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  if (value === undefined || value === " ") {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      gender: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      gender: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const dob_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  // console.log("dob:" + value);
  if (value === null || value === " ") {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      dateBirth: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      dateBirth: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const YearAusDrivers_validate = (index, value, tab6_validation, setTab6_validation) => {
  if (value === "") {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      driversLicenseObtained:
        "Year Australian drivers license obtained : Must have digits only",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
  else if (value.length < 4 || value.length > 4) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      driversLicenseObtained:
        "Year Australian drivers license obtained : Must have 4 digits",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
  else if (!digit_valid_check.digit_valid_checker.test(value)) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      driversLicenseObtained:
        "Year Australian drivers license obtained : Please insert correct type",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
  else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      driversLicenseObtained: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const state_validate = (index, value, tab6_validation, setTab6_validation) => {
  if (value === null || value === " " || value === undefined) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      stateIssued: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      stateIssued: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};
export const statusDriver_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  if (value === null || value === " " || value === undefined) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      statusDriver: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      statusDriver: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const demeritPoints3_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  // console.log("value:" + value + ":");
  if (value === null || value === " " || value === undefined) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      demeritPoints3: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      demeritPoints3: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const alcoholOffences_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  // console.log("alcoholOffence:" + value);
  if (value === null || value === " " || value === undefined) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      alcoholOffences: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      alcoholOffences: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const licenseSuspensions_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  // console.log("suspension_validate:" + value);
  if (value === null || value === " " || value === undefined) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      licenseSuspensions: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      licenseSuspensions: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const suspension1st_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  console.log("sus1:" + value);
  if (value === null || value === " " || value === undefined) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      suspension1st: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      suspension1st: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const suspension2nd_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  console.log("sus2:" + value);
  if (value === null || value === " " || value === undefined) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      suspension2nd: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      suspension2nd: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const suspension3rd_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  console.log("sus3:" + value);
  if (value === null || value === " " || value === undefined) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      suspension3rd: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      suspension3rd: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const firstOccurrence2_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  if (value === null || value === " " || value === undefined) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      firstOccurrence2: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      firstOccurrence2: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const numberClaims3_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  if (value === null || value === " " || value === undefined) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      numberClaims3: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      numberClaims3: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const firstOccurrence3_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  if (value === null || value === " " || value === undefined) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      firstOccurrence3: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      firstOccurrence3: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const reasonClaims3_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  if (value === null || value === " " || value === undefined) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      reasonClaims3: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      reasonClaims3: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const accidentClaim_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  if (value === null || value === " " || value === undefined) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      accidentClaim: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      accidentClaim: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const firstOccurrence1_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  console.log("Value:" + value);
  if (value === null || value === "0" || value === undefined) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      firstOccurrence1: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      firstOccurrence1: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const reasonFines_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  if (value === null || value === " " || value === undefined) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      reasonFines: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      reasonFines: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const firstOccurrence4_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  if (value === null || value === " " || value === undefined) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      firstOccurrence4: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      firstOccurrence4: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const ownVehicle_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  // console.log("own:" + value);
  // console.log(typeof value);
  if (value === null || value === " " || value === undefined) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      ownVehicle: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      ownVehicle: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};

export const ownsAnotherVehicle_validate = (
  index,
  value,
  tab6_validation,
  setTab6_validation
) => {
  // console.log("ownAnother :" + value);
  if (value === null || value === " " || value === undefined) {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      ownsAnotherVehicle: "Must select an option",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  } else {
    let tempArr = [...tab6_validation];
    let tempObj = tempArr[index];

    tempObj = {
      ...tempObj,
      ownsAnotherVehicle: "true",
    };

    tempArr[index] = tempObj;

    setTab6_validation(tempArr);
  }
};
