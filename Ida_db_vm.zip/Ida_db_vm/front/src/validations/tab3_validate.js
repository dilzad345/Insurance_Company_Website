import {digit_valid_check} from '../utils/validChecker';
export const tab3_validate = (tab3_policyCore) => {
  let result = true;

  // result =
  //   result *
  //   (tab3_policyCore.holdingBroker !== " " &&
  //     tab3_policyCore.holdingBroker !== null);

  result =
    result *
    (tab3_policyCore.holdingUnderwriter !== " " &&
      tab3_policyCore.holdingUnderwriter !== null);

  result =
    result *
    (tab3_policyCore.stateIssued !== " " &&
      tab3_policyCore.stateIssued !== null);

  result =
      result *
      (tab3_policyCore.registrationNumber !== " " &&
        tab3_policyCore.registrationNumber !== null);
  

  result =
    result *
    (tab3_policyCore.stampDuty !== " " && tab3_policyCore.stampDuty !== null);

  result =
    result *
    (tab3_policyCore.noClaimBonus !== " " &&
      tab3_policyCore.noClaimBonus !== null);

  if (tab3_policyCore.paymentFrequency === "Monthly") {
    result =
      result *
      (tab3_policyCore.preferredInstallments !== "" &&
        tab3_policyCore.preferredInstallments !== " ");
    result =
      result *
      (tab3_policyCore.broker_fee_installments !== "" &&
        tab3_policyCore.broker_fee_installments !== null &&
        tab3_policyCore.broker_fee_installments > 0);
  }

  // result =
  //   result *
  //   (tab3_policyCore.productType !== " " &&
  //     tab3_policyCore.productType !== null);

  result =
    result *
    (tab3_policyCore.coverType !== " " && tab3_policyCore.coverType !== null);

  result =
    result *
    (tab3_policyCore.sumInsured !== " " && tab3_policyCore.sumInsured !== null);

  if (tab3_policyCore.sumInsured === "Agreed Value") {
    result =
      result *
      (tab3_policyCore.agreedValueAmount !== "" &&
        tab3_policyCore.agreedValueAmount !== null &&
        tab3_policyCore.agreedValueAmount > 0);
  }

  result =
    result *
    (tab3_policyCore.policyFromDate !== "" &&
      tab3_policyCore.policyFromDate !== null);

  result =
    result *
    (tab3_policyCore.policyToDate !== "" &&
      tab3_policyCore.policyToDate !== null);

  result =
    result *
    (tab3_policyCore.roadsideAssistance !== " " &&
      tab3_policyCore.roadsideAssistance !== null);

  result =
    result *
    (tab3_policyCore.hireCareInclusion !== " " &&
      tab3_policyCore.hireCareInclusion !== null);

  result =
    result *
    (tab3_policyCore.windscreenExcessWaiver !== " " &&
      tab3_policyCore.windscreenExcessWaiver !== null);

  // result =
  //   result *
  //   (tab3_policyCore.repairsVehicle !== " ");
  // result =
  //   result *
  //   (tab3_policyCore.repairsVehicle !== " " &&
  //     tab3_policyCore.repairsVehicle !== null);

  result =
    result *
    (tab3_policyCore.claimBonusProtection !== " " &&
      tab3_policyCore.claimBonusProtection !== null);

  result =
    result *
    (tab3_policyCore.restrictedDriversDiscount !== " " &&
      tab3_policyCore.restrictedDriversDiscount !== null);

  result =
    result *
    (tab3_policyCore.namedDriver !== " " &&
      tab3_policyCore.namedDriver !== null);

  result =
    result *
    (tab3_policyCore.toolsTrade !== " " 
    && tab3_policyCore.toolsTrade !== null);

  // result =
  //   result *
  //   (tab3_policyCore.restrictedDrivers !== " " );

  result =
    result *
    (tab3_policyCore.interestedParties !== " " &&
      tab3_policyCore.interestedParties !== "Please Select");

  result =
    result *
    (tab3_policyCore.occupationPolicyholder !== " " &&
      tab3_policyCore.occupationPolicyholder !== null);

  result =
    result *
    (tab3_policyCore.commercialPurposesCaravan !== " " &&
      tab3_policyCore.commercialPurposesCaravan !== null);

  result =
    result *
    (tab3_policyCore.excessOption1 !== " " &&
      tab3_policyCore.excessOption1 !== null);

  result =
    result *
    (
      tab3_policyCore.excessOption2 !== null);

  result =
    result *
    ( 
      tab3_policyCore.excessOption3 !== null);

  result =
    result *
    (tab3_policyCore.commercialPurposesCaravan !== "" &&
      tab3_policyCore.commercialPurposesCaravan !== " ");

  result =
    result *
    (tab3_policyCore.brokerFee !== "" );

  return result;
};
export const tab3_validateEdit = (tab3_policyCore) => {
  let result = true;

  result =
    result *
    (tab3_policyCore.holdingBroker !== " " &&
      tab3_policyCore.holdingBroker !== null);

  result =
    result *
    (tab3_policyCore.holdingUnderwriter !== " " &&
      tab3_policyCore.holdingUnderwriter !== null);

  result =
    result *
    (tab3_policyCore.stampDuty !== " " && tab3_policyCore.stampDuty !== null);

  result =
    result *
    (tab3_policyCore.noClaimBonus !== " " &&
      tab3_policyCore.noClaimBonus !== null);

  if (tab3_policyCore.paymentFrequency === "Monthly") {
    result =
      result *
      (tab3_policyCore.preferredInstallments !== "" &&
        tab3_policyCore.preferredInstallments !== " ");
    result =
      result *
      (tab3_policyCore.broker_fee_installments !== "" &&
        tab3_policyCore.broker_fee_installments !== null &&
        tab3_policyCore.broker_fee_installments > 0);
  }

  // result =
  //   result *
  //   (tab3_policyCore.productType !== " " &&
  //     tab3_policyCore.productType !== null);

  result =
    result *
    (tab3_policyCore.coverType !== " " && tab3_policyCore.coverType !== null);

  result =
    result *
    (tab3_policyCore.sumInsured !== " " && tab3_policyCore.sumInsured !== null);

  if (tab3_policyCore.sumInsured === "Agreed Value") {
    result =
      result *
      (tab3_policyCore.agreedValueAmount !== "" &&
        tab3_policyCore.agreedValueAmount !== null &&
        tab3_policyCore.agreedValueAmount > 0);
  }

  result =
    result *
    (tab3_policyCore.policyFromDate !== "" &&
      tab3_policyCore.policyFromDate !== null);

  result =
    result *
    (tab3_policyCore.policyToDate !== "" &&
      tab3_policyCore.policyToDate !== null);

  result =
    result *
    (tab3_policyCore.roadsideAssistance !== " " &&
      tab3_policyCore.roadsideAssistance !== null);

  result =
    result *
    (tab3_policyCore.hireCareInclusion !== " " &&
      tab3_policyCore.hireCareInclusion !== null);

  result =
    result *
    (tab3_policyCore.windscreenExcessWaiver !== " " &&
      tab3_policyCore.windscreenExcessWaiver !== null);

  // result =
  //   result *
  //   (tab3_policyCore.repairsVehicle !== " ");
  // result =
  //   result *
  //   (tab3_policyCore.repairsVehicle !== " " &&
  //     tab3_policyCore.repairsVehicle !== null);

  result =
    result *
    (tab3_policyCore.claimBonusProtection !== " " &&
      tab3_policyCore.claimBonusProtection !== null);

  result =
    result *
    (tab3_policyCore.restrictedDriversDiscount !== " " &&
      tab3_policyCore.restrictedDriversDiscount !== null);

  result =
    result *
    (tab3_policyCore.namedDriver !== " " &&
      tab3_policyCore.namedDriver !== null);

  result =
    result *
    (tab3_policyCore.toolsTrade !== " " 
    && tab3_policyCore.toolsTrade !== null);

  // result =
  //   result *
  //   (tab3_policyCore.restrictedDrivers !== " " );

  result =
    result *
    (tab3_policyCore.interestedParties !== " " &&
      tab3_policyCore.interestedParties !== "Please Select");

  result =
    result *
    (tab3_policyCore.occupationPolicyholder !== " " &&
      tab3_policyCore.occupationPolicyholder !== null);

  result =
    result *
    (tab3_policyCore.commercialPurposesCaravan !== " " &&
      tab3_policyCore.commercialPurposesCaravan !== null);

  result =
    result *
    (tab3_policyCore.excessOption1 !== " " &&
      tab3_policyCore.excessOption1 !== null);

  // result =
  //   result *
  //   (tab3_policyCore.excessOption2 !== " " &&
  //     tab3_policyCore.excessOption2 !== null);

  // result =
  //   result *
  //   ( tab3_policyCore.excessOption3 !== " " &&
  //     tab3_policyCore.excessOption3 !== null);

  result =
    result *
    (tab3_policyCore.commercialPurposesCaravan !== "" &&
      tab3_policyCore.commercialPurposesCaravan !== " ");

  result =
    result *
    (tab3_policyCore.brokerFee !== null &&
      tab3_policyCore.brokerFee !== "" );

  return result;
};

export const holdingBroker_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      holdingBroker: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      holdingBroker: "true",
    });
  }
};

export const holdingUnderwriter_validate = (value,tab3_validation, setTab3_validation) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      holdingUnderwriter: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      holdingUnderwriter: "true",
    });
  }
};

export const stateIssued_validate = (value,tab3_validation, setTab3_validation) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      stateIssued: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      stateIssued: "true",
    });
  }
};
export const stampDuty_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      stampDuty: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      stampDuty: "true",
    });
  }
};

export const noClaimBonus_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      noClaimBonus: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      noClaimBonus: "true",
    });
  }
};

export const paymentFrequency_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      paymentFrequency: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      paymentFrequency: "true",
    });
  }
};

export const preferredInstallments_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  // console.log("prefer:" + value);
  if (value === null || value === "" || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      preferredInstallments: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      preferredInstallments: "true",
    });
  }
};

export const broker_fee_installments_validate = (value,tab3_validation,setTab3_validation) => {
  // const regex = /^([A-Za-z])([A-Za-z\s])+$/;
  //console.log(value);
  if (value === "") {
    setTab3_validation({
      ...tab3_validation,
      broker_fee_installments: "Broker Fee: Must have value",
    });
  } else if (value < 0) {
    setTab3_validation({
      ...tab3_validation,
      broker_fee_installments: "Broker Fee: Amount cannot be negative.",
    });
  } else if (value === "0") {
    setTab3_validation({
      ...tab3_validation,
      broker_fee_installments: "Broker Fee: Amount cannot be zero.",
    });
  } else if (!digit_valid_check.digit_valid_checker.test(value)) {
    setTab3_validation({
      ...tab3_validation,
      broker_fee_installments: "Broker Fee: Enter valid amount(Eg. $800.00)",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      broker_fee_installments: "true",
    });
  }
};
export const brokerFee_validate = (value,tab3_validation,setTab3_validation) => {
  if (value === "") {
    setTab3_validation({
      ...tab3_validation,
      brokerFee: "Broker Fee: Must have value",
    });
  } else if (value === "0") {
    setTab3_validation({
      ...tab3_validation,
      brokerFee: "Broker Fee: Amount cannot be zero.",
    });
  } else if (value < 0) {
    setTab3_validation({
      ...tab3_validation,
      brokerFee: "Broker Fee: Amount cannot be negative.",
    });
  } else if (!digit_valid_check.digit_valid_checker.test(value)) {
    setTab3_validation({
      ...tab3_validation,
      brokerFee: "Broker Fee: Enter valid amount(Eg. $800.00)",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      brokerFee: "true",
    });
  }
};

// export const productType_validate = (
//   value,
//   tab3_validation,
//   setTab3_validation
// ) => {
//   if (value === null || value === " ") {
//     setTab3_validation({
//       ...tab3_validation,
//       productType: "Must select an option",
//     });
//   } else {
//     setTab3_validation({
//       ...tab3_validation,
//       productType: "true",
//     });
//   }
// };

export const coverType_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      coverType: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      coverType: "true",
    });
  }
};

export const sumInsured_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      sumInsured: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      sumInsured: "true",
    });
  }
};

export const agreedValueAmount_validate = (value,tab3_validation, setTab3_validation) => {
  // const regex = /^([A-Za-z])([A-Za-z\s])+$/;
  if (value === "") {
    setTab3_validation({
      ...tab3_validation,
      agreedValueAmount: "Agreed value: Must have only digits",
    });
  } else if (value < 0) {
    setTab3_validation({
      ...tab3_validation,
      agreedValueAmount: "Agreed value: Amount cannot be negative.",
    });
  } else if (value === "0") {
    setTab3_validation({
      ...tab3_validation,
      agreedValueAmount: "Agreed value: Amount cannot be zero.",
    });

} else if (!digit_valid_check.digit_valid_checker.test(value)) {
    setTab3_validation({
      ...tab3_validation,
      agreedValueAmount: "Agreed value: Enter valid amount(Eg. $800.00)",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      agreedValueAmount: "true",
    });
  }
};

export const policyFromDate_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  // const regex = /^([A-Za-z])([A-Za-z\s])+$/;
  // console.log("poly_from_date:" + value);
  if (value === "" || value === null) {
    setTab3_validation({
      ...tab3_validation,
      policyFromDate: "Policy From Date: Must have value",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      policyFromDate: "true",
    });
  }
};

export const policyToDate_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === "" || value === null) {
    setTab3_validation({
      ...tab3_validation,
      policyToDate: "Policy To Date: Must have value",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      policyToDate: "true",
    });
  }
};

export const roadsideAssistance_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      roadsideAssistance: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      roadsideAssistance: "true",
    });
  }
};

export const hireCareInclusion_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      hireCareInclusion: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      hireCareInclusion: "true",
    });
  }
};

export const windscreenExcessWaiver_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      windscreenExcessWaiver: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      windscreenExcessWaiver: "true",
    });
  }
};

export const repairsVehicle_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      repairsVehicle: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      repairsVehicle: "true",
    });
  }
};

export const claimBonusProtection_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      claimBonusProtection: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      claimBonusProtection: "true",
    });
  }
};

export const restrictedDriversDiscount_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      restrictedDriversDiscount: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      restrictedDriversDiscount: "true",
    });
  }
};

export const namedDriver_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      namedDriver: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      namedDriver: "true",
    });
  }
};

export const toolsTrade_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      toolsTrade: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      toolsTrade: "true",
    });
  }
};

export const restrictedDrivers_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      restrictedDrivers: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      restrictedDrivers: "true",
    });
  }
};

export const interestedParties_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  // console.log(value);
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      interestedParties: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      interestedParties: "true",
    });
  }
};

export const occupationPolicyholder_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      occupationPolicyholder: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      occupationPolicyholder: "true",
    });
  }
};

export const commercialPurposesCaravan_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      commercialPurposesCaravan: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      commercialPurposesCaravan: "true",
    });
  }
};

export const excessOption1_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      excessOption1: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      excessOption1: "true",
    });
  }
};

export const excessOption2_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      excessOption2: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      excessOption2: "true",
    });
  }
};

export const excessOption3_validate = (
  value,
  tab3_validation,
  setTab3_validation
) => {
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      excessOption3: "Must select an option",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      excessOption3: "true",
    });
  }
};

export const otherParty_validate =(
  value,
  tab3_validation,
  setTab3_validation
) =>{
  if (value === null || value === " ") {
    setTab3_validation({
      ...tab3_validation,
      excessOption3: "Must have a value",
    });
  } else {
    setTab3_validation({
      ...tab3_validation,
      excessOption3: "true",
    });
  }

}

