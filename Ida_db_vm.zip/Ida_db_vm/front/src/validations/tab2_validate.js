export const tab2_validate = (tab2_importantQuestions) => {
  let result = true;

  
  if (tab2_importantQuestions.declaredBankrupt === "Yes") {
    result = result * (tab2_importantQuestions.reasonBankrupt !== "");
    result = result * (tab2_importantQuestions.reasonBankrupt !== "");
  } 

 
  if (tab2_importantQuestions.criminalOffence === "Yes") {
    result = result * (tab2_importantQuestions.reasonCriminalOffence !== "");
    result = result * (tab2_importantQuestions.reasonCriminalOffence !== "");
  } 
  

  return result;
};




export const reasonBankrupt_validate = (
  value,
  tab2_validation,
  setTab2_validation
) => {
  console.log("value"+value);
  if (value === "") {
    setTab2_validation({
      ...tab2_validation,
      reasonBankrupt: "Reason Bankrupt: must have value",
    });
  } else {
    setTab2_validation({
      ...tab2_validation,
      reasonBankrupt: "true",
    });
  }
};

export const reasonCriminalOffence_validate = (
  value,
  tab2_validation,
  setTab2_validation
) => {
  // const regex = /^([A-Za-z])([A-Za-z\s])+$/;
  if (value === "") {
    setTab2_validation({
      ...tab2_validation,
      reasonCriminalOffence: "Reason Criminal Offence: must have value",
    });
  } else {
    setTab2_validation({
      ...tab2_validation,
      reasonCriminalOffence: "true",
    });
  }
};


