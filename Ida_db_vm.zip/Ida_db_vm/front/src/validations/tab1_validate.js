import { digit_valid_check, char_valid_check, email_valid_check } from "../constants/validChecker";

export const tab1_validate = (tab1_client) => {
  let result = true;

  // result =
  //   result *
  //   (tab1_client.ClientIdFromUipath !== " " && tab1_client.ClientIdFromUipath !== "" &&
  //     tab1_client.ClientIdFromUipath !== null);
  // tab1_client.ClientIdFromUipath !== null && !ClientIdFromUipathValid_check());

  result = 
  result * (tab1_client.clientType !== " " && 
  tab1_client.clientType !== null);

  if (tab1_client.clientType === "Individual") {
    // result = result * (tab1_client.title !== null && tab1_client.title !== " ");
    result =
      result *
      (tab1_client.firstName !== "" &&
        tab1_client.firstName !== null);

    //prevent from typing multiple white spaces
    if (!tab1_client.firstName.replace(/\s/g, '').length) {
      tab1_client.firstName = "";
      result = result * (tab1_client.firstName !== "" &&
        tab1_client.firstName !== null);
    }
    if (!tab1_client.lastName.replace(/\s/g, '').length) {
      tab1_client.lastName = "";
      result = result * (tab1_client.lastName !== "" &&
        tab1_client.lastName !== null);
    }

  }

  else if (tab1_client.clientType === "Company") {

    if (!tab1_client.companyName.replace(/\s/g, '').length) {
      tab1_client.companyName = "";
      result = result *
        (tab1_client.companyName !== "" &&
          tab1_client.companyName !== null);
    }
    if (!tab1_client.tradingAs.replace(/\s/g, '').length) {
      tab1_client.tradingAs = "";
      // result = result *
      //   (tab1_client.tradingAs !== "" &&
      //     tab1_client.tradingAs !== null);
    }
  }

  result =
    result *
    (tab1_client.streetNumber !== " " &&
      tab1_client.streetNumber !== "" && tab1_client.streetNumber !== null);


  //prevent from typing blank empty whitespace with lenth >0
  if (!tab1_client.streetName.replace(/\s/g, '').length) {
    tab1_client.streetName = "";
    result =
      result *
      (tab1_client.streetName !== " " &&
        tab1_client.streetName !== null &&
        tab1_client.streetName !== "");
  }

  result =
    result *
    (tab1_client.streetType !== " " &&
      tab1_client.streetType !== "Please Select");

  if (!tab1_client.suburb.replace(/\s/g, '').length) {
    tab1_client.suburb = "";
    result =
      result * (tab1_client.suburb !== " "
        && tab1_client.suburb !== "" &&
        tab1_client.suburb !== null);
  }


  result = result * (tab1_client.state !== " " && tab1_client.state !== null);

  result =
    result * (tab1_client.postCode !== " " &&
      tab1_client.postCode !== "" && tab1_client.postCode !== null);


  result =
    result *
    (tab1_client.phone !== " " &&
      tab1_client.phone.length >= 10 &&
      tab1_client.phone !== "" &&
      tab1_client.phone !== null)


  const check_email = () => {
    if (!email_valid_check.email_valid_checker.test(tab1_client.email)) {
      //console.log("Hello" + tab1_client.email);
      return true;
    }
  };
  result =
    result *
    (tab1_client.email !== " " &&
      tab1_client.email !== "" && tab1_client.email !== null &&
      !check_email());



  // result = result *
  //   (tab1_client.branch !== " " );

  // if salesteam should be validated put null
  // result =
  //   result * (tab1_client.salesTeam !== " " && tab1_client.salesTeam !== null);
  // result =
  //   result * (tab1_client.salesTeam !== " ");

  // result =
  //   result *
  //   (tab1_client.serviceTeam !== " ");

  return result;
}; // end of tab1_validate function


// method to valide edit page nav bar

export const tab1_validateedit = (tab1_client) => {
  let result = true;
  const ClientIdFromUipathValid_check = () => {
    if (!digit_valid_check.digit_valid_checker.test((tab1_client.ClientIdFromUipath))) {
      // console.log("Hello " + tab1_client.ClientIdFromUipath);
      return true;
    }
  }
  // console.log(tab1_client.ClientIdFromUipath)
  result =
    result *
    (tab1_client.ClientIdFromUipath !== " " && tab1_client.ClientIdFromUipath !== "" &&
      tab1_client.ClientIdFromUipath !== null && !ClientIdFromUipathValid_check()
      && tab1_client.ClientIdFromUipath);

  result = result * (tab1_client.clientType !== " " && tab1_client.clientType !== null);
  if (tab1_client.clientType === "Individual") {
    // result = result * (tab1_client.title !== null && tab1_client.title !== " ");
    result = result * (tab1_client.firstName !== "");
    result = result * (tab1_client.lastName !== "");
  } else if (tab1_client.clientType === "Company") {
    result = result * (tab1_client.companyName !== "");
    // result = result * (tab1_client.tradingAs !== "");
  }

  // const digitValid_check = () => {
  //   if (!digit_valid_check.digit_valid_checker.test((tab1_client.streetNumber))) {
  //     //console.log("Hello" + tab1_client.streetNumber);
  //     return true;
  //   }
  // }
  const digitValid_check2 = () => {
    if (!digit_valid_check.digit_valid_checker.test((tab1_client.phone))) {
      // console.log("Hello" + tab1_client.phone);
      return true;
    }
  }
  result =
    result *
    (tab1_client.streetNumber !== " " && tab1_client.streetNumber !== "");
  // result =
  //   result *
  //   (tab1_client.streetNumber !== " " && tab1_client.streetNumber !== "" && !digitValid_check());

  const charValid_check = () => {
    if (!char_valid_check.char_valid_checker.test((tab1_client.streetName))) {
      //console.log("Hello" + tab1_client.streetName);
      return true;
    }
  }


  result =
    result *
    (tab1_client.streetName !== " " && tab1_client.streetName !== "" && !charValid_check());

  result =
    result *
    (tab1_client.streetType !== " " && tab1_client.streetType !== null);

  result = result * (tab1_client.suburb !== " " && tab1_client.suburb !== "");

  result = result * (tab1_client.state !== " " && tab1_client.state !== null);

  result =
    result * (tab1_client.postCode !== " " && tab1_client.postCode !== "");

  result =
    result *
    (tab1_client.phone !== " " &&
      tab1_client.phone !== "" &&
      tab1_client.phone.length === 10 && !digitValid_check2());

  const check_email = () => {
    if (!email_valid_check.email_valid_checker.test(tab1_client.email)) {
      //console.log("Hello" + tab1_client.email);
      return true;
    }
  };
  result =
    result *
    (tab1_client.email !== " " &&
      tab1_client.email !== "" &&
      !check_email());


  result =
    result *
    (tab1_client.branch !== " " && tab1_client.branch !== null);

  result =
    result * (tab1_client.salesTeam !== " " && tab1_client.salesTeam !== null);

  result =
    result *
    (tab1_client.serviceTeam !== " " && tab1_client.serviceTeam !== null);

  return result;
};

// export const tab1_validate = (tab1_client) => {
//   if (tab1_client.clientType === "Individual") {
//     if (tab1_client.title !== " " && tab1_client.title !== null)
//       if (tab1_client.firstName !== "")
//         if (tab1_client.lastName !== "") {
//           return true;
//         }
//   } else if (tab1_client.clientType === "Company") {
//     if (tab1_client.companyName !== "")
//       if (tab1_client.tradingAs !== "") {
//         return true;
//       }
//   } else {
//     return false;
//   }
// };

export const ClientIdFromUipath_validate = (value, tab1_validation, setTab1_validation) => {
  if (value === "") {
    setTab1_validation({
      ...tab1_validation,
      ClientIdFromUipath: "Client Id: Must have digits value",
    });
  }
  else if (value === null) {
    setTab1_validation({
      ...tab1_validation,
      ClientIdFromUipath: "Client Id: Please Insert Value",
    });
  }
  // else if (!digit_valid_check.digit_valid_checker.test(value)) {
  //   setTab1_validation({
  //     ...tab1_validation,
  //     ClientIdFromUipath: "Client Id: Must have only digits value",
  //   });
  // }
  else if (value.length < 4 || value.length > 4) {
    setTab1_validation({
      ...tab1_validation,
      ClientIdFromUipath: "Client Id: Must have 4 digits",
    });
  } else {
    setTab1_validation({
      ...tab1_validation,
      ClientIdFromUipath: "true",
    });
  }
}


export const clientType_validate = (value, tab1_validation, setTab1_validation) => {
  //console.log("val:" + value);
  if (value === null || value === " ") {
    setTab1_validation({
      ...tab1_validation,
      clientType: "Client type: Must select an option",
    });
  } else {
    setTab1_validation({
      ...tab1_validation,
      clientType: "true",
    });
  }
};

export const title_validate = (value, tab1_validation, setTab1_validation) => {
  if (value === null) {
    setTab1_validation({
      ...tab1_validation,
      title: "Title: Must select an option",
    });
  } else {
    setTab1_validation({
      ...tab1_validation,
      title: "true",
    });
  }
};

export const firstName_validate = (
  value,
  tab1_validation,
  setTab1_validation
) => {
  // const regex = /^([A-Za-z])([A-Za-z\s])+$/;
  if (value === "" || value === null) {
    setTab1_validation({
      ...tab1_validation,
      firstName: "First name: Must have value",
    });
  }
  // if (!value.replace(/\s/g, '').length) {
  //   console.log('string only contains whitespace (ie. spaces, tabs or line breaks)');
  // } 
  else {
    setTab1_validation({
      ...tab1_validation,
      firstName: "true",
    });
  }
};

export const lastName_validate = (
  value,
  tab1_validation,
  setTab1_validation
) => {
  // const regex = /^([A-Za-z])([A-Za-z\s])+$/;
  // console.log(value);
  //console.log(value.length);
  if (value === "" || value === null) {
    setTab1_validation({
      ...tab1_validation,
      lastName: "Last name: Must have value",
    });
  }


  else {
    setTab1_validation({
      ...tab1_validation,
      lastName: "true",
    });
  }
};

export const companyName_validate = (
  value,
  tab1_validation,
  setTab1_validation
) => {
  if (value === "") {
    setTab1_validation({
      ...tab1_validation,
      companyName: "Must have value",
    });
  } else {
    setTab1_validation({
      ...tab1_validation,
      companyName: "true",
    });
  }
};

export const tradingAs_validate = (
  value,
  tab1_validation,
  setTab1_validation
) => {
  if (value === "") {
    setTab1_validation({
      ...tab1_validation,
      tradingAs: " Must have value",
    });
  } else {
    setTab1_validation({
      ...tab1_validation,
      tradingAs: "true",
    });
  }
};

export const streetNumber_validate = (value, tab1_validation, setTab1_validation) => {
  if (value === "") {
    setTab1_validation({
      ...tab1_validation,
      streetNumber: "Street Number :Must have digits value",
    });
  }
  // else if (!digit_valid_check.digit_valid_checker.test(value)) {
  //   setTab1_validation({
  //     ...tab1_validation,
  //     streetNumber: "Street Number : Incorrect type",
  //   });
  // }
  else {
    setTab1_validation({
      ...tab1_validation,
      streetNumber: "true",
    });
  }
};

export const streetName_validate = (value, tab1_validation, setTab1_validation) => {


  if (value === "") {
    setTab1_validation({
      ...tab1_validation,
      streetName: "Street Name: Must have value",
    });
  }
  // else if (!char_valid_check.char_valid_checker.test(value)) {
  //   setTab1_validation({
  //     ...tab1_validation,
  //     streetName: "Street Name : Incorrect type",
  //   });
  // }
  else {
    setTab1_validation({
      ...tab1_validation,
      streetName: "true",
    });
  }
};

export const streetType_validate = (
  value,
  tab1_validation,
  setTab1_validation
) => {
  if (value === null || value === " ") {
    setTab1_validation({
      ...tab1_validation,
      streetType: "Street Type: Must select an option",
    });
  } else {
    setTab1_validation({
      ...tab1_validation,
      streetType: "true",
    });
  }
};

export const suburb_validate = (value, tab1_validation, setTab1_validation) => {
  const suburb_valid_check = /^[A-Za-z\s]+$/;

  if (value === "") {
    setTab1_validation({
      ...tab1_validation,
      suburb: "Must have value",
    });
  } else if (!suburb_valid_check.test(value)) {
    setTab1_validation({
      ...tab1_validation,
      suburb: "Incorrect type",
    });
  }
  else {
    setTab1_validation({
      ...tab1_validation,
      suburb: "true"
    })
  }
};

export const state_validate = (value, tab1_validation, setTab1_validation) => {
  if (value === null || value === " ") {
    setTab1_validation({
      ...tab1_validation,
      state: "Title: Must select an option",
    });
  } else {
    setTab1_validation({
      ...tab1_validation,
      state: "true",
    });
  }
};

export const postCode_validate = (
  value,
  tab1_validation,
  setTab1_validation
) => {
  if (value === "") {
    setTab1_validation({
      ...tab1_validation,
      postCode: "Must have value.",
    });
  } else {
    setTab1_validation({
      ...tab1_validation,
      postCode: "true",
    });
  }
};

export const phone_validate = (value, tab1_validation, setTab1_validation) => {
  if (value === "") {
    setTab1_validation({
      ...tab1_validation,
      phone: "Must have only digits.",
    });
  } else if (value.length > 10 || value.length < 10) {
    setTab1_validation({
      ...tab1_validation,
      phone: "Phone:Must have 10 digits.",
    });
  }

  else if (!digit_valid_check.digit_valid_checker.test(value)) {
    if (value.length === 10) {
      setTab1_validation({
        ...tab1_validation,
        phone: "Phone Number: Invalid Type.",
      });
    }
  }
  else {
    setTab1_validation({
      ...tab1_validation,
      phone: "true",
    });
  }
};

export const email_validate = (value, tab1_validation, setTab1_validation) => {


  if (value === "") {
    setTab1_validation({
      ...tab1_validation,
      email: "Email: Must have value",
    });
  } else if (!email_valid_check.email_valid_checker.test(value)) {
    setTab1_validation({
      ...tab1_validation,
      email: "Email: Invalid Email",
    });
  } else {
    setTab1_validation({
      ...tab1_validation,
      email: "true",
    });
  }
};

export const branch_validate = (value, tab1_validation, setTab1_validation) => {
  if (value === null || value === " ") {
    setTab1_validation({
      ...tab1_validation,
      branch: "Must have value",
    });
  } else {
    setTab1_validation({
      ...tab1_validation,
      branch: "true",
    });
  }
};

export const salesTeam_validate = (
  value,
  tab1_validation,
  setTab1_validation
) => {
  if (value === null || value === " ") {
    setTab1_validation({
      ...tab1_validation,
      salesTeam: "Title: Must select an option",
    });
  } else {
    setTab1_validation({
      ...tab1_validation,
      salesTeam: "true",
    });
  }
};

export const serviceTeam_validate = (
  value,
  tab1_validation,
  setTab1_validation
) => {
  if (value === null || value === " ") {
    setTab1_validation({
      ...tab1_validation,
      serviceTeam: "Title: Must select an option",
    });
  } else {
    setTab1_validation({
      ...tab1_validation,
      serviceTeam: "true",
    });
  }
};
