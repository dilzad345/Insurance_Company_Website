import { digit_valid_check } from '../constants/validChecker';
export const tab4_validate = (tab4_vehicle) => {
  let result = true;

  result =
    result *
    (tab4_vehicle.streetNumber !== ""
      && tab4_vehicle.streetNumber !== null
      && tab4_vehicle.streetNumber !== " ");

  // result =
  //   result *
  //   (tab4_vehicle.streetNumber !== "" && tab4_vehicle.streetNumber !== " " && !digitvalid_check());

  //prevent from typing blank empty whitespace if lenth >0
  if (!tab4_vehicle.streetName.replace(/\s/g, '').length) {
    tab4_vehicle.streetName = "";
    result =
      result *
      (tab4_vehicle.streetName !== "" &&
        tab4_vehicle.streetName !== null);
  }


  result =
    result *
    (tab4_vehicle.streetType !== " " &&
      tab4_vehicle.streetType !== "Please Select");

  if (!tab4_vehicle.suburb.replace(/\s/g, '').length) {
    tab4_vehicle.suburb = "";
    result = result *
      (tab4_vehicle.suburb !== "" &&
        tab4_vehicle.suburb !== " " && tab4_vehicle.suburb !== null);

  }

  result = result * (tab4_vehicle.state !== " " && tab4_vehicle.state !== null);

  const postCodedigitvalid_check = () => {

    if (!digit_valid_check.digit_valid_checker.test((tab4_vehicle.postCode))) {
      //console.log("PostCode" + tab4_vehicle.postCode);
      return true;
    }
  }
  result =
    result * (tab4_vehicle.postCode !== "" && tab4_vehicle.postCode !== null
      && !postCodedigitvalid_check());

  if (!tab4_vehicle.registrationVehicle.replace(/\s/g, '').length) {
    tab4_vehicle.registrationVehicle = "";
    result =
      result *
      (tab4_vehicle.registrationVehicle !== "" &&
        tab4_vehicle.registrationVehicle !== null &&
        tab4_vehicle.registrationVehicle !== " ");
  }


  result =
      result *
      (tab4_vehicle.stateIssued !== "" &&
        tab4_vehicle.stateIssued !== null &&
        tab4_vehicle.stateIssued !== " ");
  // result =
  //   result *
  //   (tab4_vehicle.vehicleYear.toString() !== "" && tab4_vehicle.vehicleYear.toString() !== " "
  //     && tab4_vehicle.vehicleYear.toString().length === 4 && !vehicleYear_valid_check());
  // //console.log("vehicleyear "+typeof(tab4_vehicle.vehicleYear));


  // const vehicleMakevalid_check = () => {
  //   if (!char_valid_check.char_valid_checker.test((tab4_vehicle.vehicleMake))) {
  //     //console.log("make"+tab4_vehicle.vehicleType);
  //     return true;
  //   }
  // }
  // result =
  //   result *
  //   (tab4_vehicle.vehicleMake !== "" && tab4_vehicle.vehicleMake !== " "
  //     && !vehicleMakevalid_check());

  // const vehicleTypevalid_check = () => {
  //   if (!char_valid_check.char_valid_checker.test((tab4_vehicle.vehicleType))) {
  //     //console.log("make"+tab4_vehicle.vehicleType);
  //     return true;
  //   }
  // }
  // result = result * (tab4_vehicle.vehicleModel !== "" &&
  //   tab4_vehicle.vehicleType !== " " && !vehicleTypevalid_check());

  result =
    result *
    (tab4_vehicle.securityDeviceFitted !== "" &&
      tab4_vehicle.securityDeviceFitted !== " ");

  result =
    result *
    (tab4_vehicle.similarPowerOfVehicle !== "" &&
      tab4_vehicle.similarPowerOfVehicle !== " ");

  result =
    result *
    (tab4_vehicle.vehicleParkedDay !== "" &&
      tab4_vehicle.vehicleParkedDay !== " ");




  result =
    result *
    (tab4_vehicle.vehicleUsage !== " " && tab4_vehicle.vehicleUsage !== null);

  result =
    result *
    (tab4_vehicle.numberKMsYear !== " " && tab4_vehicle.numberKMsYear !== null);

  result =
    result *
    (tab4_vehicle.vehicleParkedNight !== " " &&
      tab4_vehicle.vehicleParkedNight !== null);

  result =
    result *
    (tab4_vehicle.previouslyInsured !== " " &&
      tab4_vehicle.previouslyInsured !== null);

  result =
    result *
    (tab4_vehicle.vehicleUnregistered !== " " &&
      tab4_vehicle.vehicleUnregistered !== null);

  result =
    result *
    (tab4_vehicle.usedDriver !== " " && tab4_vehicle.usedDriver !== null);

  result =
    result *
    (tab4_vehicle.usedHireCar !== " " && tab4_vehicle.usedHireCar !== null);

  result =
    result *
    (tab4_vehicle.specialisedPaint !== " " &&
      tab4_vehicle.specialisedPaint !== null);

  result =
    result *
    (tab4_vehicle.superCharger !== " " && tab4_vehicle.superCharger !== null);

  result =
    result *
    (tab4_vehicle.hydrogenFuel !== " " && tab4_vehicle.hydrogenFuel !== null);

  result =
    result *
    (tab4_vehicle.racingHarnesses !== " " &&
      tab4_vehicle.racingHarnesses !== null);

  result =
    result *
    (tab4_vehicle.vehicleFinanced !== " " &&
      tab4_vehicle.vehicleFinanced !== null);

  result =
    result *
    (tab4_vehicle.hailDamage !== " " && tab4_vehicle.hailDamage !== null);

  // const pricedigitvalid_check = () => {

  //   if (!char_valid_check.char_valid_checker.test((tab4_vehicle.purchasePrice))) {
  //     console.log("true")
  //     return true;
  //   }
  // }

  // console.log(pricedigitvalid_check());
  // result =
  //   result *
  //   (tab4_vehicle.purchasePrice !== " ");
  // result =
  //   result *
  //   (tab4_vehicle.purchasePrice !== " " && pricedigitvalid_check());

  return result;
};

//const digit_valid_check = /^[0-9]*$/;
//const char_valid_check = /^([A-Za-z])([A-Za-z\s])+$/



/* export const unitNumber_validate=( value,tab4_validation,setTab4_validation)=>{
  if (value === "" || value === null) {
    setTab4_validation({
      ...tab4_validation,
      unitNumber: "Unit Number: Must have a value",
    });
  }
  else if(!digit_valid_check.digit_valid_checker.test(value)){
    setTab4_validation({
      ...tab4_validation,
      unitNumber: "Unit Number : Invalid Type",
    });
  }
   else {
    setTab4_validation({
      ...tab4_validation,
      unitNumber: "true",
    });
  }
}; */
export const streetNumber_validate = (value, tab4_validation, setTab4_validation) => {
  if (value === "") {
    setTab4_validation({
      ...tab4_validation,
      streetNumber: "Street Number: Must have value",
    });
  }
  // else if (!digit_valid_check.digit_valid_checker.test(value)) {
  //   setTab4_validation({
  //     ...tab4_validation,
  //     streetNumber: "Street Number: Invalid Type",
  //   });
  // }
  else {
    setTab4_validation({
      ...tab4_validation,
      streetNumber: "true",
    });
  }
};

export const streetName_validate = (value, tab4_validation, setTab4_validation) => {
  // const regex = /^([A-Za-z])([A-Za-z\s])+$/;
  if (value === "") {
    setTab4_validation({
      ...tab4_validation,
      streetName: "Street Name: Must have value",
    });
  }
  // else if (!char_valid_check.char_valid_checker.test(value)) {
  //   setTab4_validation({
  //     ...tab4_validation,
  //     streetName: "Street Name: Invalid Type",
  //   });
  // }
  else {
    setTab4_validation({
      ...tab4_validation,
      streetName: "true",
    });
  }
};

export const streetType_validate = (value, tab4_validation, setTab4_validation) => {
  if (value === null || value === " ") {
    setTab4_validation({
      ...tab4_validation,
      streetType: "Must select an option",
    });
  } else {
    setTab4_validation({
      ...tab4_validation,
      streetType: "true",
    });
  }
};

export const suburb_validate = (value, tab4_validation, setTab4_validation) => {
  // const regex = /^([A-Za-z])([A-Za-z\s])+$/;
  if (value === "") {
    setTab4_validation({
      ...tab4_validation,
      suburb: "Suburb: Must have value",
    });
  } else {
    setTab4_validation({
      ...tab4_validation,
      suburb: "true",
    });
  }
};

export const state_validate = (value, tab4_validation, setTab4_validation) => {
  if (value === null || value === " ") {
    setTab4_validation({
      ...tab4_validation,
      state: "Must select an option",
    });
  } else {
    setTab4_validation({
      ...tab4_validation,
      state: "true",
    });
  }
};

export const postCode_validate = (value, tab4_validation, setTab4_validation) => {
  // const regex = /^([A-Za-z])([A-Za-z\s])+$/;
  if (value === "") {
    setTab4_validation({
      ...tab4_validation,
      postCode: "Post Code: Must have digits",
    });
  }
  else if (!digit_valid_check.digit_valid_checker.test(value)) {
    setTab4_validation({
      ...tab4_validation,
      postCode: "Post Code: Invalid Type",
    });
  }
  else {
    setTab4_validation({
      ...tab4_validation,
      postCode: "true",
    });
  }
};

export const registrationVehicle_validate = (value, tab4_validation, setTab4_validation) => {
  if (value === "") {
    setTab4_validation({
      ...tab4_validation,
      registrationVehicle: "Registration Vehicle: Must have value",
    });
  }
  /*  else if(!char_valid_check.test(value)){
     setTab4_validation({
       ...tab4_validation,
       registrationVehicle: "Registration Vehicle: Invalid type",
     });
   } */
  else {
    setTab4_validation({
      ...tab4_validation,
      registrationVehicle: "true",
    });
  }
};

export const stateIssued_validate = (value, tab4_validation, setTab4_validation) => {
  if (value === " ") {
    setTab4_validation({
      ...tab4_validation,
      stateIssued: "Must Select An Option",
    });
  }
  /*  else if(!char_valid_check.test(value)){
     setTab4_validation({
       ...tab4_validation,
       registrationVehicle: "Registration Vehicle: Invalid type",
     });
   } */
  else {
    setTab4_validation({
      ...tab4_validation,
      stateIssued: "true",
    });
  }
};
export const vehicleYear_validate = (value, tab4_validation, setTab4_validation) => {
  // if (value === "") {
  //   setTab4_validation({
  //     ...tab4_validation,
  //     vehicleYear: "Vehicle Year: Must have 4 digits value",
  //   });

  // }
  // else if (!digit_valid_check.digit_valid_checker.test(value)) {
  //   setTab4_validation({
  //     ...tab4_validation,
  //     vehicleYear: "Vehicle Year: Invalid type",
  //   });
  // }
  // else if (value.length < 4 || value.length > 4) {
  //   setTab4_validation({
  //     ...tab4_validation,
  //     vehicleYear: "Vehicle Year: Must have 4 digits",
  //   });
  // }
  // else {
  setTab4_validation({
    ...tab4_validation,
    vehicleYear: "true",
  });
  // }
};

export const vehicleMake_validate = (value, tab4_validation, setTab4_validation) => {
  if (value === "") {
    setTab4_validation({
      ...tab4_validation,
      vehicleMake: "Vehicle Make: Must have value",
    });
  }
  // else if (!char_valid_check.char_valid_checker.test(value)) {
  //   setTab4_validation({
  //     ...tab4_validation,
  //     vehicleMake: "Vehicle Make: Invalid Type",
  //   });
  // }
  else {
    setTab4_validation({
      ...tab4_validation,
      vehicleMake: "true",
    });
  }
};
export const vehicleModel_validate = (value, tab4_validation, setTab4_validation) => {
  if (value === "") {
    setTab4_validation({
      ...tab4_validation,
      vehicleModel: "Vehicle Model: Must have value",
    });
  }
  else {
    setTab4_validation({
      ...tab4_validation,
      vehicleModel: "true",
    });
  }
};
export const vehicleType_validate = (value, tab4_validation, setTab4_validation) => {
  if (value === "") {
    setTab4_validation({
      ...tab4_validation,
      vehicleType: "Vehicle Type: Must have value",
    });
  }
  // else if (!char_valid_check.char_valid_checker.test(value)) {
  //   setTab4_validation({
  //     ...tab4_validation,
  //     vehicleType: "Vehicle Type: Invalid Type",
  //   });
  // }
  else {
    setTab4_validation({
      ...tab4_validation,
      vehicleType: "true",
    });
  }
};
export const securityDeviceFitted_validate = (value, tab4_validation, setTab4_validation) => {
  if (value === "" || value === " ") {
    setTab4_validation({
      ...tab4_validation,
      securityDeviceFitted: "Security Device Fitted: Must have value",
    });
  } else {
    setTab4_validation({
      ...tab4_validation,
      securityDeviceFitted: "true",
    });
  }
};

export const similarPowerOfVehicle_validate = (value, tab4_validation, setTab4_validation) => {
  if (value === "" || value === " ") {
    setTab4_validation({
      ...tab4_validation,
      similarPowerOfVehicle: "Security Device Fitted: Must have value",
    });
  } else {
    setTab4_validation({
      ...tab4_validation,
      similarPowerOfVehicle: "true",
    });
  }
};

export const vehicleParkedDay_validate = (value, tab4_validation, setTab4_validation) => {
  if (value === "" || value === " ") {
    setTab4_validation({
      ...tab4_validation,
      vehicleParkedDay: "Security Device Fitted: Must have value",
    });
  } else {
    setTab4_validation({
      ...tab4_validation,
      vehicleParkedDay: "true",
    });
  }
};

export const vehicleUsage_validate = (
  value,
  tab4_validation,
  setTab4_validation
) => {
  if (value === null || value === " ") {
    setTab4_validation({
      ...tab4_validation,
      vehicleUsage: "Must select an option",
    });
  } else {
    setTab4_validation({
      ...tab4_validation,
      vehicleUsage: "true",
    });
  }
};

export const numberKMsYear_validate = (
  value,
  tab4_validation,
  setTab4_validation
) => {
  if (value === null || value === " ") {
    setTab4_validation({
      ...tab4_validation,
      numberKMsYear: "Must select an option",
    });
  } else {
    setTab4_validation({
      ...tab4_validation,
      numberKMsYear: "true",
    });
  }
};

export const vehicleParkedNight_validate = (
  value,
  tab4_validation,
  setTab4_validation
) => {
  if (value === null || value === " ") {
    setTab4_validation({
      ...tab4_validation,
      vehicleParkedNight: "Must select an option",
    });
  } else {
    setTab4_validation({
      ...tab4_validation,
      vehicleParkedNight: "true",
    });
  }
};

export const previouslyInsured_validate = (
  value,
  tab4_validation,
  setTab4_validation
) => {
  if (value === null || value === " ") {
    setTab4_validation({
      ...tab4_validation,
      previouslyInsured: "Must select an option",
    });
  } else {
    setTab4_validation({
      ...tab4_validation,
      previouslyInsured: "true",
    });
  }
};

export const vehicleUnregistered_validate = (
  value,
  tab4_validation,
  setTab4_validation
) => {
  if (value === null || value === " ") {
    setTab4_validation({
      ...tab4_validation,
      vehicleUnregistered: "Must select an option",
    });
  } else {
    setTab4_validation({
      ...tab4_validation,
      vehicleUnregistered: "true",
    });
  }
};

export const usedDriver_validate = (
  value,
  tab4_validation,
  setTab4_validation
) => {
  if (value === null || value === " ") {
    setTab4_validation({
      ...tab4_validation,
      usedDriver: "Must select an option",
    });
  } else {
    setTab4_validation({
      ...tab4_validation,
      usedDriver: "true",
    });
  }
};

export const usedHireCar_validate = (
  value,
  tab4_validation,
  setTab4_validation
) => {
  if (value === null || value === " ") {
    setTab4_validation({
      ...tab4_validation,
      usedHireCar: "Must select an option",
    });
  } else {
    setTab4_validation({
      ...tab4_validation,
      usedHireCar: "true",
    });
  }
};

export const specialisedPaint_validate = (
  value,
  tab4_validation,
  setTab4_validation
) => {
  if (value === null || value === " ") {
    setTab4_validation({
      ...tab4_validation,
      specialisedPaint: "Must select an option",
    });
  } else {
    setTab4_validation({
      ...tab4_validation,
      specialisedPaint: "true",
    });
  }
};

export const superCharger_validate = (
  value,
  tab4_validation,
  setTab4_validation
) => {
  if (value === null || value === " ") {
    setTab4_validation({
      ...tab4_validation,
      superCharger: "Must select an option",
    });
  } else {
    setTab4_validation({
      ...tab4_validation,
      superCharger: "true",
    });
  }
};

export const hydrogenFuel_validate = (
  value,
  tab4_validation,
  setTab4_validation
) => {
  if (value === null || value === " ") {
    setTab4_validation({
      ...tab4_validation,
      hydrogenFuel: "Must select an option",
    });
  } else {
    setTab4_validation({
      ...tab4_validation,
      hydrogenFuel: "true",
    });
  }
};

export const racingHarnesses_validate = (value, tab4_validation, setTab4_validation
) => {
  if (value === null || value === " ") {
    setTab4_validation({
      ...tab4_validation,
      racingHarnesses: "Must select an option",
    });
  } else {
    setTab4_validation({
      ...tab4_validation,
      racingHarnesses: "true",
    });
  }
};

export const vehicleFinanced_validate = (
  value,
  tab4_validation,
  setTab4_validation
) => {
  if (value === null || value === " ") {
    setTab4_validation({
      ...tab4_validation,
      vehicleFinanced: "Must select an option",
    });
  } else {
    setTab4_validation({
      ...tab4_validation,
      vehicleFinanced: "true",
    });
  }
};

export const hailDamage_validate = (
  value,
  tab4_validation,
  setTab4_validation
) => {
  if (value === null || value === " ") {
    setTab4_validation({
      ...tab4_validation,
      hailDamage: "Must select an option",
    });
  } else {
    setTab4_validation({
      ...tab4_validation,
      hailDamage: "true",
    });
  }
};

// export const purchaseDate_validate = (
//   value,
//   tab4_validation,
//   setTab4_validation
// ) => {
//   console.log("Val:" + value);
//   if (value === null || value === "dd/MM/yyyy" || value === "") {
//     setTab4_validation({
//       ...tab4_validation,
//       purchaseDate: "Must select an option",
//     });
//   } else {
//     setTab4_validation({
//       ...tab4_validation,
//       purchaseDate: "true",
//     });
//   }
// };

export const purchasePrice_validate = (
  value,
  tab4_validation,
  setTab4_validation
) => {
  // console.log(typeof value);
  // console.log(digit_valid_check.digit_valid_checker.test(value));
  //const amount_validate = /(?:\.\d{0,1})$/;
  // if (value < 0) {
  //   setTab4_validation({
  //     ...tab4_validation,
  //     purchasePrice: "Purchase Price: Price cannot be negative.",
  //   });
  // } 
  // else if (!digit_valid_check.digit_valid_checker.test(value)) {
  //   setTab4_validation({
  //     ...tab4_validation,
  //     purchasePrice: "Purchase Price: Invalid type",
  //   });
  // } 
  if (value === "") {
    setTab4_validation({
      ...tab4_validation,
      purchasePrice: "Purchase Price: Must have digits only",
    });
  }
  else {
    setTab4_validation({
      ...tab4_validation,
      purchasePrice: "true",
    });
  }
};
