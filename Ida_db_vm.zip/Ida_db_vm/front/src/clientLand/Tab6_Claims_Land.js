import React, { useState } from "react";
import {
  TextField,
  Container,
  Button,
  InputLabel,
  MenuItem,
  Select,
  Grid,
} from "@material-ui/core";
// import { makeStyles } from "@material-ui/core/styles";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import InputAdornment from "@material-ui/core/InputAdornment";
import DatePicker from "react-datepicker";
import history from "../auth/history";
// import { Redirect } from 'react-router-dom';
import { validationForSpecialchar, validationForAlpha, validationForNumbOnly } from "../constants/validChecker";
import {
  typeClaim_validate,
  dateClaim_validate,
  description_validate,
  amount_validate,
} from "../validationLand/Tab6_Validation_Land";
import { exit } from "../constants/exit";

//increase day by 1
let myCurrentToDate = new Date();
myCurrentToDate.setDate(myCurrentToDate.getDate() - 1);


const notifyDeleteModification = () =>
  toast.success("Content Deleted!", {
    position: "bottom-center",
    autoClose: 1000,
    hideProgressBar: true,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
  });

const Tab6_Claims_Land = ({
  Tab6_Claims_Land_Var,
  setTab6,
  Tab6_Validation_Land_Var,
  setTab6_validation,
  isAllFormsValid,
  submitAllForms,
  navigation,
}) => {
  // const modiCount = Tab6_Claims_Land_Var.length;
  // const classes = useStyles();
  const notify = (res) =>
  toast.success(res, {
    position: "bottom-center",
    autoClose: 1000,
    hideProgressBar: true,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
  });

const notifyFailure = () =>
  toast.error("Submission Status: Failed!", {
    position: "bottom-center",
    autoClose: 1000,
    hideProgressBar: true,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
  });

  // add a vehicle modifications
  const addMore = () => {
    setTab6((Tab6_Claims_Land_Var) => [
      ...Tab6_Claims_Land_Var,
      { typeClaim: " ", dateClaim: new Date(myCurrentToDate), description: "", amount: "" },
    ]);
    setTab6_validation((Tab6_Validation_Land_Var) => [
      ...Tab6_Validation_Land_Var,
      { typeClaim: " ", dateClaim: " ", description: "", amount: "" },
    ]);
  };


//method for submitting quotation
const handleSubmit = () => {
  submitAllForms()
    .then((res) => {
      // console.log(res);
      if (res) {
        notify(res);
        setTimeout(function () {
          history.push('/client')
        }, 2000);
        // console.log("set load home page: " + res);
        // setLoadClientHome(true); // change to true to redirect to the client home page
      } else if (res === false) {
        notifyFailure();
        setTimeout(function () {
          history.push('/client')
        }, 2000);
      }
    })
    .catch((err) => {
      console.log(err);
    });
};

  // onClick method: delete modification when not needed
  const deleteModi = (ind) => {
    console.log(ind);
    const temp = [...Tab6_Claims_Land_Var];
    const tempValidate = [...Tab6_Validation_Land_Var];

    confirmAlert({
      title: "Confirm to delete",
      message: "Are you sure to do this?",
      buttons: [
        {
          label: "Yes",
          onClick: () => {
            // removing the element using splice
            temp.splice(ind, 1);
            tempValidate.splice(ind, 1);

            Tab6_Claims_Land_Var = temp;
            Tab6_Validation_Land_Var = tempValidate;

            // updating the list
            setTab6(temp);
            setTab6_validation(tempValidate);

            notifyDeleteModification();
          },
        },
        {
          label: "No",
          onClick: () => null,
        },
      ],
    });
  };

  // on change method; to change field values according to the changes
  const onChangeField = (ind) => (event) => {
    let name = event.target.name;
    let value = event.target.value;
    // make a copy of original list as temporary list
    let tempArr = [...Tab6_Claims_Land_Var];
    let tempObj = tempArr[ind];

    // updating the temporary list
    tempObj = {
      ...tempObj,
      [event.target.name]: event.target.value,
    };

    // replace the list with temporary list
    tempArr[ind] = tempObj;
    //console.log(tempArr);

    setTab6(tempArr, () => {
      validationAfterChange(ind, name, value);
    });
  };

  const dateClaim = (date, index) => {
    console.log(date);
    // setTab7({
    //   ...tab7_claims,
    //   dateClaim: date,

    // });
    let name = "dateClaim"
    let value = date;
    console.log("value:", value);
    console.log("index:", index);
    // make a copy of original list as temporary list
    let tempArr = [...Tab6_Claims_Land_Var];
    let tempObj = tempArr[index];

    // updating the temporary list
    tempObj = {
      ...tempObj,
      [name]: value,
    };

    // replace the list with temporary list
    tempArr[index] = tempObj;
    console.log("temparr:", tempArr);
    setTab6(tempArr);
    //console.log(setTab6);
    dateClaim_validate(index, value, Tab6_Validation_Land_Var, setTab6_validation);
  };

  // call validation
  const validationAfterChange = (index, name, value) => {
    switch (name) {
      case "typeClaim": {
        typeClaim_validate(index, value, Tab6_Validation_Land_Var, setTab6_validation);
        break;
      }
      case "dateClaim": {
        dateClaim_validate(index, value, Tab6_Validation_Land_Var, setTab6_validation);
        break;
      }
      case "description": {
        description_validate(index, value, Tab6_Validation_Land_Var, setTab6_validation);
        break;
      }
      case "amount": {
        amount_validate(index, value, Tab6_Validation_Land_Var, setTab6_validation);
        break;
      }
      default: {
        return "Not match to condition";
      }
    }
  };


  return (
    <Container maxWidth="md" style={{ marginBottom: "50px" }}>
      <div className="container p-3 my-3dark text-dark">
        <Grid xs={12} textAlign="center" justifyContent="center" container>
          <h3>CLAIMS</h3>
        </Grid>
        {Tab6_Claims_Land_Var.map((modi, index) => {
          return (
            <div>
              <Grid
                // className=""
                // style={{ marginBottom: "100px" }}
                key={index}
                // direction="row"
                container
                spacing={3}
                direction="row"
                justifyContent="center"
                alignItems="center"
                style={{ marginBottom: "20px", marginTop: "20px" }}
              >
                <Grid item xs={4}>
                  <InputLabel
                    htmlFor="typeClaim"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    Type of Claim
                  </InputLabel>
                </Grid>

                <Grid item xs={8} style={{ marginBottom: "20px" }}>
                  <Select
                    name="typeClaim"
                    variant="outlined"
                    autoComplete="off"
                    onChange={onChangeField(index)}
                    onClose={() =>
                      validationAfterChange(index, "typeClaim", modi.typeClaim)
                    }
                    value={modi.typeClaim}
                    style={{ height: "40px" }}
                    fullWidth
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    <MenuItem value="Earthquake, storm, cyclone or hail">Earthquake, storm, cyclone or hail</MenuItem>
                    <MenuItem value="Bushfire or flood">Bushfire or flood</MenuItem>
                    <MenuItem value="House fire">House fire</MenuItem>
                    <MenuItem value="Bushfire">Theft</MenuItem>
                    <MenuItem value="Damage from water from pipes and drains">Damage from water from pipes and drains</MenuItem>
                    <MenuItem value="Damage cause by children, pets or other accidental damage">Damage cause by children, pets or other accidental damage</MenuItem>
                    <MenuItem value="Other claim type">Other claim type</MenuItem>
                  </Select>
                  {Tab6_Validation_Land_Var[index].typeClaim !== null &&
                    Tab6_Validation_Land_Var[index].typeClaim !== "true" && (
                      <div className="text-danger font-italic">
                        {Tab6_Validation_Land_Var[index].typeClaim}
                      </div>
                    )}
                </Grid>

                {/* Date */}
                <Grid item xs={4}>
                  <InputLabel
                    htmlFor="dateClaim"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    Date of Claim
                  </InputLabel>
                </Grid>

                <Grid item xs={8} style={{ marginBottom: "20px" }}>
                  <div>
                    <DatePicker
                      selected={modi.dateClaim}
                      dateFormat="dd/MM/yyyy"
                      name="dateClaim"
                      className="date-picker-align"
                      variant="outlined"
                      autoComplete="off"
                      onChange={(date) => dateClaim(date, index)}
                      // onChangeRaw={handleDateChangeRaw}
                      value={modi.dateClaim}
                      maxDate={new Date(myCurrentToDate)}
                    />


                  </div>


                  {Tab6_Validation_Land_Var[index].dateClaim !== null &&
                    Tab6_Validation_Land_Var[index].dateClaim !== "true" && (
                      <div className="text-danger font-italic">
                        {Tab6_Validation_Land_Var[index].dateClaim}
                      </div>
                    )}
                </Grid>

                <Grid item xs={4}>
                  <InputLabel
                    htmlFor="Description"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    Description
                  </InputLabel>
                </Grid>

                <Grid item xs={8} style={{ marginBottom: "20px" }}>
                  <TextField
                    name="description"
                    value={modi.description}
                    onChange={onChangeField(index)}
                    onKeyPress={(e) => validationForSpecialchar(e)}
                    size="small"
                    variant="outlined"
                    autoComplete="off"
                    // style={{ marginBottom: "20px" }}
                    required
                    fullWidth
                  />
                  {Tab6_Validation_Land_Var[index].description !== null &&
                    Tab6_Validation_Land_Var[index].description !== "true" && (
                      <div className="text-danger font-italic">
                        {Tab6_Validation_Land_Var[index].description}
                      </div>
                    )}
                </Grid>

                <Grid item xs={4}>
                  <InputLabel
                    htmlFor="amount"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    Amount
                  </InputLabel>
                </Grid>

                <Grid item xs={8} style={{ marginBottom: "20px" }}>
                  <TextField
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">$</InputAdornment>
                      ),
                    }}
                    name="amount"
                    value={modi.amount}
                    onChange={onChangeField(index)}
                    size="small"
                    variant="outlined"
                    type="tel"
                    maxLength="8"
                    inputProps={{ maxLength: 8 }}
                    autoComplete="off"
                    onKeyPress={(e) => validationForNumbOnly(e)}
                    // style={{ marginBottom: "20px" }}
                    required
                    fullWidth
                  />
                  {Tab6_Validation_Land_Var[index].amount !== null &&
                    Tab6_Validation_Land_Var[index].amount !== "true" && (
                      <div className="text-danger font-italic">
                        {Tab6_Validation_Land_Var[index].amount}
                      </div>
                    )}
                </Grid>
              </Grid>

              <div>
                <Button
                  style={{ float: "right", width: "10%", marginBottom: "30px" }}
                  onClick={() => deleteModi(index)}
                  // className="bg-warning"
                  variant="contained"
                  color="secondary"
                >
                  DELETE
                </Button>

                <br />
                <hr
                  style={{
                    color: "red",
                    backgroundColor: "green",
                    height: 1,
                    marginTop: "50px",
                  }}
                />
              </div>
            </div>
          );
        })}
        <Grid
          direction="row"
          container
          justifyContent="center"
          alignItems="center"
        >
          <Grid item xs={12} style={{ marginTop: "20px" }}>
            <div className="alert alert-info">
            Use the add button below to add any claims in the last 5 years
            </div>
          </Grid>
          <Grid xs={4}></Grid>
          <Grid
            item
            xs={4}
            container
            justifyContent="center"
            alignItems="center"
          >
            <Button
              fullWidth
              onClick={addMore}
              className="bg-success text-white"
            >
              ADD MORE
            </Button>
          </Grid>
          <Grid xs={4}></Grid>
        </Grid>
      </div>

      <Grid>
            {isAllFormsValid() ? (
              <Button
                variant="contained"
                className="bg-warning"
                style={{
                  marginTop: "1rem",
                  float: "right",
                  marginBottom: "50px",
                }}
                onClick={handleSubmit}
              >
                SUBMIT
              </Button>
            ) : (
              <Button
                variant="contained"
                className="bg-alert"
                style={{
                  marginTop: "1rem",
                  float: "right",
                  marginBottom: "50px",
                }}
                disabled
              >
                SUBMIT
              </Button>
            )}
            <ToastContainer
              style={{
                marginLeft: "50px",
                marginBottom: "-25px",
                width: "30%",
              }}
            />
          </Grid>
      <Grid>
        <Button
          variant="contained"
          color="secondary"
          style={{
            marginTop: "1rem",
            float: "left",
            width: "20%",
          }}
          onClick={() => {
            exit();
          }}
        >
          SAVE & EXIT
        </Button>
      </Grid>



      <Button
        variant="contained"
        color="primary"
        // className="bg-warning"
        style={{
          marginTop: "1rem",
          float: "right",
          marginBottom: "50px",
          marginRight: "20px",
          width: "10%",
        }}
        onClick={() => navigation.previous()}
      >
        PREVIOUS
      </Button>
      <ToastContainer style={{ marginLeft: "50px", marginBottom: "-25px", width: "30%" }} />
    </Container>
  );
};

export default Tab6_Claims_Land;