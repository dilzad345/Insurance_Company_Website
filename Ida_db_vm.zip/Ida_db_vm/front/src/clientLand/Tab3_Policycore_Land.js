import React from 'react';
import "../css/homeStyle.css";
import {
  TextField,
  Container,
  Button,
  Select,
  InputLabel,
  MenuItem,
  Grid,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import { Redirect } from 'react-router-dom';
import DatePicker from "react-datepicker";
import InputAdornment from "@material-ui/core/InputAdornment";
import { preferredDays } from "../constants/dropDownData";
import {validationForNumbOnly} from "../constants/validChecker";

import {
  cover_type_accidential_validate,
  occupancy_home_validate,
  property_managed_validate,
  building_content_validate,
  building_sum_validate,
  content_ins_amount_validate,
  policy_from_date_validate,
  policy_to_date_validate,
  dob_oldest_insurede_validate,
  currently_hold_insurence_validate,
  current_insurer_validate,
  interested_parties_validate,
  stamp_duty_exempt_validate,
  no_claim_bonus_validate,
  payment_frequency_validate,
  preffered_day_installment_validate,
  broker_fee_installment_validate,
  cover_Theft_tenant_validate,
  cover_loss_validate,
  sum_ins_amount_loss_validate,
  annual_rent_amount_validate,
  weekly_rent_amount_validate,
  cover_rent_default_validate,
  tenant_rent_14Days_validate,
  residential_lease_agreement_validate,
  landlord_insurance_policy_validate,
  svu_excess_option1_validate,
  svu_excess_option2_validate,
  svu_excess_option3_validate,
  policyholder_retired_validate,
  cover_Accidental_damage_validate,

} from "../validationLand/Tab3_Validation_Land";
import { exit } from "../constants/exit";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    alignContent: "center",
    padding: theme.spacing(2),
    //textAlign: 'center',
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary,
  },

 
}));

const returnClientLand = () => {
  return <Redirect to='/client_Land_link' />
}

const Tab3_Policycore_Land = ({
  Tab3_Policycore_Land_Var,
  setTab3,
  Tab3_Validation_Land_Var, 
  setTab3_validation,
  navigation,
}) => {

  const classes = useStyles();

  const onChangeField = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    
    setTab3(
      {
        ...Tab3_Policycore_Land_Var,
        [name]: value,
      },
      () => {
        validationAfterChange(name, value);
      }
    );
  };

  //increase day by 1
  let myCurrentToDate = new Date();
  myCurrentToDate.setDate(myCurrentToDate.getDate() + 1);

  //set default year reduced by 16 from current year for date of birth
  let tempDate = new Date();
  tempDate.setFullYear(tempDate.getFullYear() - 16);

  //method for preventing user typing
  const handleDateChangeRaw = (e) => {
    e.preventDefault();
  };

   // method: to update policy date from to variable
   const setFromDate = (date,value) => {
    console.log(date);
    const tempDate = new Date(date);
    const tempToDate = tempDate.setFullYear(tempDate.getFullYear() + 1);
    console.log(new Date(tempToDate));
    setTab3({
      ...Tab3_Policycore_Land_Var,
      policy_from_date: date,
      policy_to_date: new Date(tempToDate)
      
    });
    policy_from_date_validate(date, Tab3_Validation_Land_Var, setTab3_validation);
  };

  // method: to update policy date to to variable
  const setToDate = (date) => {
    console.log("v" + date);
    setTab3({
      ...Tab3_Policycore_Land_Var,
      policy_to_date: date,
      
    });
    policy_to_date_validate(date, Tab3_Validation_Land_Var, setTab3_validation);
  };

  const setOldDate = (date,value) => {
    console.log(date);
    setTab3({
      ...Tab3_Policycore_Land_Var,
      dob_oldest_insured: date,
      
    });
    dob_oldest_insurede_validate(date, Tab3_Validation_Land_Var, setTab3_validation);
  };



  const validationAfterChange = (name, value) => {
    // console.log(name)
    // if (name === "building_content") {
    //   if (Tab3_Policycore_Land_Var.building_content === "Building only") {
    //     Tab3_Policycore_Land_Var.content_ins_amount = 0;
    //   } else if (Tab3_Policycore_Land_Var.building_content === "Contents only") {
    //     // Tab3_Policycore_Land_Var.content_ins_amount = "";
    //     Tab3_Policycore_Land_Var.building_sum_insured = 0;
    //   }
    //   // else{
    //   //   Tab3_Policycore_Land_Var.building_sum_insured = "";
    //   //   Tab3_Policycore_Land_Var.content_ins_amount = "";
    //   // }
    // }
    if (name === "payment_frequency") {
      if (value === "Monthly") {
        setTab3({
          ...Tab3_Policycore_Land_Var,
          payment_frequency: "Monthly",
          preffered_day_installment: "Please Select",
          broker_fee_installment: "",
        });
      }
    }

    if (name === "cover_loss") {
      if (value === "No") {
        setTab3({
          ...Tab3_Policycore_Land_Var,
          cover_loss: "No",
          sum_ins_amount_loss: "",
        });
      }
    }

    if (name === "cover_rent_default") {
      if (value === "No") {
        setTab3({
          ...Tab3_Policycore_Land_Var,
          cover_rent_default: "No",
          tenant_rent_14Days: "",
          landlord_insurance_policy: "",
        });
      }
    }

    switch (name) {
      case "cover_type_accidential": {
        cover_type_accidential_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "occupancy_home": {
        occupancy_home_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "property_managed": {
        property_managed_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "building_content": {
        building_content_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "building_sum_insured": {
        building_sum_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "content_ins_amount": {
        content_ins_amount_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "policy_from_date": {
        policy_from_date_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "policy_to_date": {
        policy_to_date_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "dob_oldest_insured": {
        dob_oldest_insurede_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }

      case "currently_hold_insurence": {
        currently_hold_insurence_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "current_insurer": {
        current_insurer_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "policyholder_retired": {
        policyholder_retired_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "interested_parties": {
        interested_parties_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      
      case "stamp_duty_exempt": {
        stamp_duty_exempt_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "no_claim_bonus": {
        no_claim_bonus_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }

      case "payment_frequency": {
        payment_frequency_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "preffered_day_installment": {
        preffered_day_installment_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "broker_fee_installment": {
        broker_fee_installment_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "cover_Theft_tenant": {
        cover_Theft_tenant_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "cover_loss": {
        cover_loss_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "sum_ins_amount_loss": {
        sum_ins_amount_loss_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }

      case "annual_rent_amount": {
        annual_rent_amount_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "weekly_rent_amount": {
        weekly_rent_amount_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "cover_Accidental_damage": {
        cover_Accidental_damage_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "cover_rent_default": {
        cover_rent_default_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "tenant_rent_14Days": {
        tenant_rent_14Days_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "residential_lease_agreement": {
        residential_lease_agreement_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "landlord_insurance_policy": {
        landlord_insurance_policy_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "svu_excess_option1": {
        svu_excess_option1_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "svu_excess_option2": {
        svu_excess_option2_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
      case "svu_excess_option3": {
        svu_excess_option3_validate(value, Tab3_Validation_Land_Var, setTab3_validation);
        break;
      }
     
      default: {
        console.log("Not match to condition");
      }
    }


  };

 


  return (
    <Container maxWidth="md" style={{ marginBottom: "30px" }}>
      <div>
        <Grid
          container
          spacing={3}
          direction="row"
          justifyContent="center"
          alignItems="center">

          <Grid xs={12} textAlign="center" justifyContent="center" container style={{ marginTop: "25px" }}>
            <h3>POLICY CORE INFORMATION</h3>
          </Grid>

         
         {/* Cover Type (Accidental Damage or Defined Events only) */}
         <Grid item xs={6}>
            <InputLabel
              htmlFor="Cover Type (Accidental Damage or Defined Events only)"
              style={{ marginBottom: "5px" }}
              required
            >
             Cover Type (Accidental Damage or Defined Events only)
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="cover_type_accidential"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.cover_type_accidential}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="Accidental Damage">Accidental Damage</MenuItem>
              <MenuItem value="Listed Events">Listed Events</MenuItem>
              
            </Select>
            {Tab3_Validation_Land_Var.cover_type_accidential !== null &&
              Tab3_Validation_Land_Var.cover_type_accidential !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.cover_type_accidential}
                </div>
              )}
          </Grid>

         
         
          {/* What is the occupancy of the home? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="What is the occupancy of the home?"
              style={{ marginBottom: "5px" }}
              required
            >
             What is the occupancy of the home?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="occupancy_home"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.occupancy_home}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="Rented to tenants (Long Term)">Rented to tenants (Long Term)</MenuItem>
              <MenuItem value="Rented to tenants (Short Term)">Rented to tenants (Short Term)</MenuItem>
              <MenuItem value="Owner Occupied and rented to Tenants (Short Term)">Owner Occupied and rented to Tenants (Short Term)</MenuItem>
              <MenuItem value="Weekender / Holiday Home and rented to tenants (Short Term)">Weekender / Holiday Home and rented to tenants (Short Term)</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.occupancy_home !== null &&
              Tab3_Validation_Land_Var.occupancy_home !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.occupancy_home}
                </div>
              )}
          </Grid>

          {/* How is the property managed? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="How is the property managed?"
              style={{ marginBottom: "5px" }}
              required
            >
             How is the property managed?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="property_managed"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.property_managed}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="Landlord manages the property">Landlord manages the property</MenuItem>
              <MenuItem value="Property Manager or onsite manager ">Property Manager or onsite manager </MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.occupancy_home !== null &&
              Tab3_Validation_Land_Var.occupancy_home !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.occupancy_home}
                </div>
              )}
          </Grid>

          {/* Building or Contents */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Building or Contents"
              style={{ marginBottom: "5px" }}
              required
            >
             Building or Contents
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="building_content"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.building_content}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="Building only">Building only</MenuItem>
              <MenuItem value="Contents only">Contents only</MenuItem>
              <MenuItem value="Building and Contents">Building and Contents</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.building_content !== null &&
              Tab3_Validation_Land_Var.building_content !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.building_content}
                </div>
              )}
          </Grid>


          {Tab3_Policycore_Land_Var.building_content === "Building only" && (
            
          <Grid container xs={12} direction="row" spacing={2}>
            <Grid item xs={6}>
                <InputLabel
                 htmlFor="Building Sum Insured"
                 style={{ marginTop: "15px", marginLeft:"5px" }}
                required
          >
            Building Sum Insured
                </InputLabel>
            </Grid>
             <Grid item xs={6}>
              <TextField
               InputProps={{
            startAdornment: (
              <InputAdornment position="start">$</InputAdornment>
            ),
          }}
            name="building_sum_insured"
            size="small"
            variant="outlined"
            autoComplete="off"
            style={{ marginBottom: "10px" }}
            fullWidth
            onChange={onChangeField}
            value={Tab3_Policycore_Land_Var.building_sum_insured}
               onKeyPress={(e) => validationForNumbOnly(e)}
               />
          {Tab3_Validation_Land_Var.building_sum_insured !== null &&
        Tab3_Validation_Land_Var.building_sum_insured !== "true" && (
          <div className="text-danger font-italic">
            {Tab3_Validation_Land_Var.building_sum_insured}
          </div>
        )}
      
        
         </Grid>
           </Grid>
          )}
          
          {Tab3_Policycore_Land_Var.building_content === "Contents only" && (
           <Grid container xs={12} direction="row" spacing={2}>
                <Grid item xs={6}>
                <InputLabel
                  htmlFor="Landlord Contents Sum Insured Amount"
                  style={{ marginTop: "15px", marginLeft:"5px" }}
                  required
                >
                  Landlord Contents Sum Insured Amount
                </InputLabel>
                 </Grid>
                 <Grid item xs={6}>
                <TextField
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">$</InputAdornment>
                  ),
                }}
                  name="content_ins_amount"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  style={{ marginBottom: "20px" }}
                  fullWidth
                  onChange={onChangeField}
                  value={Tab3_Policycore_Land_Var.content_ins_amount}
                  onKeyPress={(e) => validationForNumbOnly(e)}
                />
                {Tab3_Validation_Land_Var.content_ins_amount !== null &&
              Tab3_Validation_Land_Var.content_ins_amount !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.content_ins_amount}
                </div>
              )}
            
              </Grid>
           </Grid>
          )}
             
             {Tab3_Policycore_Land_Var.building_content === "Building and Contents" && (
              <Grid container xs={12} direction="row" spacing={2}>
              <Grid item xs={6}>
                  <InputLabel
                   htmlFor="Building Sum Insured"
                   style={{ marginTop: "15px", marginLeft:"5px" }}
                  required>
                  Building Sum Insured
                  </InputLabel>
              </Grid>
               <Grid item xs={6}>
                <TextField
                 InputProps={{
              startAdornment: (
                <InputAdornment position="start">$</InputAdornment>
              ),
            }}
              name="building_sum_insured"
              size="small"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "10px", marginLeft:"7px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.building_sum_insured}
                 onKeyPress={(e) => validationForNumbOnly(e)}
                 />
            {Tab3_Validation_Land_Var.building_sum_insured !== null &&
          Tab3_Validation_Land_Var.building_sum_insured !== "true" && (
            <div className="text-danger font-italic">
              {Tab3_Validation_Land_Var.building_sum_insured}
            </div>
          )}
        
          
           </Grid>

           <Grid container xs={12} direction="row" spacing={2}>
                <Grid item xs={6}>
                <InputLabel
                  htmlFor="Landlord Contents Sum Insured Amount"
                  style={{ marginTop: "15px", marginLeft:"13px" }}
                  required
                >
                  Landlord Contents Sum Insured Amount
                </InputLabel>
                 </Grid>
                 <Grid item xs={6}>
                <TextField
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">$</InputAdornment>
                  ),
                }}
                  name="content_ins_amount"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  style={{ marginBottom: "20px", marginLeft:"13px" }}
                  fullWidth
                  onChange={onChangeField}
                  value={Tab3_Policycore_Land_Var.content_ins_amount}
                  onKeyPress={(e) => validationForNumbOnly(e)}
                />
                {Tab3_Validation_Land_Var.content_ins_amount !== null &&
              Tab3_Validation_Land_Var.content_ins_amount !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.content_ins_amount}
                </div>
              )}
            
              </Grid>
           </Grid>
             </Grid>
             )}

              

               {/* Policy From Date */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Policy From Date"
              style={{ marginBottom: "5px" }}
              required
            >
              Policy From Date
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <div>
              <DatePicker
                selected={Tab3_Policycore_Land_Var.policy_from_date}
                dateFormat="dd/MM/yyyy"
                name="policy_from_date"
                minDate={new Date()}
                className="date-picker-align"
                onChange={setFromDate}
                onChangeRaw={handleDateChangeRaw}
                value={Tab3_Policycore_Land_Var.policy_from_date}

              />
            {Tab3_Validation_Land_Var.policy_from_date !== null &&
              Tab3_Validation_Land_Var.policy_from_date !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.policy_from_date}
                </div>
              )}
            </div>

          </Grid>

          {/* Policy To Date */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Policy To Date"
              style={{ marginBottom: "5px" }}
              required
            >
              Policy To Date
            </InputLabel>
          </Grid>
          <Grid item xs={6}>

            <DatePicker
              selected={Tab3_Policycore_Land_Var.policy_to_date}
              dateFormat="dd/MM/yyyy"
              name="policy_to_date"
              maxDate={new Date(myCurrentToDate)}
              onChange={setToDate}
              onChangeRaw={handleDateChangeRaw}
              value={Tab3_Policycore_Land_Var.policy_to_date}
              variant="outlined"
              autoComplete="off"
              fullWidth
              className="date-picker-align"

            />

{Tab3_Validation_Land_Var.policy_to_date !== null &&
              Tab3_Validation_Land_Var.policy_to_date !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.policy_to_date}
                </div>
              )}

          </Grid>

          {/* Date of Birth of oldest insured */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Date of Birth of oldest insured"
              style={{ marginBottom: "5px" }}
              required
            >
              Date of Birth of oldest insured
            </InputLabel>
          </Grid>
          <Grid item xs={6}>

            <DatePicker
              selected={Tab3_Policycore_Land_Var.dob_oldest_insured}
              dateFormat="dd/MM/yyyy"
              name="dob_oldest_insured"
              maxDate={tempDate}
              onChange={setOldDate}
              onChangeRaw={handleDateChangeRaw}
              yearDropdownItemNumber={700}
              scrollableYearDropdown={true}
              showYearDropdown
              showMonthDropdown
              dropdownMode="select"
              value={Tab3_Policycore_Land_Var.dob_oldest_insured}
              variant="outlined"
              autoComplete="off"
              fullWidth
              className="date-picker-align"
            />
           {Tab3_Validation_Land_Var.dob_oldest_insured !== null &&
              Tab3_Validation_Land_Var.dob_oldest_insured !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.dob_oldest_insured}
                </div>
              )}
          </Grid>

          {/* Policyholder currently hold insurance */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Policyholder currently hold insurance"
              style={{ marginBottom: "5px" }}
              required
            >
             Policyholder currently hold insurance
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="currently_hold_insurence"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.currently_hold_insurence}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.currently_hold_insurence !== null &&
              Tab3_Validation_Land_Var.currently_hold_insurence !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.currently_hold_insurence}
                </div>
              )}
          </Grid>

          {/* Current Insurer? */}

          <Grid item xs={6}>
            <InputLabel
              htmlFor="Current Insurer?"
              style={{ marginBottom: "5px" }}
              required
            >
             Current Insurer ?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="current_insurer"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.current_insurer}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="AAMI">AAMI</MenuItem>
              <MenuItem value="Ace">Ace</MenuItem>
              <MenuItem value="AIG">AIG</MenuItem>
              <MenuItem value="Allianz">Allianz</MenuItem>
              <MenuItem value="AMP">AMP</MenuItem>
              <MenuItem value="Ansvar">Ansvar</MenuItem>
              <MenuItem value="blue Zebra">Blue Zebra</MenuItem>
              <MenuItem value="Budget Direct">Budget Direct</MenuItem>
              <MenuItem value="Calliden">Calliden</MenuItem>
              <MenuItem value="CGU">CGU</MenuItem>
              <MenuItem value="Chubb">Chubb</MenuItem>
              <MenuItem value="FM">FM</MenuItem>
              <MenuItem value="GIO">GIO</MenuItem>
              <MenuItem value="IAL">IAL</MenuItem>
              <MenuItem value="Lumley">Lumley</MenuItem>
              <MenuItem value="Miramar">Miramar</MenuItem>
              <MenuItem value="NRMA">NRMA</MenuItem>
              <MenuItem value="QBE">QBE</MenuItem>
              <MenuItem value="Real insurance">Real Insurance</MenuItem>
              <MenuItem value="Suncorp">Suncorp</MenuItem>
              <MenuItem value="Viro">Viro</MenuItem>
              <MenuItem value="Youi">Youi</MenuItem>
              <MenuItem value="Zurich">Zurich</MenuItem>
              <MenuItem value="No Previous insurance">
                No Previous Insurance
              </MenuItem>
              <MenuItem value="Other">Other</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.current_insurer !== null &&
              Tab3_Validation_Land_Var.current_insurer !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.current_insurer}
                </div>
              )}
           
          </Grid>

          {/* Is the policyholder retired */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Is the policyholder retired"
              style={{ marginBottom: "5px" }}
              required
            >
             Is the policyholder retired
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="policyholder_retired"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.policyholder_retired}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.policyholder_retired !== null &&
              Tab3_Validation_Land_Var.policyholder_retired !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.policyholder_retired}
                </div>
              )}
          </Grid>
          
          {/* Interested Parties */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Interested Parties"
              style={{ marginBottom: "5px" }}
              required
            >
             Interested Parties
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="interested_parties"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.interested_parties}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Adelaide Bank Limited">Adelaide Bank Limited</MenuItem>
              <MenuItem value="AMP Limited">AMP Limited</MenuItem>
              <MenuItem value="Arab Bank">Arab Bank</MenuItem>
              <MenuItem value="Aussie Home Loans Pty Limited">Aussie Home Loans Pty Limited</MenuItem>
              <MenuItem value="Aussie Mortgages Limited">Aussie Mortgages Limited</MenuItem>
              <MenuItem value="Australia & New Zealand Bank Limited">Australia & New Zealand Bank Limited</MenuItem>
              <MenuItem value="Bank of Melbourn">Bank of Melbourn</MenuItem>
              <MenuItem value="Bank of Queensland Limited">Bank of Queensland Limited</MenuItem>
              <MenuItem value="Bank of South Australia">
                Bank of South Australia
              </MenuItem>
              <MenuItem value="Bank of Western Australia Ltd">
                Bank of Western Australia Ltd
              </MenuItem>
              <MenuItem value="Bankwest">Bankwest</MenuItem>
              <MenuItem value="Bendigo Bank Limited">Bendigo Bank Limited</MenuItem>
              <MenuItem value="Citibank">Citibank</MenuItem>
              <MenuItem value="Colonial State Bank">
                Colonial State Bank
              </MenuItem>
              <MenuItem value="Commonwealth Bank of Australia">Commonwealth Bank of Australia</MenuItem>
              <MenuItem value="Greater Building Society Ltd">
                Greater Building Society Ltd
              </MenuItem>
              <MenuItem value="Homesafe Solutions Pty Ltd">Homesafe Solutions Pty Ltd</MenuItem>
              <MenuItem value="ING Bank (Australia) Limited">ING Bank (Australia) Limited</MenuItem>
              <MenuItem value="Macquarie Bank Limited">Macquarie Bank Limited</MenuItem>
              <MenuItem value="Members Equity Bank Pty Limited">Members Equity Bank Pty Limited</MenuItem>
              <MenuItem value="National Australia Bank Limited">National Australia Bank Limited</MenuItem>
              <MenuItem value="St George Bank - A Division of Westpac Banking Corporation">St George Bank - A Division of Westpac Banking Corporation</MenuItem>
              <MenuItem value="Suncorp-Metway Limited">Suncorp-Metway Limited</MenuItem>
              <MenuItem value=">Westpac Bank Corporation">Westpac Bank Corporation</MenuItem>
              <MenuItem value="Other">Other</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.interested_parties !== null &&
              Tab3_Validation_Land_Var.interested_parties !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.interested_parties}
                </div>
              )}
          </Grid>


          {/* Holding Broker? */}
          {/* <Grid item xs={6}>
            <InputLabel
              htmlFor="Holding Broker?"
              style={{ marginBottom: "5px" }}
              required
            >
             Holding Broker?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="holding_broker"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.holding_broker}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.holding_broker !== null &&
              Tab3_Validation_Land_Var.holding_broker !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.holding_broker}
                </div>
              )}
          </Grid> */}

          

          {/* Stamp Duty Exempt? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Stamp Duty Exempt?"
              style={{ marginBottom: "5px" }}
              required
            >
             Stamp Duty Exempt?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="stamp_duty_exempt"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.stamp_duty_exempt}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.stamp_duty_exempt !== null &&
              Tab3_Validation_Land_Var.stamp_duty_exempt !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.stamp_duty_exempt}
                </div>
              )}
          </Grid>

          {/* No claim bonus */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="No claim bonus"
              style={{ marginBottom: "5px" }}
              required
            >
             No claim bonus
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="no_claim_bonus"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.no_claim_bonus}
            >
             <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="60% - Level 1">60% - Level 1</MenuItem>
              <MenuItem value="50% - Level 2">50% - Level 2</MenuItem>
              <MenuItem value="40% - Level 3">40% - Level 3</MenuItem>
              <MenuItem value="30% - Level 4">30% - Level 4</MenuItem>
              <MenuItem value="20% - Level 5">20% - Level 5</MenuItem>
              <MenuItem value="0% - Level 6">0% - Level 6</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.no_claim_bonus !== null &&
              Tab3_Validation_Land_Var.no_claim_bonus !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.no_claim_bonus}
                </div>
              )}
          </Grid>

          {/* Payment Frequency */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Payment Frequency"
              style={{ marginBottom: "5px" }}
              required
            >
             Payment Frequency
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="payment_frequency"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.payment_frequency}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="Yearly">Yearly</MenuItem>
              <MenuItem value="Monthly">Monthly</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.payment_frequency !== null &&
              Tab3_Validation_Land_Var.payment_frequency !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.payment_frequency}
                </div>
              )}
          </Grid>

          {/* Preferred Day for installments */}
          {Tab3_Policycore_Land_Var.payment_frequency === "Monthly" && (
            <Grid container xs={12} direction="row" spacing={2}>
          <Grid item xs={6}>
                <InputLabel
                  htmlFor="Preferred Day for installments"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Preferred Day for installments
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                {/* <TextField
                  name="preffered_day_installment"
                  size="small"
                  type="tel"
                  maxLength="2"
                  variant="outlined"
                  autoComplete="off"
                  style={{ marginBottom: "20px" }}
                  inputProps={{ maxLength: 2 }}
                  fullWidth
                  onChange={onChangeField}
                  value={Tab3_Policycore_Land_Var.preffered_day_installment}
                  onKeyPress={(e) => validationForNumbOnly(e)}
                />
                {Tab3_Validation_Land_Var.preffered_day_installment !== null &&
              Tab3_Validation_Land_Var.preffered_day_installment !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.preffered_day_installment}
                </div>
              )} */}
              <Select 
                    name="preffered_day_installment"
                    onChange={onChangeField}
                    value={Tab3_Policycore_Land_Var.preffered_day_installment}
                    variant="outlined"
                    fullWidth
                    style={{
                     marginBottom: "20px",
                     height: "40px",
                     marginLeft: "6px",
                     width: "450px",
                         }}
                  >
                   {preferredDays.map(({day} , index) => (
                    <MenuItem  
                     key ={day}
                     disabled={index === 0}
                     value={day}
                    >
                     {day}
                     </MenuItem>
                     ))}
                  </Select>   
              </Grid>

              {/* Broker Fee (installments) */}
              <Grid item xs={6}>
                <InputLabel
                  htmlFor="Broker Fee (installments)"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Broker Fee (installments)
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                <TextField
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">$</InputAdornment>
                  ),
                }}
                  name="broker_fee_installment"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  style={{ marginBottom: "20px" }}
                  fullWidth
                  onChange={onChangeField}
                  value={Tab3_Policycore_Land_Var.broker_fee_installment}
                  onKeyPress={(e) => validationForNumbOnly(e)}
                />
                {Tab3_Validation_Land_Var.broker_fee_installment !== null &&
              Tab3_Validation_Land_Var.broker_fee_installment !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.broker_fee_installment}
                </div>
              )}
              </Grid>
              </Grid>
          )}

              {/* Optional cover for Theft by tenant */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Optional cover for Theft by tenant"
              style={{ marginBottom: "5px" }}
              required
            >
             Optional cover for Theft by tenant
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="cover_Theft_tenant"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.cover_Theft_tenant}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.cover_Theft_tenant !== null &&
              Tab3_Validation_Land_Var.cover_Theft_tenant !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.cover_Theft_tenant}
                </div>
              )}
          </Grid>

          {/* Optional cover for Loss of Rent */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Optional cover for Loss of Rent"
              style={{ marginBottom: "5px" }}
              required
            >
             Optional cover for Loss of Rent
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="cover_loss"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.cover_loss}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.cover_loss !== null &&
              Tab3_Validation_Land_Var.cover_loss !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.cover_loss}
                </div>
              )}
          </Grid>

          {/* Optional Cover for Accidental damage by tenants */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Optional Cover for Accidental damage by tenants"
              style={{ marginBottom: "5px" }}
              required
            >
             Optional Cover for Accidental damage by tenants
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="cover_Accidental_damage"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.cover_Accidental_damage}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.cover_Accidental_damage !== null &&
              Tab3_Validation_Land_Var.cover_Accidental_damage !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.cover_Accidental_damage}
                </div>
              )}
          </Grid>

              {/* Optional cover for Rent Default */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Optional cover for Rent Default"
              style={{ marginBottom: "5px" }}
              required
            >
             Optional cover for Rent Default
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="cover_rent_default"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.cover_rent_default}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.cover_rent_default !== null &&
              Tab3_Validation_Land_Var.cover_rent_default !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.cover_rent_default}
                </div>
              )}
          </Grid>

          {/* Sum insured amount for loss of rent ( SCTP) */}
          {Tab3_Policycore_Land_Var.cover_loss === "Yes" && (
            <Grid container xs={12} direction="row" spacing={2}>
              <Grid item xs={6}>
                <InputLabel
                  htmlFor="Sum insured amount for loss of rent ( SCTP)"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Sum insured amount for loss of rent ( SCTP)
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                <TextField
                  name="sum_ins_amount_loss"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  style={{ marginBottom: "20px" }}
                  fullWidth
                  onChange={onChangeField}
                  onKeyPress={(e) => validationForNumbOnly(e)}
                  value={Tab3_Policycore_Land_Var.sum_ins_amount_loss}
                />
                {Tab3_Validation_Land_Var.sum_ins_amount_loss !== null &&
              Tab3_Validation_Land_Var.sum_ins_amount_loss !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.sum_ins_amount_loss}
                </div>
              )}
              </Grid>
              </Grid>
          )}

              {/* Annual rental amount */}
          <Grid item xs={6}>
                <InputLabel
                  htmlFor="Annual rental amount"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Annual rental amount
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                <TextField
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">$</InputAdornment>
                  ),
                }}
                  name="annual_rent_amount"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  style={{ marginBottom: "20px" }}
                  fullWidth
                  onChange={onChangeField}
                  value={Tab3_Policycore_Land_Var.annual_rent_amount}
                  onKeyPress={(e) => validationForNumbOnly(e)}
                />
                {Tab3_Validation_Land_Var.annual_rent_amount !== null &&
              Tab3_Validation_Land_Var.annual_rent_amount !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.annual_rent_amount}
                </div>
              )}
              </Grid>

              {/* Weekly rental amount */}
          <Grid item xs={6}>
                <InputLabel
                  htmlFor="Weekly rental amount"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Weekly rental amount
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                <TextField
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">$</InputAdornment>
                  ),
                }}
                  name="weekly_rent_amount"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  style={{ marginBottom: "20px" }}
                  fullWidth
                  onChange={onChangeField}
                  value={Tab3_Policycore_Land_Var.weekly_rent_amount}
                  onKeyPress={(e) => validationForNumbOnly(e)}
                />
                {Tab3_Validation_Land_Var.weekly_rent_amount !== null &&
              Tab3_Validation_Land_Var.weekly_rent_amount !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.weekly_rent_amount}
                </div>
              )}
              </Grid>


          {/* Is the property Currently tenanted and is there a written residential lease/rental agreement?  */}
          {Tab3_Policycore_Land_Var.cover_rent_default === "Yes" && (
            <Grid container xs={12} direction="row" spacing={2}>
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Is the property Currently tenanted and is there a written residential lease/rental agreement? "
              style={{ marginBottom: "5px" }}
              required
            >
             Is the property Currently tenanted and is there a written residential lease/rental agreement? 
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="residential_lease_agreement"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.residential_lease_agreement}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.residential_lease_agreement !== null &&
              Tab3_Validation_Land_Var.residential_lease_agreement !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.residential_lease_agreement}
                </div>
              )}
          </Grid>

          {/* Has the tenant been behind on rent by more than 14 days? */}

          <Grid item xs={6}>
            <InputLabel
              htmlFor="Has the tenant been behind on rent by more than 14 days?"
              style={{ marginBottom: "5px" }}
              required
            >
             Has the tenant been behind on rent by more than 14 days?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="tenant_rent_14Days"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.tenant_rent_14Days}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.tenant_rent_14Days !== null &&
              Tab3_Validation_Land_Var.tenant_rent_14Days !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.tenant_rent_14Days}
                </div>
              )}
          </Grid>

          {/* Already insured under an existing landlord insurance policy including rent default cover that expired on the same day as the start of the period of insurance for this policy, */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Already insured under an existing landlord insurance policy including rent default cover that expired on the same day as the start of the period of insurance for this policy,"
              style={{ marginBottom: "5px" }}
              required
            >
             Already insured under an existing landlord insurance policy including rent default cover that expired on the same day as the start of the period of insurance for this policy,
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="landlord_insurance_policy"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.landlord_insurance_policy}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.landlord_insurance_policy !== null &&
              Tab3_Validation_Land_Var.landlord_insurance_policy !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.landlord_insurance_policy}
                </div>
              )}
          </Grid>
          </Grid>
          )}

          {/*SVU Excess Option 1 */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="SVU Excess Option 1"
              style={{ marginBottom: "5px" }}
              required
            >
              SVU Excess Option 1
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="svu_excess_option1"
              margin="none"
              variant="outlined"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.svu_excess_option1}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="300">$300</MenuItem>
              <MenuItem value="500">$500</MenuItem>
              <MenuItem value="600">$600</MenuItem>
              <MenuItem value="750">$750</MenuItem>
              <MenuItem value="800">$800</MenuItem>
              <MenuItem value="900">$900</MenuItem>
              <MenuItem value="1000">$1000</MenuItem>
              <MenuItem value="1250">$1250</MenuItem>
              <MenuItem value="1500">$1500</MenuItem>
              <MenuItem value="1750">$1750</MenuItem>
              <MenuItem value="2000">$2000</MenuItem>
              <MenuItem value="2500">$2500</MenuItem>
              <MenuItem value="3000">$3000</MenuItem>
              <MenuItem value="5000">$5000</MenuItem>
              <MenuItem value="7500">$7500</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.svu_excess_option1 !== null &&
              Tab3_Validation_Land_Var.svu_excess_option1 !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.svu_excess_option1}
                </div>
              )}
          </Grid>

          {/*SVU Excess Option 2 */}
          {/* <Grid item xs={6}>
            <InputLabel
              htmlFor="SVU Excess Option 2"
              style={{ marginBottom: "5px" }}
              required
            >
              SVU Excess Option 2
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="svu_excess_option2"
              margin="none"
              variant="outlined"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.svu_excess_option2}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="300">$300</MenuItem>
              <MenuItem value="500">$500</MenuItem>
              <MenuItem value="600">$600</MenuItem>
              <MenuItem value="750">$750</MenuItem>
              <MenuItem value="800">$800</MenuItem>
              <MenuItem value="900">$900</MenuItem>
              <MenuItem value="1000">$1000</MenuItem>
              <MenuItem value="1250">$1250</MenuItem>
              <MenuItem value="1500">$1500</MenuItem>
              <MenuItem value="1750">$1750</MenuItem>
              <MenuItem value="2000">$2000</MenuItem>
              <MenuItem value="2500">$2500</MenuItem>
              <MenuItem value="3000">$3000</MenuItem>
              <MenuItem value="5000">$5000</MenuItem>
              <MenuItem value="7500">$7500</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.svu_excess_option2 !== null &&
              Tab3_Validation_Land_Var.svu_excess_option2 !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.svu_excess_option2}
                </div>
              )}
          </Grid> */}

          {/*SVU Excess Option3 */}
          {/* <Grid item xs={6}>
            <InputLabel
              htmlFor="SVU Excess Option 3"
              style={{ marginBottom: "5px" }}
              required
            >
              SVU Excess Option 3
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="svu_excess_option3"
              margin="none"
              variant="outlined"
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab3_Policycore_Land_Var.svu_excess_option3}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="300">$300</MenuItem>
              <MenuItem value="500">$500</MenuItem>
              <MenuItem value="600">$600</MenuItem>
              <MenuItem value="750">$750</MenuItem>
              <MenuItem value="800">$800</MenuItem>
              <MenuItem value="900">$900</MenuItem>
              <MenuItem value="1000">$1000</MenuItem>
              <MenuItem value="1250">$1250</MenuItem>
              <MenuItem value="1500">$1500</MenuItem>
              <MenuItem value="1750">$1750</MenuItem>
              <MenuItem value="2000">$2000</MenuItem>
              <MenuItem value="2500">$2500</MenuItem>
              <MenuItem value="3000">$3000</MenuItem>
              <MenuItem value="5000">$5000</MenuItem>
              <MenuItem value="7500">$7500</MenuItem>
            </Select>
            {Tab3_Validation_Land_Var.svu_excess_option3 !== null &&
              Tab3_Validation_Land_Var.svu_excess_option3 !== "true" && (
                <div className="text-danger font-italic">
                  {Tab3_Validation_Land_Var.svu_excess_option3}
                </div>
              )}
          </Grid> */}

          {/* Broker Fee */}
          {/* <Grid item xs={6}>
                <InputLabel
                  htmlFor="Broker Fee"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Broker Fee
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                <TextField
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">$</InputAdornment>
                  ),
                }}
                  name="broker_fee"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  style={{ marginBottom: "20px" }}
                  fullWidth
                  onChange={onChangeField}
                  value={Tab3_Policycore_Land_Var.broker_fee}
                  onKeyPress={(e) => validationForNumbOnly(e)}
                />
              </Grid> */}

              <Grid item xs={6}>
            <Button
              variant="contained"
              color="secondary"
              style={{
                marginTop: "1rem",
                float: "left",
                width: "20%",
              }}
            onClick={() => 
            {
              exit();
            }}
            >
              EXIT
            </Button>
          </Grid>

          <Grid item xs={6}>
            <Button
              variant="contained"
              color="primary"
              style={{
                marginTop: "1rem",
                float: "right",
              }}
              onClick={() => navigation.next()}
            >
              NEXT
            </Button>
            <Button
        variant="contained"
        color="primary"
        // className="bg-warning"
        style={{
          marginTop: "1rem",
          float: "right",
          marginBottom: "50px",
          marginRight: "20px",
          width: "20%",
        }}
        onClick={() => navigation.previous()}
      >
        PREVIOUS
      </Button>
          </Grid>




    </Grid>
      </div>
    </Container>
  );
}

export default Tab3_Policycore_Land;