import React from 'react';
import "../css/homeStyle.css";
import {
  TextField,
  Container,
  Button,
  Select,
  InputLabel,
  MenuItem,
  Grid,
  Box,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import { Autocomplete } from "@mui/material";
import { streetTypes, stateAus } from "../constants/dropDownData";
import { Redirect } from 'react-router-dom';
import { validationForSpecialchar, validationForAlpha, validationForNumbOnly } from "../constants/validChecker";
import {
  // client_ID_validate,
  clientType_validate,
  firstName_validate,
  lastName_validate,
  companyName_validate,
  tradingAs_validate,
  streetNumber_validate,
  streetName_validate,
  streetType_validate,
  suburb_validate,
  state_validate,
  postCode_validate,
  phone_validate,
  email_validate,
  branch_validate,
  salesTeam_validate,
  serviceTeam_validate,
  insuredAddress_validate,
  street_number_insured_validate,
  street_name_insured_validate,
  street_type_insured_validate,
  suburb_insured_validate,
  state_insured_validate,
  postcode_insured_validate,
} from "../validationLand/Tab1_Validation_Land";
import { exit } from "../constants/exit";


const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    alignContent: "center",
    padding: theme.spacing(2),
    //textAlign: 'center',
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary,
  },

  // bg_color: {
  //   backgroundColor: "#f0f0f5",
  //   marginBottom: "5px",
  // },
}));

const returnClientLand = () => {
  return <Redirect to='/client_Land_link' />
}


const Tab1_Client_Land = ({
  Tab1_Client_Land_var,
  setTab1,
  Tab1_Validation_Land_Var,
  setTab1_validation,
  navigation,

}) => {

  const classes = useStyles();




  // call validation

  const onChangeField = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    setTab1(
      {
        ...Tab1_Client_Land_var,
        [name]: value,
      },
      () => {
        validationAfterChange(name, value);
      }
    );
  };

  const setStreetType = (val) => {
    console.log("val", val);
    // console.log(i);
    // console.log(streetType[0]);
    //  let name = e.target.name;
    let name = "street_type_postal";
    if (val) {
      let value = val.group;
      setTab1(
        {
          ...Tab1_Client_Land_var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    } else {
      let value = " ";
      setTab1(
        {
          ...Tab1_Client_Land_var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    }
  };

  //for insure

  const setStreetType_insured = (val) => {
    console.log("val", val);
    // console.log(i);
    // console.log(streetType[0]);
    //  let name = e.target.name;
    let name = "street_type_insured";
    if (val) {
      let value = val.group;
      setTab1(
        {
          ...Tab1_Client_Land_var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    } else {
      let value = " ";
      setTab1(
        {
          ...Tab1_Client_Land_var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    }
  };

  //set state for Aus
  const setStateAus = (val, event) => {
    console.log(val);
    if (val) {
      let name = "state_postal";
      let value = val.stAus;
      console.log(value);
      setTab1(
        {
          ...Tab1_Client_Land_var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    } else {
      let name = "state_postal";
      let value = " ";
      setTab1(
        {
          ...Tab1_Client_Land_var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    }
    //  console.log(event);
  };

  //set state for insure
  const setStateAus_insure = (val, event) => {
    console.log(val);
    if (val) {
      let name = "state_insured";
      let value = val.stAus;
      console.log(value);
      setTab1(
        {
          ...Tab1_Client_Land_var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    } else {
      let name = "state_insured";
      let value = " ";
      setTab1(
        {
          ...Tab1_Client_Land_var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    }
    //  console.log(event);
  };


  // call validation
  const validationAfterChange = (name, value) => {
    if (name === "client_type") {
      if (Tab1_Client_Land_var.client_type === "Company") {
        Tab1_Client_Land_var.client_title = " ";
        Tab1_Client_Land_var.client_firstName = "";
        Tab1_Client_Land_var.client_lastName = "";
      } else if (Tab1_Client_Land_var.client_type === "Individual") {
        Tab1_Client_Land_var.company_name = "";
        Tab1_Client_Land_var.trading_as = "";
      }
    }



    switch (name) {
      case "client_type": {
        clientType_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "client_firstName": {
        firstName_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "client_lastName": {
        lastName_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "company_name": {
        companyName_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "trading_as": {
        tradingAs_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }

      case "street_number_postal": {
        streetNumber_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "street_name_postal": {
        streetName_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "street_type_postal": {
        streetType_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "suburb_postal": {
        suburb_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "state_postal": {
        state_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "postcode_postal": {
        postCode_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "phone": {
        phone_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "email": {
        email_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "branch": {
        branch_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "sales_team": {
        salesTeam_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "service_team": {
        serviceTeam_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "insuredAddress": {
        insuredAddress_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "street_number_insured": {
        street_number_insured_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "street_name_insured": {
        street_name_insured_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "street_type_insured": {
        street_type_insured_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "suburb_insured": {
        suburb_insured_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "state_insured": {
        state_insured_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      case "postcode_insured": {
        postcode_insured_validate(value, Tab1_Validation_Land_Var, setTab1_validation);
        break;
      }
      default: {
        console.log("Not match to condition");
      }
    }
  };



  return (
    <Container maxWidth="md" style={{ marginBottom: "30px" }}>
      <div>
        <Grid
          container
          spacing={3}
          direction="row"
          justifyContent="center"
          alignItems="center"
        >
          <Grid
            item
            xs={12}
            textalign="center"
            justifyContent="center"
            container
          >
            <h3>GENERAL INFORMATION</h3>
          </Grid>



          <Grid item xs={5}>
            <InputLabel
              required
              htmlFor="Client Type"
              style={{ marginBottom: "5px" }}
            >
              Client Type
            </InputLabel>
          </Grid>

          <Grid item xs={7}>
            <Select
              name="client_type"
              margin="none"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "2px", height: "40px", marginLeft: "5px", width: "500px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab1_Client_Land_var.client_type}
              onClose={() =>
                validationAfterChange("client_type", Tab1_Client_Land_var.client_type)
              }
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Individual">Individual</MenuItem>
              <MenuItem value="Company">Company</MenuItem>

            </Select>

            {Tab1_Validation_Land_Var.client_type !== null &&
              Tab1_Validation_Land_Var.client_type !== "true" && (
                <div className="text-danger font-italic">
                  {Tab1_Validation_Land_Var.client_type}
                </div>
              )}
          </Grid>

          {Tab1_Client_Land_var.client_type === "Individual" && (
            <Grid item container xs={12} direction="row" spacing={2}>
              <Grid item xs={5}>
                <InputLabel
                  htmlFor="Client Title"
                  style={{ marginBottom: "5px" }}

                >
                  Client Title
                </InputLabel>
              </Grid>

              <Grid item xs={7}>
                <Select
                  margin="none"
                  name="client_title"
                  variant="outlined"
                  size="small"
                  autoComplete="off"
                  style={{ height: "40px", marginLeft: "7px", width: "500px" }}
                  fullWidth
                  onChange={onChangeField}
                  value={Tab1_Client_Land_var.client_title}
                >
                  <MenuItem disabled value=" ">
                    Please Select
                  </MenuItem>
                  <MenuItem value="Mr">Mr</MenuItem>
                  <MenuItem value="Miss">Miss</MenuItem>
                  <MenuItem value="Mrs">Mrs</MenuItem>
                  <MenuItem value="Ms">Ms</MenuItem>
                  <MenuItem value="Dr">Dr</MenuItem>
                </Select>

              </Grid>

              <Grid item xs={5}>
                {/* First Name */}
                <InputLabel
                  htmlFor="First Name"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  First Name
                </InputLabel>
              </Grid>

              <Grid item xs={7}>
                <TextField
                  name="client_firstName"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  style={{ marginBottom: "5px", marginLeft: "7px", width: "500px" }}
                  fullWidth
                  onChange={onChangeField}
                  value={Tab1_Client_Land_var.client_firstName}
                  onKeyPress={(e) => validationForAlpha(e)}
                />
                {Tab1_Validation_Land_Var.client_firstName !== null &&
                  Tab1_Validation_Land_Var.client_firstName !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab1_Validation_Land_Var.client_firstName}
                    </div>
                  )}
              </Grid>

              <Grid item xs={5}>
                {/* Last Name */}
                <InputLabel
                  htmlFor="Last Name"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Last Name
                </InputLabel>
              </Grid>

              <Grid item xs={7}>
                <TextField
                  name="client_lastName"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  style={{ marginLeft: "7px", width: "500px" }}
                  fullWidth
                  onChange={onChangeField}
                  value={Tab1_Client_Land_var.client_lastName}
                  onKeyPress={(e) => validationForAlpha(e)}
                />

                {Tab1_Validation_Land_Var.client_firstName !== null &&
                  Tab1_Validation_Land_Var.client_firstName !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab1_Validation_Land_Var.client_firstName}
                    </div>
                  )}

              </Grid>
            </Grid>
          )}


          {Tab1_Client_Land_var.client_type === "Company" && (
            <Grid item container xs={12} direction="row" spacing={2}>
              <Grid item xs={5} >
                <InputLabel
                  htmlFor="Company Name"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Company Name
                </InputLabel>
              </Grid>

              <Grid item xs={7}>
                <TextField
                  name="company_name"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  style={{ marginBottom: "10px", marginLeft: "8px", width: "500px" }}
                  fullWidth
                  onChange={onChangeField}
                  onKeyPress={(e) => validationForSpecialchar(e)}
                  value={Tab1_Client_Land_var.company_name}
                // onKeyPress={(e) => validationForAlpha(e)}
                />

                {Tab1_Validation_Land_Var.company_name !== null &&
                  Tab1_Validation_Land_Var.company_name !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab1_Validation_Land_Var.company_name}
                    </div>
                  )}

              </Grid>

              {/* Trading As */}
              <Grid item xs={5}>
                <InputLabel
                  htmlFor="Trading As"
                  style={{ marginBottom: "5px" }}

                >
                  Trading As
                </InputLabel>
              </Grid>

              <Grid item xs={7}>
                <TextField
                  name="trading_as"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  style={{ marginLeft: "7px", width: "500px" }}
                  fullWidth
                  onChange={onChangeField}
                  value={Tab1_Client_Land_var.trading_as}
                  onKeyPress={(e) => validationForAlpha(e)}
                />

              </Grid>
            </Grid>
          )}



          <Box
            component="span"
            sx={{
              width: "100%",
              p: 4,
              borderRadius: 8,
              border: "1px solid grey",
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
              // flexDirection: 'column',
            }}
            m={2}
            pt={3}
          >
            <Grid item xs={12} justifyContent="center" container>
              <Box
                sx={{
                  border: "1px solid grey",
                  borderRadius: 8,
                  padding: "6px 8px 0px 7px",
                  // alignItems:'center',
                  // alignContent:'center',
                  margin: "0px 0px 10px 2px",
                  justifyContent: "center",
                }}
              >
                <h5>POSTAL ADDRESS</h5>
              </Box>
            </Grid>

            {/* Unit Number */}

            <Grid item xs={4} style={{ padding: "8px" }}>
              <TextField
                // label="Unit Number (not req for PO Box)"
                name="unit_number_postal"
                label="Unit Number"
                size="small"
                type="text"
                // margin="normal"
                variant="outlined"
                autoComplete="off"
                style={{ width: "100%" }}
                fullWidth
                onChange={onChangeField}
                onKeyPress={(e) => validationForSpecialchar(e)}
                value={Tab1_Client_Land_var.unit_number_postal}

              />

              {Tab1_Validation_Land_Var.unit_number_postal !== null &&
                Tab1_Validation_Land_Var.unit_number_postal !== "true" && (
                  <div className="text-danger font-italic">
                    {Tab1_Validation_Land_Var.unit_number_postal}
                  </div>
                )}

            </Grid>

            {/* Street Number */}
            {/* <Grid item xs={5}>
            <InputLabel
              htmlFor="Street Number (not req for PO Box)"
              style={{ marginBottom: "5px" }}
              required
            >
              Street Number (not req for PO Box)
            </InputLabel>
          </Grid> */}
            <Grid item xs={4} style={{ padding: "8px" }}>
              <TextField
                // label="Street Number (not req for PO Box)"
                name="street_number_postal"
                label="Street Number"
                required
                // margin="normal"
                size="small"
                type="text"
                variant="outlined"
                autoComplete="off"
                style={{ width: "100%" }}
                fullWidth
                onChange={onChangeField}
                onKeyPress={(e) => validationForSpecialchar(e)}
                value={Tab1_Client_Land_var.street_number_postal}
              />

              {Tab1_Validation_Land_Var.street_number_postal !== null &&
                Tab1_Validation_Land_Var.street_number_postal !== "true" && (
                  <div className="text-danger font-italic">
                    {Tab1_Validation_Land_Var.street_number_postal}
                  </div>
                )}

            </Grid>

            {/* Street Name */}
            {/* <Grid item xs={5}>
            <InputLabel
              required
              htmlFor="Street Name"
              style={{ marginBottom: "5px" }}
            >
              Street Name
            </InputLabel>
          </Grid> */}
            <Grid item xs={4} style={{ padding: "8px" }}>
              <TextField
                // label="Street Name (or PO Box)"
                name="street_name_postal"
                required
                size="small"
                // margin="normal"
                label="Street Name"
                variant="outlined"
                autoComplete="off"
                style={{ width: "100%" }}
                fullWidth
                onChange={onChangeField}
                onKeyPress={(e) => validationForSpecialchar(e)}
                value={Tab1_Client_Land_var.street_name_postal}
              />

              {Tab1_Validation_Land_Var.client_firstName !== null &&
                Tab1_Validation_Land_Var.street_name_postal !== "true" && (
                  <div className="text-danger font-italic">
                    {Tab1_Validation_Land_Var.street_name_postal}
                  </div>
                )}
            </Grid>



            {/* Street Type */}
            <Grid item xs={4} style={{ padding: "8px" }}>
              <Autocomplete
                options={streetTypes}
                sx={{ width: "100%" }}
                isOptionEqualToValue={(option, value) =>
                  option.id === value.id
                }
                getOptionLabel={(option) =>
                  option.group
                    ? option.group
                    : Tab1_Client_Land_var.street_type_postal
                }
                defaultValue={"please Select"}
                name="street_type_postal"
                onChange={(event, value) => setStreetType(value)}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant="outlined"
                    value={Tab1_Client_Land_var.street_type_postal}
                    label="Street Type"
                    required
                    inputProps={{
                      ...params.inputProps,
                      style: { padding: "1px 0" },
                    }}
                    InputLabelProps={{ style: { fontSize: 15 } }}
                  />
                )}
              />

              {Tab1_Validation_Land_Var.street_type_postal !== null &&
                Tab1_Validation_Land_Var.street_type_postal !== "true" && (
                  <div className="text-danger font-italic">
                    {Tab1_Validation_Land_Var.street_type_postal}
                  </div>
                )}
            </Grid>


            {/* Suburb */}
            {/* <Grid item xs={5}>
            <InputLabel
              required
              htmlFor="Suburb"
              style={{ marginBottom: "5px" }}
            >
              Suburb
            </InputLabel>
          </Grid> */}
            <Grid item xs={4} style={{ padding: "8px" }}>
              <TextField
                label="Suburb"
                name="suburb_postal"
                size="small"
                style={{ width: "100%" }}
                required
                // margin="normal"
                variant="outlined"
                autoComplete="off"
                fullWidth
                onChange={onChangeField}
                onKeyPress={(e) => validationForAlpha(e)}
                value={Tab1_Client_Land_var.suburb_postal}
              />
              {Tab1_Validation_Land_Var.suburb_postal !== null &&
                Tab1_Validation_Land_Var.suburb_postal !== "true" && (
                  <div className="text-danger font-italic">
                    {Tab1_Validation_Land_Var.suburb_postal}
                  </div>
                )}
            </Grid>

            {/* State */}

            <Grid item xs={4} style={{ padding: "8px" }}>

              <Autocomplete
                options={stateAus}
                sx={{ width: "100%" }}
                isOptionEqualToValue={(option, value) =>
                  option.id === value.id
                }
                getOptionLabel={(option) =>
                  option.stAus
                    ? option.stAus : Tab1_Client_Land_var.state_postal
                }
                defaultValue={"Please Select"}
                name="state_postal"
                onChange={(event, value) => setStateAus(value, event)}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    variant="outlined"
                    fullWidth
                    value={Tab1_Client_Land_var.state_postal}
                    label="State"
                    required
                    inputProps={{
                      ...params.inputProps,
                      style: { padding: "1px 0" },
                    }}
                  />
                )}
              />

              {Tab1_Validation_Land_Var.state_postal !== null &&
                Tab1_Validation_Land_Var.state_postal !== "true" && (
                  <div className="text-danger font-italic">
                    {Tab1_Validation_Land_Var.state_postal}
                  </div>
                )}
            </Grid>

            {/* Post Code */}
            {/* <Grid item xs={5}>
            <InputLabel
              required
              htmlFor="Post Code"
              style={{ marginBottom: "5px" }}
            >
              Post Code
            </InputLabel>
          </Grid> */}
            <Grid item xs={4} style={{ padding: "8px" }}>
              <TextField
                name="postcode_postal"
                required
                label="Post Code"
                size="small"
                style={{ width: "100%" }}
                variant="outlined"
                type="number"
                autoComplete="off"
                fullWidth
                onChange={onChangeField}
                onKeyPress={(e) => validationForNumbOnly(e)}
                value={Tab1_Client_Land_var.postcode_postal}
              />
              {Tab1_Validation_Land_Var.postcode_postal !== null &&
                Tab1_Validation_Land_Var.postcode_postal !== "true" && (
                  <div className="text-danger font-italic">
                    {Tab1_Validation_Land_Var.postcode_postal}
                  </div>
                )}

            </Grid>
          </Box>
          {/* Phone */}
          <Grid item xs={5}>
            <InputLabel
              required
              htmlFor="Phone"
              style={{ marginBottom: "5px", width: "500px" }}
              maxLength="10"
            >
              Phone
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              name="phone"
              // inputProps={{ inputMode: 'numeric', pattern: '[0-9]*' }}
              size="small"
              style={{ marginLeft: "5px", width: "500px" }}
              variant="outlined"
              type="tel"
              maxLength="10"
              autoComplete="off"
              inputProps={{ maxLength: 10 }}
              fullWidth
              onChange={onChangeField}
              onKeyPress={(e) => validationForNumbOnly(e)}
              value={Tab1_Client_Land_var.phone}
            />
            {Tab1_Validation_Land_Var.phone !== null &&
              Tab1_Validation_Land_Var.phone !== "true" && (
                <div className="text-danger font-italic">
                  {Tab1_Validation_Land_Var.phone}
                </div>
              )}
          </Grid>

          {/* E-mail */}
          <Grid item xs={5}>
            <InputLabel
              required
              htmlFor="E-mail"
              style={{ marginBottom: "5px" }}
            >
              E-mail
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <TextField
              // label="E-mail"
              name="email"
              size="small"
              style={{ marginLeft: "5px", width: "500px" }}
              // margin="normal"
              variant="outlined"
              autoComplete="off"
              pattern="[a-zA-Z0-9.]+\@[a-zA-Z0-9.]+\.[a-zA-Z]+"
              fullWidth
              onChange={onChangeField}
              value={Tab1_Client_Land_var.email}
            />
            {Tab1_Validation_Land_Var.email !== null &&
              Tab1_Validation_Land_Var.email !== "true" && (
                <div className="text-danger font-italic">
                  {Tab1_Validation_Land_Var.email}
                </div>
              )}
          </Grid>


          {/* Is insured address the same as Postal Address */}
          <Grid item xs={5}>
            <InputLabel
              htmlFor=" Is the property heritage listed?"
              style={{ marginBottom: "5px" }}
              required
            >
              Is insured address the same as Postal Address?
            </InputLabel>
          </Grid>
          <Grid item xs={7}>
            <Select
              name="insuredAddress"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              value={Tab1_Client_Land_var.insuredAddress}
              style={{
                marginBottom: "20px",
                height: "40px",
                marginLeft: "6px",
                width: "500px",
              }}
              fullWidth
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab1_Validation_Land_Var.insuredAddress !== null &&
              Tab1_Validation_Land_Var.insuredAddress !== "true" && (
                <div className="text-danger font-italic">
                  {Tab1_Validation_Land_Var.insuredAddress}
                </div>
              )}
          </Grid>


          {Tab1_Client_Land_var.insuredAddress === "Yes" && (
            <Grid>
              {/* box component */}
              <Box
                component="span"
                sx={{
                  width: "100%",
                  // height: 00,
                  p: 4,
                  // alignItems: '',
                  borderRadius: 8,
                  border: "1px solid grey",
                  display: "flex",
                  flexWrap: "wrap",
                  // alignItems:'center',
                  justifyContent: "space-between",
                  flexDirection: "row",
                }}
                m={2}
                pt={3}
              >
                <Grid item xs={12} justifyContent="center" container>
                  <Box
                    sx={{
                      border: "1px solid grey",
                      borderRadius: 8,
                      padding: "6px 8px 0px 7px",
                      // alignItems:'center',
                      // alignContent:'center',
                      margin: "0px 0px 10px 2px",
                      justifyContent: "center",
                    }}
                  >
                    <h5>INSURED ADDRESS</h5>
                  </Box>
                </Grid>

                {/* Unit Number */}
                <Grid item xs={4} style={{ padding: "8px" }}>
                  <TextField
                    label="Unit Number"
                    name="unit_number_postal"
                    size="small"
                    type="text"
                    // margin="normal"
                    variant="outlined"
                    autoComplete="off"
                    disabled
                    onChange={onChangeField}
                    value={Tab1_Client_Land_var.unit_number_postal}
                    style={{ width: "100%" }}
                    InputLabelProps={{ style: { fontSize: 15 } }}
                    fullWidth
                  />
                </Grid>
                {/* Street Number */}
                <Grid item xs={4} style={{ padding: "8px" }}>
                  <TextField
                    // label="Street Number (not req for PO Box)"
                    name="street_number_postal"
                    label="Street Number"
                    size="small"
                    type="text"
                    variant="outlined"
                    autoComplete="new-password"
                    // onChange={onChangeField}
                    disabled
                    value={Tab1_Client_Land_var.street_number_postal}
                    style={{ width: "100%" }}
                    required
                    fullWidth
                    InputLabelProps={{ style: { fontSize: 15 } }}
                  />
                </Grid>

                <Grid item xs={4} style={{ padding: "8px" }}>
                  <TextField
                    // label="Street Name (or PO Box)"
                    name="street_name_postal"
                    size="small"
                    label="Street Name"
                    variant="outlined"
                    autoComplete="new-password"
                    // onChange={onChangeField}
                    disabled
                    value={Tab1_Client_Land_var.street_name_postal}
                    style={{ width: "100%" }}
                    required
                    fullWidth
                    InputLabelProps={{ style: { fontSize: 15 } }}
                  />
                </Grid>

                {/* Street Type */}
                <Grid item xs={4} style={{ padding: "8px" }}>
                  <Autocomplete
                    options={streetTypes}
                    sx={{ width: "100%" }}
                    isOptionEqualToValue={(option, value) =>
                      option.id === value.id
                    }
                    getOptionLabel={(option) =>
                      option.group
                        ? option.group
                        : Tab1_Client_Land_var.street_type_postal
                    }
                    defaultValue={"please Select"}
                    disabled
                    name="street_type_postal"
                    // onChange={(event, value) => setStreetType(value)}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        variant="outlined"
                        value={Tab1_Client_Land_var.street_type_postal}
                        label="Street Type"
                        required
                        inputProps={{
                          ...params.inputProps,
                          style: { padding: "1px 0" },
                        }}
                      />
                    )}
                  />
                </Grid>

                {/* Suburb */}
                <Grid item xs={4} style={{ padding: "8px" }}>
                  <TextField
                    // label="Suburb"
                    name="suburb_postal"
                    size="small"
                    style={{ width: "100%" }}
                    label="Suburb"
                    variant="outlined"
                    disabled
                    // onChange={onChangeField}
                    autoComplete="new-password"
                    value={Tab1_Client_Land_var.suburb_postal}
                    required
                    fullWidth
                    InputLabelProps={{ style: { fontSize: 15 } }}
                  />
                </Grid>

                {/* State */}
                <Grid item xs={4} style={{ padding: "8px" }}>
                  <Autocomplete
                    options={stateAus}
                    sx={{ width: "100%" }}
                    isOptionEqualToValue={(option, value) =>
                      option.id === value.id
                    }
                    getOptionLabel={(option) =>
                      option.stAus ? option.stAus : Tab1_Client_Land_var.state_postal
                    }
                    disabled
                    defaultValue={"Please Select"}
                    name="state_postal"
                    // onChange={(event, value) => setStateAus(value, event)}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        variant="outlined"
                        fullWidth
                        value={Tab1_Client_Land_var.state_postal}
                        label="State"
                        required
                        inputProps={{
                          ...params.inputProps,
                          style: { padding: "1px 0" },
                        }}
                      />
                    )}
                  />
                </Grid>

                {/* Post Code */}
                <Grid item xs={4} style={{ padding: "8px" }}>
                  <TextField
                    name="postcode_postal"
                    size="small"
                    style={{ width: "100%", marginLeft: '106%' }}
                    variant="outlined"
                    type="number"
                    label="Post Code"
                    autoComplete="new-password"
                    disabled
                    // onChange={onChangeField}
                    value={Tab1_Client_Land_var.postcode_postal}
                    required
                    fullWidth
                    InputLabelProps={{ style: { fontSize: 15 } }}
                  />
                </Grid>
              </Box>
            </Grid>
          )}

          {Tab1_Client_Land_var.insuredAddress === "No" && (
            <Grid>
              {/* box component */}
              <Box
                component="span"
                sx={{
                  width: "100%",
                  p: 4,
                  borderRadius: 8,
                  border: "1px solid grey",
                  display: "flex",
                  flexWrap: "wrap",
                  justifyContent: "space-between",
                  flexDirection: "row",
                }}
                m={2}
                pt={3}
              >
                <Grid item xs={12} justifyContent="center" container>
                  <Box
                    sx={{
                      border: "1px solid grey",
                      borderRadius: 8,
                      padding: "6px 8px 0px 7px",
                      margin: "0px 0px 10px 2px",
                      justifyContent: "center",
                    }}
                  >
                    <h5>INSURED ADDRESS</h5>
                  </Box>
                </Grid>

                {/* Unit Number */}
                <Grid item xs={4} style={{ padding: "8px" }}>
                  <TextField
                    name="unit_number_insured"
                    size="small"
                    type="text"
                    label="Unit Number"
                    variant="outlined"
                    autoComplete="off"
                    style={{ width: "100%" }}
                    fullWidth
                    onChange={onChangeField}
                    onKeyPress={(e) => validationForSpecialchar(e)}
                    value={Tab1_Client_Land_var.unit_number_insured}
                  />
                </Grid>

                {/* Street Number */}
                <Grid item xs={4} style={{ padding: "8px" }}>
                  <TextField
                    name="street_number_insured" //this value is should be passed into value field otherwise we cannot type
                    label="Street Number"
                    size="small"
                    type="text"
                    variant="outlined"
                    autoComplete="off"
                    onChange={onChangeField}
                    value={Tab1_Client_Land_var.street_number_insured}
                    onKeyPress={(e) => validationForSpecialchar(e)}
                    style={{ width: "100%" }}
                    required
                    fullWidth
                  />
                  {Tab1_Validation_Land_Var.street_number_insured !== null &&
                    Tab1_Validation_Land_Var.street_number_insured !==
                    "true" && (
                      <div className="text-danger font-italic">
                        {Tab1_Validation_Land_Var.street_number_insured}
                      </div>
                    )}
                </Grid>

                {/* Street Name */}
                <Grid item xs={4} style={{ padding: "8px" }}>
                  <TextField
                    name="street_name_insured"
                    size="small"
                    label="Street Name"
                    variant="outlined"
                    autoComplete="off"
                    onChange={onChangeField}
                    value={Tab1_Client_Land_var.street_name_insured}
                    onKeyPress={(e) => validationForSpecialchar(e)}
                    style={{ width: "100%" }}
                    required
                    fullWidth
                  />
                  {Tab1_Validation_Land_Var.street_name_insured !== null &&
                    Tab1_Validation_Land_Var.street_name_insured !==
                    "true" && (
                      <div className="text-danger font-italic">
                        {Tab1_Validation_Land_Var.street_name_insured}
                      </div>
                    )}
                </Grid>
                {/* Street Type */}
                <Grid item xs={4} style={{ padding: "8px" }}>
                  <Autocomplete
                    options={streetTypes}
                    sx={{ width: "100%" }}
                    isOptionEqualToValue={(option, value) =>
                      option.id === value.id
                    }
                    getOptionLabel={(option) =>
                      option.group
                        ? option.group
                        : Tab1_Client_Land_var.street_type_insured
                    }
                    defaultValue={"please Select"}
                    name="street_type_insured"
                    onChange={(event, value) => setStreetType_insured(value)}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        variant="outlined"
                        value={Tab1_Client_Land_var.street_type_insured}
                        label="Street Type"
                        required
                        inputProps={{
                          ...params.inputProps,
                          style: { padding: "1px 0" },
                        }}
                      />
                    )}
                  />
                  {Tab1_Validation_Land_Var.street_type_insured !== null &&
                    Tab1_Validation_Land_Var.street_type_insured !==
                    "true" && (
                      <div className="text-danger font-italic">
                        {Tab1_Validation_Land_Var.street_type_insured}
                      </div>
                    )}
                </Grid>

                {/* Suburb */}
                <Grid item xs={4} style={{ padding: "8px" }}>
                  <TextField
                    name="suburb_insured"
                    size="small"
                    style={{ width: "100%" }}
                    label="Suburb"
                    variant="outlined"
                    onChange={onChangeField}
                    onKeyPress={(e) => validationForAlpha(e)}
                    autoComplete="off"
                    value={Tab1_Client_Land_var.suburb_insured}
                    required
                    fullWidth
                  />
                  {Tab1_Validation_Land_Var.suburb_insured !== null &&
                    Tab1_Validation_Land_Var.suburb_insured !== "true" && (
                      <div className="text-danger font-italic">
                        { }
                        {Tab1_Validation_Land_Var.suburb_insured}
                      </div>
                    )}
                </Grid>

                {/* State */}
                <Grid item xs={4} style={{ padding: "8px" }}>
                  <Autocomplete
                    options={stateAus}
                    sx={{ width: "100%" }}
                    isOptionEqualToValue={(option, value) =>
                      option.id === value.id
                    }
                    getOptionLabel={(option) =>
                      option.stAus
                        ? option.stAus
                        : Tab1_Client_Land_var.state_insured
                    }
                    defaultValue={"Please Select"}
                    name="state_insured"
                    onChange={(event, value) => setStateAus_insure(value, event)}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        variant="outlined"
                        fullWidth
                        value={Tab1_Client_Land_var.state_insured}
                        label="State"
                        required
                        inputProps={{
                          ...params.inputProps,
                          style: { padding: "1px 0" },
                        }}
                      />
                    )}
                  />
                  {Tab1_Validation_Land_Var.state_insured !== null &&
                    Tab1_Validation_Land_Var.state_insured !== "true" && (
                      <div className="text-danger font-italic">
                        { }
                        {Tab1_Validation_Land_Var.state_insured}
                      </div>
                    )}
                </Grid>

                {/* Post Code */}
                <Grid item xs={4} style={{ padding: "8px" }}>
                  <TextField
                    name="postcode_insured"
                    size="small"
                    style={{ width: "100%", marginLeft: '106%' }}
                    variant="outlined"
                    type="number"
                    label="Post Code"
                    autoComplete="off"
                    onChange={onChangeField}
                    value={Tab1_Client_Land_var.postcode_insured}
                    required
                    onKeyPress={(e) => validationForNumbOnly(e)}
                    fullWidth
                  />
                  {Tab1_Validation_Land_Var.postcode_insured !== null &&
                    Tab1_Validation_Land_Var.postcode_insured !== "true" && (
                      <div className="text-danger font-italic">
                        { }
                        {Tab1_Validation_Land_Var.postcode_insured}
                      </div>
                    )}
                </Grid>
              </Box>
            </Grid>
          )}

          {/* navigation buttons */}
          <Grid item xs={6}>
            <Button
              variant="contained"
              color="secondary"
              style={{
                marginTop: "1rem",
                float: "left",
                width: "20%",
              }}
              onClick={() => {
                exit();
              }}
            >
              EXIT
            </Button>
          </Grid>

          <Grid item xs={6}>
            <Button
              variant="contained"
              color="primary"
              style={{
                marginTop: "1rem",
                float: "right",
              }}
              onClick={() => navigation.next()}
            >
              NEXT
            </Button>
          </Grid>

        </Grid>
      </div>
    </Container>


  );
}



//   };
export default Tab1_Client_Land;