// imports
import React, { useState } from "react";
import { useStep } from "react-hooks-helper";
import { useStateWithCallbackLazy } from "use-state-with-callback";

// local imports
import Tab1_Client_Land from './Tab1_Client_Land';
import Tab2_Importan_Question_Land from './Tab2_Importan_Question_Land';
import Tab3_Policycore_Land from './Tab3_Policycore_Land';
import Tab4_Building_Land from "./Tab4_Building_Land";
import Tab5_Contents_Land from './Tab5_Contents_Land';
import Tab6_Claims_Land from './Tab6_Claims_Land';
import navigationBarLand from "../coreLand/navigationBarLand";
import { addAllFormsValues, validateAllForms } from "./Land_Controller_clientLink";

const steps = [
    { id: "Tab1_Client_Land" },
    { id: "Tab2_Importan_Question_Land" },
    { id: "Tab3_Policycore_Land" },
    { id: "Tab4_Building_Land" },
    { id: "Tab5_Contents_Land" },
    { id: "Tab6_Claims_Land" },
  ];

const ClientLandLink =() => {
    const { step, navigation } = useStep({
        steps,
        initialStep: 0,
    });


// tab1 variable object defined
const [Tab1_Client_Land_var, setTab1] = useStateWithCallbackLazy({
  client_ID: "",
  client_type: " ",
  client_title: " ",
  client_firstName: "",
  client_lastName: "",
  company_name: "",
  trading_as: "",
  reference_code: "",
  unit_number_postal: "",
  street_number_postal: "",
  street_name_postal: "",
  street_type_postal: "Please Select",
  suburb_postal: "",
  state_postal: "Please Select",
  postcode_postal: '',
  phone: "",
  email: "",
  branch: " ",
  sales_team: " ",
  service_team: " ",
  insuredAddress:" ",
  unit_number_insured: "",
  street_number_insured: "",
  street_name_insured: "",
  street_type_insured: "Please Select",
  suburb_insured: "",
  state_insured: "Please Select",
  postcode_insured: "",

  


  // client_id: null,
  // client_type: "Individual",
  // client_title: "Mr",
  // client_firstName: "Hi",
  // client_lastName: "Sj",
  // company_name: null,
  // trading_as: null,
  // unit_number_postal: null,
  // street_number_postal: "12",
  // street_name_postal: "ji",
  // street_type_postal: "BEND",
  // suburb_postal: "xs",
  // state_postal: "NSW",
  // postcode_postal: "1234",
  // phone: "1234567890",
  // email: "abc@gmail.com",
  // branch: "Insurance Brokers Australia",
  // sales_team: "Gary Hayward",
  // service_team: "Brisbane",
  // insuredAddress: "Yes",
  // unit_number_insured:"",
  // street_number_insured: "",
  // street_name_insured: "",
  // street_type_insured: " ",
  // suburb_insured: "",
  // state_insured: " ",
  // postcode_insured: "",
  });

  // tab1 validation
  const [Tab1_Validation_Land_Var, setTab1_validation] = useState({
    client_id: null,
    client_type: null,
    client_title: null,
    client_firstName: null,
    client_lastName: null,
    company_name: null,
    trading_as: null,
    unit_number_postal: null,
    street_number_postal: "",
    street_name_postal: "",
    street_type_postal: " ",
    suburb_postal: "",
    state_postal: " ",
    postcode_postal: "",
    phone: "",
    email: "",
    branch: "",
    sales_team: "",
    service_team: "",
    insuredAddress: null,
    unit_number_insured:"",
    street_number_insured: "",
    street_name_insured: "",
    street_type_insured: " ",
    suburb_insured: "",
    state_insured: " ",
    postcode_insured: "",

   
  });


   // tab2 variable object defined
   const [Tab2_Importan_Question_Land_var, setTab2] = useStateWithCallbackLazy({
    any_policy_decline_last5years: "No",
    howmany_policy_decline_last5years: "1",
    howmany_policy_decline_last3years: "1",
    reason_forThe_decline: "Cancelled due to change in risk outside the insurer's underwriting guidelines",
    clime_decline: "No",
    reason_clime_decline: "",
    any_criminal_conviction: "No",
    property_everBe_unoccupied: "No",
    checking_onThe_property: "No",
    why_property_unoccupied: "",
    under_construction_renovation: "No",
    renovation_over$100000: "No",
    value_of_renovation: "",
    start_date_renovations: new Date(),
    Estimated_completion_date: new Date(),
    what_work_undertaken: "",
    building_not_secure: "No",
    contract_works_policy: "No",
    external_roof_walls: "No",
    rain_intoThe_building: "No",
    poorly_maintained: "No",
    property_heritage: "No",
    details_heritage_list: "",
    bed_breakfast: "No",
    boarding_house: "No",
    used_hostel: "No",
    community_public_housing: "No",
    home_office_surgery: "No",
    social_housing_service: "No",
    property_redevelopment: "No",
    property_trust: "No",
    flooded_last_10years: "No",
    property_used_farming: " ",
    business_activity_conducted: " ",

    // any_policy_decline_last5years: "No",
    // howmany_policy_decline_last5years: "1",
    // howmany_policy_decline_last3years: "1",
    // reason_forThe_decline: "Cancelled due to change in risk outside the insurer's underwriting guidelines",
    // clime_decline: "No",
    // reason_clime_decline: "required to be disclosed",
    // any_criminal_conviction: "No",
    // property_everBe_unoccupied: "No",
    // checking_onThe_property: "No",
    // why_property_unoccupied: "No",
    // under_construction_renovation: "No",
    // renovation_over$100000: "No",
    // value_of_renovation: "1000",
    // start_date_renovations: new Date(),
    // Estimated_completion_date: new Date(),
    // what_work_undertaken: "undertaken",
    // building_not_secure: "No",
    // contract_works_policy: "No",
    // external_roof_walls: "No",
    // rain_intoThe_building: "No",
    // poorly_maintained: "No",
    // property_heritage: "No",
    // details_heritage_list: "heritage listing",
    // bed_breakfast: "No",
    // boarding_house: "No",
    // used_hostel: "No",
    // community_public_housing: "No",
    // home_office_surgery: "No",
    // social_housing_service: "No",
    // property_redevelopment: "No",
    // property_trust: "No",
    // flooded_last_10years: "No",
    // property_used_farming: "No",
    // business_activity_conducted: "Other",
    });

    // tab2 validation
    const [Tab2_Validation_Land_Var, setTab2_validation] = useState({
      howmany_policy_decline_last5years: null,
      howmany_policy_decline_last3years: null,
      reason_forThe_decline: null,
      reason_clime_decline: "",
      checking_onThe_property: null,
      why_property_unoccupied: "",
      renovation_over$100000: null,
      value_of_renovation: "",
      start_date_renovations: "",
      Estimated_completion_date: "",
      what_work_undertaken: "",
      details_heritage_list: "",
      business_activity_conducted: null,
    });
  
    let myCurrentToDate = new Date();
  // console.log(myCurrentToDate.getFullYear());
  myCurrentToDate.setFullYear(myCurrentToDate.getFullYear() + 1);

   // set default year reduced by 16 from current year for date of birth
   let tempYear= new Date();
   tempYear.setFullYear(tempYear.getFullYear()-16);
   
    // tab3 variable object defined
  const [Tab3_Policycore_Land_Var, setTab3] = useStateWithCallbackLazy({
    cover_type_accidential: " ",
    occupancy_home: " ",
    property_managed: " ",
    building_content: " ",
    building_sum_insured: "",
    content_ins_amount: "",
    policy_from_date: new Date,
    policy_to_date: myCurrentToDate,
    dob_oldest_insured: new Date(tempYear),  //dob:date of birth
    currently_hold_insurence: " ",
    current_insurer: " ",
    policyholder_retired: " ",
    interested_parties: " ",
    holding_broker: " ",
    holding_underwriter: " ",
    stamp_duty_exempt: " ",
    no_claim_bonus: " ",
    payment_frequency: " ",
    preffered_day_installment: "Please Select",
    broker_fee_installment: "",
    cover_Theft_tenant: " ",
    cover_loss: " ",
    sum_ins_amount_loss: "",
    annual_rent_amount: "",
    weekly_rent_amount: "",
    cover_rent_default: " ",
    cover_Accidental_damage: " ",
    tenant_rent_14Days: " ",
    residential_lease_agreement: " ",
    landlord_insurance_policy: " ",
    svu_excess_option1: " ",
    svu_excess_option2: " ",
    svu_excess_option3: " ",
    broker_fee: " ",

    // cover_type_accidential: "Accidental Damage",
    // occupancy_home: "Rented to tenants (Long Term)",
    // property_managed: "Landlord manages the property",
    // building_content: "Building only",
    // building_sum_insured: "1000",
    // content_ins_amount: "1000",
    // policy_from_date: new Date(myCurrentToDate),
    // policy_to_date: new Date(myCurrentToDate),
    // dob_oldest_insured: new Date(tempYear),  //dob:date of birth
    // currently_hold_insurence: "No",
    // policyholder_retired: "No",
    // interested_parties: "Adelaide Bank",
    // holding_broker: "No",
    // holding_underwriter: "AAMI",
    // stamp_duty_exempt: "No",
    // no_claim_bonus: "60% - Level 1",
    // payment_frequency: "Monthly",
    // preffered_day_installment: "25",
    // broker_fee_installment: "1000",
    // cover_Theft_tenant: "No",
    // cover_loss: "No",
    // sum_ins_amount_loss: "1000",
    // annual_rent_amount: "1000",
    // weekly_rent_amount: "1000",
    // cover_rent_default: "No",
    // cover_Accidental_damage: "No",
    // tenant_rent_14Days: "No",
    // residential_lease_agreement: "Yes",
    // landlord_insurance_policy: "No",
    // svu_excess_option1: "300",
    // svu_excess_option2: "300",
    // svu_excess_option3: "300",
    // broker_fee: "600",
  });

  // tab3 validation
  const [Tab3_Validation_Land_Var, setTab3_validation] = useState({
    occupancy_home: null,
    property_managed: null,
    building_content: null,
    policy_from_date: null,
    policy_to_date: null,
    dob_oldest_insured: null,
    currently_hold_insurence: null,
    interested_parties: null,
    holding_broker: null,
    holding_underwriter: null,
    stamp_duty_exempt: null,
    no_claim_bonus: null,
    payment_frequency: null,
    preffered_day_installment: "",
    broker_fee_installment: "",
    cover_Theft_tenant: null,
    cover_loss: null,
    sum_ins_amount_loss: "",
    annual_rent_amount: "",
    weekly_rent_amount: "",
    cover_rent_default: null,
    tenant_rent_14Days: null,
    landlord_insurance_policy: null,
    svu_excess_option1: null,
    svu_excess_option2: null,
    svu_excess_option3: null,
   
  });


  // tab4 variable object defined

  const [Tab4_Building_Land_Var, setTab4 ] = useStateWithCallbackLazy({
    

    building_type: " ",
    free_standing_what_built: " ",
    apartment_what_type: " ",
    semi_deteched_what_type: " ",
    semi_deteched_body_corprate: " ",
    dewelling_what_describe: " ",
    multiple_unit_insured_all: " ",
    multiple_unit_number: "",
    multiple_unit_insured_building: " ",
    multiple_unit_total_units: " ",
    construction_period: " ",
    original_year_build: "",
    construction_wall: " ",
    roof_construction: " ",
    numbers_of_bathrooms: " ",
    numbers_of_bedrooms: " ",
    construction_quality: " ",
    storeys: " ",
    unit_building_level: " ",
    building_size: " ",
    effected_by_flood: " ",
    main_water_supply: " ",
    window_security: " ",
    door_security: " ",
    burglar_alarm: " ",
    smoke_detector: " ",
    building_construction12months: "No",
    outdoor_spa: " ",
    located_below_ground: " ",
    flood_mitigration: " ",
    occupancy_certificate: " ",
    register_body_corprote: " ",
    strata_title: " ",
    person_living_the_building: "",


    // building_type: "Other",
    // free_standing_what_built: " ",
    // apartment_what_type: " ",
    // semi_deteched_what_type: " ",
    // semi_deteched_body_corprate: " ",
    // dewelling_what_describe: "Shed",
    // multiple_unit_insured_all: " ",
    // multiple_unit_number: "",
    // multiple_unit_insured_building: " ",
    // multiple_unit_total_units: " ",
    // construction_period: "1946-1959",
    // original_year_build: "2020",
    // construction_wall: "Metal",
    // roof_construction: "Slate",
    // numbers_of_bathrooms: "1",
    // numbers_of_bedrooms: "1",
    // construction_quality: "Quality",
    // storeys: "1",
    // unit_building_level: " ",
    // building_size: " ",
    // effected_by_flood: "No",
    // main_water_supply: "No",
    // window_security: "Security screens",
    // door_security: "Security cards",
    // burglar_alarm: "None",
    // smoke_detector: "None",
    // building_construction12months: "No",
    // outdoor_spa: "No",
    // located_below_ground: "No",
    // flood_mitigration: "No",
    // occupancy_certificate: "No",
    // register_body_corprote: "No",
    // strata_title: "No",
    // person_living_the_building: "12",
  });

  // tab4 validation
  const [Tab4_Validation_Land_Var, setTab4_validation] = useState({
    building_type: null,
    free_standing_what_built: null,
    apartment_what_type: null,
    unit_building_level: null,
    semi_deteched_what_type: null,
    semi_deteched_body_corprate: null,
    multiple_unit_insured_all: null,
    multiple_unit_number:"",
    multiple_unit_insured_building: null,
    multiple_unit_total_units: null,
    construction_period: null,
    original_year_build:"",
    construction_wall: null,
    roof_construction: null,
    numbers_of_bathrooms: null,
    numbers_of_bedrooms: null,
    construction_quality: null,
    storeys: null,
    building_size:"",
    effected_by_flood: null,
    main_water_supply: null,
    window_security: null,
    door_security: null,
    burglar_alarm: null,
    smoke_detector: null,
    building_construction12months: null,
    outdoor_spa: null,
    located_below_ground: null,
    flood_mitigration: null,
    occupancy_certificate: null,
    register_body_corprote: null,
    strata_title: null,
    person_living_the_building:"",
  });

 
  const [Tab5_Contents_Land_Var, setTab5] = useStateWithCallbackLazy([]);

  const [Tab5_Validation_Land_Var, setTab5_validation] = useState([]);



  const [Tab6_Claims_Land_Var, setTab6] = useStateWithCallbackLazy([]);

  const [Tab6_Validation_Land_Var, setTab6_validation] = useState([]);

  

  // submit all forms
  const submitAllForms = () => {
    return addAllFormsValues(
      Tab1_Client_Land_var,
      Tab2_Importan_Question_Land_var,
      Tab3_Policycore_Land_Var,
      Tab4_Building_Land_Var,
      Tab5_Contents_Land_Var,
      Tab6_Claims_Land_Var
    ).then((res) => {
      console.log(res);
      if(res.status === 200){
        return res.data.Message;
      } else {
        return false;
      }
      
    }).catch((error) => {
      console.log(error);
      return false;
    });
  }; // end of submit function

  // validate all forms
  const isAllFormsValid = () => {
    const isValid = validateAllForms(
      Tab1_Client_Land_var,
      Tab2_Importan_Question_Land_var,
      Tab3_Policycore_Land_Var,
      Tab4_Building_Land_Var,
      Tab5_Contents_Land_Var,
      Tab6_Claims_Land_Var,
    );
    return isValid;
  };

 // props: tab1, creating props to provide to every tab components
 const props1 = {
    Tab1_Client_Land_var,
    setTab1,
    Tab1_Validation_Land_Var, 
    setTab1_validation,
    navigation,
  };

  // props: tab2, creating props to provide to every tab components
 const props2 = {
    Tab2_Importan_Question_Land_var,
    setTab2,
    Tab2_Validation_Land_Var,
    setTab2_validation,
    navigation,
  };

  const props3 = {
    Tab3_Policycore_Land_Var,
    setTab3,
    Tab3_Validation_Land_Var, 
    setTab3_validation,
    navigation,
    
  };
  const props4 = {
    Tab4_Building_Land_Var,
    setTab4,
    Tab4_Validation_Land_Var, 
    setTab4_validation,
    navigation,
    
  };

  const props5 = {
    Tab5_Contents_Land_Var,
    setTab5,
    Tab5_Validation_Land_Var, 
    setTab5_validation,
    navigation,
  };

  const props6 = {
    Tab6_Claims_Land_Var,
    setTab6,
    Tab6_Validation_Land_Var, 
    setTab6_validation,
    isAllFormsValid,
    submitAllForms,
    navigation
    
  };

  
    const displayTabs = () => {
        switch (step.id){
            default: return <Tab1_Client_Land />;
            case "Tab1_Client_Land": return <Tab1_Client_Land {...props1} />;
            case "Tab2_Importan_Question_Land": return <Tab2_Importan_Question_Land {...props2} />;
            case "Tab3_Policycore_Land": return <Tab3_Policycore_Land {...props3}/>;
            case "Tab4_Building_Land": return <Tab4_Building_Land {...props4}/>;
            case "Tab5_Contents_Land": return <Tab5_Contents_Land {...props5}/>;
            case "Tab6_Claims_Land": return <Tab6_Claims_Land {...props6}/>;
            
        }
    }

     // set props to navigation bar
  const propsNavBarLand = {
    step,
    navigation,
    Tab1_Client_Land_var,
    Tab2_Importan_Question_Land_var,
    Tab3_Policycore_Land_Var,
    Tab4_Building_Land_Var,
    Tab5_Contents_Land_Var,
    Tab6_Claims_Land_Var,
  };



    // return ui content
    return (<div>
        {navigationBarLand(propsNavBarLand)}
        {displayTabs()}
     </div>);
}

export default ClientLandLink;