// import { getThemeProps } from "@material-ui/styles";

import {
    Tab1_Validation_Land
} from "../validationLand/Tab1_Validation_Land";
import {
    Tab2_Validation_Land
} from "../validationLand/Tab2_Validation_Land";
import {
    Tab3_Validation_Land
} from "../validationLand/Tab3_Validation_Land";
import {
    Tab4_Validation_Land
} from "../validationLand/Tab4_Validation_Land";
import {
    Tab5_Validation_Land
} from "../validationLand/Tab5_Validation_Land";
import {
    Tab6_Validation_Land
} from "../validationLand/Tab6_Validation_Land";
import axios from "axios";
import {API} from "../config";
// import { saveAs } from 'file-saver';

export const validateAllForms = (
    Tab1_Client_Land_var,
    Tab2_Importan_Question_Land_var,
    Tab3_Policycore_Land_Var,
    Tab4_Building_Land_Var,
    Tab5_Contents_Land_Var,
    Tab6_Claims_Land_Var
) => {
    let isValid = true;
    isValid = isValid * Tab1_Validation_Land(Tab1_Client_Land_var);
    isValid = isValid * Tab2_Validation_Land(Tab2_Importan_Question_Land_var);
    isValid = isValid * Tab3_Validation_Land(Tab3_Policycore_Land_Var);
    isValid = isValid * Tab4_Validation_Land(Tab4_Building_Land_Var);
    isValid = isValid * Tab5_Validation_Land(Tab5_Contents_Land_Var);
    isValid = isValid * Tab6_Validation_Land(Tab6_Claims_Land_Var);
    return isValid;
};

export const addAllFormsValues = async (
    Tab1_Client_Land_var,
    Tab2_Importan_Question_Land_var,
    Tab3_Policycore_Land_Var,
    Tab4_Building_Land_Var,
    Tab5_Contents_Land_Var,
    Tab6_Claims_Land_Var
) => {

    const dataTabLand = {
        ClientLand: Tab1_Client_Land_var,
        IqLand : Tab2_Importan_Question_Land_var,
        PolicycoreLand : Tab3_Policycore_Land_Var,
        Buildingland : Tab4_Building_Land_Var,
        ContentsLand : Tab5_Contents_Land_Var,
        ClaimsLand : Tab6_Claims_Land_Var 
    };

   
    try{
        const response =  await axios.post(`${API}/quotationLandlords/addQuotationLandlords`,dataTabLand)
        // const response2 = await axios.get(`${API}/quotationLandlords/fetchPdf`, { responseType: 'blob' });
        // const pdfBlob = new Blob([response2.data], { type: 'application/pdf' });
        // saveAs(pdfBlob, 'newPdf.pdf');

        // axios.all([response, response2]).then(axios.spread((...responses) => {
        //     const responseOne = responses[0];
        //     const responseTwo = responses[1];
        //     console.log('hi');
        //     console.log(responseOne , responseTwo);
        //   })).catch(errors => {
        //     console.log(errors);
        //   })

        // Promise.all([response, response2]).then(function(values) {
        //     console.log(values);
        //   });
        
    //     .then(() => axios.get(`${API}/quotationLandlords/fetchPdf`, { responseType: 'blob' }))
    //     .then((res) => {
    //      const pdfBlob = new Blob([res.data], { type: 'application/pdf' });

    //     saveAs(pdfBlob, 'newPdf.pdf');
    //   })
        // then(await axios.post(`${API}/quotationLandlords/createPDF`,dataTabLand));

        return response;
    }
    catch(err){
        console.log(err);
    }
    
};