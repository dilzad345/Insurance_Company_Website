import React from "react";
import "../css/homeStyle.css";
import {
  TextField,
  Container,
  Button,
  Select,
  InputLabel,
  MenuItem,
  Grid,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import DatePicker from "react-datepicker";
import { Redirect } from 'react-router-dom';
import {validationForSpecialchar , validationForAlpha , validationForNumbOnly} from "../constants/validChecker";
import {
  howmany_policy_decline_last5years_validate,
  howmany_policy_decline_last3years_validate,
  reason_forThe_decline_validate,
  reason_clime_decline_validate,
  checking_onThe_property_validate,
  why_property_unoccupied_validate,
  renovation_over$100000_validate,
  value_of_renovation_validate,
  start_date_renovations_validate,
  Estimated_completion_date_validate,
  what_work_undertaken_validate,
  details_heritage_list_validate,
  business_activity_conducted_validate,
} from "../validationLand/Tab2_Validation_Land";
import { exit } from "../constants/exit";

const useStyles = makeStyles((theme) => ({
    root: {
      flexGrow: 1,
      alignContent: "center",
      padding: theme.spacing(2),
      //textAlign: 'center',
    },
    paper: {
      padding: theme.spacing(2),
      textAlign: "center",
      color: theme.palette.text.secondary,
    },
  
    // bg_color: {
    //   backgroundColor: "#f0f0f5",
    //   marginBottom: "5px",
    // },
  }));

  const returnClientLand = () => {
    return <Redirect to='/client_Land_link' />
  }

 

  const Tab2_Importan_Question_Land = ({
    Tab2_Importan_Question_Land_var,
    setTab2,
    Tab2_Validation_Land_Var, 
    setTab2_validation,
    navigation,
  }) => {

    const classes = useStyles();

    const onChangeField = (e) => {
      let name = e.target.name;
      let value = e.target.value;
      setTab2(
        {
          ...Tab2_Importan_Question_Land_var,
          [name]: value,
        },
        () => {
          validationAfterChange(name, value);
        }
      );
    };

    const setToDate = (date,value) => {
      console.log(date);
      setTab2({
        ...Tab2_Importan_Question_Land_var,
        start_date_renovations: date,
        
      });
      start_date_renovations_validate(date, Tab2_Validation_Land_Var, setTab2_validation);
    };

    const setFromDate = (date,value) => {
      console.log(date);
      setTab2({
        ...Tab2_Importan_Question_Land_var,
        Estimated_completion_date: date,
        
      });
      Estimated_completion_date_validate(date, Tab2_Validation_Land_Var, setTab2_validation);
    };

    const validationAfterChange = (name, value) => {
      if (name === "any_policy_decline_last5years") {
        if (value === "No") {
          setTab2({
            ...Tab2_Importan_Question_Land_var,
            any_policy_decline_last5years: "No",
            howmany_policy_decline_last5years: "",
            howmany_policy_decline_last3years: "",
            reason_forThe_decline: "",
          });
        }
      }

      if (name === "clime_decline") {
        if (value === "No") {
          setTab2({
            ...Tab2_Importan_Question_Land_var,
            clime_decline: "No",
            reason_clime_decline: "",
            
          });
        }
      }

      if (name === "property_used_farming") {
        if (value === "No") {
          setTab2({
            ...Tab2_Importan_Question_Land_var,
            property_used_farming: "No",
            business_activity_conducted: "",
            
          });
        }
      }

      if (name === "property_everBe_unoccupied") {
        if (value === "No") {
          setTab2({
            ...Tab2_Importan_Question_Land_var,
            property_everBe_unoccupied: "No",
            checking_onThe_property: "",
            why_property_unoccupied: "",
          });
        }
      }

      if (name === "under_construction_renovation") {
        if (value === "No") {
          setTab2({
            ...Tab2_Importan_Question_Land_var,
            under_construction_renovation: "No",
            renovation_over$100000: "",
            value_of_renovation: "",
            start_date_renovations: "",
            Estimated_completion_date: "",
            what_work_undertaken: "",
            building_not_secure: "",
            contract_works_policy: "",
            external_roof_walls: "",
            rain_intoThe_building: "",
            
          });
        }
      }

      if (name === "renovation_over$100000") {
        if (value === "No") {
          setTab2({
            ...Tab2_Importan_Question_Land_var,
            renovation_over$100000: "No",
            value_of_renovation: "",
            start_date_renovations: "",
            Estimated_completion_date: "",
            what_work_undertaken: "",
            
          });
        }
      }

      if (name === "property_heritage") {
        if (value === "No") {
          setTab2({
            ...Tab2_Importan_Question_Land_var,
            property_heritage: "No",
            details_heritage_list: "",
            
          });
        }
      }

      switch (name) {
        case "howmany_policy_decline_last5years": {
          howmany_policy_decline_last5years_validate(value, Tab2_Validation_Land_Var, setTab2_validation);
          break;
        }
        case "howmany_policy_decline_last3years": {
          howmany_policy_decline_last3years_validate(value, Tab2_Validation_Land_Var, setTab2_validation);
          break;
        }
        case "reason_forThe_decline": {
          reason_forThe_decline_validate(value, Tab2_Validation_Land_Var, setTab2_validation);
          break;
        }
        case "reason_clime_decline": {
          reason_clime_decline_validate(value, Tab2_Validation_Land_Var, setTab2_validation);
          break;
        }
        case "checking_onThe_property": {
          checking_onThe_property_validate(value, Tab2_Validation_Land_Var, setTab2_validation);
          break;
        }
        case "why_property_unoccupied": {
          why_property_unoccupied_validate(value, Tab2_Validation_Land_Var, setTab2_validation);
          break;
        }
  
        case "renovation_over$100000": {
          renovation_over$100000_validate(value, Tab2_Validation_Land_Var, setTab2_validation);
          break;
        }
        case "value_of_renovation": {
          value_of_renovation_validate(value, Tab2_Validation_Land_Var, setTab2_validation);
          break;
        }
        case "start_date_renovations": {
          start_date_renovations_validate(value, Tab2_Validation_Land_Var, setTab2_validation);
          break;
        }
        case "Estimated_completion_date": {
          Estimated_completion_date_validate(value, Tab2_Validation_Land_Var, setTab2_validation);
          break;
        }
        case "what_work_undertaken": {
          what_work_undertaken_validate(value, Tab2_Validation_Land_Var, setTab2_validation);
          break;
        }
        case "details_heritage_list": {
          details_heritage_list_validate(value, Tab2_Validation_Land_Var, setTab2_validation);
          break;
        }
        case "business_activity_conducted": {
          business_activity_conducted_validate(value, Tab2_Validation_Land_Var, setTab2_validation);
          break;
        }
       
        default: {
          console.log("Not match to condition");
        }
      }


    };

    


    return (
        <Container maxWidth="md" style={{ marginBottom: "30px" }}>
      <div >
        <Grid
          container
          spacing={3}
          direction="row"
          justifyContent="center"
          alignItems="center"
        >
          <Grid xs={12} item={true} justifyContent="center" container style={{ marginTop: "25px" }}>
            <h3>IMPORTANT QUESTIONS</h3>
          </Grid>

          

          {/* Any insurance policy declined or cancelled by the insurer in the last 5 years */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Any insurance policy declined or cancelled by the insurer in the last 5 years"
              style={{ marginBottom: "5px" }}
              required
            >
             Any insurance policy declined or cancelled by the insurer in the last 5 years
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="any_policy_decline_last5years"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.any_policy_decline_last5years}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Last 12 months">Last 12 months</MenuItem>
              <MenuItem value="Last 24 months">Last 24 months</MenuItem>
              <MenuItem value="Last 5 years">Last 5 years</MenuItem>
            </Select>
          </Grid>

          {/* How many policies has the insured had declined or cancelled in the last 5 years */}
          {Tab2_Importan_Question_Land_var.any_policy_decline_last5years !== "No" && (
            <Grid container xs={12} direction="row" spacing={2}>
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Any insurance policy declined or cancelled by the insurer in the last 5 years"
              style={{ marginBottom: "5px" }}
              required
            >
             How many policies has the insured had declined or cancelled in the last 5 years
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="howmany_policy_decline_last5years"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.howmany_policy_decline_last5years}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="1">1</MenuItem>
              <MenuItem value="2">2</MenuItem>
              <MenuItem value="3">3</MenuItem>
              <MenuItem value="4">4</MenuItem>
              <MenuItem value="5">5</MenuItem>
              <MenuItem value="6">6</MenuItem>
              <MenuItem value="more than 6">more than 6</MenuItem>
            </Select>
            {Tab2_Validation_Land_Var.howmany_policy_decline_last5years !== null &&
              Tab2_Validation_Land_Var.howmany_policy_decline_last5years !== "true" && (
                <div className="text-danger font-italic">
                  {Tab2_Validation_Land_Var.howmany_policy_decline_last5years}
                </div>
              )}
          </Grid>
          

          {/* How many policies has the insured had declined or cancelled in the last 3 years (Allianz) */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Any insurance policy declined or cancelled by the insurer in the last 5 years"
              style={{ marginBottom: "5px" }}
              required
            >
             How many policies has the insured had declined or cancelled in the last 3 years (Allianz)
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="howmany_policy_decline_last3years"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.howmany_policy_decline_last3years}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="1">1</MenuItem>
              <MenuItem value="2">2</MenuItem>
              <MenuItem value="3">3</MenuItem>
              <MenuItem value="4">4</MenuItem>
              <MenuItem value="5">5</MenuItem>
              <MenuItem value="6">6</MenuItem>
              <MenuItem value="more than 6">more than 6</MenuItem>
            </Select>
            {Tab2_Validation_Land_Var.howmany_policy_decline_last3years !== null &&
              Tab2_Validation_Land_Var.howmany_policy_decline_last3years !== "true" && (
                <div className="text-danger font-italic">
                  {Tab2_Validation_Land_Var.howmany_policy_decline_last3years}
                </div>
              )}
          </Grid>
          

          {/* What was the reason for the insured's most recent policy decline / cancellation? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="What was the reason for the insured's most recent policy decline / cancellation?"
              style={{ marginBottom: "5px" }}
              required
            >
             What was the reason for the insured's most recent policy decline / cancellation?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="reason_forThe_decline"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.reason_forThe_decline}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="Cancelled due to change in risk outside the insurer's underwriting guidelines">Cancelled due to change in risk outside the insurer's underwriting guidelines</MenuItem>
              <MenuItem value="Cancelled due to a total loss claim">Cancelled due to a total loss claim</MenuItem>
              <MenuItem value="Cancelled due to non-payment">Cancelled due to non-payment</MenuItem>
              <MenuItem value="Declined due to change in Insurer Underwriting Guidelines">Declined due to change in Insurer Underwriting Guidelines</MenuItem>
              <MenuItem value="Declined due to claims history">Declined due to claims history</MenuItem>
              <MenuItem value="Declined due to payment history">Declined due to payment history</MenuItem>
              <MenuItem value="Other">Other</MenuItem>
            </Select>
            {Tab2_Validation_Land_Var.reason_forThe_decline !== null &&
              Tab2_Validation_Land_Var.reason_forThe_decline !== "true" && (
                <div className="text-danger font-italic">
                  {Tab2_Validation_Land_Var.reason_forThe_decline}
                </div>
              )}
          </Grid>
          </Grid>
          )}
          

          {/* Had a claim declined */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Had a claim declined"
              style={{ marginBottom: "5px" }}
              required
            >
             Had a claim declined
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="clime_decline"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.clime_decline}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Last 1 year">Last 1 year</MenuItem>
              <MenuItem value="Last 2 years">Last 2 years</MenuItem>
              <MenuItem value="Last 3 years">Last 3 years</MenuItem>
              <MenuItem value="Last 4 years">Last 4 years</MenuItem>
              <MenuItem value="Last 5 years">Last 5 years</MenuItem>
            </Select>
          </Grid>

          
          {/* Why was the claim declined? */}
          {Tab2_Importan_Question_Land_var.clime_decline !== "No" && (
            <Grid container xs={12} direction="row" spacing={2}>
          <Grid item xs={6}>
                <InputLabel
                  htmlFor="Why was the claim declined?"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Why was the claim declined?
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                <TextField
                  name="reason_clime_decline"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  onKeyPress={(e) => validationForAlpha(e)}
                  // style={{ marginBottom: "5px" , marginLeft: "7px" , width: "500px" }}
                  fullWidth
                  onChange={onChangeField}
                  value={Tab2_Importan_Question_Land_var.reason_clime_decline}
                />
                {Tab2_Validation_Land_Var.reason_clime_decline !== null &&
              Tab2_Validation_Land_Var.reason_clime_decline !== "true" && (
                <div className="text-danger font-italic">
                  {Tab2_Validation_Land_Var.reason_clime_decline}
                </div>
              )}
              </Grid>
              </Grid>
          )}

              {/* Had any criminal conviction relating to fraud, theft, dishonesty, arson, or malicious damage in the last 5 years (excluding any convictions that are not legally required to be disclosed)? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Had any criminal conviction relating to fraud, theft, dishonesty, arson, or malicious damage in the last 5 years (excluding any convictions that are not legally required to be disclosed)?"
              style={{ marginBottom: "5px" }}
              required
            >
             Had any criminal conviction relating to fraud, theft, dishonesty, arson, or malicious damage in the last 5 years (excluding any convictions that are not legally required to be disclosed)?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="any_criminal_conviction"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.any_criminal_conviction}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

          {/* Will the property ever be unoccupied for more than 60 or 90 or 100 continuous days? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Will the property ever be unoccupied for more than 60 or 90 or 100 continuous days?"
              style={{ marginBottom: "5px" }}
              required
            >
             Will the property ever be unoccupied for more than 60 or 90 or 100 continuous days?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="property_everBe_unoccupied"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.property_everBe_unoccupied}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Up to 60 days">Up to 60 days</MenuItem>
              <MenuItem value="Up to 90 days">Up to 90 days</MenuItem>
              <MenuItem value="Up to 120 days">Up to 120 days</MenuItem>
            </Select>
          </Grid>

          {/* Is anyone checking on the property (managing agent / mail collected) and Maintenance? */}
          {Tab2_Importan_Question_Land_var.property_everBe_unoccupied !== "No" && (
            <Grid container xs={12} direction="row" spacing={2}>
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Is anyone checking on the property (managing agent / mail collected) and Maintenance?"
              style={{ marginBottom: "5px" }}
              required
            >
             Is anyone checking on the property (managing agent / mail collected) and Maintenance?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="checking_onThe_property"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.checking_onThe_property}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab2_Validation_Land_Var.checking_onThe_property !== null &&
              Tab2_Validation_Land_Var.checking_onThe_property !== "true" && (
                <div className="text-danger font-italic">
                  {Tab2_Validation_Land_Var.checking_onThe_property}
                </div>
              )}
          </Grid>

          {/* Please provide information as to why property is unoccupied and the security measures */}
          <Grid item xs={6}>
                <InputLabel
                  htmlFor="Please provide information as to why property is unoccupied and the security measures"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Please provide information as to why property is unoccupied and the security measures
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                <TextField
                  name="why_property_unoccupied"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  onKeyPress={(e) => validationForAlpha(e)}
                  // style={{ marginBottom: "5px" , marginLeft: "7px" , width: "500px" }}
                  fullWidth
                  onChange={onChangeField}
                  value={Tab2_Importan_Question_Land_var.why_property_unoccupied}
                />
                {Tab2_Validation_Land_Var.why_property_unoccupied !== null &&
              Tab2_Validation_Land_Var.why_property_unoccupied !== "true" && (
                <div className="text-danger font-italic">
                  {Tab2_Validation_Land_Var.why_property_unoccupied}
                </div>
              )}
              </Grid>
              </Grid>
          )}

          {/* Is the home under construction / renovation? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Is the home under construction / renovation?"
              style={{ marginBottom: "5px" }}
              required
            >
             Is the home under construction / renovation?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="under_construction_renovation"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.under_construction_renovation}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

          {/* Is the renovation over $100,000? */}
          {Tab2_Importan_Question_Land_var.under_construction_renovation === "Yes" && (
            <Grid container xs={12} direction="row" spacing={2}>
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Is the renovation over $100,000?"
              style={{ marginBottom: "5px" }}
              required
            >
             Is the renovation over $100,000?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="renovation_over$100000"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.renovation_over$100000}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab2_Validation_Land_Var.renovation_over$100000 !== null &&
              Tab2_Validation_Land_Var.renovation_over$100000 !== "true" && (
                <div className="text-danger font-italic">
                  {Tab2_Validation_Land_Var.renovation_over$100000}
                </div>
              )}
          </Grid>


          {/* Value of the renovation */}
          {Tab2_Importan_Question_Land_var.renovation_over$100000 !== "No" && (
            <Grid container xs={12} direction="row" spacing={2}>
          <Grid item xs={6}>
                <InputLabel
                  htmlFor="Value of the renovation"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Value of the renovation
                </InputLabel>
                </Grid>

              <Grid item xs={6}>
                <TextField
                  name="value_of_renovation"
                  size="small"
                  variant="outlined"
                  onKeyPress={(e) => validationForNumbOnly(e)}
                  autoComplete="off"
                  // style={{ marginBottom: "5px" , marginLeft: "7px" , width: "500px" }}
                  fullWidth
                  onChange={onChangeField}
                  value={Tab2_Importan_Question_Land_var.value_of_renovation}
                />
                {Tab2_Validation_Land_Var.value_of_renovation !== null &&
              Tab2_Validation_Land_Var.value_of_renovation !== "true" && (
                <div className="text-danger font-italic">
                  {Tab2_Validation_Land_Var.value_of_renovation}
                </div>
              )}
              </Grid>

              {/* Start date of renovations */}
              <Grid item xs={6}>
                <InputLabel
                  htmlFor="Start date of renovations"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Start date of renovations
                </InputLabel>
              </Grid>

          <Grid item xs={6}>

            <DatePicker
              selected={Tab2_Importan_Question_Land_var.start_date_renovations}
              dateFormat="dd/MM/yyyy"
              name="start_date_renovations"
              minDate={new Date()}
              onChange={setToDate}
              value={Tab2_Importan_Question_Land_var.start_date_renovations}
              variant="outlined"
              autoComplete="off"
              fullWidth
              className="date-picker-align"
              

            />
            {Tab2_Validation_Land_Var.start_date_renovations !== null &&
              Tab2_Validation_Land_Var.start_date_renovations !== "true" && (
                <div className="text-danger font-italic">
                  {Tab2_Validation_Land_Var.start_date_renovations}
                </div>
              )}

            <div className="text-danger font-italic" >

            </div>

          </Grid>

              

              {/* Estimated completion date */}
          <Grid item xs={6}>
                <InputLabel
                  htmlFor="Estimated completion date"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Estimated completion date
                </InputLabel>
              </Grid>

              <Grid item xs={6}>

            <DatePicker
              selected={Tab2_Importan_Question_Land_var.Estimated_completion_date}
              dateFormat="dd/MM/yyyy"
              name="Estimated_completion_date"
              minDate={new Date()}
              onChange={setFromDate}
              value={Tab2_Importan_Question_Land_var.Estimated_completion_date}
              variant="outlined"
              autoComplete="off"
              fullWidth
              className="date-picker-align"
              

            />
             {Tab2_Validation_Land_Var.Estimated_completion_date !== null &&
              Tab2_Validation_Land_Var.Estimated_completion_date !== "true" && (
                <div className="text-danger font-italic">
                  {Tab2_Validation_Land_Var.Estimated_completion_date}
                </div>
              )}

            <div className="text-danger font-italic" >

            </div>

          </Grid>

              {/* <Grid item xs={6}>
                <TextField
                  name="Estimated_completion_date"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  // style={{ marginBottom: "5px" , marginLeft: "7px" , width: "500px" }}
                  fullWidth
                  value={Tab2_Importan_Question_Land_var.Estimated_completion_date}
                />
              </Grid> */}

              {/* What is the works being undertaken? */}
          <Grid item xs={6}>
                <InputLabel
                  htmlFor="What is the works being undertaken?"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  What is the works being undertaken?
                </InputLabel>
          </Grid>

              <Grid item xs={6}>
                <TextField
                  name="what_work_undertaken"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  onKeyPress={(e) => validationForAlpha(e)}
                  // style={{ marginBottom: "5px" , marginLeft: "7px" , width: "500px" }}
                  fullWidth
                  onChange={onChangeField}
                  value={Tab2_Importan_Question_Land_var.what_work_undertaken}
                />
                {Tab2_Validation_Land_Var.what_work_undertaken !== null &&
              Tab2_Validation_Land_Var.what_work_undertaken !== "true" && (
                <div className="text-danger font-italic">
                  {Tab2_Validation_Land_Var.what_work_undertaken}
                </div>
              )}
              </Grid>
              </Grid>
          )}


          {/* The building is not secure? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="The building is not secure?"
              style={{ marginBottom: "5px" }}
              required
            >
             The building is not secure?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="building_not_secure"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.building_not_secure}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

          {/* Is there a contract works policy in place? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Is there a contract works policy in place?"
              style={{ marginBottom: "5px" }}
              required
            >
             Is there a contract works policy in place?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="contract_works_policy"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.contract_works_policy}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

          {/* There is an opening in the external roof or walls? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="There is an opening in the external roof or walls?"
              style={{ marginBottom: "5px" }}
              required
            >
             There is an opening in the external roof or walls?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="external_roof_walls"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.external_roof_walls}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

          {/* Rain and weather can get into the building? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Rain and weather can get into the building?"
              style={{ marginBottom: "5px" }}
              required
            >
            Rain and weather can get into the building?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="rain_intoThe_building"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.rain_intoThe_building}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>
          </Grid>
          )}

          {/* Is the property poorly maintained or in poor condition? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Is the property poorly maintained or in poor condition?"
              style={{ marginBottom: "5px" }}
              required
            >
             Is the property poorly maintained or in poor condition?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="poorly_maintained"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.poorly_maintained}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

          {/* Is the property heritage listed? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Is the property heritage listed?"
              style={{ marginBottom: "5px" }}
              required
            >
            Is the property heritage listed?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="property_heritage"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.property_heritage}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

          {/* What is the works being undertaken?
          <Grid item xs={6}>
                <InputLabel
                  htmlFor="What is the works being undertaken?"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  What is the works being undertaken?
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                <TextField
                  name="details_heritage_list"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  // style={{ marginBottom: "5px" , marginLeft: "7px" , width: "500px" }}
                  fullWidth
                />
              </Grid> */}

              {/* Provide more details on the heritage listing */}
              {Tab2_Importan_Question_Land_var.property_heritage === "Yes" && (
            <Grid container xs={12} direction="row" spacing={2}>
          <Grid item xs={6}>
                <InputLabel
                  htmlFor="Provide more details on the heritage listing"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Provide more details on the heritage listing
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                <TextField
                  name="details_heritage_list"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  // style={{ marginBottom: "5px" , marginLeft: "7px" , width: "500px" }}
                  fullWidth
                  onChange={onChangeField}
                  value={Tab2_Importan_Question_Land_var.details_heritage_list}
                />
                {Tab2_Validation_Land_Var.details_heritage_list !== null &&
              Tab2_Validation_Land_Var.details_heritage_list !== "true" && (
                <div className="text-danger font-italic">
                  {Tab2_Validation_Land_Var.details_heritage_list}
                </div>
              )}
              </Grid>
              </Grid>
          )}

               {/* Is the property used for Bed and Breakfast? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Is the property used for Bed and Breakfast?"
              style={{ marginBottom: "5px" }}
              required
            >
            Is the property used for Bed and Breakfast?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="bed_breakfast"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.bed_breakfast}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

              {/*Is the property used as a Boarding House? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Is the property used as a Boarding House?"
              style={{ marginBottom: "5px" }}
              required
            >
            Is the property used as a Boarding House?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="boarding_house"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.boarding_house}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

          {/* Is the property used as a Hostel? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Is the property used as a Hostel?"
              style={{ marginBottom: "5px" }}
              required
            >
            Is the property used as a Hostel?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="used_hostel"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.used_hostel}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

          {/* Is the property used for community housing or public housing? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Is the property used for community housing or public housing?"
              style={{ marginBottom: "5px" }}
              required
            >
            Is the property used for community housing or public housing?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="community_public_housing"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.community_public_housing}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

          {/* Is the property used for business purposes other than home office or surgery? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Is the property used for business purposes other than home office or surgery?"
              style={{ marginBottom: "5px" }}
              required
            >
            Is the property used for business purposes other than home office or surgery?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="home_office_surgery"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.home_office_surgery}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

          {/* Are you a charity registered with any regulatory, government or community organisation providing community, public or social housing accommodation services? Or do you lease, or intend to lease property to businesses or organisations that provide community, public or social housing accommodation services? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Are you a charity registered with any regulatory, government or community organisation providing community, public or social housing accommodation services? Or do you lease, or intend to lease property to businesses or organisations that provide community, public or social housing accommodation services?"
              style={{ marginBottom: "5px" }}
              required
            >
            Are you a charity registered with any regulatory, government or community organisation providing community, public or social housing accommodation services? Or do you lease, or intend to lease property to businesses or organisations that provide community, public or social housing accommodation services?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="social_housing_service"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.social_housing_service}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

          {/* Are you a business whose main business activity is residential building construction, demolition, land or property redevelopment? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Are you a business whose main business activity is residential building construction, demolition, land or property redevelopment?"
              style={{ marginBottom: "5px" }}
              required
            >
            Are you a business whose main business activity is residential building construction, demolition, land or property redevelopment?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="property_redevelopment"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.property_redevelopment}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

          {/* Are you a self-managed superannuation fund (SMSF), the trustee of a SMSF, or a property trust? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Are you a self-managed superannuation fund (SMSF), the trustee of a SMSF, or a property trust?"
              style={{ marginBottom: "5px" }}
              required
            >
           Are you a self-managed superannuation fund (SMSF), the trustee of a SMSF, or a property trust?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="property_trust"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.property_trust}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

          {/* Has the land where the building or contents are situated been flooded or inundated by water more than once in the last 10 years? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Has the land where the building or contents are situated been flooded or inundated by water more than once in the last 10 years?"
              style={{ marginBottom: "5px" }}
              required
            >
             Has the land where the building or contents are situated been flooded or inundated by water more than once in the last 10 years?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="flooded_last_10years"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.flooded_last_10years}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

          {/* Property to be used for farming (including hobby farming), or earning an income other than residential rental income? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Property to be used for farming (including hobby farming), or earning an income other than residential rental income?"
              style={{ marginBottom: "5px" }}
              required
            >
           Property to be used for farming (including hobby farming), or earning an income other than residential rental income?
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="property_used_farming"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.property_used_farming}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem disabled value=" ">Please Select</MenuItem>
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
          </Grid>

          {/* Select the type of business activity conducted */}
          {Tab2_Importan_Question_Land_var.property_used_farming === "Yes" && (
            <Grid container xs={12} direction="row" spacing={2}>
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Select the type of business activity conducted"
              style={{ marginBottom: "5px" }}
              required
            >
           Select the type of business activity conducted
            </InputLabel>
          </Grid>
          <Grid item xs={6}>
            <Select
              name="business_activity_conducted"
              margin="none"
              variant="outlined"
              autoComplete="off"
              value={Tab2_Importan_Question_Land_var.business_activity_conducted}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              onChange={onChangeField}
            >
              <MenuItem disabled value="">Please Select</MenuItem>
              <MenuItem value="Farming (annual  turnover < $10000)">{"Farming (annual  turnover < $10,000)"}</MenuItem>
              <MenuItem value="Farming (annual  turnover > $10000)">{"Farming (annual  turnover >$10,000)"}</MenuItem>
              <MenuItem value="Other">Other</MenuItem>
            </Select>
            {Tab2_Validation_Land_Var.business_activity_conducted !== null &&
              Tab2_Validation_Land_Var.business_activity_conducted !== "true" && (
                <div className="text-danger font-italic">
                  {Tab2_Validation_Land_Var.business_activity_conducted}
                </div>
              )}
          </Grid>
          </Grid>
          )}

          <Grid item xs={6}>
            <Button
              variant="contained"
              color="secondary"
              style={{
                marginTop: "1rem",
                float: "left",
                width: "20%",
              }}
            onClick={() => 
            {
              exit();
            }}
            >
              EXIT
            </Button>
          </Grid>

          <Grid item xs={6}>
            <Button
              variant="contained"
              color="primary"
              style={{
                marginTop: "1rem",
                float: "right",
              }}
              onClick={() => navigation.next()}
            >
              NEXT
            </Button>
            <Button
        variant="contained"
        color="primary"
        // className="bg-warning"
        style={{
          marginTop: "1rem",
          float: "right",
          marginBottom: "50px",
          marginRight: "20px",
          width: "20%",
        }}
        onClick={() => navigation.previous()}
      >
        PREVIOUS
      </Button>
          </Grid>

          </Grid>
          </div>
    </Container>
    );
}

export default Tab2_Importan_Question_Land;