import React from 'react';

const adminAddUser = () => {

return (
    <div>Hello</div>
);

}

export default adminAddUser;