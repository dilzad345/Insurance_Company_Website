import React, { useState } from "react";
// import * as FaIcons from "react-icons/fa";
// import * as AiIcons from "react-icons/ai";
import { Link } from "react-router-dom";
import { SidebarData } from "./SidebarData";
import "../css/Navbar.css";
import { IconContext } from "react-icons";
import {validation} from "../user/validation";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { API } from "../config";
import {
  TextField,
  Button,
  Select,
  InputLabel,
  MenuItem,
  Grid,
  Box,
} from "@material-ui/core";

const UserDashboard = () => {
  const [user, setUser] = useState({
    email: "",
    firstName: "",
    lastName: "",
    userRole: "broker",
    password: "",
    loading: false,
    redirectToReferrer: false,
  });

  const {
    email,
    password,
    firstName,
    lastName,
    userRole,
    // error,
    // redirectToReferrer,
  } = user;

  const handleChange = (e) => {
    let name = e.target.name;
    let value = e.target.value;

    setUser({
      ...user,
      error: false,
      [name]: value,
    });
    setError(validation(user));
  };

  const [errors, setError] = useState({
    passwordValid: false,
    emailValid: false,
  });

  // click submit button method
  const clickSubmit = (event) => {
    event.preventDefault();
    console.log("usr: " + email + " pass: " + password);

    const data = {
      userEmail: email,
      firstName: firstName,
      lastName: lastName,
      userRole: userRole,
      password: password,
    };

    // add user method to call server response POST
    axios
      .post(`${API}/user/admin/addUser`, data)
      .then((response) => {
        console.log(response);
      })
      .catch((error) => {
        console.log(error);
      });

    // const notify = () =>
    toast.success("User Entered Successfully!", {
      position: "bottom-center",
      autoClose: 5000,
      hideProgressBar: true,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });
  };

  const [sidebar, setSidebar] = useState(false);

  const showSidebar = () => setSidebar(!sidebar);

  return (
    // <>

    <div>
      <div>
        <IconContext.Provider value={{ color: "#fff" }}>
          <div className="navbar">
            {/* <Link to="#" className="menu-bars">
              <FaIcons.FaBars onClick={showSidebar} />
            </Link> */}
          </div>
        </IconContext.Provider>
        {/* <Grid item xs={4}> */}
        {/* <nav className={sidebar ? "nav-menu active" : "nav-menu"}> */}
        <nav className={"nav-menu active"}>
          <ul className="nav-menu-items" onClick={showSidebar}>
            <li className="navbar-toggle">
              <Link to="#" className="menu-bars">
                {/* <AiIcons.AiOutlineClose /> */}
              </Link>
            </li>
            {SidebarData.map((item, index) => {
              return (
                <li key={index} className={item.cName}>
                  <Link to={item.path}>
                    {item.icon}
                    <span>{item.title}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
        {/* </Grid> */}
      </div>

      {/* <Grid item xs={12}> */}
      <div className="add-user-box">
        <Box
          // component="form"
          // sx={{
          //   "& .MuiTextField-root": { m: 1, width: "25ch" },
          // }}
          noValidate
          autoComplete="off"
        >
          <form>
            <Grid
              container
              spacing={2}
              direction="row"
              justifyContent="center"
              alignItems="center"
            >
              <Grid item xs={6}>
                <InputLabel
                  htmlFor="First Name"
                  style={{ marginBottom: "5px" }}
                >
                  First Name
                </InputLabel>
                <TextField
                  name="firstName"
                  value={user.firstName}
                  onChange={handleChange}
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  style={{ marginBottom: "10px" }}
                  fullWidth
                />

                <div className="form-group">
                  <InputLabel
                    htmlFor="Last Name"
                    style={{ marginBottom: "5px" }}
                  >
                    Last Name
                  </InputLabel>
                  <TextField
                    name="lastName"
                    value={user.lastName}
                    onChange={handleChange}
                    size="small"
                    variant="outlined"
                    autoComplete="off"
                    fullWidth
                  />
                </div>

                <InputLabel htmlFor="Email" style={{ marginBottom: "5px" }}>
                  Email
                </InputLabel>
                <TextField
                  variant="outlined"
                  size="small"
                  required
                  onChange={handleChange}
                  type="email"
                  name="email"
                  value={user.email}
                  fullWidth
                />
                <div style={{ marginBottom: "1rem" }}>
                  {errors.email === "Email is required" && (
                    <p style={{ color: "orange" }}> {errors.email}</p>
                  )}
                  {errors.email === "Email is invalid" && (
                    <p style={{ color: "red" }}> {errors.email}</p>
                  )}
                </div>
              </Grid>

              <Grid item xs={6}>
                <InputLabel htmlFor="Password" style={{ marginBottom: "5px" }}>
                  Password
                </InputLabel>

                <TextField
                  variant="outlined"
                  onChange={handleChange}
                  type="password"
                  name="password"
                  value={user.password}
                  fullWidth
                  size="small"
                />
                <div style={{ marginBottom: "1rem" }}>
                  {errors.password === "Password is required" && (
                    <p style={{ color: "orange" }}>{errors.password}</p>
                  )}
                  {errors.password ===
                    "Password must be more than 6 characters" && (
                    <p style={{ color: "red" }}>{errors.password}</p>
                  )}
                </div>

                <InputLabel htmlFor="User Role" style={{ marginBottom: "5px" }}>
                  User Role
                </InputLabel>
                <Select
                  name="userRole"
                  value={user.userRole}
                  onChange={handleChange}
                  variant="outlined"
                  style={{ height: "40px" }}
                  fullWidth
                >
                  <MenuItem value={"broker"}>Broker</MenuItem>
                  <MenuItem value={"admin"}>Admin</MenuItem>
                  <MenuItem value={"underWriter"}>Under Writer</MenuItem>
                </Select>
              </Grid>
              <Button
                onClick={clickSubmit}
                variant="contained"
                color="primary"
                style={{
                  marginTop: "1rem",
                }}
              >
                Submit
              </Button>
            </Grid>
            <div>
              {/* <button onClick={notify}>Notify !</button> */}
              <ToastContainer
                style={{
                  marginLeft: "50px",
                  marginBottom: "-25px",
                  width: "30%",
                }}
              />
            </div>
          </form>
          {/* {loginStatus && (
        <button onClick={userAuthenticated}> check if authenticated..</button>
      )} */}
        </Box>
      </div>
    </div>
  );
};

export default UserDashboard;
