import React from 'react';
import '../style.css';

const Layout = ({
  title = 'Title',
  description = 'Description',
  className,
  children,
}) => (
  <div >
   <div className='container text-black' style={{marginBottom: '1px', marginTop: '4em'}}>
      <h2 style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }} >{title}</h2>
      <p className='lead' style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}>{description}</p>
    </div>
    <div className={className}>{children}</div>
  </div>
);

export default Layout;
