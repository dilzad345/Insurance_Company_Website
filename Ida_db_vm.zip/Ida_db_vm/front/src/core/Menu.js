// import React ,{useContext}from "react";
// import { signout } from "../auth";
// import { Button } from 'react-bootstrap';
// import history from "../auth/history";
// import DialogContentText from "@material-ui/core/DialogContentText";
// // import logo from "../images/logo_ensur.png";
// import logo from "../images/logo.png";
// import { UserContext } from "../App";
// // import { Redirect } from 'react-router-dom'
// const MenuBar = ({ name }) => {
//   const {state, dispatch} = useContext(UserContext)
//   return (
//     <div  style={{backgroundColor:"#02516b", width: "100%", height: "80px"}}>
//       {/* {console.log(email)} */}
//       <div style={{ float: "left"}} className="my-2 ml-5">
//         <img src={logo} width="35%" height="25%" alt="EnsurTek Logo" />
//       </div>
//       <div className="row align-items-center float-right">
//         <DialogContentText variant="h6" style={{color:"white", paddingTop: "25px"}}>{name}</DialogContentText>
//         <Button
//           className="mx-4 float-right"
//           style={{padding:"10px",borderRadius:"5px"}}
//           onClick={() => {
//             signout(() => {
//               dispatch({type:"USER", payload :true});
//               history.push("/signin");
//               // return <Redirect to="/signin" push={true} />
//             });
//           }}
//           variant="info"
//         >
//           Sign Out
//         </Button>
//       </div>
//     </div>
//   );
// };

// export default MenuBar;
