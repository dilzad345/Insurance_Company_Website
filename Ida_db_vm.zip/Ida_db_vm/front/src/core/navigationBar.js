import React from "react";
import { Button, Grid } from "@material-ui/core";
// import { Button } from react-bootstrap;
import { tab1_validate,tab1_validateedit } from "../validations/tab1_validate";
import { tab3_validate,tab3_validateEdit } from "../validations/tab3_validate";
import { tab4_validate } from "../validations/tab4_validate";
import { tab5_validate, tab5_validateEdit } from "../validations/tab5_validate";
import { tab6_validate, tab6_validateEdit } from "../validations/tab6_validate";
import { tab7_validate } from "../validations/tab7_validate";
import { Navbar } from "react-bootstrap";
 import logo from "../images/logo.png";
 import "./navBar.css"

export const navigationBar = ({
  step,
  navigation,
  tab1_client,
  tab2_importantQuestions,
  tab3_policyCore,
  tab4_vehicle,
  tab5_modifications,
  tab6_drivers,
  tab7_claims,
}) => {
  const navButtonClick = (index) => {
    navigation.go(index);
  };

  return (
    <div className="btn-container">
      
      {/* <Grid
        container
        spacing={2}
        direction="row"
        justifyContent="center"
        alignItems="center"
        style={{ marginBottom: "50px" }}
        className="my-2"
      >
        <Grid item xs={1}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: tab1_validate(tab1_client)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab1_client" ? "#02516b" : "#207996",
            }}
            onClick={() => {navButtonClick(0);}}>
            Client
          </Button>
        </Grid>
        <Grid item xs={2}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: "solid 3px #05fc81",
              backgroundColor:
                step.id === "tab2_importantQuestions" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(1);
            }}
          >
            Important Questions
          </Button>
        </Grid>
        <Grid item xs={"auto"}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: tab3_validate(tab3_policyCore)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab3_policyCore" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(2);
            }}
          >
            Policy Core
          </Button>
        </Grid>
        <Grid item xs={1}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: tab4_validate(tab4_vehicle)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab4_vehicle" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(3);
            }}
          >
            Vehicle
          </Button>
        </Grid>
        <Grid item xs={"auto"}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: tab5_validate(tab5_modifications)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab5_modifications" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(4);
            }}
          >
           MODIFICATIONS/ACCESSORIES
          </Button>
        </Grid>
        <Grid item xs={1}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: tab6_validate(tab6_drivers)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab6_drivers" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(5);
            }}
          >
            Drivers
          </Button>
        </Grid>
        <Grid item xs={1}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: tab7_validate(tab7_claims)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab7_claims" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(6);
            }}
          >
            Claims
          </Button>
        </Grid>
      </Grid> */}
      <button  
       onClick={() => {navButtonClick(0);}}
       style={{
        border: tab1_validate(tab1_client)
        ? "solid 3px #05fc81"
        : "solid 3px red",
        backgroundColor:
        step.id === "tab1_client" ? "#1B1523" : "#2A3A64",
          }}
        className="btn"
     >
      Client
     </button>

     <button
     style={{
      border: "solid 3px #05fc81",
      backgroundColor:
        step.id === "tab2_importantQuestions" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {navButtonClick(1);}}>Important Questions</button>
     
     <button
     style={{
      border: tab3_validate(tab3_policyCore)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "tab3_policyCore" ? "#02516b" : "#2A3A64",
    }}
    onClick={() => {
      navButtonClick(2);
    }}
    className="btn"
     >Policy Core</button>

     <button
     style={{
      border: tab4_validate(tab4_vehicle)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "tab4_vehicle" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {
      navButtonClick(3);
    }}>Vehicle</button>

     <button
     style={{
      border: tab5_validate(tab5_modifications)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "tab5_modifications" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {
      navButtonClick(4);
    }}>Modifications/Accessories</button>

     <button
     style={{
      border: tab6_validate(tab6_drivers)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "tab6_drivers" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {
      navButtonClick(5);
    }}>
       Drivers
     </button>

     <button
     style={{
      border: tab7_validate(tab7_claims)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "tab7_claims" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {
      navButtonClick(6);
    }}>
       Claims
     </button>

    </div>
  );
}; // end of client page navBar

//
export const navigationBarEdit = ({
  step,
  navigation,
  tab1_client,
  tab2_importantQuestions,
  tab3_policyCore,
  tab4_vehicle,
  tab5_modifications,
  tab6_drivers,
  tab7_claims,
}) => {
  const navButtonClick = (index) => {
    navigation.go(index);
  };

  return (
    <div className="btn-container">
     
      {/* <Grid
        container
        spacing={1}
        direction="row"
        justifyContent="center"
        alignItems="center"
        style={{ marginBottom: "50px" }}
        className="my-2"
      >
        <Grid item xs={1}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: tab1_validateedit(tab1_client)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab1_client" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(0);
            }}
          >
            Client
          </Button>
        </Grid>
        <Grid item xs={2}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: "solid 3px #05fc81",
              backgroundColor:
                step.id === "tab2_importantQuestions" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(1);
            }}
          >
            Important Questions
          </Button>
        </Grid>
        <Grid item xs={"auto"}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: tab3_validateEdit(tab3_policyCore)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab3_policyCore" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(2);
            }}
          >
            Policy Core
          </Button>
        </Grid>
        <Grid item xs={1}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: tab4_validate(tab4_vehicle)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab4_vehicle" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(3);
            }}
          >
            Vehicle
          </Button>
        </Grid>
        <Grid item xs={"auto"}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: tab5_validateEdit(tab5_modifications)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab5_modifications" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(4);
            }}
          >
            MODIFICATIONS/ACCESSORIES
          </Button>
        </Grid>
        <Grid item xs={1}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: tab6_validateEdit(tab6_drivers)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab6_drivers" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(5);
            }}
          >
            Drivers
          </Button>
        </Grid>
        <Grid item xs={1}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: tab7_validate(tab7_claims)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab7_claims" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(6);
            }}
          >
            Claims
          </Button>
        </Grid>
      </Grid> */}

     <button  
       onClick={() => {navButtonClick(0)}}
       style={{
        border: tab1_validateedit(tab1_client)
        ? "solid 3px #05fc81"
        : "solid 3px red",
        backgroundColor:
        step.id === "tab1_client" ? "#1B1523" : "#2A3A64",
          }}
        className="btn"
     >
      Client
     </button>

     <button
     style={{
      border: "solid 3px #05fc81",
      backgroundColor:
        step.id === "tab2_importantQuestions" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
      onClick={() => {navButtonClick(1);}}>Important Questions</button>
     
     <button
     style={{
      border: tab3_validateEdit(tab3_policyCore)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "tab3_policyCore" ? "#02516b" : "#2A3A64",
    }}
    onClick={() => {
      navButtonClick(2);
    }}
    className="btn"
     >Policy Core</button>

   <button
     style={{
      border: tab4_validate(tab4_vehicle)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "tab4_vehicle" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {
      navButtonClick(3);
    }}>Vehicle</button>

    <button
     style={{
      border: tab5_validateEdit(tab5_modifications)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "tab5_modifications" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {
      navButtonClick(4);
    }}>Modifications/Accessories</button>

     <button
     style={{
      border: tab6_validateEdit(tab6_drivers)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "tab6_drivers" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {
      navButtonClick(5);
    }}>
       Drivers
     </button>

     <button
     style={{
      border: tab7_validate(tab7_claims)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "tab7_claims" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {
      navButtonClick(6);
    }}>
       Claims
     </button>
    </div>
  );
}; // end of client page navBar
