import React from "react";
import { Button, Grid } from "@material-ui/core";
// import { Button } from react-bootstrap;
import {
  Tab1_Validation_Home,
  tab1ValidationHomeEdit,
} from "../validationHome/Tab1_Validation_Home";
import {
  Tab3_Validation_Home,
  tab3validationHomeedit,
} from "../validationHome/Tab3_Validation_Home";
import "../core/navBar.css"
import { Tab4_Validation_Home } from "../validationHome/Tab4_Validation_Home";
import { Tab5_Validation_Home } from "../validationHome/Tab5_Validation_Home";
import { Tab6_Validation_Home } from "../validationHome/Tab6_Validation_Home";

// return content navigation bar
export const navigationBar = ({
  step,
  navigation,
  Tab1_Client_Home_var,
  Tab2_Importan_Question_Home_var,
  // tab2_importantQuestions
  Tab3_Policycore_Home_Var,
  Tab4_Building_Home_Var,
  Tab5_Contents_Home_Var,
  Tab6_Claims_Home_Var,
  // tab7_claims,
}) => {
  const navButtonClick = (index) => {
    navigation.go(index);
  };

  return (
    <div className="btn-container">
      

      <Grid
        container
        spacing={2}
        direction="row"
        justifyContent="center"
        alignItems="center"
        style={{ marginBottom: "50px" }}
        className="my-2"
      >
        <Grid item xs={1}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: Tab1_Validation_Home(Tab1_Client_Home_var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab1_client_home" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(0);
            }}
          >
            Client
          </Button>
        </Grid>
        <Grid item xs={2}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: "solid 3px #05fc81",
              backgroundColor:
                step.id === "tab2_importantQuestions_home"
                  ? "#02516b"
                  : "#207996",
            }}
            onClick={() => {
              navButtonClick(1);
            }}
          >
            Important Questions
          </Button>
        </Grid>
        <Grid item xs={"auto"}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: Tab3_Validation_Home(Tab3_Policycore_Home_Var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab3_policyCore_home" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(2);
            }}
          >
            Policy Core
          </Button>
        </Grid>
        <Grid item xs={1}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: Tab4_Validation_Home(Tab4_Building_Home_Var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab4_buildingDetails_home" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(3);
            }}
          >
            BUILDING
          </Button>
        </Grid>
        <Grid item xs={"auto"}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: Tab5_Validation_Home(Tab5_Contents_Home_Var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab5_contents_home" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(4);
            }}
          >
            CONTENTS
          </Button>
        </Grid>
        <Grid item xs={1}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: Tab6_Validation_Home(Tab6_Claims_Home_Var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab6_drivers" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(5);
            }}
          >
            CLAIMS
          </Button>
        </Grid>
        {/*  <Grid item xs={1}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: tab7_validate(tab7_claims)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab7_claims" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(6);
            }}
          >
            Claims
          </Button>
        </Grid> */}
      </Grid>
      {/* <Footer /> */}
    </div>
  );
}; // end of client page navBar

//return to navigation edit
export const navigationEditBar = ({
  step,
  navigation,
  Tab1_Client_Home_var,
  // Tab2_Importan_Question_Home_var,
  // tab2_importantQuestions
  Tab3_Policycore_Home_Var,
  Tab4_Building_Home_Var,
  Tab5_Contents_Home_Var,
  Tab6_Claims_Home_Var,
  // tab7_claims,
}) => {
  const navButtonClick = (index) => {
    navigation.go(index);
  };

  return (
    <div className="btn-container">
      {/* <Grid
        container
        spacing={2}
        direction="row"
        justifyContent="center"
        alignItems="center"
        style={{ marginBottom: "50px" }}
        className="my-2"
      >
        <Grid item xs={1}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: tab1ValidationHomeEdit(Tab1_Client_Home_var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab1_client_home" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(0);
            }}
          >
            Client
          </Button>
        </Grid>
        <Grid item xs={2}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: "solid 3px #05fc81",
              backgroundColor:
                step.id === "tab2_importantQuestions_home"
                  ? "#02516b"
                  : "#207996",
            }}
            onClick={() => {
              navButtonClick(1);
            }}
          >
            Important Questions
          </Button>
        </Grid>
        <Grid item xs={"auto"}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: tab3validationHomeedit(Tab3_Policycore_Home_Var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab3_policyCore_home" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(2);
            }}
          >
            Policy Core
          </Button>
        </Grid>
        <Grid item xs={1}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: Tab4_Validation_Home(Tab4_Building_Home_Var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab4_buildingDetails_home" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(3);
            }}
          >
            BUILDING
          </Button>
        </Grid>
        <Grid item xs={"auto"}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: Tab5_Validation_Home(
                Tab5_Contents_Home_Var,
                Tab3_Policycore_Home_Var
              )
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab5_contents_home" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(4);
            }}
          >
            CONTENTS
          </Button>
        </Grid>
        <Grid item xs={1}>
          <Button
            fullWidth
            size="small"
            style={{
              color: "white",
              border: Tab6_Validation_Home(Tab6_Claims_Home_Var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "tab6_drivers" ? "#02516b" : "#207996",
            }}
            onClick={() => {
              navButtonClick(5);
            }}
          >
            CLAIMS
          </Button>
        </Grid>
        
      </Grid> */}

      <button  
       onClick={() => {navButtonClick(0);}}
       style={{
        border: tab1ValidationHomeEdit(Tab1_Client_Home_var)
        ? "solid 3px #05fc81"
        : "solid 3px red",
        backgroundColor:
        step.id === "tab1_client_home" ? "#1B1523" : "#2A3A64",
        }}
      className="btn"
     >
      Client
     </button>

      <button
     style={{
      border: "solid 3px #05fc81",
      backgroundColor:
        step.id === "tab2_importantQuestions_home" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {navButtonClick(1);}}>Important Questions
    </button>

    <button
     style={{
      border: tab3validationHomeedit(Tab3_Policycore_Home_Var)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "tab3_policyCore_home" ? "#02516b" : "#2A3A64",
    }}
    onClick={() => {
      navButtonClick(2);
    }}
    className="btn"
     >Policy Core</button>

     <button
     style={{
      border: Tab4_Validation_Home(Tab4_Building_Home_Var)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "tab4_buildingDetails_home" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {
      navButtonClick(3);
    }}>Building</button>

     <button
     style={{
      border: Tab5_Validation_Home(
        Tab5_Contents_Home_Var,
        Tab3_Policycore_Home_Var
      )
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "Tab5_Contents_Home_Var" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {
      navButtonClick(4);
    }}>Contents</button>

     <button
     style={{
      border: Tab6_Validation_Home(Tab6_Claims_Home_Var)
        ? "solid 3px #05fc81"
        : "solid 3px red",
      backgroundColor:
        step.id === "Tab6_Claims_Home_Var" ? "#02516b" : "#2A3A64",
    }}
    className="btn"
    onClick={() => {
      navButtonClick(5);
    }}>
       Claims
     </button>
    </div>
  );
};
