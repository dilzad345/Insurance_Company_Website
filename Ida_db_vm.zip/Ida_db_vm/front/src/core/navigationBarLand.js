import React from "react";
import { Button, Grid } from "@material-ui/core";
import "./navBar.css"
// import { Button } from react-bootstrap;
import {
    Tab1_Validation_Land,
    tab1ValidationLandEdit,
} from "../validationLand/Tab1_Validation_Land";
import {
  Tab2_Validation_Land,
  tab2ValidationLandEdit,
} from "../validationLand/Tab2_Validation_Land";
import {
  Tab3_Validation_Land,
  tab3ValidationLandEdit
} from "../validationLand/Tab3_Validation_Land";
import { Tab4_Validation_Land, tab4ValidationLandEdit } from "../validationLand/Tab4_Validation_Land";
import { Tab5_Validation_Land, tab5ValidationLandEdit } from "../validationLand/Tab5_Validation_Land";
import { Tab6_Validation_Land, tab6ValidationLandEdit } from "../validationLand/Tab6_Validation_Land";

// import { tab7_validate } from "../validations/tab7_validate";

import { Navbar } from "react-bootstrap";
import logo from "../images/logo.png";
// import Footer from "../component/footer/Footer";
// import regionallogo from "../images/regionallogo.png"
// return content navigation bar
export const navigationBar = ({
  step,
  navigation,
  Tab1_Client_Land_var,
  Tab2_Importan_Question_Land_var,
  Tab3_Policycore_Land_Var,
  Tab4_Building_Land_Var,
  Tab5_Contents_Land_Var,
  Tab6_Claims_Land_Var
  // tab2_importantQuestions
//   Tab3_Policycore_Home_Var,
//   Tab4_Building_Home_Var,
//   Tab5_Contents_Home_Var,
//   Tab6_Claims_Home_Var,
  // tab7_claims,
}) => {
  const navButtonClick = (index) => {
    navigation.go(index);
  };

  return (
    <div className="btn-container">
      {/* <Navbar
        style={{
          // backgroundColor: "#02516b",
          backgroundColor: "#02516b",
        }}
        bg="#02516b"
        variant="dark"
      >
        <Navbar.Brand href="#">
          <img
            alt="EnsureTek logo"
            src={logo}
            // src={regionallogo}
            // width="50%"
            width="40%"
            height="35%"
            style={{ filter: "brightness(1.75)" }}
          />
        </Navbar.Brand>
      </Navbar> */}
    
      {/* <Grid
        container
        spacing={2}
        direction="row"
        justifyContent="center"
        alignItems="center"
        style={{ marginBottom: "50px" }}
        className="my-2"
      > */}
        
          <button
            style={{
             border: tab1ValidationLandEdit(Tab1_Client_Land_var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "Tab1_Client_Land" ? "#1B1523" : "#2A3A64",
            }}
            onClick={() => {
              navButtonClick(0);
            }}
            className="btn"
          >
            Client
            </button>
        

         
          <button
            style={{
              border: tab2ValidationLandEdit(Tab2_Importan_Question_Land_var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "Tab2_Importan_Question_Land_var" ? "#1B1523" : "#2A3A64",
            }}
            onClick={() => {
              navButtonClick(1);
            }}
            className="btn"
          >
            Important Questions
          </button>
        

        
          <button
            style={{
              border: tab3ValidationLandEdit(Tab3_Policycore_Land_Var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "Tab3_PolicycoreLand" ? "#1B1523" : "#2A3A64",
            }}
            onClick={() => {
              navButtonClick(2);
            }}
            className="btn"
          >
            Policy Core
          </button>
        

        
          <button
            style={{
              
              border: tab4ValidationLandEdit(Tab4_Building_Land_Var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "Tab4_buildingLand" ? "#1B1523" : "#2A3A64",
            }}
            onClick={() => {
              navButtonClick(3);
            }}
            className="btn"
          >
            BUILDING
          </button>
        

       
          <button
           
            style={{
              
              border: tab5ValidationLandEdit(Tab5_Contents_Land_Var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "Tab5_ContentsLand" ? "#1B1523" : "#2A3A64",
            }}
            onClick={() => {
              navButtonClick(4);
            }}
            className="btn"
          >
            CONTENTS
          </button>
        

        
          <button
            style={{
              border: tab6ValidationLandEdit(Tab6_Claims_Land_Var)
                ? "solid 3px #05fc81"
                : "solid 3px red",
              backgroundColor:
                step.id === "Tab6_claimsLand" ? "#1B1523" : "#2A3A64",
            }}
            onClick={() => {
              navButtonClick(5);
            }}
            className="btn"
          >
            CLAIMS
          </button>

         
        
      
     
    </div>
  );
}; // end of client page navBar

//return to navigation edit
// export const navigationEditBar = ({
//   step,
//   navigation,
//   Tab1_Client_Home_var,
//   // Tab2_Importan_Question_Home_var,
//   // tab2_importantQuestions
//   Tab3_Policycore_Home_Var,
//   Tab4_Building_Home_Var,
//   Tab5_Contents_Home_Var,
//   Tab6_Claims_Home_Var,
//   // tab7_claims,
// }) => {
//   const navButtonClick = (index) => {
//     navigation.go(index);
//   };

//   return (
//     <div>
//       <Navbar
//         style={{
//           backgroundColor: "#02516b",
//         }}
//         bg="#70aec2"
//         variant="dark"
//       >
//         <Navbar.Brand href="#">
//           <img
//             alt="EnsureTek logo"
//             // src={logo}
//             // width="50%"
//             // height="50%"
//             src={logo}
//             width="40%"
//             height="35%"
//             style={{ filter: "brightness(1.75)" }}
//           />
//         </Navbar.Brand>
//       </Navbar>

//       <Grid
//         container
//         spacing={2}
//         direction="row"
//         justifyContent="center"
//         alignItems="center"
//         style={{ marginBottom: "50px" }}
//         className="my-2"
//       >
//         <Grid item xs={1}>
//           <Button
//             fullWidth
//             size="small"
//             style={{
//               color: "white",
//               border: tab1ValidationHomeEdit(Tab1_Client_Home_var)
//                 ? "solid 3px #05fc81"
//                 : "solid 3px red",
//               backgroundColor:
//                 step.id === "tab1_client_home" ? "#02516b" : "#207996",
//             }}
//             onClick={() => {
//               navButtonClick(0);
//             }}
//           >
//             Client
//           </Button>
//         </Grid>
//         <Grid item xs={2}>
//           <Button
//             fullWidth
//             size="small"
//             style={{
//               color: "white",
//               border: "solid 3px #05fc81",
//               backgroundColor:
//                 step.id === "tab2_importantQuestions_home"
//                   ? "#02516b"
//                   : "#207996",
//             }}
//             onClick={() => {
//               navButtonClick(1);
//             }}
//           >
//             Important Questions
//           </Button>
//         </Grid>
//         <Grid item xs={"auto"}>
//           <Button
//             fullWidth
//             size="small"
//             style={{
//               color: "white",
//               border: tab3validationHomeedit(Tab3_Policycore_Home_Var)
//                 ? "solid 3px #05fc81"
//                 : "solid 3px red",
//               backgroundColor:
//                 step.id === "tab3_policyCore_home" ? "#02516b" : "#207996",
//             }}
//             onClick={() => {
//               navButtonClick(2);
//             }}
//           >
//             Policy Core
//           </Button>
//         </Grid>
//         <Grid item xs={1}>
//           <Button
//             fullWidth
//             size="small"
//             style={{
//               color: "white",
//               border: Tab4_Validation_Home(Tab4_Building_Home_Var)
//                 ? "solid 3px #05fc81"
//                 : "solid 3px red",
//               backgroundColor:
//                 step.id === "tab4_buildingDetails_home" ? "#02516b" : "#207996",
//             }}
//             onClick={() => {
//               navButtonClick(3);
//             }}
//           >
//             BUILDING
//           </Button>
//         </Grid>
//         <Grid item xs={"auto"}>
//           <Button
//             fullWidth
//             size="small"
//             style={{
//               color: "white",
//               border: Tab5_Validation_Home(
//                 Tab5_Contents_Home_Var,
//                 Tab3_Policycore_Home_Var
//               )
//                 ? "solid 3px #05fc81"
//                 : "solid 3px red",
//               backgroundColor:
//                 step.id === "tab5_contents_home" ? "#02516b" : "#207996",
//             }}
//             onClick={() => {
//               navButtonClick(4);
//             }}
//           >
//             CONTENTS
//           </Button>
//         </Grid>
//         <Grid item xs={1}>
//           <Button
//             fullWidth
//             size="small"
//             style={{
//               color: "white",
//               border: Tab6_Validation_Home(Tab6_Claims_Home_Var)
//                 ? "solid 3px #05fc81"
//                 : "solid 3px red",
//               backgroundColor:
//                 step.id === "tab6_drivers" ? "#02516b" : "#207996",
//             }}
//             onClick={() => {
//               navButtonClick(5);
//             }}
//           >
//             CLAIMS
//           </Button>
//         </Grid>
//         {/*  <Grid item xs={1}>
//           <Button
//             fullWidth
//             size="small"
//             style={{
//               color: "white",
//               border: tab7_validate(tab7_claims)
//                 ? "solid 3px #05fc81"
//                 : "solid 3px red",
//               backgroundColor:
//                 step.id === "tab7_claims" ? "#02516b" : "#207996",
//             }}
//             onClick={() => {
//               navButtonClick(6);
//             }}
//           >
//             Claims
//           </Button>
//         </Grid> */}
//       </Grid>
//     </div>
//   );
// };
