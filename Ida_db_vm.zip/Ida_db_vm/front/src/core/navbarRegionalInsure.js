import React from "react";
import { Navbar } from "react-bootstrap";
import logo from "../images/logo_ensur.png";
// import regionallogo from "../images/regionallogo.png"
export const navBarLogo = () => {
  return (
    <Navbar
      style={{ backgroundColor: "#2F5597" }}
      bg="#70aec2"
      variant="dark">
      {/* <Container> */}
      <Navbar.Brand href="./client_home">
        <div style={{ float: "right" }}>
          <img 
          src={regionallogo} 
          width="40%" height="35%" alt="EnsurTek Logo"
          style={{filter: 'brightness(1.75)'}} />
        </div>
      </Navbar.Brand>
      {/* </Container> */}
    </Navbar>
  );
};