import React from "react";
import { Navbar } from "react-bootstrap";
// import logo from "../images/logo_ensur.png";
import logo from "../images/logo.png";
export const navBarLogo = () => {
  return (<Navbar style={{ backgroundColor: "#02516b" }} bg="#70aec2" variant="dark">
    {/* <Container> */}
    <Navbar.Brand href="./client_home">
      <div style={{ float: "right" }}>
        <img src={logo} width="40%" height="35%" alt="EnsurTek Logo" />
      </div>
    </Navbar.Brand>
    {/* </Container> */}
  </Navbar>
  );
};