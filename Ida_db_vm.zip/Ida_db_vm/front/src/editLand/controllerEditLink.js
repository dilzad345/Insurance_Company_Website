import axios from "axios";
import {
  API
} from "../config";

import {
  tab1ValidationLandEdit
} from "../validationLand/Tab1_Validation_Land";
import {
  Tab2_Validation_Land
} from "../validationLand/Tab2_Validation_Land";
import {
  Tab3_Validation_Land
} from "../validationLand/Tab3_Validation_Land";
import {
  Tab4_Validation_Land
} from "../validationLand/Tab4_Validation_Land";
import {
  Tab5_Validation_Land
} from "../validationLand/Tab5_Validation_Land";
import {
  Tab6_Validation_Land
} from "../validationLand/Tab6_Validation_Land";
export const validateAllForms = (
  Tab1_Client_Land_var,
  Tab2_Importan_Question_Land_var,
  Tab3_Policycore_Land_Var,
  Tab4_Building_Land_Var,
  Tab5_Contents_Land_Var,
  Tab6_Claims_Land_Var
) => {
  let isValid = true;
  isValid = isValid * tab1ValidationLandEdit(Tab1_Client_Land_var);
  isValid = isValid * Tab2_Validation_Land(Tab2_Importan_Question_Land_var);
  isValid = isValid * Tab3_Validation_Land(Tab3_Policycore_Land_Var);
  isValid = isValid * Tab4_Validation_Land(Tab4_Building_Land_Var);
  isValid = isValid * Tab5_Validation_Land(Tab5_Contents_Land_Var);
  isValid = isValid * Tab6_Validation_Land(Tab6_Claims_Land_Var);
  return isValid;
}

//Method for getting details of a quotation using quotation Id
export const getQuotationDetail = async (quotationId) => {
  try {
    const result = await axios
      .get(`${API}/quotationLandlords/getQuotationDetails?quotationId=` + quotationId, {
        headers: JSON.parse(localStorage.getItem("user"))
      })
    // console.log("result:", result);
    return result;
  } catch (err) {
    console.log(err);
  }
}

// method: update quotation details;
export const updateAllForms = async (
  Tab1_Client_Land_var,
  Tab2_Importan_Question_Land_var,
  Tab3_Policycore_Land_Var,
  Tab4_Building_Land_Var,
  Tab5_Contents_Land_Var,
  Tab6_Claims_Land_Var,
  quotationId
) => {

  const dataForLand = {
    data_tab1: Tab1_Client_Land_var,
    data_tab2: Tab2_Importan_Question_Land_var,
    data_tab3: Tab3_Policycore_Land_Var,
    data_tab4: Tab4_Building_Land_Var,
    data_tab5: Tab5_Contents_Land_Var,
    data_tab6: Tab6_Claims_Land_Var,
    // data_tab7: tab7_claims,
    quotationId: quotationId,
  }
  console.log(dataForLand);
  try {
    const result = await axios.post(`${API}/quotationLandlords/updateQuotationLand`, dataForLand);
    // console.log(result)
    return result;
  } catch (err) {
    // console.log(err);
    return false;
  }

} // end of update all forms

//method for assigning values for tab 1
export const assignValueTab1 = (dataClient, Tab1_Client_Land_var, setTab1) => {
  setTab1({
    uiPathIdForLand: dataClient.client_code_landlord,
    client_type: dataClient.client_type, //client_type is one of the client home table's column name
    client_title: dataClient.client_title,
    client_firstName: dataClient.client_firstName,
    client_lastName: dataClient.client_lastName,
    company_name: dataClient.company_name,
    trading_as: dataClient.trading_as,
    reference_code: dataClient.reference_code,
    unit_number_postal: dataClient.unit_number_postal,
    street_number_postal: dataClient.street_number_postal,
    street_name_postal: dataClient.street_name_postal,
    street_type_insured: dataClient.street_type_insured,
    street_type_postal: dataClient.street_type_postal,
    suburb_postal: dataClient.suburb_postal,
    state_postal: dataClient.state_postal,
    state_insured: dataClient.state_insured,
    postcode_postal: dataClient.postcode_postal,
    phone: dataClient.phone,
    email: dataClient.email,
    branch: dataClient.branch,
    sales_team: dataClient.sales_team,
    service_team: dataClient.service_team,
    unit_number_insured: dataClient.unit_number_insured,
    street_number_insured: dataClient.street_number_insured,
    street_name_insured: dataClient.street_name_insured,
    street_type_insured: dataClient.street_type_insured,
    suburb_insured: dataClient.suburb_insured,
    state_insured: dataClient.state_insured,
    postcode_insured: dataClient.postcode_insured,
    insuredAddress:dataClient.insuredAddress,
  })
}

//method for assigning values for tab2
export const assignValuesTab2 = (dataIq, Tab2_Importan_Question_Land_var, setTab2) => {
  setTab2({
    any_policy_decline_last5years: dataIq.any_policy_decline_last5years,
    howmany_policy_decline_last5years: dataIq.howmany_policy_decline_last5years,
    howmany_policy_decline_last3years: dataIq.howmany_policy_decline_last3years,
    reason_forThe_decline: dataIq.reason_forThe_decline,
    clime_decline: dataIq.clime_decline,
    any_criminal_conviction: dataIq.any_criminal_conviction,
    property_everBe_unoccupied: dataIq.property_everBe_unoccupied,
    checking_onThe_property: dataIq.checking_onThe_property,
    why_property_unoccupied: dataIq.why_property_uccupied,
    under_construction_renovation: dataIq.under_construction_renovation,
    renovation_over$100000: dataIq.renovation_over$100k,
    value_of_renovation: dataIq.value_of_renovation,
    start_date_renovations: new Date(dataIq.start_date_renovation),
    Estimated_completion_date: new Date(dataIq.estimated_completion_date),
    what_work_undertaken: dataIq.what_work_undertaken,
    building_not_secure: dataIq.building_not_secure,
    contract_works_policy: dataIq.contract_works_policy,
    external_roof_walls: dataIq.external_roof_walls,
    rain_intoThe_building: dataIq.rain_intoThe_building,
    poorly_maintained: dataIq.poorly_maintained,
    property_heritage: dataIq.property_heritage,
    details_heritage_list: dataIq.details_heritage_list,
    bed_breakfast: dataIq.bed_breakfast,
    boarding_house: dataIq.boarding_house,
    used_hostel: dataIq.used_hostel,
    community_public_housing: dataIq.community_public_housing,
    home_office_surgery: dataIq.home_office_surgery,
    social_housing_service: dataIq.social_housing_service,
    property_redevelopment: dataIq.property_redevelopment,
    property_trust: dataIq.property_trust,
    flooded_last_10years: dataIq.flooded_last_10years,
    property_used_farming: dataIq.property_used_farming,
    business_activity_conducted: dataIq.business_activity_conducted
  })
}

//method for assigning values for tab3
export const assignValuesTab3 = (dataPolicyCore, Tab3_Policycore_Land_Var, setTab3) => {
  setTab3({
    occupancy_home: dataPolicyCore.occupancy_home,
    property_managed: dataPolicyCore.property_managed,
    building_content: dataPolicyCore.building_content,
    building_sum_insured: dataPolicyCore.building_sum_insured,
    content_ins_amount: dataPolicyCore.content_ins_amount,
    policy_from_date: new Date(dataPolicyCore.policy_from_date),
    policy_to_date: new Date(dataPolicyCore.policy_to_date),
    dob_oldest_insured: new Date(dataPolicyCore.dob_oldest_insured),
    currently_hold_insurence: dataPolicyCore.currently_hold_insurence,
    current_insurer : dataPolicyCore.current_insurer,
    interested_parties: dataPolicyCore.interested_parties,
    holding_broker: dataPolicyCore.holding_broker,
    holding_underwriter: dataPolicyCore.holding_underwriter,
    stamp_duty_exempt: dataPolicyCore.stamp_duty_exempt,
    no_claim_bonus: dataPolicyCore.no_claim_bonus,
    payment_frequency: dataPolicyCore.payment_frequency,
    preffered_day_installment: dataPolicyCore.preffered_day_installment,
    broker_fee_installment: dataPolicyCore.broker_fee_installment,
    cover_Theft_tenant: dataPolicyCore.cover_theft_tenant,
    cover_loss: dataPolicyCore.cover_loss,
    sum_ins_amount_loss: dataPolicyCore.sum_ins_amount_loss,
    annual_rent_amount: dataPolicyCore.annual_rent_amount,
    weekly_rent_amount: dataPolicyCore.weekly_rent_amount,
    cover_rent_default: dataPolicyCore.cover_rent_default,
    tenant_rent_14Days: dataPolicyCore.tenant_rent_14Days,
    landlord_insurance_policy: dataPolicyCore.landlord_insurance_policy,
    svu_excess_option1: dataPolicyCore.svu_excess_option1,
    svu_excess_option2: dataPolicyCore.svu_excess_option2,
    svu_excess_option3: dataPolicyCore.svu_excess_option3,
    broker_fee: dataPolicyCore.broker_fee,
    cover_type_accidential: dataPolicyCore.cover_type_accidential,
    policyholder_retired: dataPolicyCore.policyholder_retired,
    cover_Accidental_damage: dataPolicyCore.cover_Accidental_damage,
    residential_lease_agreement: dataPolicyCore.residential_lease_agreement
  })
}

//method for assigning values for tab4
export const assignValuesTab4 = (dataBuilding, Tab4_Building_Land_Var, setTab4) => {
  setTab4({
    building_type: dataBuilding.building_type,
    free_standing_what_built: dataBuilding.free_standing_what_build,
    apartment_what_type: dataBuilding.apartment_what_type,
    semi_deteched_what_type: dataBuilding.semi_deteched_what_type,
    semi_deteched_body_corprate: dataBuilding.semi_deteched_body_corprate,
    dewelling_what_describe: dataBuilding.dewelling_what_describe,
    multiple_unit_insured_all: dataBuilding.multiple_unit_insured_all,
    multiple_unit_number: dataBuilding.multiple_unit_number,
    multiple_unit_insured_building: dataBuilding.multiple_unit_insured_building,
    multiple_unit_total_units: dataBuilding.multiple_unit_total_units,
    construction_period: dataBuilding.construction_period,
    original_year_build: dataBuilding.original_year_build,
    construction_wall: dataBuilding.construction_wall,
    roof_construction: dataBuilding.roof_construction,
    numbers_of_bathrooms: dataBuilding.numbers_of_bathrooms,
    numbers_of_bedrooms: dataBuilding.numbers_of_bedrooms,
    construction_quality: dataBuilding.construction_quality,
    storeys: dataBuilding.storeys,
    unit_building_level: dataBuilding.unit_building_level,
    building_size: dataBuilding.building_size,
    effected_by_flood: dataBuilding.effected_by_flood,
    main_water_supply: dataBuilding.main_water_supply,
    window_security: dataBuilding.window_security,
    door_security: dataBuilding.door_security,
    burglar_alarm: dataBuilding.burglar_alarm,
    smoke_detector: dataBuilding.smoke_detector,
    building_construction12months: dataBuilding.building_construction12months,
    outdoor_spa: dataBuilding.outdoor_spa,
    located_below_ground: dataBuilding.located_below_ground,
    flood_mitigration: dataBuilding.flood_mitigration,
    occupancy_certificate: dataBuilding.occupancy_certificate,
    register_body_corprote: dataBuilding.register_body_corprote,
    strata_title: dataBuilding.strata_title,
    person_living_the_building: dataBuilding.person_living_the_building
  })
}

//method for assigning values for tab5
export const assignValuesTab5 = (dataContents, Tab5_Contents_Land_Var, setTab5, setTab5_validation) => {
  // console.log("line186:",dataContents)
  dataContents.map((content) => {
    setTab5((tab5_contents) => [
      ...tab5_contents,
      {
        contentID: content.content_id,
        edit: 'OLD',
        type: content.type,
        category: content.category,
        description: content.description,
        value: content.value,
      },
    ]);

    setTab5_validation((tab5_validation) => [
      ...tab5_validation,
      {
        type: true,
        category: true,
        description: true,
        value: true,
      },
    ]);
  });
}

////method for assigning values for tab6
export const assignValuesTab6 = (dataClaims, Tab6_Claims_Land_Var, setTab6, setTab6_validation) => {
  dataClaims.map((claimArray) => {
    setTab6((tab6_claims) => [
      ...tab6_claims,
      {
        edit: 'OLD',
        claimId: claimArray.claim_id,
        typeClaim: claimArray.claim_type,
        dateClaim: new Date(claimArray.claim_date),
        description: claimArray.description,
        amount: claimArray.amount,
        // insurer:claimArray.insurer
      }
    ]);

    setTab6_validation((tab6_validation) => [
      ...tab6_validation,
      {
        typeClaim: null,
        dateClaim: null,
        description: null,
        claimOutcome: null,
        amount: null,
        // insurer:null
      }
    ]);

  })
}