import React from 'react';
import "../css/homeStyle.css";
import {
  TextField,
  Container,
  Button,
  Select,
  InputLabel,
  MenuItem,
  Grid,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import { Redirect } from 'react-router-dom';
// import DatePicker from "react-datepicker";
import { validationForNumbOnly } from "../constants/validChecker";
import {
  building_type_validate,
  free_standing_what_built_validate,
  apartment_what_type_validate,
  unit_building_level_validate,
  semi_deteched_what_type_validate,
  semi_deteched_body_corprate_validate,
  multiple_unit_insured_all_validate,
  multiple_unit_number_installment_validate,
  multiple_unit_insured_building_validate,
  multiple_unit_total_units_validate,
  construction_period_validate,
  original_year_build_validate,
  construction_wall_validate,
  roof_construction_validate,
  numbers_of_bathrooms_validate,
  numbers_of_bedrooms_validate,
  construction_quality_validate,
  storeys_validate,
  building_size_validate,
  effected_by_flood_validate,
  main_water_supply_validate,
  window_security_validate,
  door_security_validate,
  burglar_alarm_validate,
  smoke_detector_validate,
  building_construction12months_validate,
  outdoor_spa_validate,
  located_below_ground_validate,
  flood_mitigration_validate,
  occupancy_certificate_validate,
  register_body_corprote_validate,
  strata_title_validate,
  person_living_the_building_validate,

} from "../validationLand/Tab4_Validation_Land";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    alignContent: "center",
    padding: theme.spacing(2),
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: "center",
    color: theme.palette.text.secondary,
  },

}));

const returnClientLand = () => {
  return <Redirect to='/client_Land_link' />
}

const Tab4_Building_Land = ({
  Tab4_Building_Land_Var,
  setTab4,
  Tab4_Validation_Land_Var,
  setTab4_validation,
  navigation,
}) => {

  // const classes = useStyles();

  const onChangeField = (e) => {
    let name = e.target.name;
    let value = e.target.value;
    setTab4(
      {
        ...Tab4_Building_Land_Var,
        [name]: value,
      },
      () => {
        validationAfterChange(name, value);
      }
    );
  };

  const validationAfterChange = (name, value) => {
    if (name === "building_type") {
      if (value === "Free Standing / House") {
        setTab4({
          ...Tab4_Building_Land_Var,
          building_type: "Free Standing / House",
          apartment_what_type: "",
          semi_deteched_what_type: "",
          semi_deteched_body_corprate: "",
          dewelling_what_describe: "",
          multiple_unit_insured_all: "",
          multiple_unit_number: "",
          multiple_unit_insured_building: "",
          multiple_unit_total_units: "",
          unit_building_level: "",
        });
      }
    }

    if (name === "building_type") {
      if (value === "Townhouse") {
        setTab4({
          ...Tab4_Building_Land_Var,
          building_type: "Townhouse",
          free_standing_what_built: "",
          apartment_what_type: "",
          semi_deteched_what_type: "",
          semi_deteched_body_corprate: "",
          dewelling_what_describe: "",
          multiple_unit_insured_all: "",
          multiple_unit_number: "",
          multiple_unit_insured_building: "",
          multiple_unit_total_units: "",
          unit_building_level: "",
        });
      }
    }

    if (name === "building_type") {
      if (value === "Display Home") {
        setTab4({
          ...Tab4_Building_Land_Var,
          building_type: "Townhouse",
          free_standing_what_built: "",
          apartment_what_type: "",
          semi_deteched_what_type: "",
          semi_deteched_body_corprate: "",
          dewelling_what_describe: "",
          multiple_unit_insured_all: "",
          multiple_unit_number: "",
          multiple_unit_insured_building: "",
          multiple_unit_total_units: "",
          unit_building_level: "",
        });
      }
    }

    if (name === "building_type") {
      if (value === "Apartment / Unit (Ground Floor)" || "Apartment / Unit (Above Ground Floor)") {
        setTab4({
          ...Tab4_Building_Land_Var,
          building_type: value,
          free_standing_what_built: "",
          semi_deteched_what_type: "",
          semi_deteched_body_corprate: "",
          dewelling_what_describe: "",
          multiple_unit_insured_all: "",
          multiple_unit_number: "",
          multiple_unit_insured_building: "",
          multiple_unit_total_units: "",
        });
      }
    }

    if (name === "building_type") {
      if (value === "Semi-Detached / Terrace") {
        setTab4({
          ...Tab4_Building_Land_Var,
          building_type: value,
          free_standing_what_built: "",
          apartment_what_type: "",
          dewelling_what_describe: "",
          multiple_unit_insured_all: "",
          multiple_unit_number: "",
          multiple_unit_insured_building: "",
          multiple_unit_total_units: "",
          unit_building_level: "",
        });
      }
    }

    if (name === "building_type") {
      if (value === "Multiple units or residenses") {
        setTab4({
          ...Tab4_Building_Land_Var,
          building_type: value,
          multiple_unit_insured_all: "",
          multiple_unit_number: "",
          multiple_unit_insured_building: "",
          multiple_unit_total_units: "",
          unit_building_level: "",
        });
      }
    }

    if (name === "building_type") {
      if (value === "Other") {
        setTab4({
          ...Tab4_Building_Land_Var,
          building_type: value,
          dewelling_what_describe: "",
        });
      }
    }

    switch (name) {
      case "building_type": {
        building_type_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "free_standing_what_built": {
        free_standing_what_built_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "apartment_what_type": {
        apartment_what_type_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "unit_building_level": {
        unit_building_level_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "semi_deteched_what_type": {
        semi_deteched_what_type_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "semi_deteched_body_corprate": {
        semi_deteched_body_corprate_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }

      case "multiple_unit_insured_all": {
        multiple_unit_insured_all_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "multiple_unit_number": {
        multiple_unit_number_installment_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "multiple_unit_insured_building": {
        multiple_unit_insured_building_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "multiple_unit_total_units": {
        multiple_unit_total_units_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "construction_period": {
        construction_period_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "original_year_build": {
        original_year_build_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }

      case "construction_wall": {
        construction_wall_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "roof_construction": {
        roof_construction_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "numbers_of_bathrooms": {
        numbers_of_bathrooms_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "numbers_of_bedrooms": {
        numbers_of_bedrooms_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "construction_quality": {
        construction_quality_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "storeys": {
        storeys_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }

      case "building_size": {
        building_size_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "effected_by_flood": {
        effected_by_flood_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "main_water_supply": {
        main_water_supply_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "window_security": {
        window_security_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "door_security": {
        door_security_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "burglar_alarm": {
        burglar_alarm_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "smoke_detector": {
        smoke_detector_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }
      case "building_construction12months": {
        building_construction12months_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }

      case "outdoor_spa": {
        outdoor_spa_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }

      case "located_below_ground": {
        located_below_ground_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }

      case "flood_mitigration": {
        flood_mitigration_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }

      case "occupancy_certificate": {
        occupancy_certificate_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }

      case "register_body_corprote": {
        register_body_corprote_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }

      case "strata_title": {
        strata_title_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }

      case "person_living_the_building": {
        person_living_the_building_validate(value, Tab4_Validation_Land_Var, setTab4_validation);
        break;
      }

      default: {
        console.log("Not match to condition");
      }
    }

  };

  return (
    <Container maxWidth="md" style={{ marginBottom: "30px" }}>
      <div>
        <Grid container
          spacing={3}
          direction="row"
          justifyContent="center"
          alignItems="center">


          <Grid item xs={12} textalign="center" justifyContent="center" container style={{ marginTop: "25px" }}>
            <h3>BUILDING INFORMATION</h3>
          </Grid>

          {/*Building Type*/}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Building Type"
              style={{ marginBottom: "5px" }}
              required
            >
              Building Type
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="building_type"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.building_type}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Free Standing / House">Free Standing / House</MenuItem>
              <MenuItem value="Townhouse">Townhouse </MenuItem>
              <MenuItem value="Apartment / Unit (Ground Floor)">Apartment / Unit (Ground Floor)</MenuItem>
              <MenuItem value="Apartment / Unit (Above Ground Floor)">Apartment / Unit (Above Ground Floor)</MenuItem>
              <MenuItem value="Display Home">Display Home</MenuItem>
              <MenuItem value="Semi-Detached / Terrace">Semi-Detached / Terracee</MenuItem>
              <MenuItem value="Multiple units or residenses">Multiple units or residenses</MenuItem>
              <MenuItem value="Other">Other</MenuItem>
            </Select>
            {Tab4_Validation_Land_Var.building_type !== null &&
              Tab4_Validation_Land_Var.building_type !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.building_type}
                </div>
              )}
          </Grid>

          {/*If Free Standing Home, what is it built on*/}
          {Tab4_Building_Land_Var.building_type === "Free Standing / House" && (
            <Grid item container xs={12} direction="row" spacing={2}>
              <Grid item xs={6}>
                <InputLabel
                  htmlFor="If Free Standing Home, what is it built on"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  If Free Standing Home, what is it built on
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                <Select
                  name="free_standing_what_built"
                  margin="none"
                  variant="outlined"
                  onChange={onChangeField}
                  style={{ marginBottom: "20px", height: "40px" }}
                  fullWidth
                  value={Tab4_Building_Land_Var.free_standing_what_built}
                >
                  <MenuItem disabled value=" ">
                    Please Select
                  </MenuItem>
                  <MenuItem value="Concrete slab">Concrete slab</MenuItem>
                  <MenuItem value="Foundations">Foundations </MenuItem>
                  <MenuItem value="Poles">Poles</MenuItem>
                </Select>
                {Tab4_Validation_Land_Var.free_standing_what_built !== null &&
                  Tab4_Validation_Land_Var.free_standing_what_built !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab4_Validation_Land_Var.free_standing_what_built}
                    </div>
                  )}
              </Grid>
            </Grid>
          )}

          {/*If an Apartment, what type of Apartment*/}
          {((Tab4_Building_Land_Var.building_type === "Apartment / Unit (Ground Floor)") || (Tab4_Building_Land_Var.building_type === "Apartment / Unit (Above Ground Floor)")) && (
            <Grid container xs={12} direction="row" spacing={2}>

              <Grid item xs={6}>
                <InputLabel
                  htmlFor="If an Apartment, what type of Apartment"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  If an Apartment, what type of Apartment
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                <Select
                  name="apartment_what_type"
                  margin="none"
                  variant="outlined"
                  onChange={onChangeField}
                  style={{ marginBottom: "20px", height: "40px" }}
                  fullWidth
                  value={Tab4_Building_Land_Var.apartment_what_type}
                >
                  <MenuItem disabled value=" ">
                    Please Select
                  </MenuItem>
                  <MenuItem value="Ground floor">Ground floor</MenuItem>
                  <MenuItem value="Mid floor">Mid floor </MenuItem>
                  <MenuItem value="Top floor">Top floor</MenuItem>
                </Select>
                {Tab4_Validation_Land_Var.apartment_what_type !== null &&
                  Tab4_Validation_Land_Var.apartment_what_type !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab4_Validation_Land_Var.apartment_what_type}
                    </div>
                  )}
              </Grid>
            </Grid>
          )}


          {/*If Semi-Detached, what type of Semi-Detached*/}
          {Tab4_Building_Land_Var.building_type === "Semi-Detached / Terrace" && (
            <Grid container xs={12} direction="row" spacing={2}>
              <Grid item xs={6}>
                <InputLabel
                  htmlFor="If Semi-Detached, what type of Semi-Detached"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  If Semi-Detached, what type of Semi-Detached
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                <Select
                  name="semi_deteched_what_type"
                  margin="none"
                  variant="outlined"
                  onChange={onChangeField}
                  style={{ marginBottom: "20px", height: "40px" }}
                  fullWidth
                  value={Tab4_Building_Land_Var.semi_deteched_what_type}
                >
                  <MenuItem disabled value=" ">
                    Please Select
                  </MenuItem>
                  <MenuItem value="Duplex/Triplex">Duplex/Triplex</MenuItem>
                  <MenuItem value="Terrace">Terrace</MenuItem>
                  <MenuItem value="Townhouse">Townhouse</MenuItem>
                  <MenuItem value="Other">Other</MenuItem>

                </Select>
                {Tab4_Validation_Land_Var.semi_deteched_what_type !== null &&
                  Tab4_Validation_Land_Var.semi_deteched_what_type !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab4_Validation_Land_Var.semi_deteched_what_type}
                    </div>
                  )}
              </Grid>

              {/* If Semi-Detached, is there a Strata Management of Body Corporate */}
              <Grid item xs={6}>
                <InputLabel
                  htmlFor="If Semi-Detached, is there a Strata Management of Body Corporate"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  If Semi-Detached, is there a Strata Management of Body Corporate
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                <Select
                  name="semi_deteched_body_corprate"
                  margin="none"
                  variant="outlined"
                  onChange={onChangeField}
                  style={{ marginBottom: "20px", height: "40px" }}
                  fullWidth
                  value={Tab4_Building_Land_Var.semi_deteched_body_corprate}
                >
                  <MenuItem disabled value=" ">
                    Please Select
                  </MenuItem>
                  <MenuItem value="No">No</MenuItem>
                  <MenuItem value="Yes">Yes</MenuItem>
                </Select>
                {Tab4_Validation_Land_Var.semi_deteched_body_corprate !== null &&
                  Tab4_Validation_Land_Var.semi_deteched_body_corprate !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab4_Validation_Land_Var.semi_deteched_body_corprate}
                    </div>
                  )}
              </Grid>
            </Grid>
          )}

          {/*If Other Dwelling, what best describes the home */}
          {Tab4_Building_Land_Var.building_type === "Other" && (
            <Grid container xs={12} direction="row" spacing={2}>
              <Grid item xs={6}>
                <InputLabel
                  htmlFor="If Other Dwelling, what best describes the home"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  If Other Dwelling, what best describes the home
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                <Select
                  name="dewelling_what_describe"
                  margin="none"
                  variant="outlined"
                  onChange={onChangeField}
                  style={{ marginBottom: "20px", height: "40px" }}
                  fullWidth
                  value={Tab4_Building_Land_Var.dewelling_what_describe}
                >
                  <MenuItem disabled value=" ">
                    Please Select
                  </MenuItem>
                  <MenuItem value="Granny flat">Granny flat</MenuItem>
                  <MenuItem value="Non-mobile caravan">Non-mobile caravan</MenuItem>
                  <MenuItem value="Relocatable home">Relocatable home</MenuItem>
                  <MenuItem value="Shed">Shed</MenuItem>
                  <MenuItem value="Storage Centre">Storage Centre</MenuItem>
                  <MenuItem value="Other">Other</MenuItem>
                </Select>
                {Tab4_Validation_Land_Var.dewelling_what_describe !== null &&
                  Tab4_Validation_Land_Var.dewelling_what_describe !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab4_Validation_Land_Var.dewelling_what_describe}
                    </div>
                  )}
              </Grid>
            </Grid>
          )}

          {/* If Multiple units or residenses, does the insured own all units? */}
          {Tab4_Building_Land_Var.building_type === "Multiple units or residenses" && (
            <Grid container xs={12} direction="row" spacing={2}>
              <Grid item xs={6}>
                <InputLabel
                  htmlFor="If Multiple units or residenses, does the insured own all units?"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  If Multiple units or residenses, does the insured own all units?
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                <Select
                  name="multiple_unit_insured_all"
                  margin="none"
                  variant="outlined"
                  onChange={onChangeField}
                  style={{ marginBottom: "20px", height: "40px" }}
                  fullWidth
                  value={Tab4_Building_Land_Var.multiple_unit_insured_all}
                >
                  <MenuItem disabled value=" ">
                    Please Select
                  </MenuItem>
                  <MenuItem value="No">No</MenuItem>
                  <MenuItem value="Yes">Yes</MenuItem>
                </Select>
                {Tab4_Validation_Land_Var.multiple_unit_insured_all !== null &&
                  Tab4_Validation_Land_Var.multiple_unit_insured_all !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab4_Validation_Land_Var.multiple_unit_insured_all}
                    </div>
                  )}
              </Grid>

              {/* If Multiple units or residenses, provide a list of the unit numbers */}
              <Grid item xs={6}>
                <InputLabel
                  htmlFor="If Multiple units or residenses, provide a list of the unit numbers"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  If Multiple units or residenses, provide a list of the unit numbers
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                <TextField
                  name="multiple_unit_number"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  style={{ marginBottom: "20px" }}
                  fullWidth
                  onChange={onChangeField}
                  value={Tab4_Building_Land_Var.multiple_unit_number}
                  onKeyPress={(e) => validationForNumbOnly(e)}
                />
                {Tab4_Validation_Land_Var.multiple_unit_number !== null &&
                  Tab4_Validation_Land_Var.multiple_unit_number !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab4_Validation_Land_Var.multiple_unit_number}
                    </div>
                  )}
              </Grid>


              {/* If Multiple units or residenses, does a body corp insure the building */}
              <Grid item xs={6}>
                <InputLabel
                  htmlFor="If Multiple units or residenses, does a body corp insure the building"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  If Multiple units or residenses, does a body corp insure the building
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                <Select
                  name="multiple_unit_insured_building"
                  margin="none"
                  variant="outlined"
                  onChange={onChangeField}
                  style={{ marginBottom: "20px", height: "40px" }}
                  fullWidth
                  value={Tab4_Building_Land_Var.multiple_unit_insured_building}
                >
                  <MenuItem disabled value=" ">
                    Please Select
                  </MenuItem>
                  <MenuItem value="No">No</MenuItem>
                  <MenuItem value="Yes">Yes</MenuItem>
                </Select>
                {Tab4_Validation_Land_Var.multiple_unit_insured_building !== null &&
                  Tab4_Validation_Land_Var.multiple_unit_insured_building !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab4_Validation_Land_Var.multiple_unit_insured_building}
                    </div>
                  )}
              </Grid>

              {/* If Multiple units or residenses, total number of units */}
              <Grid item xs={6}>
                <InputLabel
                  htmlFor="If Multiple units or residenses, total number of units"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  If Multiple units or residenses, total number of units
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                <TextField
                  name="multiple_unit_total_units"
                  size="small"
                  variant="outlined"
                  autoComplete="off"
                  style={{ marginBottom: "20px" }}
                  fullWidth
                  onChange={onChangeField}
                  value={Tab4_Building_Land_Var.multiple_unit_total_units}
                  onKeyPress={(e) => validationForNumbOnly(e)}
                />
                {Tab4_Validation_Land_Var.multiple_unit_total_units !== null &&
                  Tab4_Validation_Land_Var.multiple_unit_total_units !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab4_Validation_Land_Var.multiple_unit_total_units}
                    </div>
                  )}
              </Grid>
            </Grid>
          )}

          {/*Construction Period */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Construction Period"
              style={{ marginBottom: "5px" }}
              required
            >
              Construction Period
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="construction_period"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.construction_period}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="1960 to now (project home)">1960 to now (project home)</MenuItem>
              <MenuItem value="1960 to now (Architect)">1960 to now (Architect)</MenuItem>
              <MenuItem value="1946-1959">1946-1959</MenuItem>
              <MenuItem value="1914-1945">1914-1945</MenuItem>
              <MenuItem value="1891-1913">1891-1913</MenuItem>
              <MenuItem value="1840-1890">1840-1890</MenuItem>
            </Select>
            {Tab4_Validation_Land_Var.construction_period !== null &&
              Tab4_Validation_Land_Var.construction_period !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.construction_period}
                </div>
              )}
          </Grid>

          {/* Original Year Built */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Original Year Built"
              style={{ marginBottom: "5px" }}
              required
            >
              Original Year Built
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <TextField
              name="original_year_build"
              size="small"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              // style={{ marginBottom: "20px" }}
              fullWidth
              value={Tab4_Building_Land_Var.original_year_build}
              onKeyPress={(e) => validationForNumbOnly(e)}
            />
            {Tab4_Validation_Land_Var.original_year_build !== null &&
              Tab4_Validation_Land_Var.original_year_build !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.original_year_build}
                </div>
              )}
          </Grid>

          {/*Construction of the walls*/}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Construction of the walls"
              style={{ marginBottom: "5px" }}
              required
            >
              Construction of the walls
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="construction_wall"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.construction_wall}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Concrete">Concrete</MenuItem>
              <MenuItem value="Metal">Metal </MenuItem>
              <MenuItem value="Blockwork">Blockwork </MenuItem>
              <MenuItem value="Brick Veneer">Brick Veneer</MenuItem>
              <MenuItem value="Double Brick">Double Brick</MenuItem>
              <MenuItem value="Fibrecement (Asbestos)">Fibrecement (Asbestos)</MenuItem>
              <MenuItem value="Straw / Mudbrick">Straw / Mudbrick </MenuItem>
              <MenuItem value="EPS/Sandwich Panel">EPS/Sandwich Panel </MenuItem>
              <MenuItem value="Stonework">Stonework </MenuItem>
              <MenuItem value="Weatherboard - Timber">Weatherboard - Timber</MenuItem>
              <MenuItem value="Other (Not EPS)">Other (Not EPS)</MenuItem>

            </Select>
            {Tab4_Validation_Land_Var.construction_wall !== null &&
              Tab4_Validation_Land_Var.construction_wall !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.construction_wall}
                </div>
              )}
          </Grid>

          {/*Roof construction*/}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Roof construction"
              style={{ marginBottom: "5px" }}
              required
            >
              Roof Construction
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="roof_construction"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.roof_construction}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Colourbond">Colourbond</MenuItem>
              <MenuItem value="Concrete Tile">Concrete Tile</MenuItem>
              <MenuItem value="ConcFibrecement (Asbestos)rete">Fibrecement (Asbestos)</MenuItem>
              <MenuItem value="Fibrecement (Not Asbestos)">Fibrecement (Not Asbestos)</MenuItem>
              <MenuItem value="Metal Covering">Metal Covering</MenuItem>
              <MenuItem value="EPS/Sandwich Panel">EPS/Sandwich Panel</MenuItem>
              <MenuItem value="Slate">Slate</MenuItem>
              <MenuItem value="Terracotta">Terracotta</MenuItem>
              <MenuItem value="Timber Shingles">Timber Shingles</MenuItem>
              <MenuItem value="Other">Other</MenuItem>
            </Select>
            {Tab4_Validation_Land_Var.roof_construction !== null &&
              Tab4_Validation_Land_Var.roof_construction !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.roof_construction}
                </div>
              )}
          </Grid>

          {/*Number of bathrooms and ensuites*/}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Number of bathrooms and ensuites"
              style={{ marginBottom: "5px" }}
              required
            >
              Number of bathrooms and ensuites
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="numbers_of_bathrooms"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.numbers_of_bathrooms}

            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="1">1</MenuItem>
              <MenuItem value="2">2</MenuItem>
              <MenuItem value="3">3</MenuItem>
              <MenuItem value="4">4</MenuItem>
              <MenuItem value="5">5</MenuItem>
              <MenuItem value="6">6</MenuItem>
              <MenuItem value="7">7</MenuItem>
              <MenuItem value="8">8</MenuItem>
              <MenuItem value="9+">9+</MenuItem>

            </Select>
            {Tab4_Validation_Land_Var.numbers_of_bathrooms !== null &&
              Tab4_Validation_Land_Var.numbers_of_bathrooms !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.numbers_of_bathrooms}
                </div>
              )}
          </Grid>

          {/*Number of bedrooms*/}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Number of bedrooms"
              style={{ marginBottom: "5px" }}
              required
            >
              Number of bedrooms
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="numbers_of_bedrooms"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.numbers_of_bedrooms}

            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="1">1</MenuItem>
              <MenuItem value="2">2</MenuItem>
              <MenuItem value="3">3</MenuItem>
              <MenuItem value="4">4</MenuItem>
              <MenuItem value="5">5</MenuItem>
              <MenuItem value="6">6</MenuItem>
              <MenuItem value="7">7</MenuItem>
              <MenuItem value="8">8</MenuItem>
              <MenuItem value="9+">9+</MenuItem>

            </Select>
            {Tab4_Validation_Land_Var.numbers_of_bedrooms !== null &&
              Tab4_Validation_Land_Var.numbers_of_bedrooms !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.numbers_of_bedrooms}
                </div>
              )}
          </Grid>

          {/*Construction quality of home*/}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Construction quality of home"
              style={{ marginBottom: "5px" }}
              required
            >
              Construction quality of home
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="construction_quality"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.construction_quality}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Standard">Standard</MenuItem>
              <MenuItem value="Quality">Quality</MenuItem>
              <MenuItem value="Prestige">Prestige</MenuItem>

            </Select>
            {Tab4_Validation_Land_Var.construction_quality !== null &&
              Tab4_Validation_Land_Var.construction_quality !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.construction_quality}
                </div>
              )}
          </Grid>

          {/*Storeys*/}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Storeys"
              style={{ marginBottom: "5px" }}
              required
            >
              Storeys
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="storeys"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.storeys}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Ground">Ground</MenuItem>
              <MenuItem value="1">1</MenuItem>
              <MenuItem value="2">2</MenuItem>
              <MenuItem value="3 or more">3 or more</MenuItem>

            </Select>
            {Tab4_Validation_Land_Var.storeys !== null &&
              Tab4_Validation_Land_Var.storeys !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.storeys}
                </div>
              )}
          </Grid>

          {/*Unit Building Level*/}
          {((Tab4_Building_Land_Var.building_type === "Apartment / Unit (Ground Floor)") || (Tab4_Building_Land_Var.building_type === "Apartment / Unit (Above Ground Floor)")) && (
            <Grid container xs={12} direction="row" spacing={2}>
              <Grid item xs={6}>
                <InputLabel
                  htmlFor="Unit Building Level"
                  style={{ marginBottom: "5px" }}
                  required
                >
                  Unit Building Level
                </InputLabel>
              </Grid>

              <Grid item xs={6}>
                <Select
                  name="unit_building_level"
                  margin="none"
                  variant="outlined"
                  onChange={onChangeField}
                  style={{ marginBottom: "20px", height: "40px" }}
                  fullWidth
                  value={Tab4_Building_Land_Var.unit_building_level}
                >
                  <MenuItem disabled value=" ">
                    Please Select
                  </MenuItem>
                  <MenuItem value="Low-Rise (1-3 storey)">Low-Rise (1-3 storey)</MenuItem>
                  <MenuItem value="Mid-Rise (4-7 storey)">Mid-Rise (4-7 storey)</MenuItem>
                  <MenuItem value="High-Rise (8-14 storey)">High-Rise (8-14 storey)</MenuItem>
                  <MenuItem value="Tall (15+ storey)">Tall (15+ storey)</MenuItem>
                </Select>
                {Tab4_Validation_Land_Var.unit_building_level !== null &&
                  Tab4_Validation_Land_Var.unit_building_level !== "true" && (
                    <div className="text-danger font-italic">
                      {Tab4_Validation_Land_Var.unit_building_level}
                    </div>
                  )}
              </Grid>
            </Grid>
          )}

          {/* Building size in square meters */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Building size in square meters"
              style={{ marginBottom: "5px" }}
            >
              Building size in square meters
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <TextField
              name="building_size"
              size="small"
              variant="outlined"
              autoComplete="off"
              onChange={onChangeField}
              // style={{ marginBottom: "20px" }}
              fullWidth
              value={Tab4_Building_Land_Var.building_size}
              onKeyPress={(e) => validationForNumbOnly(e)}
            />
            {Tab4_Validation_Land_Var.building_size !== null &&
              Tab4_Validation_Land_Var.building_size !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.building_size}
                </div>
              )}
          </Grid>


          {/* House within 250m of named water course or effected by flood */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="House within 250m of named water course or effected by flood"
              style={{ marginBottom: "5px" }}
              required
            >
              House within 250m of named water course or effected by flood
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="effected_by_flood"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.effected_by_flood}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab4_Validation_Land_Var.effected_by_flood !== null &&
              Tab4_Validation_Land_Var.effected_by_flood !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.effected_by_flood}
                </div>
              )}
          </Grid>


          {/* Mains Water Supply */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Mains Water Supply"
              style={{ marginBottom: "5px" }}
              required
            >
              Mains Water Supply
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="main_water_supply"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.main_water_supply}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab4_Validation_Land_Var.main_water_supply !== null &&
              Tab4_Validation_Land_Var.main_water_supply !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.main_water_supply}
                </div>
              )}
          </Grid>

          {/*Window Security*/}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Window Security"
              style={{ marginBottom: "5px" }}
              required
            >
              Window Security
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="window_security"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.window_security}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Key Operated Locks">Key Operated Locks</MenuItem>
              <MenuItem value="No accessible windows">No accessible windows</MenuItem>
              <MenuItem value="Security screens">Security screens</MenuItem>
              <MenuItem value="None of these">None of these</MenuItem>

            </Select>
            {Tab4_Validation_Land_Var.window_security !== null &&
              Tab4_Validation_Land_Var.window_security !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.window_security}
                </div>
              )}
          </Grid>

          {/*Door Security*/}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Door Security"
              style={{ marginBottom: "5px" }}
              required
            >
              Door Security
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="door_security"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.door_security}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Key operated dead locks/bolts">Key operated dead locks/bolts</MenuItem>
              <MenuItem value="Security cards">Security cards</MenuItem>
              <MenuItem value="None of the above">None of the above</MenuItem>

            </Select>
            {Tab4_Validation_Land_Var.door_security !== null &&
              Tab4_Validation_Land_Var.door_security !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.door_security}
                </div>
              )}
          </Grid>

          {/*Burglar Alarm*/}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Burglar Alarm"
              style={{ marginBottom: "5px" }}
              required
            >
              Burglar Alarm
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="burglar_alarm"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.burglar_alarm}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Back to base">Back to base</MenuItem>
              <MenuItem value="Local">Local</MenuItem>
              <MenuItem value="None">None</MenuItem>

            </Select>
            {Tab4_Validation_Land_Var.burglar_alarm !== null &&
              Tab4_Validation_Land_Var.burglar_alarm !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.burglar_alarm}
                </div>
              )}
          </Grid>

          {/*Smoke Detectors*/}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Burglar Alarm"
              style={{ marginBottom: "5px" }}
              required
            >
              Smoke Detectors
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="smoke_detector"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.smoke_detector}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="Back to base">Back to base</MenuItem>
              <MenuItem value="Local">Local</MenuItem>
              <MenuItem value="None">None</MenuItem>

            </Select>
            {Tab4_Validation_Land_Var.smoke_detector !== null &&
              Tab4_Validation_Land_Var.smoke_detector !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.smoke_detector}
                </div>
              )}
          </Grid>

          {/* Building or construction in the next 12 months */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Building or construction in the next 12 months"
              style={{ marginBottom: "5px" }}
              required
            >
              Building or construction in the next 12 months
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="building_construction12months"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.building_construction12months}
            >

              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab4_Validation_Land_Var.building_construction12months !== null &&
              Tab4_Validation_Land_Var.building_construction12months !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.building_construction12months}
                </div>
              )}
          </Grid>

          {/* Does the property have a swimming pool, outdoor spa or lift */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Does the property have a swimming pool, outdoor spa or lift"
              style={{ marginBottom: "5px" }}
              required
            >
              Does the property have a swimming pool, outdoor spa or lift
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="outdoor_spa"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.outdoor_spa}
            >

              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab4_Validation_Land_Var.outdoor_spa !== null &&
              Tab4_Validation_Land_Var.outdoor_spa !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.outdoor_spa}
                </div>
              )}
          </Grid>

          {/* Is there any portion of the Building or Contents located below ground level? e.g. basement, garage, storage room */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Is there any portion of the Building or Contents located below ground level? e.g. basement, garage, storage room"
              style={{ marginBottom: "5px" }}
              required
            >
              Is there any portion of the Building or Contents located below ground level? e.g. basement, garage, storage room
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="located_below_ground"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.located_below_ground}
            >

              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab4_Validation_Land_Var.located_below_ground !== null &&
              Tab4_Validation_Land_Var.located_below_ground !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.located_below_ground}
                </div>
              )}
          </Grid>

          {/* Are there any private flood mitigation measures at your property? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Are there any private flood mitigation measures at your property?"
              style={{ marginBottom: "5px" }}
              required
            >
              Are there any private flood mitigation measures at your property?
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="flood_mitigration"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.flood_mitigration}
            >

              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab4_Validation_Land_Var.flood_mitigration !== null &&
              Tab4_Validation_Land_Var.flood_mitigration !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.flood_mitigration}
                </div>
              )}
          </Grid>

          {/* Has property an occupancy certificate */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Has property an occupancy certificate"
              style={{ marginBottom: "5px" }}
              required
            >
              Has property an occupancy certificate
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="occupancy_certificate"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.occupancy_certificate}
            >

              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab4_Validation_Land_Var.occupancy_certificate !== null &&
              Tab4_Validation_Land_Var.occupancy_certificate !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.occupancy_certificate}
                </div>
              )}
          </Grid>

          {/* Is the property registered under a Body Corporate ? */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Is the property registered under a Body Corporate ?"
              style={{ marginBottom: "5px" }}
              required
            >
              Is the property registered under a Body Corporate ?
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="register_body_corprote"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.register_body_corprote}
            >
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab4_Validation_Land_Var.register_body_corprote !== null &&
              Tab4_Validation_Land_Var.register_body_corprote !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.register_body_corprote}
                </div>
              )}
          </Grid>

          {/* Is the property part of a strata title */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="Is the property part of a strata title"
              style={{ marginBottom: "5px" }}
              required
            >
              Is the property part of a strata title
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <Select
              name="strata_title"
              margin="none"
              variant="outlined"
              onChange={onChangeField}
              style={{ marginBottom: "20px", height: "40px" }}
              fullWidth
              value={Tab4_Building_Land_Var.strata_title}
            >
              <MenuItem disabled value=" ">
                Please Select
              </MenuItem>
              <MenuItem value="No">No</MenuItem>
              <MenuItem value="Yes">Yes</MenuItem>
            </Select>
            {Tab4_Validation_Land_Var.strata_title !== null &&
              Tab4_Validation_Land_Var.strata_title !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.strata_title}
                </div>
              )}
          </Grid>

          {/* How many unrelated persons are living in the building */}
          <Grid item xs={6}>
            <InputLabel
              htmlFor="How many unrelated persons are living in the building"
              style={{ marginBottom: "5px" }}
              required
            >
              How many unrelated persons are living in the building
            </InputLabel>
          </Grid>

          <Grid item xs={6}>
            <TextField
              name="person_living_the_building"
              size="small"
              variant="outlined"
              autoComplete="off"
              style={{ marginBottom: "20px" }}
              fullWidth
              onChange={onChangeField}
              value={Tab4_Building_Land_Var.person_living_the_building}
              onKeyPress={(e) => validationForNumbOnly(e)}
            />
            {Tab4_Validation_Land_Var.person_living_the_building !== null &&
              Tab4_Validation_Land_Var.person_living_the_building !== "true" && (
                <div className="text-danger font-italic">
                  {Tab4_Validation_Land_Var.person_living_the_building}
                </div>
              )}
          </Grid>

          <Grid item xs={6}>
            <Button
              variant="contained"
              color="secondary"
              style={{
                marginTop: "1rem",
                float: "left",
                width: "20%",
              }}
              onClick={() => {
                returnClientLand()
              }}
            >
              EXIT
            </Button>
          </Grid>

          <Grid item xs={6}>
            <Button
              variant="contained"
              color="primary"
              style={{
                marginTop: "1rem",
                float: "right",
              }}
              onClick={() => navigation.next()}
            >
              NEXT
            </Button>
            <Button
              variant="contained"
              color="primary"
              // className="bg-warning"
              style={{
                marginTop: "1rem",
                float: "right",
                marginBottom: "50px",
                marginRight: "20px",
                width: "20%",
              }}
              onClick={() => navigation.previous()}
            >
              PREVIOUS
            </Button>
          </Grid>













        </Grid>

      </div>
    </Container>
  );
}




export default Tab4_Building_Land;