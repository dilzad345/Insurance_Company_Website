import React, { useEffect, useState  } from "react";
import Tab1_Client_Land from "./Tab1_Client_Land";
import Tab2_Importan_Question_Land from "./Tab2_Importan_Question_Land"
import Tab3_Policycore_Land from "./Tab3_Policycore_Land";
import Tab4_Building_Land from "./Tab4_Building_Land";
import Tab5_Contents_Land from "./Tab5_Contents_Land";
import Tab6_Claims_Land from "./Tab6_Claims_Land";
import { useStateWithCallbackLazy } from "use-state-with-callback";
import {updateAllForms} from "./controllerEditLink";
import { useStep } from "react-hooks-helper";
import {navigationBar} from "../core/navigationBarLand";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import history from "../auth/history";
import { signout } from "../auth";


import{
  validateAllForms,
  getQuotationDetail, 
  assignValueTab1, 
  assignValuesTab2,
  assignValuesTab3,
  assignValuesTab4,
  assignValuesTab5,
  assignValuesTab6
} from "./controllerEditLink";

let tokenError = false;

//Error message for invalid tokeTab2_Importan_Question_Landn
const tokenErrorMessage = (tokenError) => {
  return (
    <div>
      {tokenError === true &&
        confirmAlert({
          title: "Invalid User",
          message: "Re-login to system.",
          buttons: [
            {
              label: "Login",
              onClick: () => {
                signout(() => {
                  history.push("/login");
                });
              },
            },
          ],
        })}
    </div>
  );
};
// navigation helper
const steps = [
    { id: "Tab1_Client_Land" },
    { id: "Tab2_IqLand" },
    { id: "Tab3_PolicycoreLand" },
    { id: "Tab4_buildingLand" },
    { id: "Tab5_ContentsLand" },
    { id: "Tab6_claimsLand" },
  ];

const EditLinkLand = (props) =>{
  
    const [quotationId, setQuotationId] = useStateWithCallbackLazy();
    // console.log(props);
    const { step, navigation } = useStep({
      steps,
      initialStep: 0,
    }); // end of useStep

    // get all quotation details from the db and assign values to the related variables
  useEffect(() => {
    //props.match.params.quotation_id
    // console.log(quotationId);
    setQuotationId(props.id, () => {
      assignValuesToEveryForm(props.id );
      //set_quotationEdit(result_quotationEdit, () => {console.log(quotationEdit);});
    });
  });


const assignValuesToEveryForm = async(quotationId) =>{
    if(quotationId){
        await getQuotationDetail(quotationId)
        .then(async(resQuote)=>{
            // console.log("results:" ,resQuote.data.data);

            if (resQuote.data.message) {
                console.log("Error in token");
                tokenError = true;
                tokenErrorMessage(tokenError);
              }
              else{
                  const dataClient =resQuote.data.data.ClientDetailsForLand;
                  // console.log(dataClient);
                  const dataIq = resQuote.data.data.IqDetailsForLand;
                  const dataPolicyCore = resQuote.data.data.PolicycoreDetailsForLand;
                  const dataBuilding = resQuote.data.data.BuildingDetailsForLand;
                  const dataContents = resQuote.data.data.ContentsDetailsForLand;
                  const dataClaims = resQuote.data.data.ClaimsDetailsForLand
                  assignValueTab1(dataClient, Tab1_Client_Land_var, setTab1);
                  assignValuesTab2(dataIq,Tab2_Importan_Question_Land_var,setTab2);
                  assignValuesTab3(dataPolicyCore,Tab3_Policycore_Land_Var, setTab3)
                  assignValuesTab4(dataBuilding,Tab4_Building_Land_Var, setTab4);
                  assignValuesTab5(dataContents, Tab5_Contents_Land_Var, setTab5, setTab5_validation);
                  assignValuesTab6(dataClaims,Tab6_Claims_Land_Var,setTab6,setTab6_validation);

              }
        })
        .catch((error)=>{
            console.log(error);
        }) 
    }
}

const [Tab1_Client_Land_var, setTab1] = useStateWithCallbackLazy({
    uiPathIdForLand : "",
    client_type: "Company",
    client_title: " ",
    client_firstName: "Anantha",
    client_lastName: "Raj",
    company_name: "KaayalTek",
    trading_as: "Software Solutions",
    reference_code: "0000",
    unit_number_postal: "111",
    street_number_postal: "145",
    street_name_postal: "Railway Stations Road",
    street_type_postal: "street",
    suburb_postal: "Subb",
    state_postal: "QLD",
    postcode_postal: '1234',
    phone: "0117788985",
    email: "sample@mail.com",
    branch: "Insurance Brokers Australia",
    sales_team: "Chris Dalton",
    service_team: "Brisbane",
    insuredAddress:"Yes",
    unit_number_insured: "",
  street_number_insured: "",
  street_name_insured: "",
  street_type_insured: "Please Select",
  suburb_insured: "",
  state_insured: "Please Select",
  postcode_insured: "",
    });
  
    // tab1 validation
    const [Tab1_Validation_Land_Var, setTab1_validation] = useState({
      // client_type: null,
      // client_title: null,
      // client_firstName: null,
      // client_lastName: null,
      // company_name: null,
      // trading_as: null,
      // unit_number_postal: null,
      // street_number_postal: ,
      // street_name_postal: "",
      // street_type_postal: " ",
      // suburb_postal: "",
      // state_postal: " ",
      // postcode_postal: "",
      // phone: "",
      // email: "",
      // branch: "",
      // sales_team: "",
      // service_team: "",
      // unit_number_insured:"",
      // street_number_insured: "",
      // street_name_insured: "",
      // street_type_insured: " ",
      // suburb_insured: "",
      // state_insured: " ",
      // postcode_insured: "",
    });

    const[Tab2_Importan_Question_Land_var,setTab2] = useStateWithCallbackLazy({
    any_policy_decline_last5years: "No",
    howmany_policy_decline_last5years: "1",
    howmany_policy_decline_last3years: "1",
    reason_forThe_decline: "Cancelled due to change in risk outside the insurer's underwriting guidelines",
    clime_decline: "No",
    reason_clime_decline: "required to be disclosed",
    any_criminal_conviction: "No",
    property_everBe_unoccupied: "No",
    checking_onThe_property: "No",
    why_property_unoccupied: "No",
    under_construction_renovation: "No",
    renovation_over$100000: "No",
    value_of_renovation: "No",
    start_date_renovations: new Date(),
    Estimated_completion_date: new Date(),
    what_work_undertaken: "undertaken",
    building_not_secure: "No",
    contract_works_policy: "No",
    external_roof_walls: "No",
    rain_intoThe_building: "No",
    poorly_maintained: "No",
    property_heritage: "No",
    details_heritage_list: "heritage listing",
    bed_breakfast: "No",
    boarding_house: "No",
    used_hostel: "No",
    community_public_housing: "No",
    home_office_surgery: "No",
    social_housing_service: "No",
    property_redevelopment: "No",
    property_trust: "No",
    flooded_last_10years: "No",
    property_used_farming: "No",
    business_activity_conducted: " ",
    });

    const [Tab2_Validation_Land_Var, setTab2_validation] = useState({
      howmany_policy_decline_last5years: null,
      howmany_policy_decline_last3years: null,
      reason_forThe_decline: null,
      reason_clime_decline: "",
      checking_onThe_property: null,
      why_property_unoccupied: "",
      renovation_over$100000: null,
      value_of_renovation: "",
      start_date_renovations: "",
      Estimated_completion_date: "",
      what_work_undertaken: "",
      details_heritage_list: "",
      business_activity_conducted: null,
    });

    const [Tab3_Policycore_Land_Var, setTab3] = useStateWithCallbackLazy({
      cover_type_accidential: "Accidental Damage",
      occupancy_home: "Rented to tenants (Long Term)",
      property_managed: "Landlord manages the property",
      building_content: "Building only",
      building_sum_insured: "1000",
      content_ins_amount: "1000",
      policy_from_date: new Date(),
      policy_to_date: new Date(),
      dob_oldest_insured: new Date(),  //dob:date of birth
      currently_hold_insurence: "No",
      current_insurer: "AAMI",
      policyholder_retired: "No",
      interested_parties: "Adelaide Bank",
      holding_broker: "No",
      holding_underwriter: "AAMI",
      stamp_duty_exempt: "No",
      no_claim_bonus: "60% - Level 1",
      payment_frequency: "Yearly",
      preffered_day_installment: "preffered_day_installment",
      broker_fee_installment: "1000",
      cover_Theft_tenant: "No",
      cover_loss: "No",
      sum_ins_amount_loss: "1000",
      annual_rent_amount: "1000",
      weekly_rent_amount: "1000",
      cover_rent_default: "No",
      cover_Accidental_damage: "No",
      tenant_rent_14Days: "No",
      residential_lease_agreement: "Yes",
      landlord_insurance_policy: "No",
      svu_excess_option1: "300",
      svu_excess_option2: "300",
      svu_excess_option3: "300",
      broker_fee: "600",
    });
  
    // tab3 validation
    const [Tab3_Validation_Land_Var, setTab3_validation] = useState({
      occupancy_home: null,
      property_managed: null,
      building_content: null,
      policy_from_date: null,
      policy_to_date: null,
      dob_oldest_insured: null,
      currently_hold_insurence: null,
      interested_parties: null,
      holding_broker: null,
      holding_underwriter: null,
      stamp_duty_exempt: null,
      no_claim_bonus: null,
      payment_frequency: null,
      preffered_day_installment: "",
      broker_fee_installment: "",
      cover_Theft_tenant: null,
      cover_loss: null,
      sum_ins_amount_loss: "",
      annual_rent_amount: "",
      weekly_rent_amount: "",
      cover_rent_default: null,
      tenant_rent_14Days: null,
      landlord_insurance_policy: null,
      svu_excess_option1: null,
      svu_excess_option2: null,
      svu_excess_option3: null,
     
    });

    const [Tab4_Building_Land_Var,setTab4] = useStateWithCallbackLazy({
      building_type: "Free Standing / House",
      free_standing_what_built: "Concrete slab",
      apartment_what_type: "Ground floor",
      semi_deteched_what_type: "Duplex/Triplex",
      semi_deteched_body_corprate: "No",
      dewelling_what_describe: "Granny flat",
      multiple_unit_insured_all: "No",
      multiple_unit_number: "10s",
      multiple_unit_insured_building: "No",
      multiple_unit_total_units: "No",
      construction_period: "1960 to now (project home)",
      original_year_build: "1",
      construction_wall: "Concrete",
      roof_construction: "Colourbond",
      numbers_of_bathrooms: "1",
      numbers_of_bedrooms: "1",
      construction_quality: "Standard",
      storeys: "Ground",
      unit_building_level: "Low-Rise (1-3 storey)",
      building_size: "100",
      effected_by_flood: "No",
      main_water_supply: "No",
      window_security: "Key Operated Locks",
      door_security: "Key operated dead locks/bolts",
      burglar_alarm: "Back to base",
      smoke_detector: "Back to base",
      building_construction12months: "No",
      outdoor_spa: "No",
      located_below_ground: "No",
      flood_mitigration: "No",
      occupancy_certificate: "No",
      register_body_corprote: "No",
      strata_title: "No",
      person_living_the_building: "5",
    })
    const [Tab4_Validation_Land_Var, setTab4_validation] = useState({
      building_type: null,
    free_standing_what_built: null,
    apartment_what_type: null,
    unit_building_level: null,
    semi_deteched_what_type: null,
    semi_deteched_body_corprate: null,
    multiple_unit_insured_all: null,
    multiple_unit_number:"",
    multiple_unit_insured_building: null,
    multiple_unit_total_units: null,
    construction_period: null,
    original_year_build:"",
    construction_wall: null,
    roof_construction: null,
    numbers_of_bathrooms: null,
    numbers_of_bedrooms: null,
    construction_quality: null,
    storeys: null,
    building_size:"",
    effected_by_flood: null,
    main_water_supply: null,
    window_security: null,
    door_security: null,
    burglar_alarm: null,
    smoke_detector: null,
    building_construction12months: null,
    outdoor_spa: null,
    located_below_ground: null,
    flood_mitigration: null,
    occupancy_certificate: null,
    register_body_corprote: null,
    strata_title: null,
    person_living_the_building:"",
    })
    const [Tab5_Contents_Land_Var, setTab5] = useStateWithCallbackLazy([]);

    const [Tab5_Validation_Land_Var, setTab5_validation] = useState([]);
  
    const [Tab6_Claims_Land_Var, setTab6] = useStateWithCallbackLazy([]);

  const [Tab6_Validation_Land_Var, setTab6_validation] = useState([]);

// Update all forms
const updateAllForm = () => {
  return updateAllForms(
    Tab1_Client_Land_var,
    Tab2_Importan_Question_Land_var,
    Tab3_Policycore_Land_Var,
    Tab4_Building_Land_Var,
    Tab5_Contents_Land_Var,
    Tab6_Claims_Land_Var,
    quotationId
  )
    .then((res) => {
      // console.log(res.data.Message);
      if (res.status === 200) {
        console.log("No Error");
        return res.data.Message;
      } else {
        console.log("Error");
        return false;
      }
    })
    .catch((err) => {
      console.log(err);
      return false;
    });
}; // end of submit function

  // validate all forms
  const isAllFormsValid = () => {

    // console.log("validate a;ll forms: ", Tab6_Claims_Home_Var)
    const isValid = validateAllForms(
      Tab1_Client_Land_var,
      Tab2_Importan_Question_Land_var,
      Tab3_Policycore_Land_Var,
      Tab4_Building_Land_Var,
      Tab5_Contents_Land_Var,
      Tab6_Claims_Land_Var
    );
    return isValid;
  };
const props1 = {
        Tab1_Client_Land_var,
        setTab1,
        Tab1_Validation_Land_Var, 
        setTab1_validation,
        navigation,
      };

const props2 ={
  Tab2_Importan_Question_Land_var,
  setTab2,
  Tab2_Validation_Land_Var,
  setTab2_validation,
  navigation
};

const props3 ={
  Tab3_Policycore_Land_Var,
  setTab3,
  Tab3_Validation_Land_Var,
  setTab3_validation,
  navigation
};

const props4 ={
  Tab4_Building_Land_Var,
  setTab4,
  Tab4_Validation_Land_Var,
  setTab4_validation,
  navigation
}

const props5 ={
  Tab5_Contents_Land_Var,
  setTab5,
  Tab5_Validation_Land_Var,
  setTab5_validation,
  navigation
}
const props6 ={
  Tab6_Claims_Land_Var,
  setTab6,
  Tab6_Validation_Land_Var,
  setTab6_validation,
  isAllFormsValid,
  updateAllForm,
  navigation
}
// console.log(props5)
      const displayTabs = () => {
        // console.log(step.id);
        switch (step.id) {
          default:
            return <Tab1_Client_Land {...props1} />;
          case "Tab1_Client_Land":
            return <Tab1_Client_Land {...props1} />;
          case "Tab2_IqLand":
            return <Tab2_Importan_Question_Land {...props2} />;
          case "Tab3_PolicycoreLand":
            return <Tab3_Policycore_Land {...props3} />;
          case "Tab4_buildingLand":
            return <Tab4_Building_Land {...props4} />;
          case "Tab5_ContentsLand":
            return <Tab5_Contents_Land {...props5} />;
          case "Tab6_claimsLand":
            return <Tab6_Claims_Land {...props6} />;
    
        }
      };

const propsNavBar ={
    step,
    navigation,
    Tab1_Client_Land_var,
    Tab2_Importan_Question_Land_var,
    Tab3_Policycore_Land_Var,
    Tab4_Building_Land_Var,
    Tab5_Contents_Land_Var,
    Tab6_Claims_Land_Var
}
      return (
          <>
          {navigationBar(propsNavBar)}
          {displayTabs()}
      <ToastContainer
        style={{ marginLeft: "50px", marginBottom: "-25px", width: "30%" }}
      />
          </>
      )
}
export default EditLinkLand;
    
    