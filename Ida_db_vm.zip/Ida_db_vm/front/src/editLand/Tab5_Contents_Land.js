import React from "react";
import {
  TextField,
  Container,
  Button,
  InputLabel,
  MenuItem,
  Select,
  Grid,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import InputAdornment from "@material-ui/core/InputAdornment";
import {validationForSpecialchar , validationForAlpha , validationForNumbOnly} from "../constants/validChecker";
import {
  type_validate,
  category_validate,
  description_validate,
  value_validate,
} from "../validationLand/Tab5_Validation_Land";



// const useStyles = makeStyles((theme) => ({
//   root: {
//     flexGrow: 1,
//     alignContent: "center",
//     padding: theme.spacing(2),
//     //textAlign: 'center',
//   },
//   paper: {
//     padding: theme.spacing(2),
//     textAlign: "center",
//     color: theme.palette.text.secondary,
//   },
// }));

const notifyDeletecontent = () =>
  toast.success("Content Deleted!", {
    position: "bottom-center",
    autoClose: 5000,
    hideProgressBar: true,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
  });

const Tab5_Contents_Land = ({
  Tab5_Contents_Land_Var,
  setTab5,
  Tab5_Validation_Land_Var,
  setTab5_validation,
  navigation,
}) => {
  // const modiCount = Tab5_Contents_Land_Var.length;
  // const classes = useStyles();
  // console.log(Tab5_Contents_Land_Var);
  // add a vehicle modifications
  const addMore = () => {
    setTab5((Tab5_Contents_Land_Var) => [
      ...Tab5_Contents_Land_Var,
      { edit:"NEW",type: " ", category: " ", description: "", value: "" },
    ]);
    setTab5_validation((Tab5_Validation_Land_Var) => [
      ...Tab5_Validation_Land_Var,
      { type: " ", category: " ", description: "", value: "" },
    ]);
  };

  const deletecontent = (ind) => {
    console.log(ind);
    let tempArr = [...Tab5_Contents_Land_Var];
    console.log("temp array tab5 contents: ", tempArr);
    let tempObj = tempArr[ind];
    // let tempValidate = [...Tab5_Validation_Home_Var];
    // console.log(tempValidate);
    confirmAlert({
      title: "Confirm to delete",
      message: "Are you sure to do this?",
      buttons: [
        {
          label: "Yes",
          onClick: () => {

            if (tempObj.edit === "NEW") {
              console.log("new delete: " + ind);
              const temp = [...Tab5_Contents_Land_Var];
              const tempValidate = [...Tab5_Validation_Land_Var];
              temp.splice(ind, 1); // removing the element using splice
              tempValidate.splice(ind, 1);
              Tab5_Contents_Land_Var = temp;
              Tab5_Validation_Land_Var = tempValidate;

              // updating the list
              setTab5(temp);
              setTab5_validation(tempValidate);

            }
            else {
              console.log("contents: old")
              tempObj = {
                // updating the temporary list
                ...tempObj,
                edit: "DELETED",
              };
              tempArr[ind] = tempObj; // replace the list with temporary list
              console.log("ind: " + ind + " edit: " + tempArr[ind].edit);
              setTab5(tempArr);
              console.log(tempArr)
            }
            notifyDeletecontent();
          },
        },
        {
          label: "No",
          onClick: () => null,
        },
      ],
    });
  };

  // on change method; to change field values according to the changes
  const onChangeField = (ind) => (event) => {
    let name = event.target.name;
    let value = event.target.value;
    // make a copy of original list as temporary list
    let tempArr = [...Tab5_Contents_Land_Var];
    let tempObj = tempArr[ind];

    // updating the temporary list
    tempObj = {
      ...tempObj,
      [event.target.name]: event.target.value,
    };

    // replace the list with temporary list
    tempArr[ind] = tempObj;
    //console.log(tempArr);

    setTab5(tempArr, () => {
      validationAfterChange(ind, name, value);
    });
  };

  // call validation
  const validationAfterChange = (index, name, value) => {
    switch (name) {
      case "type": {
        type_validate(index, value, Tab5_Validation_Land_Var, setTab5_validation);
        break;
      }
      case "category": {
        category_validate(index, value, Tab5_Validation_Land_Var, setTab5_validation);
        break;
      }
      case "description": {
        description_validate(index, value, Tab5_Validation_Land_Var, setTab5_validation);
        break;
      }
      case "value": {
        value_validate(index, value, Tab5_Validation_Land_Var, setTab5_validation);
        break;
      }
      default: {
        return "Not match to condition";
      }
    }
  };

  return (
    <Container maxWidth="md" style={{ marginBottom: "50px" }}>
      <div className="container p-3 my-3dark text-dark">
        <Grid item xs={12} textalign="center" justifyContent="center" container>
          <h3>CONTENTS</h3>
        </Grid>
        {Tab5_Contents_Land_Var.map((modi, index) => {
          return (
            <div key={index}>
              <Grid
                container
                spacing={3}
                direction="row"
                justifyContent="center"
                alignItems="center"
                style={{ marginBottom: "20px", marginTop: "20px" }}
              >
                <Grid item xs={4}>
                  <InputLabel
                    htmlFor="Type"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    Type
                  </InputLabel>
                </Grid>

                <Grid item xs={8} style={{ marginBottom: "20px" }}>
                  <Select
                    name="type"
                    variant="outlined"
                    autoComplete="off"
                    onChange={onChangeField(index)}
                    onClose={() =>
                      validationAfterChange(index, "type", modi.type)
                    }
                    value={modi.type}
                    style={{ height: "40px" }}
                    fullWidth
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    <MenuItem value="Valuable Item">Valuable Item</MenuItem>
                    <MenuItem value="Specified Portable Item">
                    Specified Portable Item
                    </MenuItem>
                  </Select>
                  {/* {Tab5_Validation_Land_Var[index].type !== null &&
                    Tab5_Validation_Land_Var[index].type !== "true" && (
                      <div className="text-danger font-italic">
                        {Tab5_Validation_Land_Var[index].type}
                      </div>
                    )} */}
                </Grid>

                <Grid item xs={4}>
                  <InputLabel
                    htmlFor="Category"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    Category
                  </InputLabel>
                </Grid>

                <Grid item xs={8} style={{ marginBottom: "20px" }}>
                  <Select
                    name="category"
                    variant="outlined"
                    autoComplete="off"
                    onChange={onChangeField(index)}
                    onClose={() =>
                      validationAfterChange(index, "category", modi.category)
                    }
                    value={modi.category}
                    style={{ height: "40px" }}
                    fullWidth
                  >
                    <MenuItem disabled value=" ">
                      Please Select
                    </MenuItem>
                    <MenuItem value="Handbags and Wallets">Handbags and Wallets</MenuItem>
                    <MenuItem value="Jewellery and Watches">
                    Jewellery and Watches
                    </MenuItem>
                    <MenuItem value="Phones,Laptops and Tablets">Phones,Laptops and Tablets</MenuItem>
                    <MenuItem value="Other portable electronics">
                    Other portable electronics
                    </MenuItem>
                    <MenuItem value="Sporting and Recreational Goods">
                    Sporting and Recreational Goods
                    </MenuItem>
                    <MenuItem value="Photo, video and binocular equipment">
                    Photo, video and binocular equipment
                    </MenuItem>
                    <MenuItem value="Wheelchairs,Mobility Scooters and Golf Carts">Wheelchairs,Mobility Scooters and Golf Carts</MenuItem>
                    <MenuItem value="Medical aids, glasses and hearing aids">
                    Medical aids, glasses and hearing aids
                    </MenuItem>
                    <MenuItem value="Bicycles">
                    Bicycles
                    </MenuItem>
                    <MenuItem value="Musical Equipment">
                    Musical Equipment
                    </MenuItem>
                    <MenuItem value="Prams and Strollers">Prams and Strollers</MenuItem>
                    <MenuItem value="other">other</MenuItem>
                  </Select>
                  {/* {Tab5_Validation_Land_Var[index].category !== null &&
                    Tab5_Validation_Land_Var[index].category !== "true" && (
                      <div className="text-danger font-italic">
                        {Tab5_Validation_Land_Var[index].category}
                      </div>
                    )} */}
                </Grid>

                <Grid item xs={4}>
                  <InputLabel
                    htmlFor="Description"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    Description
                  </InputLabel>
                </Grid>

                <Grid item xs={8} style={{ marginBottom: "20px" }}>
                  <TextField
                    name="description"
                    value={modi.description}
                    onChange={onChangeField(index)}
                    size="small"
                    variant="outlined"
                    autoComplete="off"
                    onKeyPress={(e) => validationForSpecialchar(e)}
                    // style={{ marginBottom: "20px" }}
                    required
                    fullWidth
                  />
                  {/* {Tab5_Validation_Land_Var[index].description !== null &&
                    Tab5_Validation_Land_Var[index].description !== "true" && (
                      <div className="text-danger font-italic">
                        {Tab5_Validation_Land_Var[index].description}
                      </div>
                    )} */}
                </Grid>

                <Grid item xs={4}>
                  <InputLabel
                    htmlFor="Value"
                    style={{ marginBottom: "5px" }}
                    required
                  >
                    Value
                  </InputLabel>
                </Grid>

                <Grid item xs={8} style={{ marginBottom: "20px" }}>
                  <TextField
                    name="value"
                    value={modi.value}
                    onChange={onChangeField(index)}
                    size="small"
                    type="tel"
                    maxLength="8"
                    inputProps={{ maxLength: 8 }}
                    variant="outlined"
                    autoComplete="off"
                    // style={{ margingTop:"40px", height: "40px" }}
                    onKeyPress={(e) => validationForNumbOnly(e)}
                    required
                    fullWidth
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">$</InputAdornment>
                      ),
                    }}
                  />
                  {/* {Tab5_Validation_Land_Var[index].value !== null &&
                    Tab5_Validation_Land_Var[index].value !== "true" && (
                      <div className="text-danger font-italic">
                        {Tab5_Validation_Land_Var[index].value}
                      </div>
                    )} */}
                </Grid>
              </Grid>

              <div>
                <Button
                  style={{ float: "right", width: "10%", marginBottom: "30px" }}
                  onClick={() => deletecontent(index)}
                  // className="bg-warning"
                  variant="contained"
                  color="secondary"
                >
                  DELETE
                </Button>

                <br />
                <hr
                  style={{
                    color: "red",
                    backgroundColor: "green",
                    height: 1,
                    marginTop: "50px",
                  }}
                />
              </div>
            </div>
          );
        })}
        <Grid
          direction="row"
          container
          justifyContent="center"
          alignItems="center"
        >
          <Grid item xs={12} style={{ marginTop: "20px" }}>
            <div className="alert alert-info">
              Add More Content by Pressing 'ADD MORE' button
            </div>
          </Grid>
          <Grid item xs={4}></Grid>
          <Grid
            item
            xs={4}
            container
            justifyContent="center"
            alignItems="center"
          >
            <Button
              fullWidth
              onClick={addMore}
              className="bg-success text-white"
            >
              ADD MORE
            </Button>
          </Grid>
          <Grid item xs={4}></Grid>
        </Grid>
      </div>

      <Grid>
            <Button
              variant="contained"
              color="secondary"
              style={{
                marginTop: "1rem",
                float: "left",
                width: "10%",
              }}
              onClick={() => navigation.next()}
            >
              EXIT
            </Button>
          </Grid>

      <Button
        variant="contained"
        color="primary"
        type="Submit"
        style={{
          marginTop: "1rem",
          float: "right",
          marginBottom: "50px",
          width: "10%",
        }}
        onClick={() => navigation.next()}
      >
        NEXT
      </Button>

      <Button
        variant="contained"
        color="primary"
        // className="bg-warning"
        style={{
          marginTop: "1rem",
          float: "right",
          marginBottom: "50px",
          marginRight: "20px",
          width: "10%",
        }}
        onClick={() => navigation.previous()}
      >
        PREVIOUS
      </Button>
      <ToastContainer style={{ marginLeft:"50px", marginBottom:"-25px", width:"30%"}}/>
    </Container>
  );
};

export default Tab5_Contents_Land;
