import history from "../auth/history";
import { confirmAlert } from "react-confirm-alert";
const returnClientHome = () => {
    history.push("/client");
  };

// onClick method: exit when clicking exit btn
export const exit = () => {
    confirmAlert({
      title: "Confirm to exit",
      message: "Are you going to exit without saving values?",
      buttons: [
        {
          label: "Yes",
          onClick: () => {
            returnClientHome();
          },
        },
        {
          label: "No",
          onClick: () => null,
        },
      ],
    });
  };