
import {streetTypes} from "./dropDownData"
export const digit_valid_check = {
    digit_valid_checker: /^[0-9]*$/,
}

export const char_valid_check = {

    char_valid_checker: /^([A-Za-z])([A-Za-z\s])+$/
}

export const email_valid_check = {
    email_valid_checker: /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i
}


//number validation for checking input
export const inpNum = (e) => {
    // console.log(e.target.value);
    e = e || window.event;
    var charCode = (typeof e.which == "undefined") ? e.keyCode : e.which;
    var charStr = String.fromCharCode(charCode);
    
    if (!charStr.match(/^[0-9]+$/))
        e.preventDefault();
}


//for +ve numbers
// export const inppNum = (e) => {
//     // console.log(e.target.value);
//     e = e || window.event;
//     var charCode = (typeof e.which == "undefined") ? e.keyCode : e.which;
//     var charStr = String.fromCharCode(charCode);
//     // if (e.which === 38 || e.which === 40) {
//     //     e.preventDefault();
//     // }
//     if (!charStr.match(/^[0-9]+$/))
//         e.preventDefault();
// }

//it allows only numerical , text and hypen value for unitnumber and street number
export const validationForSpecialchar =(e) =>{
    var regex = new RegExp("^[a-zA-Z0-9 ]+$"); 
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
    if (regex.test(str)) {
        return true;
    }
    e.preventDefault();
    return false;
}


export const validationForAlpha =(e) =>{
    var regex = new RegExp("^[a-zA-Z ]+$"); 
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
    if (regex.test(str)) {
        return true;
    }
    e.preventDefault();
    return false;
}
export const validationForNumbOnly =(e) =>{
    var regex = new RegExp("^[0-9]+$"); 
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
    // console.log(e);
    if (regex.test(str)) {
        return true;
    }
    e.preventDefault();
    return false;
}

//it allows only text,.'- and whitespace for firstname and lastname
export const inText =(e) =>{
    var regex = new RegExp("^[a-zA-Z ,.'-]+$"); 
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);

    if (regex.test(str)) {
        return true;
    }
    e.preventDefault();
    return false;
}

//it allows only text and whitespace for suburb,
//  street name and vehicle make
export const inpTextwithSpace =(e) =>{
    var regex = new RegExp("^[a-zA-Z ]+$"); 
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);

    if (regex.test(str)) {
        return true;
    }
    e.preventDefault();
    return false;
}


//it allows only text, number and whitespace for company name and trading as fields
export const inpTextwithNumSpe =(e) =>{
    var regex = new RegExp("^[a-zA-Z0-9 ,.'-]+$"); 
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);

    if (regex.test(str)) {
        return true;
    }
    e.preventDefault();
    return false;
}

//it allows only text , number and whitepsaces for vehicle model
export const inpTextwithNumWspe =(e) =>{
    var regex = new RegExp("^[a-zA-Z0-9 ]+$"); 
    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);

    if (regex.test(str)) {
        return true;
    }
    e.preventDefault();
    return false;
}




